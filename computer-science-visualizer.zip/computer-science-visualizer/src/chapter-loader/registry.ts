// chapter-loader/registry.ts
// Automatic chapter discovery + Topic-based restructure.
// - Loads real chapters via Vite glob
// - Merges with synthetic coming-soon chapters from topics/definitions
// - Guarantees chapterOrder resets per topic
// - Guarantees no global numbering

import type { ChapterMeta, TopicWithChapters } from './types'
import { TOPICS } from '../topics/definitions'

// Eagerly import every chapter's meta so the Home page is synchronous.
const modules = import.meta.glob('../content/topics/*/*/meta.ts', { eager: true }) as Record<
  string,
  { default: ChapterMeta }
>

function validate(meta: any, key: string): meta is ChapterMeta {
  const baseOk =
    !!meta &&
    typeof meta.id === 'string' &&
    typeof meta.slug === 'string' &&
    typeof meta.order === 'number' &&
    (meta.status === 'available' || meta.status === 'coming-soon')
  if (!baseOk) {
    console.error(`[chapter-loader] invalid base meta.ts at ${key}:`, meta)
    return false
  }
  if (meta.topicId && typeof meta.topicId !== 'string') {
    console.error(`[chapter-loader] invalid topicId at ${key}`)
    return false
  }
  if (meta.chapterOrder && typeof meta.chapterOrder !== 'number') {
    console.error(`[chapter-loader] invalid chapterOrder at ${key}`)
    return false
  }
  return true
}

// 1) Load real chapters
const realChapters: ChapterMeta[] = Object.entries(modules)
  .filter(([key, m]) => validate(m.default, key))
  .map(([, m]) => {
    const meta = m.default
    return {
      ...meta,
      chapterOrder: meta.chapterOrder ?? meta.order,
      order: meta.chapterOrder ?? meta.order,
      topicOrder: meta.topicOrder ?? 0,
    }
  })

// 3) Generate synthetic coming-soon chapters for every topic definition
const syntheticChapters: ChapterMeta[] = []

for (const topic of TOPICS) {
  for (const chDef of topic.chapters) {
    // Check if a real chapter already covers this topic+order or slug
    const alreadyExists = realChapters.some(
      (rc) =>
        rc.topicSlug === topic.slug &&
        (rc.chapterOrder === chDef.order || rc.slug === chDef.slug || rc.id === chDef.id)
    )
    if (alreadyExists) continue

    // Also check if legacy maps already cover exactly this definition
    // e.g., chapter-02 maps to resource-loading which is in topic 04 ch 02 — we already skipped
    // High quality JPG thumbnails, no text, only illustration (like chap 1-3 standard)
    const tNum = String(topic.order).padStart(2, '0')
    const cNum = String(chDef.order).padStart(2, '0')
    const thumbPath = `/thumbnails/topic-${tNum}--ch-${cNum}.jpg`
    const synth: ChapterMeta = {
      id: `${topic.slug}--${chDef.slug}`,
      slug: chDef.slug,
      order: chDef.order,
      chapterOrder: chDef.order,
      topicId: topic.id,
      topicSlug: topic.slug,
      topicOrder: topic.order,
      topicTitle: topic.title,
      status: 'coming-soon',
      title: chDef.title,
      subtitle: (chDef as any).subtitle || { en: '', vi: '' },
      accent: topic.accent,
      thumbnail: thumbPath,
    }
    syntheticChapters.push(synth)
  }
}

// 4) Merge all
export const chapters: ChapterMeta[] = [...realChapters, ...syntheticChapters].sort((a, b) => {
  if (a.topicOrder !== b.topicOrder) return a.topicOrder - b.topicOrder
  return a.chapterOrder - b.chapterOrder
})

// Validation: no duplicate chapterOrder within same topic
{
  const seen = new Map<string, Set<number>>()
  for (const c of chapters) {
    const key = c.topicSlug
    if (!seen.has(key)) seen.set(key, new Set())
    const s = seen.get(key)!
    if (s.has(c.chapterOrder)) {
      console.error(`[chapter-loader] duplicate chapterOrder ${c.chapterOrder} in topic ${key} — ${c.id}`)
    }
    s.add(c.chapterOrder)
  }
}

// Grouped by topic for Home
export const topicsWithChapters: TopicWithChapters[] = TOPICS.map((t) => {
  const chs = chapters.filter((c) => c.topicSlug === t.slug)
  return {
    id: t.id,
    slug: t.slug,
    order: t.order,
    title: t.title,
    subtitle: t.subtitle,
    accent: t.accent,
    centralQuestion: t.centralQuestion,
    chapters: chs,
  }
})

export function getChapter(idOrSlug: string): ChapterMeta | undefined {
  // Try exact id
  let found = chapters.find((c) => c.id === idOrSlug)
  if (found) return found
  // Try slug exact (chapter slug alone)
  found = chapters.find((c) => c.slug === idOrSlug)
  if (found) return found
  // Try composite topic/chapter
  if (idOrSlug.includes('/')) {
    const [tSlug, cSlug] = idOrSlug.split('/')
    found = chapters.find((c) => c.topicSlug === tSlug && c.slug === cSlug)
    if (found) return found
  }
  // Try topic--chapter synthetic id
  found = chapters.find((c) => c.id === idOrSlug || `${c.topicSlug}--${c.slug}` === idOrSlug)
  return found
}

export function getChapterByTopicAndSlug(topicSlug: string, chapterSlug: string): ChapterMeta | undefined {
  return chapters.find((c) => c.topicSlug === topicSlug && c.slug === chapterSlug)
}

export function isAvailable(id: string): boolean {
  return getChapter(id)?.status === 'available'
}

export function getTopics(): TopicWithChapters[] {
  return topicsWithChapters
}
