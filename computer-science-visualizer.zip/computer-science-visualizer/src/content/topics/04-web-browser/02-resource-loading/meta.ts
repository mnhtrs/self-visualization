// content/chapter-02-browser-loading/meta.ts — FROZEN thumbnail, question-based title

import type { ChapterMeta } from '../../../../chapter-loader/types'
import thumb from './assets/thumbnail.jpg'

const meta: ChapterMeta = {
  id: 'topic-04-web-browser--ch-02-resource-loading',
  slug: 'resource-loading',
  order: 2,
  chapterOrder: 2,
  topicId: 'topic-04-web-browser',
  topicSlug: 'web-browser',
  topicOrder: 4,
  topicTitle: { en: 'Web Browser', vi: 'Trình duyệt Web' },
  status: 'available',
  thumbnail: thumb,
  title: { en: 'How does a website reach my screen?', vi: 'Một trang web đến màn hình của bạn như thế nào?' },
  subtitle: { en: 'From navigation to bytes on screen.', vi: 'Từ điều hướng đến byte trên màn hình.' },
  accent: '#22d3ee',
  loadStory: () => import('./index').then((m) => m.chapter),
}
export default meta
