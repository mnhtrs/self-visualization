// content/topics/02-operating-systems/02-process-execution/renderers.ts
//
// Chapter renderer barrel. The painters live in renderers/world.ts:
//   storage-bay   — two program tiles + the data file (immutable artifacts)
//   os-band       — the granting mediator (CH01 grammar; labels earned)
//   machine-bay   — quiet physical context (CPU glint only while advancing)
//   process-field — Process A's interior anatomy (column, bands, dock,
//                   registers, gold point), Process B (held), grants, pills
//
// LAYOUT-SYSTEM DRIVEN: every coordinate is a named metric (scenes/metrics.ts)
// or derived in scenes/layout.ts (Layout Derivation Law). Every renderer is a
// pure function of (PresentationState, entity): all beat-driven content
// derives from s.beatIndex / s.beatElapsed (VISUAL_LANGUAGE §15).
//
// SCOPE LOCK (increment rule): nothing here draws Process States, context
// switches, pause/resume choreography, schedulers, queues, threads or
// virtual-memory internals. Process B's HELD point is a phenomenon only.

import { RENDERER_TABLE } from './renderers/world'

export const RENDERERS = RENDERER_TABLE
