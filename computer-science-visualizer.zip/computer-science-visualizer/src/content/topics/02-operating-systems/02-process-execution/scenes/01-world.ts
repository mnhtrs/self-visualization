// scenes/01-world.ts — the single stable world of Topic 02 Chapter 02:
// STORAGE (two program tiles + the data file, west) → OS band (middle) →
// EXECUTION FIELD (Process A looked INTO, Process B the generality proof,
// the quiet machine bay far east). One scene, zero relocations
// (VISUAL_LANGUAGE §6 Spatial Stability). Every anchor derives from
// scenes/layout.ts (Layout Derivation Law).

import * as L from './layout'
import * as M from './metrics'
import type { Vec2 } from '../../../../../chapter-loader/types'
import type { PartSpec } from '../types'

// ---- entities ----------------------------------------------------------------

/** The storage bay painter goes first in the west: bay + both tiles + file. */
export const storage: PartSpec = {
  id: 'storage',
  kind: 'storage-bay',
  pos: { x: M.PHOTOS_C.x, y: (M.PHOTOS_C.y + M.NOTES_C.y) / 2 },
  color: M.COL.program,
  name: 'Programs',
  gloss: {
    en: 'Stored applications — “Photos” (the one Chapter 1 launched) and “Notes”, plus a data file. Ordered lists of instructions, doing nothing on their own.',
    vi: 'Các ứng dụng được lưu — “Photos” (cái mà Chương 1 đã khởi chạy) và “Notes”, cùng một tệp dữ liệu. Những danh sách lệnh có thứ tự, tự chúng không làm gì cả.',
  },
}

export const os: PartSpec = {
  id: 'os',
  kind: 'os-band',
  pos: { ...M.OS_C },
  color: M.COL.os,
  name: 'OS',
  gloss: {
    en: 'The Operating System — the manager between stored programs and the machine. In this chapter you watch it GRANT: space, memory, access to outside things.',
    vi: 'Hệ điều hành — người quản lý giữa các chương trình được lưu và cỗ máy. Trong chương này bạn sẽ thấy nó CẤP: không gian, bộ nhớ, quyền truy cập những thứ bên ngoài.',
  },
}

/** The field painter draws BOTH Process cells, their interiors, the pills,
 *  the grant comets and the climax — all read from scenes/story.ts. */
export const field: PartSpec = {
  id: 'field',
  kind: 'process-field',
  pos: { ...M.A_C },
  color: M.COL.process,
  name: '',
  gloss: { en: '', vi: '' },
}

export const machine: PartSpec = {
  id: 'machine',
  kind: 'machine-bay',
  pos: { ...M.MACHINE_C },
  color: M.COL.machine,
  name: 'Machine',
  gloss: {
    en: 'The physical machine — CPU, memory, I/O devices. One machine: it advances one execution at a time.',
    vi: 'Cỗ máy vật lý — CPU, bộ nhớ, thiết bị I/O. Một cỗ máy: nó tiến từng việc thực thi một.',
  },
}

export const PATH_WORLD: Vec2[] = L.PATH_WORLD
export const BBOX_WORLD = L.bboxWorld()
export const PHOTOS_HIT_RECT = L.PHOTOS_HIT()
