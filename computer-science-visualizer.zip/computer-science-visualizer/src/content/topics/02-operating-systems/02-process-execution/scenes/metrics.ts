// scenes/metrics.ts — Topic 02 Chapter 02 (increment 1: Inside a Process)
// layout *primitives*: every bare number the geometry and the renderers use,
// named exactly once. PURE — no imports — so the derived layout system builds
// on it without cycles (VISUAL_LANGUAGE §2.2 Derivable Geometry).
//
// GEOMETRY AS PEDAGOGY (blueprint §3): the CH01 world axis is preserved
// (DEF-01): STORAGE (west, now with TWO stored programs and a data file)
// → OS band (middle, the granting mediator) → EXECUTION FIELD (east) with
// the quiet machine bay at the far edge (LOK-07: machine ≠ OS). What is NEW
// is the INTERIOR of the Process cell: a private memory column (code / data /
// heap / stack), a resource dock (handle chips) and the execution-point
// markers (gold row marker, register slots, stack-top tick) — all structure
// STRICTLY INSIDE the cell rect (the layout gate proves containment).
// CH01 pixel values are NOT inherited (they are CH01-specific per
// 01_INHERITED_AND_LOCKED_DECISIONS §4); the semantic axis is.

// ---- global spacing scale ----------------------------------------------------
export const BREATH = 8
export const CLIP_INSET = 16
export const LABEL_GAP = 12
export const LABEL_TEXT_H = 20

// ---- canvas font families (same single source as Topic 01/CH01) ---------------
export const FONT = "'Quicksand', system-ui, sans-serif"
export const MONO = "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace"

// ---- type scale (world px) — one named size per role -------------------------
// Entity hierarchy inherited (DEF-02): Process caption (15) > PID chip (14)
// > provenance (11).
export const F = {
  partName: 19,
  osTitle: 26,
  appName: 15,
  machineTitle: 16,
  machineRes: 14,
  cellCaption: 15,
  sourceCue: 11,
  chipText: 14,
  bandLabel: 12,
  handleText: 12,
  regGlyph: 16,
  termPill: 21,
  tag: 12,
  sub: 14,
  small: 13,
  micro: 11,
  mark: 24,
}

// ---- palette (cross-domain consistency §10) -----------------------------------
export const COL = {
  machine: '#fb923c', // T01 CPU identity
  ram: '#a78bfa', // T01 RAM identity (machine bay only — NEVER the column)
  io: '#94a3b8',
  program: '#22d3ee', // storage / Program cyan (T01)
  os: '#f472b6', // Topic-02 accent
  process: '#4ade80', // Process life green (CH01)
  gold: '#fbbf24', // the execution point (T01 golden-instruction continuity)
  chipText: '#e2e8f0',
  dim: 'rgba(170,180,208,0.72)',
  panel: 'rgba(10,14,32,0.92)',
}
/** The T01 value glyphs (◆ ▲ ■ ●) — data values, already named in T01. */
export const GLYPHS = ['◆', '▲', '■', '●'] as const
export const GLYPH_COLS = ['#22d3ee', '#fbbf24', '#f472b6', '#4ade80'] as const

// ==============================================================================
// REGION 1 — STORAGE (west): TWO stored programs + one data file.
// Two tiles prove "programs" is a class, not one exemplar; the data file
// (photo.jpg) exists so the Resources beats have a real, never-moving target.
// ==============================================================================
export const AXIS_Y = 400
export const PROGRAM_TILE = { w: 144, h: 150, r: 16 }
export const APP_ICON = { size: 60, r: 14 }
export const APP_NAME_GAP = 20
export const PHOTOS_C = { x: 225, y: 285 } // the CH01 program — same identity
export const NOTES_C = { x: 225, y: 552 } // a DIFFERENT program (generality)
export const FILE_C = { x: 225, y: 425 } // a data file on the same storage
export const FILE_GLYPH = { w: 34, h: 42, fold: 10 }
export const BAY = { padX: 42, padTop: 60, padBot: 46, r: 14 } // recessed bay

// ==============================================================================
// REGION 2 — THE OS (middle): CH01 grammar unchanged. The three function-row
// labels (create / identify / manage) are shown from beat 0 — they were
// EARNED in CH01 (no unlearning; no re-teach).
// ==============================================================================
export const OS_C = { x: 520, y: AXIS_Y }
export const OS_BAND = { w: 220, h: 232, r: 6 }
export const OS_TITLE = { dy: 34 }
export const OS_SUB = { dy: 58 }
export const OS_CORE = { inset: 18, top: 70, h: 112, r: 12 }
export const OS_ROW = { h: 26, gap: 12, padX: 12, r: 6 }
export const OS_PORT = { w: 12, h: 44, r: 4 }

// ==============================================================================
// REGION 3 — THE EXECUTION FIELD (east): Process A (the focus cell, looked
// INTO), Process B (the generality proof), the quiet machine bay.
// ==============================================================================

/** Process A — the focus cell. Large because its INTERIOR is the chapter. */
export const A_C = { x: 955, y: 405 }
export const CELL_A = { w: 430, h: 470, r: 18 }
/** Header (de-windowed: spacing + weight only, no divider): caption left,
 *  provenance under it, PID chip right — all inside the cell. */
export const HEAD_A = { capX: 24, capY: 20, srcY: 42, srcIcon: 13, srcGap: 5 }
export const CHIP = { w: 96, h: 24, r: 12, dx: 16, dy: 14 } // from cell top-right

/** The private memory column (INSIDE the cell; never touches the machine). */
export const COL_A = { dx: 22, dy: 82, w: 200, padBot: 26, inner: 6 }
/** The four bands (top-down). Heap HEIGHT is a story fact (it grows). */
export const BAND = { codeH: 140, dataH: 52, stackH: 60, gap: 4 }
export const HEAP_H = { base: 36, grown: 68, max: 80 }
export const CODE_ROWS = 10
export const CODE_ROW_PAD = 6
/** Sub-task rows (indented) — the stack beat steps into these. */
export const SUB_ROWS: [number, number] = [6, 8]

/** Resource dock (right side of cell A): handle chips. */
export const DOCK_A = { dx: 264, y0: 112, chipW: 150, chipH: 30, gap: 10, r: 8 }
/** Register strip (right-lower): three slots with T01 value glyphs. */
export const REG_A = { dx: 264, dy: 214, slot: 44, gap: 10, n: 3, r: 8 }

/** Process B — the generality proof: same anatomy, compact scale. Offset
 *  from A on BOTH axes (anti-queue: never a row/pipeline with A). */
export const B_C = { x: 1370, y: 555 }
export const CELL_B = { w: 320, h: 310, r: 16 }
export const HEAD_B = { capX: 18, capY: 18, srcY: 38, srcIcon: 11, srcGap: 4 }
export const CHIP_B = { w: 88, h: 22, r: 11, dx: 12, dy: 12 }
export const COL_B = { dx: 18, dy: 60, w: 128, padBot: 18, inner: 4 }
export const BAND_B = { codeH: 92, dataH: 34, heapH: 24, stackH: 44, gap: 3 }
export const CODE_ROWS_B = 6
export const DOCK_B = { dx: 184, y0: 74, chipW: 118, chipH: 26, gap: 10, r: 7 }
export const REG_B = { dx: 184, dy: 152, slot: 36, gap: 8, n: 2, r: 7 }

/** The machine bay (far east, LOK-07) — CH01 grammar: CPU · RAM · I/O.
 *  Its CPU slot carries a soft glint ONLY while an execution point is
 *  advancing (truthful ambient); memory grants never light it. */
export const MACHINE_C = { x: 1495, y: 230 }
export const MACHINE = { w: 140, h: 196, r: 8 }
export const MACHINE_SLOT = { w: 112, h: 36, gap: 12, topPad: 50 }

// ---- term pills / rings / animation feel --------------------------------------
export const TERM = { h: 44, r: 22, padX: 22 }
/** Concept band ABOVE cell A (Address Space, Resources — class concepts). */
export const PILL_CONCEPT_C = { x: 955, y: 112 }
/** Execution Context pill BELOW cell A (its subject is inside that cell). */
export const PILL_EC_C = { x: 955, y: 682 }
export const RING = { pad: 10, w: 2.5 }
export const PULSE = { birthR: 84, ring: 3 }
export const SPARK_NEAR = 130
export const STACK_TICK = { w: 10, h: 8 }
