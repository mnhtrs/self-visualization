// scenes/story.ts — the single source of truth for every beat-driven fact of
// Topic 02 Chapter 02 (increment 1: Inside a Process — Memory, Resources &
// Execution Context): the beat map, the grant schedules (space, heap, file,
// display), the code-copy stream, the execution-point schedule for Process A,
// the HELD point of Process B, the stack depth, the heap height, the band-
// label / term-pill reveal windows and the silent-climax schedule. Everything
// is a pure function of (beatIndex, beatFraction) — scrubbing, pausing and
// stepping backwards stay deterministic (VISUAL_LANGUAGE §15; LOK-08).
//
// Quantity discipline (PEDAGOGICAL_SYSTEM §4.5): every number the narration
// speaks — the PIDs 4488 / 4517 — derives from the tables below.
//
// SCOPE LOCK (Guardian T02 §5 CH02 non-goals + increment rule): nothing here
// models Process States, context switching, pausing/resuming as mechanism,
// scheduling, queues, threads, or virtual-memory internals. Process B's
// execution point being HELD is shown as a phenomenon only — the bridge
// question, never the later story.

import { HEAP_H } from './metrics'

// =============================================================================
// Beat index map
// =============================================================================
export const B = {
  question: 0, // cognitive replay of the CH01 exit + the central question
  relaunch: 1, // a known operation, watched once more — to look INSIDE
  emptyShell: 2, // named, bounded — and visibly empty; instructions far away
  space: 3, // first grant: a private space of its own
  code: 4, // instructions copied in; the Program unchanged (coexistence)
  firstRun: 5, // the gold point steps; produced values are KEPT (data)
  heap: 6, // mid-run room, granted on request — the space GROWS
  stack: 7, // sub-task entered and returned from — the way back is kept
  addressSpace: 8, // the four bands ringed as ONE granted space → the term
  file: 9, // outside thing #1: the file stays; a handle docks
  resources: 10, // outside thing #2 (display) → the term Resources
  exactPoint: 11, // everything quiets; the point alone — execution IS somewhere
  snapshot: 12, // the point's companions: registers + stack top, ringed as one
  execContext: 13, // the term Execution Context (PC / Stack Pointer named)
  anotherProgram: 14, // a DIFFERENT program → same anatomy (generality)
  oneMachine: 15, // one machine: A's point advances, B's point stands HELD
  climax: 16, // SILENT — the whole model operating at once
  bridge: 17, // quiet integration + the permitted open loop
} as const

/** Beat durations (ms) — narration/beats.ts reads these; never typed twice. */
export const DURATIONS: number[] = [
  7000, // question
  8000, // relaunch
  7000, // emptyShell
  7000, // space
  8000, // code
  8000, // firstRun
  8000, // heap
  8000, // stack
  7000, // addressSpace
  7500, // file
  7500, // resources
  7000, // exactPoint
  7500, // snapshot
  7500, // execContext
  9000, // anotherProgram
  8000, // oneMachine
  16000, // climax (silent)
  10000, // bridge
]

// =============================================================================
// Identities (single source; narration derives from here)
// =============================================================================
export const PID_A = 4488
export const PID_B = 4517

// =============================================================================
// (beat, frac) windows + helpers
// =============================================================================
export interface Win { beat: number; frac: number }

export const cmp = (beat: number, frac: number, w: Win): number =>
  beat !== w.beat ? beat - w.beat : frac - w.frac
export const after = (beat: number, frac: number, w: Win): boolean =>
  cmp(beat, frac, w) >= 0

export const ramp01 = (x: number, a: number, b: number): number =>
  Math.min(1, Math.max(0, (x - a) / (b - a)))

/** 0→1→0 hump over [from,to] of the beat fraction. */
export const hump = (frac: number, from: number, to: number): number => {
  if (frac <= from || frac >= to) return 0
  return Math.sin(((frac - from) / (to - from)) * Math.PI)
}

// =============================================================================
// Process A lifecycle (B01) — CH01 birth grammar reused
// =============================================================================
export const A_BIRTH = { birth: 0.5, alive: 0.8, chip: 0.84, chipDock: 0.95 } // fracs of B.relaunch

// =============================================================================
// The GRANT sequences — the chapter's one new causal grammar:
// need cue → request comet (cell → OS intake) → manage row lights →
// grant arc (OS creation port → cell) → the granted structure grows.
// All windows are fracs WITHIN their own beat.
// =============================================================================
export interface Grant {
  beat: number
  need: [number, number] // the local need cue at the cell
  req: [number, number] // request comet cell → OS
  row: [number, number] // OS manage row lights
  grant: [number, number] // grant arc OS → cell
  grow: [number, number] // the structure materializes / grows
}

export const GRANT_SPACE: Grant = {
  beat: B.space,
  need: [0.04, 0.16], req: [0.12, 0.3], row: [0.28, 0.5], grant: [0.46, 0.64], grow: [0.6, 0.9],
}
export const GRANT_HEAP: Grant = {
  beat: B.heap,
  need: [0.06, 0.2], req: [0.16, 0.34], row: [0.32, 0.52], grant: [0.48, 0.64], grow: [0.6, 0.85],
}
export const GRANT_FILE: Grant = {
  beat: B.file,
  need: [0.06, 0.22], req: [0.2, 0.38], row: [0.36, 0.54], grant: [0.5, 0.66], grow: [0.64, 0.84],
}
export const GRANT_DISPLAY: Grant = {
  beat: B.resources,
  need: [0.04, 0.16], req: [0.12, 0.28], row: [0.26, 0.44], grant: [0.4, 0.54], grow: [0.52, 0.7],
}
/** Climax heap grant (auxiliary, decayed weight §18). */
export const GRANT_CLIMAX: Grant = {
  beat: B.climax,
  need: [0.1, 0.16], req: [0.14, 0.22], row: [0.2, 0.28], grant: [0.26, 0.34], grow: [0.32, 0.46],
}
export const GRANTS: Grant[] = [GRANT_SPACE, GRANT_HEAP, GRANT_FILE, GRANT_DISPLAY, GRANT_CLIMAX]

/** B09: the file itself STAYS on storage — pulses before (the need points
 *  west) and after (still there, untouched) the handle docks. */
export const FILE_PULSE = { before: [0.06, 0.24] as const, still: [0.8, 0.96] as const }
/** B10: the display is reached through the machine's I/O — one restrained
 *  acknowledgment pulse on the I/O slot (context, never explained). */
export const IO_ACK = { from: 0.5, to: 0.72 }

// =============================================================================
// The code-copy stream (B04): three staggered comets Program → OS → code
// band, while the Program pulses UNCHANGED (CH01 coexistence grammar).
// =============================================================================
export const COPY_COMETS: [number, number][] = [
  [0.12, 0.42],
  [0.28, 0.58],
  [0.44, 0.74],
]
export const PROGRAM_UNCHANGED_PULSE = { from: 0.38, to: 0.74 }
/** Code rows condense in as the comets land. */
export const CODE_FILL = { from: 0.3, to: 0.85 }

// =============================================================================
// Band-label reveals (Knowledge Reveal Law — AFTER each behaviour observed)
// =============================================================================
export const LABEL_CODE: Win = { beat: B.code, frac: 0.8 }
export const LABEL_DATA: Win = { beat: B.firstRun, frac: 0.8 }
export const LABEL_HEAP: Win = { beat: B.heap, frac: 0.86 }
export const LABEL_STACK: Win = { beat: B.stack, frac: 0.86 }
/** "registers" is Topic-01 vocabulary — the strip may carry it from firstRun. */
export const LABEL_REGS: Win = { beat: B.firstRun, frac: 0.4 }

// =============================================================================
// Term pills (windows are fracs of their own beat; each fades early in the
// following beat)
// =============================================================================
export const PILL_AS = { beat: B.addressSpace, from: 0.45, to: 0.65 }
export const PILL_RES = { beat: B.resources, from: 0.74, to: 0.9 }
export const PILL_EC = { beat: B.execContext, from: 0.25, to: 0.45 }

/** The Address-Space ring (B08): closes around the whole column BEFORE the
 *  term lands. Stays through the pill, releases as the beat ends. */
export const AS_RING = { from: 0.1, to: 0.4 }
/** The snapshot ring (B12): three small rings (point, registers, stack top)
 *  then one enclosing ring — the three ARE one state. */
export const SNAP_SMALL = { from: 0.15, to: 0.4 }
export const SNAP_BIG = { from: 0.45, to: 0.75 }
/** B13: micro-labels — position=Program Counter, top=Stack Pointer. */
export const EC_LABELS = { from: 0.5, to: 0.72 }

// =============================================================================
// The execution point of Process A — THE gold marker (T01 continuity).
// Row position is a pure per-beat function; the smoke gate asserts that at
// most ONE marker chapter-wide is ever advancing (T01 canon C-05: one CPU,
// one advancing point).
// =============================================================================
export const MAIN_ROWS = 6 // rows 0..5 = the main flow (loops — programs loop)
export const SUB_FROM = 6 // rows 6..8 = the sub-task (drawn indented)
export const SUB_TO = 8
export const CALL_ROW = 4 // the call happens here; returns to the next row

export interface MarkerState {
  /** Fractional row in the code band; null = no point yet. */
  row: number | null
  /** Is the point ADVANCING at this instant? (drives the machine glint) */
  advancing: boolean
}

/** B07 stack choreography (fracs of B.stack). */
export const STACK_CALL = { jump: 0.2, subRun: [0.26, 0.56] as const, hold: 0.62, ret: 0.68 }
export const STACK_PUSH = { from: 0.16, to: 0.3 }
export const STACK_POP = { from: 0.64, to: 0.78 }

/** Climax sub-task excursion (fracs of B.climax). */
export const CLIMAX_CALL = { jump: 0.52, subRun: [0.55, 0.66] as const, ret: 0.7 }
export const CLIMAX_PUSH = { from: 0.5, to: 0.56 }
export const CLIMAX_POP = { from: 0.68, to: 0.74 }
/** Climax file-handle use blink (dashed logical link to the file). */
export const CLIMAX_FILE_USE = { from: 0.78, to: 0.9 }

export function markerA(beat: number, frac: number): MarkerState {
  const lin = (a: number, b: number, f0: number, f1: number) =>
    a + (b - a) * ramp01(frac, f0, f1)
  switch (beat) {
    case B.firstRun:
      if (frac < 0.15) return { row: 0, advancing: frac > 0.08 }
      return { row: lin(0, 3, 0.15, 0.75), advancing: frac < 0.78 }
    case B.heap:
      return { row: lin(3, 4, 0.25, 0.9), advancing: frac > 0.22 && frac < 0.92 }
    case B.stack: {
      if (frac < STACK_CALL.jump) return { row: CALL_ROW, advancing: false }
      if (frac < STACK_CALL.subRun[0]) return { row: SUB_FROM, advancing: true }
      if (frac < STACK_CALL.subRun[1])
        return { row: lin(SUB_FROM, SUB_TO, STACK_CALL.subRun[0], STACK_CALL.subRun[1]), advancing: true }
      if (frac < STACK_CALL.ret) return { row: SUB_TO, advancing: false }
      return { row: CALL_ROW + 1, advancing: frac < STACK_CALL.ret + 0.06 }
    }
    case B.addressSpace:
    case B.file:
    case B.resources:
      return { row: CALL_ROW + 1, advancing: false }
    case B.exactPoint:
      return { row: lin(5, 5.9, 0.2, 0.8), advancing: frac > 0.18 && frac < 0.82 }
    case B.snapshot:
    case B.execContext:
    case B.anotherProgram:
      return { row: 5.9, advancing: false } // a snapshot is an instant — held still
    case B.oneMachine: {
      // A's point advances again — and wraps to the loop start (programs loop)
      const r = (5.9 + 2.2 * ramp01(frac, 0.15, 0.85)) % MAIN_ROWS
      return { row: r, advancing: frac > 0.15 && frac < 0.85 }
    }
    case B.climax: {
      if (frac >= CLIMAX_CALL.jump && frac < CLIMAX_CALL.ret) {
        const r =
          frac < CLIMAX_CALL.subRun[0]
            ? SUB_FROM
            : frac < CLIMAX_CALL.subRun[1]
              ? SUB_FROM + (SUB_TO - SUB_FROM) * ramp01(frac, CLIMAX_CALL.subRun[0], CLIMAX_CALL.subRun[1])
              : SUB_TO
        return { row: r, advancing: true }
      }
      const base = frac < CLIMAX_CALL.jump ? frac : frac - (CLIMAX_CALL.ret - CLIMAX_CALL.jump)
      return { row: (2 + base * 7) % MAIN_ROWS, advancing: true }
    }
    case B.bridge:
      return { row: (1 + frac * 3) % MAIN_ROWS, advancing: true }
    default:
      return { row: null, advancing: false }
  }
}

// =============================================================================
// Process B (Notes → PID 4517) — formation schedule inside B14, then HELD.
// Its point NEVER advances (asserted by the smoke gate).
// =============================================================================
export const B_FORM = {
  birth: 0.5, // birth bloom starts (fracs of B.anotherProgram)
  alive: 0.66,
  column: [0.66, 0.78] as const, // its own space materializes
  codeFill: [0.72, 0.84] as const, // its own code condenses
  handle: [0.82, 0.9] as const, // its own handle docks
  marker: [0.88, 0.94] as const, // its own execution point resolves — and HOLDS
  chip: [0.9, 0.97] as const, // PID 4517
}
export const B_HELD_ROW = 1 // where B's point stands, from dock on, forever

/** B15: the held-point emphasis — B's point is ringed once, visibly NOT
 *  advancing, while A's point moves (one machine, one advancing point). */
export const HELD_ACK = { from: 0.42, to: 0.68 }

// =============================================================================
// Heap height + stack depth + data tokens (story facts the renderer reads)
// =============================================================================
export function heapHAt(beat: number, frac: number): number {
  if (beat < B.space || (beat === B.space && frac < GRANT_SPACE.grow[0])) return HEAP_H.base
  if (beat < B.heap) return HEAP_H.base
  if (beat === B.heap)
    return HEAP_H.base + (HEAP_H.grown - HEAP_H.base) * ramp01(frac, GRANT_HEAP.grow[0], GRANT_HEAP.grow[1])
  if (beat === B.climax)
    return HEAP_H.grown + (HEAP_H.max - HEAP_H.grown) * ramp01(frac, GRANT_CLIMAX.grow[0], GRANT_CLIMAX.grow[1])
  if (beat > B.climax) return HEAP_H.max
  return HEAP_H.grown
}

/** Stack depth (frames) of A: 1 base frame from the first run; +1 during the
 *  sub-task; climax repeats the push/pop. Affirmative derivation (§4.6). */
export function stackDepthA(beat: number, frac: number): number {
  const base = after(beat, frac, { beat: B.firstRun, frac: 0.2 }) ? 1 : 0
  if (beat === B.stack) {
    if (frac >= STACK_PUSH.from && frac < STACK_POP.to) {
      const inK = ramp01(frac, STACK_PUSH.from, STACK_PUSH.to)
      const outK = 1 - ramp01(frac, STACK_POP.from, STACK_POP.to)
      return base + Math.min(inK, outK)
    }
    return base
  }
  if (beat === B.climax) {
    if (frac >= CLIMAX_PUSH.from && frac < CLIMAX_POP.to) {
      const inK = ramp01(frac, CLIMAX_PUSH.from, CLIMAX_PUSH.to)
      const outK = 1 - ramp01(frac, CLIMAX_POP.from, CLIMAX_POP.to)
      return base + Math.min(inK, outK)
    }
  }
  return base
}

/** Data tokens (T01 value glyphs) settled in A's data band. */
export const DATA_TOKENS: Win[] = [
  { beat: B.firstRun, frac: 0.3 },
  { beat: B.firstRun, frac: 0.5 },
  { beat: B.firstRun, frac: 0.7 },
  { beat: B.climax, frac: 0.42 },
]
export function dataCountA(beat: number, frac: number): number {
  let n = 0
  for (const w of DATA_TOKENS) if (after(beat, frac, w)) n++
  return n
}

// =============================================================================
// Handles (single source: id, dock slot, target, dock window)
// =============================================================================
export interface HandleSpec {
  id: 'file' | 'display'
  slot: number
  dockAt: Win
  label: { en: string; vi: string }
}
export const HANDLES_A: HandleSpec[] = [
  { id: 'file', slot: 0, dockAt: { beat: B.file, frac: GRANT_FILE.grow[1] }, label: { en: 'photo.jpg', vi: 'photo.jpg' } },
  { id: 'display', slot: 1, dockAt: { beat: B.resources, frac: GRANT_DISPLAY.grow[1] }, label: { en: 'display', vi: 'màn hình' } },
]

// =============================================================================
// B02 (empty shell) choreography: the interior scanned and found empty;
// the eye sent WEST to where the instructions still live.
// =============================================================================
export const EMPTY_SCAN = { from: 0.15, to: 0.45 }
export const EMPTY_LOOK_WEST = { from: 0.55, to: 0.85 }

/** B11 (the exact point): the world quiets — every region except the code
 *  band + marker drops to low salience. */
export const QUIET = { from: 0.08, to: 0.25 } // dim eases in over this window

// =============================================================================
// Protagonist travels / rests (path anchors: 0=Photos · 1=OS · 2=cell A ·
// 3=Notes · 4=OS · 5=cell B)
// =============================================================================
export interface TravelSpec { from: number; to: number; holdFrom?: number }

export const TRAVELS: Record<number, TravelSpec> = {
  [B.relaunch]: { from: 0, to: 2, holdFrom: 0.5 }, // Photos → OS → A (birth watched)
  // The attention signal STEPS ASIDE to the watch-point while the interior
  // becomes the subject — continuous motion, no teleport (§5 continuity).
  [B.emptyShell]: { from: 2, to: 3, holdFrom: 0.22 },
  [B.anotherProgram]: { from: 3, to: 6, holdFrom: 0.55 }, // watch → Notes → OS → B
  [B.oneMachine]: { from: 6, to: 7, holdFrom: 0.35 }, // B → the one machine
}

export const RESTS: Record<number, number> = {
  [B.question]: 0, // at Photos — the CH01 exit state
  // Interior beats: the protagonist parks at the WATCH-POINT beside cell A
  // (anchor 3) — never on the interior, so the gold execution marker is the
  // ONLY gold point that reads as "the execution" (§18 protagonist priority).
  [B.space]: 3,
  [B.code]: 3,
  [B.firstRun]: 3,
  [B.heap]: 3,
  [B.stack]: 3,
  [B.addressSpace]: 3,
  [B.file]: 3,
  [B.resources]: 3,
  [B.exactPoint]: 3,
  [B.snapshot]: 3,
  [B.execContext]: 3,
  [B.climax]: 5, // at the OS — the holder of everything (loop)
  [B.bridge]: 5,
}

// =============================================================================
// Captions (bilingual, plain language) — single source for canvas text
// =============================================================================
export const CAP = {
  appPhotos: { en: 'Photos', vi: 'Photos' },
  appNotes: { en: 'Notes', vi: 'Notes' },
  fileName: { en: 'photo.jpg', vi: 'photo.jpg' },
  shelf: { en: 'storage', vi: 'bộ lưu trữ' },
  orient: { en: 'execution space', vi: 'không gian thực thi' },
  cellCaption: { en: 'Process', vi: 'Process' },
  chipPrefix: 'PID',
  osLetters: 'OS',
  osSubtitle: { en: 'Operating System', vi: 'Hệ điều hành' },
  /** OS function rows — labels were EARNED in CH01; shown from beat 0. */
  osRows: [
    { en: 'create', vi: 'tạo' },
    { en: 'identify', vi: 'định danh' },
    { en: 'manage', vi: 'quản lý' },
  ],
  machineTitle: { en: 'the machine', vi: 'cỗ máy' },
  machineRes: ['CPU', 'RAM', 'I/O'],
  /** Band labels — locked English terms, revealed after observation. */
  bands: [
    { en: 'code', vi: 'code' },
    { en: 'data', vi: 'data' },
    { en: 'heap', vi: 'heap' },
    { en: 'stack', vi: 'stack' },
  ],
  registers: { en: 'registers', vi: 'thanh ghi' },
  stackTop: { en: 'top', vi: 'đỉnh' },
  /** B13 micro-labels — the exact names of the point's parts. */
  ecPos: { en: 'position — Program Counter', vi: 'vị trí — Program Counter' },
  ecTop: { en: 'stack top — Stack Pointer', vi: 'đỉnh stack — Stack Pointer' },
}

export const AS_TERM = {
  term: 'Address Space',
  sub: {
    en: "the Process's own private memory space, granted and tracked by the OS",
    vi: 'không gian bộ nhớ riêng của Process, được OS cấp và theo dõi',
  },
}
export const RES_TERM = {
  term: 'Resources',
  sub: {
    en: 'outside things the Process may use — granted through the OS, recorded as handles',
    vi: 'những thứ bên ngoài mà Process được dùng — OS cấp quyền, ghi lại bằng handle',
  },
}
export const EC_TERM = {
  term: 'Execution Context',
  sub: {
    en: 'the exact point its execution stands: position, register values, stack top',
    vi: 'điểm chính xác mà việc thực thi đang đứng: vị trí, giá trị thanh ghi, đỉnh stack',
  },
}
