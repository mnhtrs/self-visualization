// scenes/layout.ts — the derived layout system for Topic 02 Chapter 02.
// Every rectangle and anchor the renderers draw derives HERE from named
// metrics + container functions — no inline literal coordinates (Layout
// Derivation Law; VISUAL_LANGUAGE §2.2).
//
// Imports metrics (pure) + nothing else; nothing imports this file back.

import * as M from './metrics'
import type { Vec2 } from '../../../../../chapter-loader/types'

export interface Rect { x: number; y: number; w: number; h: number; r: number }

const rectAt = (c: { x: number; y: number }, d: { w: number; h: number; r: number }): Rect => ({
  x: c.x - d.w / 2, y: c.y - d.h / 2, w: d.w, h: d.h, r: d.r,
})

// =============================================================================
// REGION 1 — storage: two program tiles + the data file, on one recessed bay
// =============================================================================
export const photosRect = (): Rect => rectAt(M.PHOTOS_C, M.PROGRAM_TILE)
export const notesRect = (): Rect => rectAt(M.NOTES_C, M.PROGRAM_TILE)

/** The recessed storage bay containing both tiles + the file. */
export const bayRect = (): Rect => {
  const p = photosRect()
  const n = notesRect()
  return {
    x: Math.min(p.x, n.x) - M.BAY.padX,
    y: p.y - M.BAY.padTop,
    w: Math.max(p.w, n.w) + 2 * M.BAY.padX,
    h: n.y + n.h + M.BAY.padBot - (p.y - M.BAY.padTop),
    r: M.BAY.r,
  }
}

export const appIconRect = (tile: Rect): Rect => ({
  x: tile.x + (tile.w - M.APP_ICON.size) / 2,
  y: tile.y + 20,
  w: M.APP_ICON.size,
  h: M.APP_ICON.size,
  r: M.APP_ICON.r,
})
export const appNamePos = (tile: Rect): Vec2 => {
  const icon = appIconRect(tile)
  return { x: tile.x + tile.w / 2, y: icon.y + icon.h + M.APP_NAME_GAP }
}

/** The data file (photo.jpg) — a small document glyph between the tiles. */
export const fileC = (): Vec2 => ({ ...M.FILE_C })

// =============================================================================
// REGION 2 — the OS (CH01 grammar, derived identically)
// =============================================================================
export const osRect = (): Rect => rectAt(M.OS_C, M.OS_BAND)
export const osCoreRect = (): Rect => {
  const r = osRect()
  return { x: r.x + M.OS_CORE.inset, y: r.y + M.OS_CORE.top, w: r.w - 2 * M.OS_CORE.inset, h: M.OS_CORE.h, r: M.OS_CORE.r }
}
export const osRowRect = (i: number): Rect => {
  const c = osCoreRect()
  const innerH = 3 * M.OS_ROW.h + 2 * M.OS_ROW.gap
  const top = c.y + (c.h - innerH) / 2
  return { x: c.x + M.OS_ROW.padX, y: top + i * (M.OS_ROW.h + M.OS_ROW.gap), w: c.w - 2 * M.OS_ROW.padX, h: M.OS_ROW.h, r: M.OS_ROW.r }
}
export const osWestPort = (): Vec2 => ({ x: osRect().x, y: M.OS_C.y })
export const osEastPort = (): Vec2 => { const r = osRect(); return { x: r.x + r.w, y: M.OS_C.y } }
export const osWestPortRect = (): Rect => { const p = osWestPort(); return { x: p.x - M.OS_PORT.w / 2, y: p.y - M.OS_PORT.h / 2, w: M.OS_PORT.w, h: M.OS_PORT.h, r: M.OS_PORT.r } }
export const osEastPortRect = (): Rect => { const p = osEastPort(); return { x: p.x - M.OS_PORT.w / 2, y: p.y - M.OS_PORT.h / 2, w: M.OS_PORT.w, h: M.OS_PORT.h, r: M.OS_PORT.r } }

// =============================================================================
// REGION 3 — Process A: the focus cell and its interior anatomy
// =============================================================================
export const cellA = (): Rect => rectAt(M.A_C, M.CELL_A)

export const chipA = (): Rect => {
  const c = cellA()
  return { x: c.x + c.w - M.CHIP.w - M.CHIP.dx, y: c.y + M.CHIP.dy, w: M.CHIP.w, h: M.CHIP.h, r: M.CHIP.r }
}

/** The private memory column (strictly inside the cell). */
export const colA = (): Rect => {
  const c = cellA()
  return { x: c.x + M.COL_A.dx, y: c.y + M.COL_A.dy, w: M.COL_A.w, h: c.h - M.COL_A.dy - M.COL_A.padBot, r: 10 }
}

/** Band index: 0=code, 1=data, 2=heap, 3=stack. Heap height is a story fact
 *  passed in (it grows). Code and data stack top-down; the STACK band is
 *  anchored to the column bottom; the heap sits under data and grows DOWNWARD
 *  toward the stack — the real address-space shape (heap → gap ← stack). */
export function bandRect(i: number, heapH: number): Rect {
  const col = colA()
  const x = col.x + M.COL_A.inner
  const w = col.w - 2 * M.COL_A.inner
  const g = M.BAND.gap
  const top = col.y + M.COL_A.inner
  if (i === 0) return { x, y: top, w, h: M.BAND.codeH, r: 6 }
  if (i === 1) return { x, y: top + M.BAND.codeH + g, w, h: M.BAND.dataH, r: 6 }
  if (i === 2) return { x, y: top + M.BAND.codeH + g + M.BAND.dataH + g, w, h: heapH, r: 6 }
  // stack — bottom-anchored
  return { x, y: col.y + col.h - M.COL_A.inner - M.BAND.stackH, w, h: M.BAND.stackH, r: 6 }
}

/** Code row `i` (0..CODE_ROWS-1) inside the code band. */
export function codeRowRect(i: number, heapH: number): Rect {
  const b = bandRect(0, heapH)
  const rowH = (b.h - 2 * M.CODE_ROW_PAD) / M.CODE_ROWS
  return { x: b.x + 8, y: b.y + M.CODE_ROW_PAD + i * rowH, w: b.w - 16, h: rowH, r: 3 }
}

/** Handle chip `i` in the resource dock (0=file, 1=display). */
export const dockChipA = (i: number): Rect => {
  const c = cellA()
  return { x: c.x + M.DOCK_A.dx, y: c.y + M.DOCK_A.y0 + i * (M.DOCK_A.chipH + M.DOCK_A.gap), w: M.DOCK_A.chipW, h: M.DOCK_A.chipH, r: M.DOCK_A.r }
}

/** Register slot `i` (0..REG_A.n-1). */
export const regSlotA = (i: number): Rect => {
  const c = cellA()
  return { x: c.x + M.REG_A.dx + i * (M.REG_A.slot + M.REG_A.gap), y: c.y + M.REG_A.dy, w: M.REG_A.slot, h: M.REG_A.slot, r: M.REG_A.r }
}

// =============================================================================
// Process B — same anatomy, compact (the generality proof)
// =============================================================================
export const cellB = (): Rect => rectAt(M.B_C, M.CELL_B)
export const chipB = (): Rect => {
  const c = cellB()
  return { x: c.x + c.w - M.CHIP_B.w - M.CHIP_B.dx, y: c.y + M.CHIP_B.dy, w: M.CHIP_B.w, h: M.CHIP_B.h, r: M.CHIP_B.r }
}
export const colB = (): Rect => {
  const c = cellB()
  return { x: c.x + M.COL_B.dx, y: c.y + M.COL_B.dy, w: M.COL_B.w, h: c.h - M.COL_B.dy - M.COL_B.padBot, r: 8 }
}
export function bandRectB(i: number): Rect {
  const col = colB()
  const x = col.x + M.COL_B.inner
  const w = col.w - 2 * M.COL_B.inner
  const g = M.BAND_B.gap
  const top = col.y + M.COL_B.inner
  if (i === 0) return { x, y: top, w, h: M.BAND_B.codeH, r: 5 }
  if (i === 1) return { x, y: top + M.BAND_B.codeH + g, w, h: M.BAND_B.dataH, r: 5 }
  if (i === 2) return { x, y: top + M.BAND_B.codeH + g + M.BAND_B.dataH + g, w, h: M.BAND_B.heapH, r: 5 }
  return { x, y: col.y + col.h - M.COL_B.inner - M.BAND_B.stackH, w, h: M.BAND_B.stackH, r: 5 }
}
export function codeRowRectB(i: number): Rect {
  const b = bandRectB(0)
  const rowH = (b.h - 2 * M.CODE_ROW_PAD) / M.CODE_ROWS_B
  return { x: b.x + 6, y: b.y + M.CODE_ROW_PAD + i * rowH, w: b.w - 12, h: rowH, r: 3 }
}
export const dockChipB = (): Rect => {
  const c = cellB()
  return { x: c.x + M.DOCK_B.dx, y: c.y + M.DOCK_B.y0, w: M.DOCK_B.chipW, h: M.DOCK_B.chipH, r: M.DOCK_B.r }
}
export const regSlotB = (i: number): Rect => {
  const c = cellB()
  return { x: c.x + M.DOCK_B.dx + i * (M.REG_B.slot + M.REG_B.gap), y: c.y + M.REG_B.dy, w: M.REG_B.slot, h: M.REG_B.slot, r: M.REG_B.r }
}

// =============================================================================
// The machine bay (far east — LOK-07: never inside the OS)
// =============================================================================
export const machineRect = (): Rect => rectAt(M.MACHINE_C, M.MACHINE)
export const machineSlotRect = (i: number): Rect => {
  const m = machineRect()
  return { x: m.x + (m.w - M.MACHINE_SLOT.w) / 2, y: m.y + M.MACHINE_SLOT.topPad + i * (M.MACHINE_SLOT.h + M.MACHINE_SLOT.gap), w: M.MACHINE_SLOT.w, h: M.MACHINE_SLOT.h, r: 4 }
}

// =============================================================================
// Term pill anchors
// =============================================================================
export const pillConceptC = (): Vec2 => ({ ...M.PILL_CONCEPT_C })
export const pillEcC = (): Vec2 => ({ ...M.PILL_EC_C })

// =============================================================================
// The protagonist path — the attention/launch signal's world route.
// Anchors: 0=Photos · 1=OS · 2=cell A ·
// 3=watch-point beside A · 4=Notes · 5=OS · 6=cell B · 7=below the machine.
// =============================================================================
export const P_PHOTOS: Vec2 = { ...M.PHOTOS_C }
export const P_NOTES: Vec2 = { ...M.NOTES_C }
export const P_OS: Vec2 = { ...M.OS_C }
export const P_A: Vec2 = { ...M.A_C }
export const P_B: Vec2 = { ...M.B_C }
/** Watch-points: while the INTERIOR is the subject, the protagonist (the
 *  learner's attention signal) parks BESIDE the cell, never on top of the
 *  gold execution marker — exactly one gold point ever reads as "the
 *  execution". Anchor 7 (the machine) hosts the one-machine beat. */
export const P_A_WATCH: Vec2 = {
  x: M.A_C.x + M.CELL_A.w / 2 + 52,
  y: M.A_C.y - M.CELL_A.h / 2 - 26,
}
export const P_MACHINE: Vec2 = { x: M.MACHINE_C.x, y: M.MACHINE_C.y + M.MACHINE.h / 2 + 40 }

export const PATH_WORLD: Vec2[] = [P_PHOTOS, P_OS, P_A, P_A_WATCH, P_NOTES, P_OS, P_B, P_MACHINE]

// =============================================================================
// Scene bbox — derived from content + clip inset
// =============================================================================
export const bboxWorld = () => {
  const bay = bayRect()
  const a = cellA()
  const b = cellB()
  const m = machineRect()
  const pc = pillConceptC()
  const pe = pillEcC()
  const minX = bay.x - M.CLIP_INSET
  const maxX = Math.max(b.x + b.w, m.x + m.w) + M.CLIP_INSET
  const minY = Math.min(bay.y, m.y, pc.y - M.TERM.h / 2 - M.LABEL_TEXT_H, a.y) - M.CLIP_INSET
  const maxY = Math.max(bay.y + bay.h, a.y + a.h, b.y + b.h, pe.y + M.TERM.h / 2 + M.LABEL_TEXT_H) + M.CLIP_INSET
  return { minX, maxX, minY, maxY }
}

/** Hit zone: the Photos tile (click to relaunch = click to start). */
export const PHOTOS_HIT = () => {
  const p = photosRect()
  return { x: p.x, y: p.y, w: p.w, h: p.h }
}
