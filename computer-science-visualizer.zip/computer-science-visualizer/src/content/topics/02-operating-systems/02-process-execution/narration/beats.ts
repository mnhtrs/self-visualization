// narration/beats.ts — the storyboard of Topic 02 Chapter 02 (increment 1):
// 18 beats in one stable world, answering exactly one question — what
// actually makes a Process a managed execution instance? — with every answer
// OBSERVED before it is named.
//
// Structure (mirrors the blueprint beat table):
//   ACT 1 (b0–b2):  cognitive replay — the CH01 world; one relaunch, watched
//                   to look INSIDE; the tension: named, bounded — and empty.
//   ACT 2 (b3–b8):  the private space is granted; code copied in (Program
//                   unchanged); running keeps values (data); room granted
//                   mid-run (heap); a sub-task and the way back (stack);
//                   the four ringed as ONE → Address Space.
//   ACT 3 (b9–b10): outside things stay outside; handles dock → Resources.
//   ACT 4 (b11–b13): the exact point of execution; its companions; the name:
//                   Execution Context.
//   ACT 5 (b14–b15): a DIFFERENT program shows the same anatomy; one machine,
//                   one advancing point — the other point stands, held.
//   ACT 6 (b16):    SILENT CLIMAX — the whole model operating at once.
//   ACT 7 (b17):    quiet integration + the permitted open loop (bridge to
//                   the States / Switch / Resume increment: question only).
//
// Authoring rules honoured here:
//   • Knowledge Reveal Law: band names land per-band AFTER observation;
//     "Address Space" first in b8, "Resources" first in b10, "Execution
//     Context" (with Program Counter / Stack Pointer) first in b13.
//   • No unlearning: nothing taught here contradicts CH01 or T01; PID and OS
//     grammar are reused, not re-taught; registers are T01 vocabulary.
//   • The climax (b16) carries NO narration, NO term, NO conclusion.
//   • Forbidden territory (increment rule): no state names, no context
//     switch, no pause/resume-as-mechanism, no scheduling, no threads, no
//     virtual-memory internals. The bridge asks; it never answers.
//   • Silent beats use a non-breaking space so the narration panel keeps its
//     height while showing nothing.

import type { BeatDescription } from '../../../../../chapter-loader/types'
import { B, DURATIONS, TRAVELS, RESTS, PID_A, PID_B } from '../scenes/story'

const SILENT: { en: string; vi: string } = { en: '\u00A0', vi: '\u00A0' }

/** Build travel/rest fields from the story tables (single source, §4.5). */
const move = (bi: number) => {
  const t = TRAVELS[bi]
  if (t) {
    return t.holdFrom !== undefined
      ? { travel: { from: t.from, to: t.to, holdAt: { index: t.to, from: t.holdFrom, to: 1 } } }
      : { travel: { from: t.from, to: t.to } }
  }
  return { rest: { at: RESTS[bi] ?? 0 } }
}

export const beats: BeatDescription[] = [
  // ===========================================================================
  // ACT 1 — the CH01 world, and the question it left open
  // ===========================================================================
  {
    id: 'the-question',
    scene: 'world',
    line: {
      en: 'This is the world as the last chapter left it: programs stored on the shelf, the OS between them and the machine, and Processes born on this side — each with its own identity. We called a Process “a managed execution instance”. But so far, all we have seen of one is a boundary and a number. What actually makes it a managed execution instance?',
      vi: 'Đây là thế giới như chương trước để lại: các chương trình nằm trên kệ, OS đứng giữa chúng và cỗ máy, và các Process được sinh ra ở phía bên này — mỗi cái một danh tính riêng. Ta đã gọi Process là “một thực thể thực thi được quản lý”. Nhưng đến giờ, thứ ta thấy ở nó mới chỉ là một đường bao và một con số. Điều gì thực sự khiến nó là một thực thể thực thi được quản lý?',
    },
    duration: DURATIONS[B.question], active: 'os', ...move(B.question), emerge: true,
  },
  {
    id: 'relaunch',
    scene: 'world',
    line: {
      en: `Launch Photos once more — you know this route: the request goes to the OS, and the OS creates a new Process. PID ${PID_A}. This time, we are not watching from outside. This time, we look in.`,
      vi: `Khởi chạy Photos thêm một lần — bạn đã biết con đường này: yêu cầu đi đến OS, và OS tạo ra một Process mới. PID ${PID_A}. Nhưng lần này, ta không đứng ngoài quan sát nữa. Lần này, ta nhìn vào bên trong.`,
    },
    duration: DURATIONS[B.relaunch], active: null, ...move(B.relaunch),
  },
  {
    id: 'empty-shell',
    scene: 'world',
    line: {
      en: 'Look inside the boundary. Nothing. A name, a number — and an empty interior. Yet the instructions this Process must execute are still far away, inside the stored file on the shelf. An empty instance cannot execute anything. Something has to be put here first. What?',
      vi: 'Nhìn vào trong đường bao. Trống rỗng. Một cái tên, một con số — và một khoảng trống. Trong khi những lệnh mà Process này phải thực thi vẫn nằm tận đằng kia, trong tệp được lưu trên kệ. Một thực thể trống rỗng thì không thể thực thi gì cả. Phải có thứ gì đó được đặt vào đây trước đã. Thứ gì?',
    },
    duration: DURATIONS[B.emptyShell], active: null, ...move(B.emptyShell),
  },

  // ===========================================================================
  // ACT 2 — the private space: code, data, heap, stack → Address Space
  // ===========================================================================
  {
    id: 'the-space',
    scene: 'world',
    line: {
      en: 'Watch the first thing that happens. The Process asks — and the OS answers: it grants this Process a space of its own. Not the shelf. Not somebody else’s space. A private area that belongs to this one instance, and the OS keeps track of it.',
      vi: 'Hãy xem điều đầu tiên xảy ra. Process gửi yêu cầu — và OS đáp lại: nó cấp cho Process này một vùng không gian của riêng nó. Không phải cái kệ. Không phải không gian của ai khác. Một vùng riêng thuộc về đúng thực thể này, và OS ghi nhận, theo dõi vùng đó.',
    },
    duration: DURATIONS[B.space], active: 'os', ...move(B.space),
  },
  {
    id: 'code-arrives',
    scene: 'world',
    line: {
      en: 'Now something is placed into that space: a copy of the program’s instructions. Watch the shelf while it happens — the stored file does not move and does not change. The Process receives its own copy to execute. That part of its space holds code.',
      vi: 'Giờ có thứ được đặt vào vùng không gian ấy: một bản sao các lệnh của chương trình. Hãy nhìn cái kệ trong lúc đó — tệp được lưu không hề di chuyển, không hề thay đổi. Process nhận bản sao của riêng nó để thực thi. Phần không gian ấy chứa code.',
    },
    duration: DURATIONS[B.code], active: 'program', ...move(B.code),
  },
  {
    id: 'first-run',
    scene: 'world',
    line: {
      en: 'And execution begins — the golden point you know from Topic 1, stepping through the instructions line by line. What it computes has to be kept somewhere. Watch the values settle just below the code, into the Process’s own space — and the working values sit in registers, exactly as Topic 1 showed. That region of kept values is its data.',
      vi: 'Và việc thực thi bắt đầu — đốm sáng vàng bạn đã quen từ Topic 1, bước qua từng dòng lệnh. Những gì nó tính ra phải được giữ lại ở đâu đó. Hãy xem các giá trị lắng xuống ngay dưới phần code, vào chính không gian riêng của Process — còn giá trị đang dùng thì nằm trong thanh ghi, đúng như Topic 1 đã cho thấy. Vùng giá trị được giữ ấy là data.',
    },
    duration: DURATIONS[B.firstRun], active: null, ...move(B.firstRun),
  },
  {
    id: 'heap',
    scene: 'world',
    line: {
      en: 'Then the Process opens a photo — and suddenly it needs much more room than anyone could have planned in advance. Watch the route: it asks, the OS grants, and its space grows. Room that appears while running, on request, is the heap.',
      vi: 'Rồi Process mở một bức ảnh — và đột nhiên nó cần nhiều chỗ hơn hẳn những gì có thể tính trước. Hãy nhìn con đường: nó xin, OS cấp, và không gian của nó lớn thêm. Phần chỗ xuất hiện trong lúc chạy, theo yêu cầu, chính là heap.',
    },
    duration: DURATIONS[B.heap], active: 'os', ...move(B.heap),
  },
  {
    id: 'stack',
    scene: 'world',
    line: {
      en: 'One more thing to watch. The execution steps into a sub-task — and a small frame is set down at the bottom of the space: the way back. The sub-task finishes, the frame lifts, and execution returns to exactly where it left. That growing and shrinking pile of return points is the stack.',
      vi: 'Còn một điều nữa để quan sát. Việc thực thi bước vào một tác vụ con — và một khung nhỏ được đặt xuống đáy vùng không gian: đường quay về. Tác vụ con xong, khung được nhấc lên, và việc thực thi trở lại đúng nơi nó rời đi. Chồng điểm-quay-về phồng lên xẹp xuống ấy là stack.',
    },
    duration: DURATIONS[B.stack], active: null, ...move(B.stack),
  },
  {
    id: 'address-space',
    scene: 'world',
    line: {
      en: 'Step back and look at what has formed. Code. Data. Heap. Stack. Four regions — one granted, private space, tracked by the OS from the moment it was given. This space has a name: the Address Space. Every Process gets its own.',
      vi: 'Lùi lại và nhìn thứ vừa thành hình. Code. Data. Heap. Stack. Bốn vùng — nhưng là một không gian riêng được cấp, và OS theo dõi nó từ khoảnh khắc trao đi. Không gian ấy có tên: Address Space — không gian địa chỉ. Mỗi Process có một cái của riêng mình.',
    },
    duration: DURATIONS[B.addressSpace], active: null, ...move(B.addressSpace),
  },

  // ===========================================================================
  // ACT 3 — outside things: handles → Resources
  // ===========================================================================
  {
    id: 'the-file',
    scene: 'world',
    line: {
      en: 'But not everything a Process needs can live inside its space. The photo it opened is a file — it belongs to storage, out there. Watch what actually happens: the request goes through the OS… and the file never moves. What arrives instead is small: a recorded grant — a handle — docked inside the Process.',
      vi: 'Nhưng không phải mọi thứ Process cần đều nằm được trong không gian của nó. Bức ảnh nó mở là một tệp — thuộc về bộ lưu trữ, ở ngoài kia. Hãy xem điều thực sự xảy ra: yêu cầu đi qua OS… và tệp không hề di chuyển. Thứ đến nơi lại rất nhỏ: một quyền truy cập được ghi lại — một handle — cắm vào trong Process.',
    },
    duration: DURATIONS[B.file], active: 'os', ...move(B.file),
  },
  {
    id: 'outside-things',
    scene: 'world',
    line: {
      en: 'And it repeats. To show the photo, the Process needs the display — again through the OS, again a handle. These recorded grants are the Process’s Resources: the outside things it may use, each one granted and tracked. The OS knows exactly what this Process holds.',
      vi: 'Và điều đó lặp lại. Muốn hiển thị bức ảnh, Process cần màn hình — lại đi qua OS, lại một handle. Những quyền được ghi lại ấy là Resources — tài nguyên của Process: những thứ bên ngoài nó được dùng, từng cái đều được cấp và theo dõi. OS biết chính xác Process này đang giữ gì.',
    },
    duration: DURATIONS[B.resources], active: null, ...move(B.resources),
  },

  // ===========================================================================
  // ACT 4 — the exact point → Execution Context
  // ===========================================================================
  {
    id: 'the-exact-point',
    scene: 'world',
    line: {
      en: 'Now let everything else go quiet, and watch only the golden point. At this very instant, the execution of this Process IS somewhere — one exact line, not roughly, not somewhere in the middle. Freeze the moment in your mind: where is it, precisely?',
      vi: 'Giờ hãy để mọi thứ khác lắng xuống, và chỉ nhìn đốm sáng vàng. Ngay khoảnh khắc này, việc thực thi của Process này ĐANG ở một nơi — một dòng chính xác, không phải áng chừng, không phải khoảng nào đó ở giữa. Hãy giữ khoảnh khắc ấy lại trong đầu: nó đang ở đâu, chính xác?',
    },
    duration: DURATIONS[B.exactPoint], active: null, ...move(B.exactPoint),
  },
  {
    id: 'the-snapshot',
    scene: 'world',
    line: {
      en: 'The position is not alone. Look at what belongs to this exact moment: the line it stands on, the values in the registers, the top of the stack. Together they are one precise description of “where this execution stands right now”. Change any one of them, and it is a different moment.',
      vi: 'Vị trí ấy không đứng một mình. Hãy nhìn những gì thuộc về đúng khoảnh khắc này: dòng lệnh nó đang đứng, các giá trị trong thanh ghi, đỉnh của stack. Gộp lại, chúng là một bản mô tả chính xác về “việc thực thi này đang đứng ở đâu ngay lúc này”. Đổi bất kỳ thứ nào trong đó, là đã thành một khoảnh khắc khác.',
    },
    duration: DURATIONS[B.snapshot], active: null, ...move(B.snapshot),
  },
  {
    id: 'execution-context',
    scene: 'world',
    line: {
      en: 'That precise description has a name: the Execution Context. The position has its own name — the Program Counter. The stack top has one too — the Stack Pointer. And here is the part that matters: the OS holds this context for every Process, just as it holds the space and the resources.',
      vi: 'Bản mô tả chính xác ấy có tên: Execution Context — ngữ cảnh thực thi. Vị trí có tên riêng — Program Counter. Đỉnh stack cũng vậy — Stack Pointer. Và đây là điều quan trọng: OS giữ ngữ cảnh này cho mỗi Process, cũng như nó giữ không gian và tài nguyên vậy.',
    },
    duration: DURATIONS[B.execContext], active: null, ...move(B.execContext),
  },

  // ===========================================================================
  // ACT 5 — generality + the honest constraint
  // ===========================================================================
  {
    id: 'another-program',
    scene: 'world',
    line: {
      en: `Is all of this a Photos thing? Launch a completely different program — Notes. Watch the second Process form: its own granted space with the same four regions, its own copied code, its own handle, its own execution point, its own PID — ${PID_B}. This anatomy is not the app. It is what a Process IS.`,
      vi: `Tất cả những điều này có phải chỉ riêng cho Photos? Hãy khởi chạy một chương trình hoàn toàn khác — Notes. Xem Process thứ hai thành hình: không gian được cấp của riêng nó với đúng bốn vùng ấy, bản sao code riêng, handle riêng, điểm thực thi riêng, PID riêng — ${PID_B}. Cấu trúc này không thuộc về ứng dụng. Nó chính là bản chất của một Process.`,
    },
    duration: DURATIONS[B.anotherProgram], active: null, ...move(B.anotherProgram),
  },
  {
    id: 'one-machine',
    scene: 'world',
    line: {
      en: 'Both Processes exist, each complete. But look closely at the two golden points. Only one is moving. The machine over there is one machine — it advances one execution at a time. The second point is not gone and not lost: it stands exactly where it stands, held. Held by whom? You already know — everything a Process is, the OS holds.',
      vi: 'Cả hai Process đều tồn tại, mỗi cái đều đầy đủ. Nhưng hãy nhìn kỹ hai đốm sáng vàng. Chỉ một đốm đang di chuyển. Cỗ máy đằng kia là một cỗ máy — nó tiến từng việc thực thi một. Đốm thứ hai không biến mất, không bị thất lạc: nó đứng yên đúng tại chỗ của nó, được giữ lại. Ai giữ? Bạn biết rồi đấy — mọi thứ làm nên một Process, OS đều giữ.',
    },
    duration: DURATIONS[B.oneMachine], active: 'machine', ...move(B.oneMachine),
  },

  // ===========================================================================
  // ACT 6 — THE SILENT CLIMAX
  // ===========================================================================
  {
    id: 'climax',
    scene: 'world',
    line: SILENT,
    duration: DURATIONS[B.climax], active: null, ...move(B.climax), effect: 'loop',
  },

  // ===========================================================================
  // ACT 7 — quiet integration + the open loop
  // ===========================================================================
  {
    id: 'bridge',
    scene: 'world',
    line: {
      en: 'This is what makes a Process a managed execution instance: its own Address Space, its Resources, its Execution Context — all granted, all tracked, all held by the OS. And one question to carry forward: the second Process’s exact point is being held, not lost. If the exact point of an execution can be held… can an execution stop — and later continue from exactly there?',
      vi: 'Đây chính là điều khiến một Process là một thực thể thực thi được quản lý: Address Space của riêng nó, Resources của nó, Execution Context của nó — tất cả được cấp, được theo dõi, được OS nắm giữ. Và một dòng suy nghĩ để mang theo: điểm thực thi chính xác của Process thứ hai đang được giữ lại, chứ không mất đi. Nếu điểm chính xác của một việc thực thi có thể được giữ… thì việc thực thi có thể ngừng — rồi sau đó tiếp diễn từ đúng chỗ ấy không?',
    },
    duration: DURATIONS[B.bridge], active: null, ...move(B.bridge), effect: 'loop',
  },
]
