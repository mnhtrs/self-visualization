// narration/labels.ts — UI strings of Topic 02 Chapter 02 (the Viewer reads
// these via chapter.ui; every key the generic Viewer may look for is provided).

import type { LocalizedText } from '../../../../../chapter-loader/types'

export const chapterTitle: LocalizedText = {
  en: 'What actually makes a Process a managed execution instance?',
  vi: 'Điều gì thực sự khiến một Process là một thực thể thực thi được quản lý?',
}

export const waitingLine: LocalizedText = {
  en: 'The last chapter showed WHAT the OS creates. This one looks inside it. Launch Photos once more — and this time, watch the interior.',
  vi: 'Chương trước cho thấy OS tạo ra CÁI GÌ. Chương này nhìn vào bên trong nó. Hãy khởi chạy Photos thêm một lần — và lần này, quan sát phần bên trong.',
}

export const startButton: LocalizedText = {
  en: 'Launch the program',
  vi: 'Khởi chạy chương trình',
}

export const sceneTag: LocalizedText = {
  en: 'Inside a Process',
  vi: 'Bên trong một Process',
}

export const tipText: LocalizedText = {
  en: 'Click the Photos program to launch it. Use the < > buttons or the dots to step through.',
  vi: 'Bấm vào chương trình Photos để khởi chạy. Dùng nút < > hoặc các chấm để tua tới lui.',
}

export const doneLabel: LocalizedText = { en: 'Done', vi: 'Xong' }
