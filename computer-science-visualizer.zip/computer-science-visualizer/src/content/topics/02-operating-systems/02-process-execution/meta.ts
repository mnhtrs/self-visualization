// content/topics/02-operating-systems/02-process-execution/meta.ts
// Topic 02 Chapter 02 — canonical CH02 (`process-execution`), per the
// curriculum graph and CURRICULUM_GUARDIAN_T02_DRAFT.md §5 (CH02).
//
// INCREMENT NOTE: this release ships increment 1 of the canonical CH02 —
// "Inside a Process: Memory, Resources & Execution Context". The later
// execution story (States, Context Switch, Resume) extends this same chapter
// in a later increment; its bridge question is this increment's exit state.

import type { ChapterMeta } from '../../../../chapter-loader/types'
import thumb from './assets/thumbnail.jpg'

const meta: ChapterMeta = {
  id: 'topic-02-operating-systems--ch-02-process-execution',
  slug: 'process-execution',
  order: 2,
  chapterOrder: 2,
  topicId: 'topic-02-operating-systems',
  topicSlug: 'operating-systems',
  topicOrder: 2,
  topicTitle: { en: 'Processes & Threads', vi: 'Tiến trình & Luồng' },
  status: 'available',
  thumbnail: thumb,
  title: {
    en: 'Inside a Process: Memory, Resources & Execution Context',
    vi: 'Bên trong một Process: Bộ nhớ, Tài nguyên & Ngữ cảnh thực thi',
  },
  subtitle: {
    en: 'Look inside the Process the OS created: watch it receive its own private Address Space (code, data, heap, stack), collect handles to outside Resources, and carry an exact Execution Context — the point where its execution stands.',
    vi: 'Nhìn vào bên trong Process mà OS đã tạo: xem nó nhận không gian bộ nhớ riêng (code, data, heap, stack), thu nhận handle tới các tài nguyên bên ngoài, và mang một ngữ cảnh thực thi chính xác — điểm mà việc thực thi của nó đang đứng.',
  },
  accent: '#f472b6',
  loadStory: () => import('./index').then((m) => m.chapter),
}

export default meta
