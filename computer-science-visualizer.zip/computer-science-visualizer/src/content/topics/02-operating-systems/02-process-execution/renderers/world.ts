// renderers/world.ts — the painters of Topic 02 Chapter 02's single world:
// the storage bay (two program tiles + the data file, spatially persistent,
// NEVER moving), the OS band (CH01 grammar — its function-row labels were
// EARNED in CH01 and are visible from beat 0), the machine bay (quiet
// physical context; its CPU slot glints ONLY while an execution point is
// advancing), and the process field — Process A looked INTO (memory column
// with code/data/heap/stack, resource dock, register strip, the gold
// execution point) and Process B (same anatomy, compact, its point HELD).
//
// Everything here is a pure function of (beatIndex, beatFraction) read from
// scenes/story.ts — deterministic by construction (VISUAL_LANGUAGE §15).
// Ambient breathing reads s.t exactly as CH01's ambience does.
//
// LOAD-BEARING VISUAL ARGUMENTS (blueprint §3–4):
//   • The memory column lives STRICTLY INSIDE the Process cell — the private
//     space is part of the Process, never the machine's RAM (which stays a
//     separate quiet bay that memory grants never light).
//   • Grants are WATCHED: request comet → OS manage row → grant arc →
//     structure grows. Memory/access is given and tracked, never ambient.
//   • The Program tiles' painters take no input from any Process state —
//     immutability by construction (copy comets pulse them UNCHANGED).
//   • At most ONE gold point is ever advancing (one machine, T01 canon
//     C-05); Process B's point resolves once and stands HELD.
//   • Nothing here draws Process States, context switches, queues, threads
//     or address numbers — scope-locked to this increment.

import type { EntityRenderer } from '../../../../../rendering/types'
import type { Vec2, Lang } from '../../../../../chapter-loader/types'
import { rrPath, hexA } from '../../../../../rendering/primitives/canvas-utils'
import { glow } from '../../../../../rendering/primitives/glow'
import { drawName } from '../../../../../rendering/primitives/text'
import { TAU, clamp, easeInOutCubic, lerp } from '../../../../../shared/math'
import { polylinePoint } from '../../../../../shared/geometry'

import { beats } from '../narration/beats'
import * as M from '../scenes/metrics'
import * as L from '../scenes/layout'
import * as S from '../scenes/story'

// ---------------------------------------------------------------------------
// shared helpers
// ---------------------------------------------------------------------------
const DUR: Record<number, number> = Object.fromEntries(beats.map((b, i) => [i, b.duration]))
export const beatFrac = (s: { beatIndex: number; beatElapsed: number }): number =>
  clamp(s.beatElapsed / (DUR[s.beatIndex] ?? 3000), 0, 1)

const T = (txt: { en: string; vi: string }, lang: string) =>
  (lang as Lang) === 'vi' ? txt.vi : txt.en

const near = (a: Vec2, b: Vec2, r: number) => Math.hypot(a.x - b.x, a.y - b.y) <= r

const ramp = S.ramp01
const pulseK = S.hump

function label(
  ctx: CanvasRenderingContext2D,
  text: string,
  at: Vec2,
  opts: { size?: number; color?: string; align?: CanvasTextAlign; alpha?: number; weight?: number; mono?: boolean } = {},
) {
  if ((opts.alpha ?? 1) <= 0.01) return
  ctx.save()
  ctx.globalAlpha = opts.alpha ?? 1
  ctx.font = `${opts.weight ?? 700} ${opts.size ?? M.F.sub}px ${opts.mono ? M.MONO : M.FONT}`
  ctx.textAlign = opts.align ?? 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = opts.color ?? M.COL.dim
  ctx.fillText(text, at.x, at.y)
  ctx.restore()
}

/** Term pill (Topic-01/CH01 convention: term + plain sub, after observation). */
function drawTermPill(
  ctx: CanvasRenderingContext2D,
  c: Vec2,
  term: string,
  sub: string,
  color: string,
  alpha: number,
) {
  if (alpha <= 0.01) return
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.font = `800 ${M.F.termPill}px ${M.FONT}`
  const w = ctx.measureText(term).width + 2 * M.TERM.padX
  rrPath(ctx, c.x - w / 2, c.y - M.TERM.h / 2, w, M.TERM.h, M.TERM.r)
  ctx.fillStyle = M.COL.panel
  ctx.fill()
  ctx.strokeStyle = hexA(color, 0.95)
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.fillStyle = '#ffffff'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(term, c.x, c.y + 1)
  label(ctx, sub, { x: c.x, y: c.y + M.TERM.h / 2 + M.BREATH + M.F.sub / 2 }, {
    size: M.F.sub, color: M.COL.dim, alpha,
  })
  ctx.restore()
}

/** The Photos app glyph (sun + mountains) — CH01 continuity: same identity. */
function drawPhotosGlyph(ctx: CanvasRenderingContext2D, cx: number, cy: number, s: number, lit: boolean) {
  ctx.fillStyle = hexA('#eaf6ff', lit ? 0.95 : 0.8)
  ctx.beginPath()
  ctx.arc(cx - s * 0.18, cy - s * 0.15, s * 0.1, 0, TAU)
  ctx.fill()
  ctx.beginPath()
  ctx.moveTo(cx - s * 0.32, cy + s * 0.24)
  ctx.lineTo(cx - s * 0.02, cy - s * 0.1)
  ctx.lineTo(cx + s * 0.32, cy + s * 0.24)
  ctx.closePath()
  ctx.fill()
  ctx.beginPath()
  ctx.moveTo(cx - s * 0.14, cy + s * 0.24)
  ctx.lineTo(cx + s * 0.06, cy - s * 0.02)
  ctx.lineTo(cx + s * 0.2, cy + s * 0.24)
  ctx.closePath()
  ctx.fillStyle = hexA('#cfe8ff', (lit ? 0.85 : 0.65) * 0.9)
  ctx.fill()
}

/** The Notes app glyph (ruled page + pen tick) — a clearly DIFFERENT program. */
function drawNotesGlyph(ctx: CanvasRenderingContext2D, cx: number, cy: number, s: number, lit: boolean) {
  const a = lit ? 0.95 : 0.78
  ctx.strokeStyle = hexA('#eaf6ff', a)
  ctx.lineWidth = Math.max(1.4, s * 0.045)
  ctx.lineCap = 'round'
  for (let i = -1; i <= 1; i++) {
    ctx.beginPath()
    ctx.moveTo(cx - s * 0.26, cy + i * s * 0.18)
    ctx.lineTo(cx + s * (i === 1 ? 0.06 : 0.26), cy + i * s * 0.18)
    ctx.stroke()
  }
  ctx.strokeStyle = hexA('#cfe8ff', a * 0.9)
  ctx.beginPath()
  ctx.moveTo(cx + s * 0.1, cy + s * 0.26)
  ctx.lineTo(cx + s * 0.3, cy + s * 0.02)
  ctx.stroke()
}

/** A small document glyph (the data file — photo.jpg). */
function drawFileGlyph(ctx: CanvasRenderingContext2D, c: Vec2, lit: boolean, alpha = 1) {
  const w = M.FILE_GLYPH.w
  const h = M.FILE_GLYPH.h
  const f = M.FILE_GLYPH.fold
  const x = c.x - w / 2
  const y = c.y - h / 2
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.beginPath()
  ctx.moveTo(x, y)
  ctx.lineTo(x + w - f, y)
  ctx.lineTo(x + w, y + f)
  ctx.lineTo(x + w, y + h)
  ctx.lineTo(x, y + h)
  ctx.closePath()
  ctx.fillStyle = hexA(M.COL.program, lit ? 0.2 : 0.1)
  ctx.fill()
  ctx.strokeStyle = hexA(M.COL.program, lit ? 0.95 : 0.55)
  ctx.lineWidth = 1.8
  ctx.stroke()
  ctx.beginPath()
  ctx.moveTo(x + w - f, y)
  ctx.lineTo(x + w - f, y + f)
  ctx.lineTo(x + w, y + f)
  ctx.stroke()
  // tiny photo mark inside
  drawPhotosGlyph(ctx, c.x, c.y + 4, w * 0.62, lit)
  ctx.restore()
}

// ===========================================================================
// STORAGE BAY — two program tiles + the data file. Painters take NO input
// from any Process state: the artifacts are immutable by construction.
// ===========================================================================
function drawProgramTile(
  ctx: CanvasRenderingContext2D,
  tile: L.Rect,
  which: 'photos' | 'notes',
  name: string,
  lit: boolean,
  pulse: number,
) {
  ctx.save()
  if (lit) glow(ctx, { x: tile.x + tile.w / 2, y: tile.y + tile.h / 2 }, M.COL.program, 100, 0.2)
  if (pulse > 0.02) {
    ctx.strokeStyle = hexA(M.COL.program, 0.85 * pulse)
    ctx.lineWidth = M.PULSE.ring
    rrPath(ctx, tile.x - 8 * pulse, tile.y - 8 * pulse, tile.w + 16 * pulse, tile.h + 16 * pulse, tile.r + 5)
    ctx.stroke()
  }
  rrPath(ctx, tile.x, tile.y, tile.w, tile.h, tile.r)
  ctx.fillStyle = hexA(M.COL.program, lit ? 0.1 : 0.06)
  ctx.fill()
  ctx.strokeStyle = hexA(M.COL.program, lit ? 0.9 : 0.5)
  ctx.lineWidth = 2
  ctx.stroke()
  const icon = L.appIconRect(tile)
  rrPath(ctx, icon.x, icon.y, icon.w, icon.h, icon.r)
  ctx.fillStyle = hexA(M.COL.program, lit ? 0.22 : 0.14)
  ctx.fill()
  ctx.strokeStyle = hexA(M.COL.program, lit ? 1 : 0.7)
  ctx.lineWidth = 2.2
  ctx.stroke()
  if (which === 'photos') drawPhotosGlyph(ctx, icon.x + icon.w / 2, icon.y + icon.h / 2, icon.w, lit)
  else drawNotesGlyph(ctx, icon.x + icon.w / 2, icon.y + icon.h / 2, icon.w, lit)
  label(ctx, name, L.appNamePos(tile), {
    size: M.F.appName, color: hexA('#eaf0ff', lit ? 0.95 : 0.7), weight: 700,
  })
  ctx.restore()
}

export const drawStorageBay: EntityRenderer = (ctx, s, e, active) => {
  const bi = s.beatIndex
  const frac = beatFrac(s)
  const bay = L.bayRect()
  const photos = L.photosRect()
  const notes = L.notesRect()

  // pulses (all beat-local, from story windows):
  // B02 — the eye is sent WEST: the instructions still live here.
  const lookWest = bi === S.B.emptyShell ? pulseK(frac, S.EMPTY_LOOK_WEST.from, S.EMPTY_LOOK_WEST.to) : 0
  // B04 — while the copy comets fly, the Program pulses UNCHANGED (coexistence).
  const unchanged = bi === S.B.code ? pulseK(frac, S.PROGRAM_UNCHANGED_PULSE.from, S.PROGRAM_UNCHANGED_PULSE.to) : 0
  // B09 — the FILE pulses: first "the need points here", then "still here, untouched".
  const fileBefore = bi === S.B.file ? pulseK(frac, S.FILE_PULSE.before[0], S.FILE_PULSE.before[1]) : 0
  const fileStill = bi === S.B.file ? pulseK(frac, S.FILE_PULSE.still[0], S.FILE_PULSE.still[1]) : 0
  // Climax: the file glows softly while its handle is in use.
  const fileUse = bi === S.B.climax ? pulseK(frac, S.CLIMAX_FILE_USE.from, S.CLIMAX_FILE_USE.to) : 0

  const sparkNearPhotos = s.sparkScale > 0.1 && near(s.sparkPos, M.PHOTOS_C, M.SPARK_NEAR)
  const sparkNearNotes = s.sparkScale > 0.1 && near(s.sparkPos, M.NOTES_C, M.SPARK_NEAR)

  ctx.save()
  // the recessed bay — the artifacts SIT IN storage (CH01 grammar)
  rrPath(ctx, bay.x, bay.y, bay.w, bay.h, bay.r)
  ctx.fillStyle = 'rgba(10,14,32,0.35)'
  ctx.fill()
  label(ctx, T(S.CAP.shelf, s.lang), { x: bay.x + bay.w / 2, y: bay.y + 24 }, {
    size: M.F.small, color: M.COL.dim,
  })
  ctx.restore()

  drawProgramTile(ctx, photos, 'photos', T(S.CAP.appPhotos, s.lang),
    (active && bi === S.B.code) || sparkNearPhotos, Math.max(lookWest, unchanged))
  drawProgramTile(ctx, notes, 'notes', T(S.CAP.appNotes, s.lang),
    sparkNearNotes, 0)

  // the data file — between the tiles, never moving
  const fp = L.fileC()
  const filePulse = Math.max(fileBefore, fileStill, fileUse)
  if (filePulse > 0.02) {
    ctx.save()
    ctx.strokeStyle = hexA(M.COL.program, 0.8 * filePulse)
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.arc(fp.x, fp.y, 32 + 10 * filePulse, 0, TAU)
    ctx.stroke()
    ctx.restore()
  }
  drawFileGlyph(ctx, fp, filePulse > 0.05)
  label(ctx, T(S.CAP.fileName, s.lang), { x: fp.x + M.FILE_GLYPH.w / 2 + 10, y: fp.y }, {
    size: M.F.micro, color: hexA(M.COL.program, 0.66), align: 'left', mono: true,
  })

  drawName(ctx, e.pos, e.name, e.color, false, bay.h / 2 + M.LABEL_GAP, M.F.partName)
}

// ===========================================================================
// OS BAND — CH01 grammar unchanged; the row labels are EARNED knowledge.
// Row glow: manage row lights during every GRANT; create row during births;
// identify row during PID resolves.
// ===========================================================================
function osRowGlow(bi: number, frac: number): [number, number, number] {
  const g: [number, number, number] = [0, 0, 0]
  // grants → the manage row (the OS granting and tracking)
  for (const gr of S.GRANTS) {
    if (bi === gr.beat) g[2] = Math.max(g[2], pulseK(frac, gr.row[0], gr.row[1]))
  }
  // births → the create row
  if (bi === S.B.relaunch) g[0] = pulseK(frac, 0.28, S.A_BIRTH.alive)
  if (bi === S.B.anotherProgram) g[0] = pulseK(frac, 0.36, S.B_FORM.alive)
  // PID resolves → the identify row
  if (bi === S.B.relaunch) g[1] = Math.max(g[1], pulseK(frac, S.A_BIRTH.chip, S.A_BIRTH.chipDock))
  if (bi === S.B.anotherProgram) g[1] = Math.max(g[1], pulseK(frac, S.B_FORM.chip[0], S.B_FORM.chip[1]))
  return g
}

export const drawOsBand: EntityRenderer = (ctx, s, e, active) => {
  const r = L.osRect()
  const frac = beatFrac(s)
  const bi = s.beatIndex
  const lang = s.lang as Lang

  const sparkIn = s.sparkScale > 0.1 && near(s.sparkPos, M.OS_C, M.OS_BAND.w)
  const rowGlow = osRowGlow(bi, frac)
  const work = Math.max(sparkIn ? 0.8 : 0, rowGlow[0], rowGlow[1], rowGlow[2])
  const lit = active || work > 0.05

  ctx.save()
  if (lit) glow(ctx, e.pos, e.color, 150, 0.14 + 0.12 * work)

  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fillStyle = hexA(e.color, 0.07 + 0.05 * work)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, lit ? 0.95 : 0.55)
  ctx.lineWidth = 2.5
  ctx.stroke()

  label(ctx, S.CAP.osLetters, { x: e.pos.x, y: r.y + M.OS_TITLE.dy }, {
    size: M.F.osTitle, color: hexA('#ffffff', lit ? 0.95 : 0.72), weight: 800,
  })
  label(ctx, T(S.CAP.osSubtitle, lang), { x: e.pos.x, y: r.y + M.OS_SUB.dy }, {
    size: M.F.micro, color: hexA('#eaf0ff', lit ? 0.68 : 0.52), weight: 700,
  })

  // ports (plain causal entry/exit sockets — no static arrows, CH01 rule)
  const wp = L.osWestPortRect()
  rrPath(ctx, wp.x, wp.y, wp.w, wp.h, wp.r)
  ctx.fillStyle = hexA(e.color, 0.35 + (sparkIn ? 0.3 : 0))
  ctx.fill()
  const ep = L.osEastPortRect()
  let emit = 0
  for (const gr of S.GRANTS) if (bi === gr.beat) emit = Math.max(emit, pulseK(frac, gr.grant[0], gr.grant[1]))
  if (bi === S.B.relaunch) emit = Math.max(emit, pulseK(frac, 0.42, 0.58))
  if (bi === S.B.anotherProgram) emit = Math.max(emit, pulseK(frac, 0.44, 0.58))
  rrPath(ctx, ep.x, ep.y, ep.w, ep.h, ep.r)
  ctx.fillStyle = hexA(M.COL.process, 0.3 + 0.6 * emit)
  ctx.fill()
  if (emit > 0.02) {
    ctx.strokeStyle = hexA(M.COL.process, 0.7 * emit)
    ctx.lineWidth = 2.5
    ctx.beginPath()
    ctx.arc(L.osEastPort().x, L.osEastPort().y, 14 + 26 * emit, -Math.PI / 3, Math.PI / 3)
    ctx.stroke()
  }

  // the management core — three labeled action tracks (labels earned in CH01)
  const c = L.osCoreRect()
  rrPath(ctx, c.x, c.y, c.w, c.h, c.r)
  ctx.fillStyle = hexA('#0b1026', 0.22)
  ctx.fill()
  for (let i = 0; i < 3; i++) {
    const row = L.osRowRect(i)
    const gk = rowGlow[i]
    rrPath(ctx, row.x, row.y, row.w, row.h, row.r)
    ctx.fillStyle = hexA(e.color, 0.07 + 0.22 * gk)
    ctx.fill()
    if (gk > 0.05) {
      ctx.strokeStyle = hexA(e.color, 0.25 + 0.55 * gk)
      ctx.lineWidth = 1.5
      ctx.stroke()
    }
    label(ctx, T(S.CAP.osRows[i], lang), { x: row.x + row.w / 2, y: row.y + row.h / 2 + 1 }, {
      size: M.F.micro, color: hexA('#eaf0ff', 0.55 + 0.35 * gk), weight: 700,
    })
  }
  ctx.restore()
}

// ===========================================================================
// MACHINE BAY — quiet physical context (LOK-07). Its CPU slot carries a soft
// glint ONLY while an execution point is advancing (truthful ambient); memory
// grants never light it (blocks "the column is the RAM stick").
// ===========================================================================
function drawCpuGlyph(ctx: CanvasRenderingContext2D, cx: number, cy: number, color: string) {
  const sz = 20
  const x = cx - sz / 2
  const y = cy - sz / 2
  ctx.fillStyle = hexA(color, 0.85)
  for (let i = 0; i < 4; i++) {
    const px = x + 3.5 + i * ((sz - 7) / 3)
    ctx.fillRect(px - 1.2, y - 3.5, 2.4, 3.5)
    ctx.fillRect(px - 1.2, y + sz, 2.4, 3.5)
  }
  rrPath(ctx, x, y, sz, sz, 4)
  ctx.fillStyle = hexA(color, 0.22)
  ctx.fill()
  ctx.strokeStyle = hexA(color, 0.9)
  ctx.lineWidth = 1.6
  ctx.stroke()
  ctx.fillStyle = hexA('#fff3c0', 0.95)
  ctx.beginPath()
  ctx.arc(cx, cy, 4.4, 0, TAU)
  ctx.fill()
  ctx.fillStyle = hexA(color, 0.95)
  ctx.beginPath()
  ctx.arc(cx, cy, 2.3, 0, TAU)
  ctx.fill()
}
function drawRamGlyph(ctx: CanvasRenderingContext2D, cx: number, cy: number, color: string) {
  const w = 28
  const h = 18
  const x = cx - w / 2
  const y = cy - h / 2
  rrPath(ctx, x, y, w, h, 4)
  ctx.fillStyle = hexA(color, 0.22)
  ctx.fill()
  ctx.strokeStyle = hexA(color, 0.9)
  ctx.lineWidth = 1.6
  ctx.stroke()
  ctx.fillStyle = hexA(color, 0.9)
  for (let i = 0; i < 4; i++) ctx.fillRect(x + 4 + i * 5.6, y + 3.6, 3, h - 7.2)
}
function drawIoGlyph(ctx: CanvasRenderingContext2D, cx: number, cy: number, color: string) {
  const w = 28
  const h = 16
  const x = cx - w / 2
  const y = cy - h / 2
  ctx.beginPath()
  ctx.moveTo(x, y + h)
  ctx.lineTo(x + 4, y)
  ctx.lineTo(x + w - 4, y)
  ctx.lineTo(x + w, y + h)
  ctx.closePath()
  ctx.fillStyle = hexA(color, 0.22)
  ctx.fill()
  ctx.strokeStyle = hexA(color, 0.9)
  ctx.lineWidth = 1.6
  ctx.stroke()
  ctx.fillStyle = hexA(color, 0.9)
  for (let i = 0; i < 4; i++) ctx.fillRect(x + 4.5 + i * 5.6, y + h, 2.8, 3.2)
}

/** Is ANY execution point advancing at (beat, frac)? (A's marker or the
 *  climax; B's point never advances — by construction.) */
function anyAdvancing(bi: number, frac: number): boolean {
  return S.markerA(bi, frac).advancing
}

export const drawMachineBay: EntityRenderer = (ctx, s, e, active) => {
  const r = L.machineRect()
  const bi = s.beatIndex
  const frac = beatFrac(s)
  const lang = s.lang as Lang

  const running = anyAdvancing(bi, frac)
  const ioAck = bi === S.B.resources ? pulseK(frac, S.IO_ACK.from, S.IO_ACK.to) : 0

  ctx.save()
  if (active) glow(ctx, e.pos, e.color, 110, 0.22)

  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fillStyle = hexA('#0b1026', 0.28)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.8 : 0.4)
  ctx.lineWidth = 1.5
  ctx.stroke()

  label(ctx, T(S.CAP.machineTitle, lang), { x: e.pos.x, y: r.y + 20 }, {
    size: M.F.machineTitle, color: hexA('#eaf0ff', 0.9), weight: 700,
  })

  const resCols = [M.COL.machine, M.COL.ram, M.COL.io]
  for (let i = 0; i < 3; i++) {
    const slot = L.machineSlotRect(i)
    // the CPU slot's truthful glint: an execution point is advancing NOW
    const gk = i === 0 && running ? 0.5 + 0.2 * Math.sin(s.t * 0.006) : i === 2 ? ioAck : 0
    rrPath(ctx, slot.x, slot.y, slot.w, slot.h, slot.r)
    ctx.fillStyle = hexA(resCols[i], 0.12 + 0.1 * gk)
    ctx.fill()
    ctx.strokeStyle = hexA(resCols[i], 0.38 + 0.4 * gk)
    ctx.lineWidth = 1.2
    ctx.stroke()
    const gx = slot.x + 18
    const gy = slot.y + slot.h / 2
    if (i === 0) drawCpuGlyph(ctx, gx, gy, resCols[i])
    else if (i === 1) drawRamGlyph(ctx, gx, gy, resCols[i])
    else drawIoGlyph(ctx, gx, gy, resCols[i])
    label(ctx, S.CAP.machineRes[i], { x: slot.x + 38, y: slot.y + slot.h / 2 + 1 }, {
      size: M.F.machineRes, color: hexA('#eaf0ff', 0.8), mono: true, align: 'left',
    })
  }
  ctx.restore()
}

// ===========================================================================
// PROCESS FIELD — Process A (looked into), Process B (held), grants, pills.
// ===========================================================================

/** Rounded-rect boundary sweep (CH01 birth grammar). */
function boundarySweep(ctx: CanvasRenderingContext2D, r: L.Rect, sweep: number, color: string) {
  if (sweep <= 0.02 || sweep >= 0.999) return
  const rr = Math.min(r.r, r.w / 2, r.h / 2)
  const perim = 2 * (r.w - 2 * rr) + 2 * (r.h - 2 * rr) + TAU * rr
  ctx.save()
  ctx.strokeStyle = hexA(color, 0.9)
  ctx.lineWidth = 2.5
  ctx.setLineDash([perim, perim])
  ctx.lineDashOffset = perim * (1 - sweep)
  rrPath(ctx, r.x, r.y, r.w, r.h, rr)
  ctx.stroke()
  ctx.setLineDash([])
  ctx.restore()
}

/** Birth (bloom + pulse + sweep), k in [0,1] — CH01 materialization grammar. */
function drawBirth(ctx: CanvasRenderingContext2D, r: L.Rect, c: Vec2, k: number) {
  const pk = pulseK(k, 0, 0.55)
  if (pk > 0) {
    ctx.strokeStyle = hexA(M.COL.process, 0.8 * pk)
    ctx.lineWidth = M.PULSE.ring
    ctx.beginPath()
    ctx.arc(c.x, c.y, 12 + M.PULSE.birthR * k, 0, TAU)
    ctx.stroke()
  }
  if (k > 0.05 && k < 0.9) {
    const bloomR = (Math.max(r.w, r.h) / 2) * (0.35 + 0.65 * easeInOutCubic(k))
    const g = ctx.createRadialGradient(c.x, c.y, 0, c.x, c.y, bloomR)
    g.addColorStop(0, hexA(M.COL.process, 0.2 * Math.sin(k * Math.PI)))
    g.addColorStop(1, hexA(M.COL.process, 0))
    ctx.fillStyle = g
    ctx.beginPath()
    ctx.arc(c.x, c.y, bloomR, 0, TAU)
    ctx.fill()
  }
  boundarySweep(ctx, r, easeInOutCubic(ramp(k, 0.25, 1)), M.COL.process)
}

/** A PID chip resolving in place (CH01 identity grammar), a in [0,1]. */
function drawChip(ctx: CanvasRenderingContext2D, chip: L.Rect, pid: number, a: number) {
  if (a <= 0.02) return
  const cx = chip.x + chip.w / 2
  const cy = chip.y + chip.h / 2
  const scale = 1.12 - 0.12 * easeInOutCubic(a)
  const w = chip.w * scale
  const h = chip.h * scale
  ctx.save()
  ctx.globalAlpha = a
  rrPath(ctx, cx - w / 2, cy - h / 2, w, h, chip.r * scale)
  ctx.fillStyle = hexA('#0b1026', 0.88)
  ctx.fill()
  ctx.strokeStyle = hexA(M.COL.os, 0.9)
  ctx.lineWidth = 1.5
  ctx.stroke()
  label(ctx, `${S.CAP.chipPrefix} ${pid}`, { x: cx, y: cy + 1 }, {
    size: M.F.chipText, color: '#ffffff', weight: 800, mono: true,
  })
  ctx.restore()
}

/** A gold execution-point marker over a fractional code row. */
function markerRect(row: number, heapH: number, compact: boolean): L.Rect {
  if (compact) {
    const r0 = L.codeRowRectB(0)
    const rowH = r0.h
    const b = L.bandRectB(0)
    const rr = Math.min(row, M.CODE_ROWS_B - 1)
    return { x: r0.x, y: b.y + M.CODE_ROW_PAD + rr * rowH, w: r0.w, h: rowH, r: 3 }
  }
  const r0 = L.codeRowRect(0, heapH)
  const rowH = r0.h
  const b = L.bandRect(0, heapH)
  const indent = row >= S.SUB_FROM - 0.5 ? 12 : 0
  return { x: r0.x + indent, y: b.y + M.CODE_ROW_PAD + row * rowH, w: r0.w - indent, h: rowH, r: 3 }
}

function drawMarker(
  ctx: CanvasRenderingContext2D,
  r: L.Rect,
  advancing: boolean,
  t: number,
  alpha = 1,
) {
  if (alpha <= 0.02) return
  ctx.save()
  ctx.globalAlpha = alpha
  const c = { x: r.x + r.w / 2, y: r.y + r.h / 2 }
  // held points glint slowly; advancing points burn steady + leading edge
  const heldGlint = advancing ? 1 : 0.62 + 0.18 * Math.sin(t * 0.0022)
  glow(ctx, c, M.COL.gold, 44, 0.3 * heldGlint)
  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fillStyle = hexA(M.COL.gold, 0.3 * heldGlint)
  ctx.fill()
  ctx.strokeStyle = hexA(M.COL.gold, 0.95 * heldGlint)
  ctx.lineWidth = 1.8
  ctx.stroke()
  if (advancing) {
    ctx.fillStyle = hexA('#fff3c0', 0.95)
    ctx.beginPath()
    ctx.arc(r.x + r.w - 8, c.y, 3.2, 0, TAU)
    ctx.fill()
  }
  ctx.restore()
}

/** One code row's instruction stub (two tone bars — no real text: code rows
 *  are structure, not readable program listings). */
function drawCodeRow(ctx: CanvasRenderingContext2D, r: L.Rect, sub: boolean, a: number) {
  if (a <= 0.02) return
  ctx.save()
  ctx.globalAlpha = a
  const indent = sub ? 12 : 0
  const y = r.y + r.h / 2
  ctx.strokeStyle = hexA(sub ? '#9fb4d8' : '#cfe0ff', sub ? 0.4 : 0.55)
  ctx.lineWidth = 2.4
  ctx.lineCap = 'round'
  ctx.beginPath()
  ctx.moveTo(r.x + 4 + indent, y)
  ctx.lineTo(r.x + 4 + indent + r.w * 0.28, y)
  ctx.stroke()
  ctx.strokeStyle = hexA(sub ? '#7e93b8' : '#9fb4d8', sub ? 0.3 : 0.4)
  ctx.beginPath()
  ctx.moveTo(r.x + 12 + indent + r.w * 0.28, y)
  ctx.lineTo(r.x + 12 + indent + r.w * 0.28 + r.w * (sub ? 0.22 : 0.34), y)
  ctx.stroke()
  ctx.restore()
}

/** A GRANT's moving parts: request comet cell → OS, grant arc OS → cell. */
function drawGrantMotion(
  ctx: CanvasRenderingContext2D,
  gr: S.Grant,
  frac: number,
  cellC: Vec2,
  aux = false,
) {
  const osP = L.osEastPort()
  const w = aux ? 0.55 : 1 // climax = auxiliary weight (§18)
  // need cue: a small ring at the cell edge
  const needK = pulseK(frac, gr.need[0], gr.need[1])
  if (needK > 0.02) {
    ctx.strokeStyle = hexA(M.COL.process, 0.6 * needK * w)
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.arc(cellC.x, cellC.y, 14 + 10 * needK, 0, TAU)
    ctx.stroke()
  }
  // request comet: cell → OS (green — the Process asking)
  const reqK = ramp(frac, gr.req[0], gr.req[1])
  if (reqK > 0 && reqK < 1) {
    const p = { x: lerp(cellC.x, osP.x, easeInOutCubic(reqK)), y: lerp(cellC.y, osP.y, easeInOutCubic(reqK)) }
    glow(ctx, p, M.COL.process, 26 * w, 0.35 * w)
    ctx.fillStyle = hexA('#d9ffe6', 0.85 * w)
    ctx.beginPath()
    ctx.arc(p.x, p.y, 4 * w + 1, 0, TAU)
    ctx.fill()
  }
  // grant arc: OS → cell (pink — the OS granting)
  const gk = ramp(frac, gr.grant[0], gr.grant[1])
  if (gk > 0 && gk < 1) {
    const p = { x: lerp(osP.x, cellC.x, easeInOutCubic(gk)), y: lerp(osP.y, cellC.y, easeInOutCubic(gk)) }
    glow(ctx, p, M.COL.os, 30 * w, 0.4 * w)
    ctx.fillStyle = hexA('#ffe1f0', 0.9 * w)
    ctx.beginPath()
    ctx.arc(p.x, p.y, 5 * w + 1, 0, TAU)
    ctx.fill()
    // the grant trails a short pink thread back toward the OS
    ctx.strokeStyle = hexA(M.COL.os, 0.35 * w * (1 - gk))
    ctx.lineWidth = 1.5
    ctx.beginPath()
    ctx.moveTo(osP.x, osP.y)
    ctx.lineTo(p.x, p.y)
    ctx.stroke()
  }
}

/** A handle chip (docked resource token). */
function drawHandle(
  ctx: CanvasRenderingContext2D,
  chip: L.Rect,
  id: 'file' | 'display',
  text: string,
  a: number,
  useBlink = 0,
) {
  if (a <= 0.02) return
  ctx.save()
  ctx.globalAlpha = a
  rrPath(ctx, chip.x, chip.y, chip.w, chip.h, chip.r)
  ctx.fillStyle = hexA('#0b1026', 0.75)
  ctx.fill()
  ctx.strokeStyle = hexA(M.COL.os, 0.75 + 0.25 * useBlink)
  ctx.lineWidth = 1.5 + useBlink
  ctx.stroke()
  // mini glyph on the left
  const gx = chip.x + 15
  const gy = chip.y + chip.h / 2
  ctx.strokeStyle = hexA(M.COL.program, 0.9)
  ctx.lineWidth = 1.5
  if (id === 'file') {
    ctx.strokeRect(gx - 5, gy - 6.5, 10, 13)
    ctx.beginPath()
    ctx.moveTo(gx - 2.5, gy - 2)
    ctx.lineTo(gx + 2.5, gy - 2)
    ctx.moveTo(gx - 2.5, gy + 2)
    ctx.lineTo(gx + 2.5, gy + 2)
    ctx.stroke()
  } else {
    ctx.strokeRect(gx - 6.5, gy - 5, 13, 9)
    ctx.beginPath()
    ctx.moveTo(gx - 3, gy + 6.5)
    ctx.lineTo(gx + 3, gy + 6.5)
    ctx.stroke()
  }
  label(ctx, text, { x: gx + 12, y: gy + 1 }, {
    size: M.F.handleText, color: '#eaf0ff', align: 'left', mono: true,
  })
  ctx.restore()
}

/** A ring around a rect (concept grouping). */
function ringRect(ctx: CanvasRenderingContext2D, r: L.Rect, pad: number, color: string, a: number) {
  if (a <= 0.02) return
  ctx.save()
  ctx.strokeStyle = hexA(color, 0.85 * a)
  ctx.lineWidth = M.RING.w
  ctx.setLineDash([9, 7])
  rrPath(ctx, r.x - pad, r.y - pad, r.w + 2 * pad, r.h + 2 * pad, r.r + pad)
  ctx.stroke()
  ctx.setLineDash([])
  ctx.restore()
}

// ---------------------------------------------------------------------------
// Process A interior
// ---------------------------------------------------------------------------
function drawCellAInterior(ctx: CanvasRenderingContext2D, s: { t: number; lang: Lang }, bi: number, frac: number) {
  const lang = s.lang
  const heapH = S.heapHAt(bi, frac)
  const quiet = bi === S.B.exactPoint ? 1 - 0.68 * ramp(frac, S.QUIET.from, S.QUIET.to) : 1

  // ---- the private memory column (materializes during GRANT_SPACE.grow) ----
  const colK =
    bi > S.B.space ? 1 : bi === S.B.space ? easeInOutCubic(ramp(frac, S.GRANT_SPACE.grow[0], S.GRANT_SPACE.grow[1])) : 0
  if (colK > 0.02) {
    const col = L.colA()
    ctx.save()
    ctx.globalAlpha = colK
    // soft private-space tint — green family (part of the Process), NEVER the
    // machine's RAM violet
    rrPath(ctx, col.x, col.y, col.w, col.h, col.r)
    ctx.fillStyle = hexA(M.COL.process, 0.05)
    ctx.fill()
    ctx.strokeStyle = hexA(M.COL.process, 0.4 * quiet)
    ctx.lineWidth = 1.5
    ctx.stroke()
    boundarySweep(ctx, col, colK, M.COL.process)

    // ---- bands ----
    const bandAlpha = [
      // code band exists once the space exists (empty until the copy)
      colK,
      bi > S.B.firstRun ? 1 : bi === S.B.firstRun ? ramp(frac, 0.24, 0.4) : 0,
      bi > S.B.heap ? 1 : bi === S.B.heap ? ramp(frac, S.GRANT_HEAP.grow[0], S.GRANT_HEAP.grow[1]) : bi >= S.B.firstRun ? 0.28 : 0,
      bi > S.B.firstRun || (bi === S.B.firstRun && frac > 0.2) ? 1 : 0,
    ]
    const labelOn = [
      S.after(bi, frac, S.LABEL_CODE) ? 1 : 0,
      S.after(bi, frac, S.LABEL_DATA) ? 1 : 0,
      S.after(bi, frac, S.LABEL_HEAP) ? 1 : 0,
      S.after(bi, frac, S.LABEL_STACK) ? 1 : 0,
    ]
    for (let i = 0; i < 4; i++) {
      const a = bandAlpha[i] * (i === 0 ? 1 : quiet)
      if (a <= 0.02) continue
      const b = L.bandRect(i, heapH)
      ctx.globalAlpha = a * colK
      rrPath(ctx, b.x, b.y, b.w, b.h, b.r)
      ctx.fillStyle = hexA(M.COL.process, i === 0 ? 0.09 : 0.06)
      ctx.fill()
      ctx.strokeStyle = hexA(M.COL.process, 0.22)
      ctx.lineWidth = 1
      ctx.stroke()
      if (labelOn[i]) {
        // 24px offset clears the Address-Space ring at its widest spread.
        label(ctx, T(S.CAP.bands[i], lang), { x: b.x + b.w + 24, y: b.y + 10 }, {
          size: M.F.bandLabel, color: hexA('#cfe0ff', 0.75 * a), align: 'left', mono: true,
        })
      }
    }

    // ---- code rows (condense during the copy stream) ----
    const fillK = bi > S.B.code ? 1 : bi === S.B.code ? ramp(frac, S.CODE_FILL.from, S.CODE_FILL.to) : 0
    if (fillK > 0.02) {
      for (let i = 0; i < M.CODE_ROWS - 1; i++) {
        const rowA = clamp(fillK * (M.CODE_ROWS - 1) - i, 0, 1)
        const sub = i >= S.SUB_FROM
        drawCodeRow(ctx, L.codeRowRect(i, heapH), sub, rowA * (0.5 + 0.5 * quiet))
      }
    }

    // ---- data tokens (T01 value glyphs, settled) ----
    const dataN = S.dataCountA(bi, frac)
    if (dataN > 0 && bandAlpha[1] > 0.1) {
      const db = L.bandRect(1, heapH)
      for (let i = 0; i < dataN; i++) {
        const gx = db.x + 20 + i * 34
        label(ctx, M.GLYPHS[i % 4], { x: gx, y: db.y + db.h / 2 + 1 }, {
          size: M.F.regGlyph, color: hexA(M.GLYPH_COLS[i % 4], 0.9 * quiet), weight: 700,
        })
      }
    }

    // ---- heap fill blocks (the granted room being used) ----
    if (bandAlpha[2] > 0.3) {
      const hb = L.bandRect(2, heapH)
      const used = clamp((heapH - 14) / M.HEAP_H.max, 0, 1)
      const n = Math.floor(3 + used * 3)
      for (let i = 0; i < n; i++) {
        const bw = (hb.w - 8 - (n - 1) * 4) / n
        rrPath(ctx, hb.x + 4 + i * (bw + 4), hb.y + 6, bw, hb.h - 12, 3)
        ctx.fillStyle = hexA(M.COL.process, 0.18 * quiet)
        ctx.fill()
      }
    }

    // ---- stack slats + top tick ----
    const depth = S.stackDepthA(bi, frac)
    if (depth > 0.02 && bandAlpha[3] > 0.1) {
      const sb = L.bandRect(3, heapH)
      const slatH = 16
      const full = Math.floor(depth + 0.0001)
      const partial = depth - full
      for (let i = 0; i < full + (partial > 0.02 ? 1 : 0); i++) {
        const a = i < full ? 1 : easeInOutCubic(partial)
        const y = sb.y + sb.h - 6 - (i + 1) * (slatH + 4) + (1 - a) * 10
        ctx.globalAlpha = a * quiet * colK
        rrPath(ctx, sb.x + 8, y + 4, sb.w - 16, slatH, 4)
        ctx.fillStyle = hexA(M.COL.process, 0.2)
        ctx.fill()
        ctx.strokeStyle = hexA(M.COL.process, 0.5)
        ctx.lineWidth = 1.2
        ctx.stroke()
      }
      // the gold top tick — where the stack currently ends
      const topY = sb.y + sb.h - 6 - depth * (slatH + 4) + 4
      ctx.globalAlpha = quiet < 1 && bi === S.B.exactPoint ? quiet : 1
      ctx.fillStyle = hexA(M.COL.gold, 0.9)
      ctx.beginPath()
      ctx.moveTo(sb.x + 2, topY)
      ctx.lineTo(sb.x + 2 + M.STACK_TICK.w, topY - M.STACK_TICK.h / 2)
      ctx.lineTo(sb.x + 2 + M.STACK_TICK.w, topY + M.STACK_TICK.h / 2)
      ctx.closePath()
      ctx.fill()
    }
    ctx.restore()
  }

  // ---- register strip (right-lower; T01 vocabulary) ----
  const regsOn = S.after(bi, frac, S.LABEL_REGS)
  if (regsOn) {
    ctx.save()
    ctx.globalAlpha = quiet
    const mk = S.markerA(bi, frac)
    for (let i = 0; i < M.REG_A.n; i++) {
      const r = L.regSlotA(i)
      rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
      ctx.fillStyle = hexA('#0b1026', 0.5)
      ctx.fill()
      ctx.strokeStyle = hexA(M.COL.process, 0.4)
      ctx.lineWidth = 1.2
      ctx.stroke()
      if (mk.row !== null) {
        const gi = (Math.floor(mk.row * 1.7) + i) % 4
        label(ctx, M.GLYPHS[gi], { x: r.x + r.w / 2, y: r.y + r.h / 2 + 1 }, {
          size: M.F.regGlyph, color: hexA(M.GLYPH_COLS[gi], 0.9), weight: 700,
        })
      }
    }
    const r0 = L.regSlotA(0)
    label(ctx, T(S.CAP.registers, lang), { x: r0.x, y: r0.y - 10 }, {
      size: M.F.bandLabel, color: hexA('#cfe0ff', 0.6 * quiet), align: 'left', mono: true,
    })
    ctx.restore()
  }

  // ---- handle chips ----
  for (const h of S.HANDLES_A) {
    const docked = S.after(bi, frac, h.dockAt)
    const gr = h.id === 'file' ? S.GRANT_FILE : S.GRANT_DISPLAY
    const resolving = bi === gr.beat ? ramp(frac, gr.grow[0], gr.grow[1]) : 0
    const a = docked ? 1 : resolving
    const useBlink =
      bi === S.B.climax && h.id === 'file' ? pulseK(frac, S.CLIMAX_FILE_USE.from, S.CLIMAX_FILE_USE.to) : 0
    drawHandle(ctx, L.dockChipA(h.slot), h.id, T(h.label, lang), a * quiet, useBlink)
  }

  // ---- the gold execution point ----
  const mk = S.markerA(bi, frac)
  if (mk.row !== null) {
    drawMarker(ctx, markerRect(mk.row, heapH, false), mk.advancing, s.t)
  }
}

// ---------------------------------------------------------------------------
// Process B interior (compact; formed inside B14; point HELD forever)
// ---------------------------------------------------------------------------
function drawCellB(ctx: CanvasRenderingContext2D, s: { t: number; lang: Lang }, bi: number, frac: number) {
  const born = bi > S.B.anotherProgram || (bi === S.B.anotherProgram && frac >= S.B_FORM.birth)
  if (!born) return
  const r = L.cellB()
  const c = { x: r.x + r.w / 2, y: r.y + r.h / 2 }
  const lang = s.lang

  const birthK = bi === S.B.anotherProgram ? ramp(frac, S.B_FORM.birth, S.B_FORM.alive) : 1
  if (birthK < 1) drawBirth(ctx, r, c, birthK)
  const bodyA = bi === S.B.anotherProgram ? easeInOutCubic(ramp(frac, S.B_FORM.birth + 0.06, S.B_FORM.alive)) : 1
  if (bodyA <= 0.02) return

  ctx.save()
  ctx.globalAlpha = bodyA
  const breathe = 0.5 + 0.5 * Math.sin(s.t * 0.0016 + 2.4)
  glow(ctx, c, M.COL.process, 90, 0.08 + 0.03 * breathe)
  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fillStyle = hexA(M.COL.process, 0.08)
  ctx.fill()
  ctx.strokeStyle = hexA(M.COL.process, 0.75 + 0.08 * breathe)
  ctx.lineWidth = 2.2
  ctx.stroke()

  // header (de-windowed): caption + provenance (Notes)
  label(ctx, T(S.CAP.cellCaption, lang), { x: r.x + M.HEAD_B.capX, y: r.y + M.HEAD_B.capY }, {
    size: M.F.cellCaption, color: hexA('#eaf0ff', 0.8), weight: 800, align: 'left',
  })
  label(ctx, T(S.CAP.appNotes, lang), { x: r.x + M.HEAD_B.capX, y: r.y + M.HEAD_B.srcY }, {
    size: M.F.sourceCue, color: hexA(M.COL.program, 0.55), weight: 600, align: 'left',
  })

  // its own column + bands
  const colK = bi === S.B.anotherProgram ? ramp(frac, S.B_FORM.column[0], S.B_FORM.column[1]) : 1
  if (colK > 0.02) {
    const col = L.colB()
    ctx.globalAlpha = bodyA * colK
    rrPath(ctx, col.x, col.y, col.w, col.h, col.r)
    ctx.fillStyle = hexA(M.COL.process, 0.05)
    ctx.fill()
    ctx.strokeStyle = hexA(M.COL.process, 0.35)
    ctx.lineWidth = 1.2
    ctx.stroke()
    for (let i = 0; i < 4; i++) {
      const b = L.bandRectB(i)
      rrPath(ctx, b.x, b.y, b.w, b.h, b.r)
      ctx.fillStyle = hexA(M.COL.process, i === 0 ? 0.08 : 0.05)
      ctx.fill()
      label(ctx, T(S.CAP.bands[i], lang), { x: b.x + b.w + 6, y: b.y + 8 }, {
        size: M.F.micro, color: hexA('#cfe0ff', 0.55), align: 'left', mono: true,
      })
    }
    const fillK = bi === S.B.anotherProgram ? ramp(frac, S.B_FORM.codeFill[0], S.B_FORM.codeFill[1]) : 1
    for (let i = 0; i < M.CODE_ROWS_B - 1; i++) {
      const rowA = clamp(fillK * (M.CODE_ROWS_B - 1) - i, 0, 1)
      drawCodeRow(ctx, L.codeRowRectB(i), false, rowA * 0.9)
    }
  }

  // its own handle
  const hK = bi === S.B.anotherProgram ? ramp(frac, S.B_FORM.handle[0], S.B_FORM.handle[1]) : 1
  drawHandle(ctx, L.dockChipB(), 'display', T({ en: 'display', vi: 'màn hình' }, lang), hK * bodyA)

  // its own registers (2 slots)
  if (hK > 0.5 || bi > S.B.anotherProgram) {
    for (let i = 0; i < M.REG_B.n; i++) {
      const rr = L.regSlotB(i)
      rrPath(ctx, rr.x, rr.y, rr.w, rr.h, rr.r)
      ctx.fillStyle = hexA('#0b1026', 0.5)
      ctx.fill()
      ctx.strokeStyle = hexA(M.COL.process, 0.35)
      ctx.lineWidth = 1.1
      ctx.stroke()
      const gi = (S.B_HELD_ROW + i * 2) % 4
      label(ctx, M.GLYPHS[gi], { x: rr.x + rr.w / 2, y: rr.y + rr.h / 2 + 1 }, {
        size: M.F.regGlyph - 2, color: hexA(M.GLYPH_COLS[gi], 0.85), weight: 700,
      })
    }
  }

  // its own execution point — resolves once, then stands HELD (never advances)
  const mkOn = bi > S.B.anotherProgram || (bi === S.B.anotherProgram && frac >= S.B_FORM.marker[0])
  if (mkOn) {
    const mkA = bi === S.B.anotherProgram ? ramp(frac, S.B_FORM.marker[0], S.B_FORM.marker[1]) : 1
    drawMarker(ctx, markerRect(S.B_HELD_ROW, 0, true), false, s.t, mkA * bodyA)
    // B15: the held-point acknowledgment ring — visibly NOT advancing
    if (bi === S.B.oneMachine) {
      const k = pulseK(frac, S.HELD_ACK.from, S.HELD_ACK.to)
      if (k > 0.02) ringRect(ctx, markerRect(S.B_HELD_ROW, 0, true), 6 + 4 * k, M.COL.gold, k)
    }
  }

  // PID chip
  const chipA_ =
    bi > S.B.anotherProgram ? 1 : frac >= S.B_FORM.chip[1] ? 1 : ramp(frac, S.B_FORM.chip[0], S.B_FORM.chip[1])
  drawChip(ctx, L.chipB(), S.PID_B, chipA_ * bodyA)
  ctx.restore()
}

// ---------------------------------------------------------------------------
// THE FIELD painter
// ---------------------------------------------------------------------------
export const drawProcessField: EntityRenderer = (ctx, s, _e, _active) => {
  const bi = s.beatIndex
  const frac = beatFrac(s)
  const lang = s.lang as Lang
  const st = { t: s.t, lang }

  // =========================================================================
  // Process A — the focus cell
  // =========================================================================
  const aBorn = bi > S.B.relaunch || (bi === S.B.relaunch && frac >= S.A_BIRTH.birth)
  if (aBorn) {
    const r = L.cellA()
    const c = { x: r.x + r.w / 2, y: r.y + r.h / 2 }
    const birthK = bi === S.B.relaunch ? ramp(frac, S.A_BIRTH.birth, S.A_BIRTH.alive) : 1
    if (birthK < 1) drawBirth(ctx, r, c, birthK)
    const bodyA = bi === S.B.relaunch ? easeInOutCubic(ramp(frac, S.A_BIRTH.birth + 0.05, S.A_BIRTH.alive)) : 1

    if (bodyA > 0.02) {
      ctx.save()
      ctx.globalAlpha = bodyA
      const breathe = 0.5 + 0.5 * Math.sin(s.t * 0.0016)
      glow(ctx, c, M.COL.process, 130, 0.08 + 0.03 * breathe)
      rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
      ctx.fillStyle = hexA(M.COL.process, 0.07)
      ctx.fill()
      ctx.strokeStyle = hexA(M.COL.process, 0.8 + 0.08 * breathe)
      ctx.lineWidth = 2.5
      ctx.stroke()

      // header — de-windowed (no divider): Process (title) > Photos (subtitle)
      label(ctx, T(S.CAP.cellCaption, lang), { x: r.x + M.HEAD_A.capX, y: r.y + M.HEAD_A.capY }, {
        size: M.F.cellCaption, color: hexA('#eaf0ff', 0.85), weight: 800, align: 'left',
      })
      label(ctx, T(S.CAP.appPhotos, lang), { x: r.x + M.HEAD_A.capX, y: r.y + M.HEAD_A.srcY }, {
        size: M.F.sourceCue, color: hexA(M.COL.program, 0.55), weight: 600, align: 'left',
      })

      // B02 — the empty-interior scan: a dashed ring sweeps the vacant inside
      if (bi === S.B.emptyShell) {
        const k = pulseK(frac, S.EMPTY_SCAN.from, S.EMPTY_SCAN.to)
        if (k > 0.02) {
          ctx.save()
          ctx.strokeStyle = hexA('#ffffff', 0.5 * k)
          ctx.lineWidth = 1.8
          ctx.setLineDash([7, 8])
          const pad = 26 + 16 * (1 - k)
          rrPath(ctx, r.x + pad, r.y + 58, r.w - 2 * pad, r.h - 58 - pad, 12)
          ctx.stroke()
          ctx.setLineDash([])
          label(ctx, '?', { x: c.x, y: c.y + 10 }, {
            size: M.F.mark, color: hexA('#ffffff', 0.7 * k), weight: 800,
          })
          ctx.restore()
        }
      }

      drawCellAInterior(ctx, st, bi, frac)

      // PID chip (resolves at the end of the birth beat, CH01 grammar)
      const chipK =
        bi > S.B.relaunch ? 1 : frac >= S.A_BIRTH.chipDock ? 1 : ramp(frac, S.A_BIRTH.chip, S.A_BIRTH.chipDock)
      drawChip(ctx, L.chipA(), S.PID_A, chipK)
      ctx.restore()
    }

    // ---- concept rings on A ----
    if (bi === S.B.addressSpace) {
      const k = ramp(frac, S.AS_RING.from, S.AS_RING.to)
      const rel = 1 - ramp(frac, 0.9, 1)
      if (k > 0.02) ringRect(ctx, L.colA(), 8 + 6 * (1 - easeInOutCubic(k)), M.COL.process, Math.min(k, rel))
    }
    if (bi === S.B.snapshot) {
      const kS = pulseK(frac, S.SNAP_SMALL.from, S.SNAP_SMALL.to + 0.3)
      const heapH = S.heapHAt(bi, frac)
      const mk = S.markerA(bi, frac)
      if (kS > 0.02 && mk.row !== null) {
        ringRect(ctx, markerRect(mk.row, heapH, false), 5, M.COL.gold, kS)
        // registers ring
        const r0 = L.regSlotA(0)
        const rn = L.regSlotA(M.REG_A.n - 1)
        ringRect(ctx, { x: r0.x, y: r0.y, w: rn.x + rn.w - r0.x, h: r0.h, r: 8 }, 6, M.COL.gold, kS)
        // stack-top ring
        const sb = L.bandRect(3, heapH)
        ringRect(ctx, { x: sb.x, y: sb.y + sb.h - 30, w: sb.w, h: 26, r: 6 }, 4, M.COL.gold, kS)
      }
      const kB = ramp(frac, S.SNAP_BIG.from, S.SNAP_BIG.to)
      if (kB > 0.02) {
        // one enclosing ring: the three ARE one state
        const col = L.colA()
        const rn = L.regSlotA(M.REG_A.n - 1)
        const enclosing = {
          x: col.x - 4,
          y: col.y + 40,
          w: rn.x + rn.w - col.x + 12,
          h: col.h - 36,
          r: 14,
        }
        ringRect(ctx, enclosing, 6 * easeInOutCubic(kB), M.COL.gold, kB * (1 - ramp(frac, 0.92, 1)))
      }
    }
    if (bi === S.B.execContext) {
      // micro-labels: position = Program Counter · stack top = Stack Pointer.
      // They live in the FREE lower-right area of the cell (below the
      // register strip — nothing is drawn there), each with a thin gold
      // leader line to its target, so they never collide with the handles
      // or the register slots.
      const k = ramp(frac, S.EC_LABELS.from, S.EC_LABELS.to)
      if (k > 0.02) {
        const heapH = S.heapHAt(bi, frac)
        const mk = S.markerA(bi, frac)
        const cell = L.cellA()
        const labX = cell.x + 236
        const posY = cell.y + cell.h - 46
        const topY = posY + 24
        ctx.save()
        ctx.globalAlpha = k
        ctx.strokeStyle = hexA(M.COL.gold, 0.45)
        ctx.lineWidth = 1.2
        if (mk.row !== null) {
          const mr = markerRect(mk.row, heapH, false)
          ctx.beginPath()
          ctx.moveTo(labX - 6, posY)
          ctx.lineTo(mr.x + mr.w + 4, mr.y + mr.h / 2)
          ctx.stroke()
          label(ctx, T(S.CAP.ecPos, lang), { x: labX, y: posY }, {
            size: M.F.micro, color: hexA(M.COL.gold, 0.92), align: 'left', mono: true,
          })
        }
        const sb = L.bandRect(3, heapH)
        ctx.beginPath()
        ctx.moveTo(labX - 6, topY)
        ctx.lineTo(sb.x + sb.w + 4, sb.y + sb.h - 20)
        ctx.stroke()
        label(ctx, T(S.CAP.ecTop, lang), { x: labX, y: topY }, {
          size: M.F.micro, color: hexA(M.COL.gold, 0.92), align: 'left', mono: true,
        })
        ctx.restore()
      }
    }
  }

  // =========================================================================
  // Process B
  // =========================================================================
  drawCellB(ctx, st, bi, frac)

  // =========================================================================
  // Grant motions (request comets / grant arcs) — the OS is WATCHED granting
  // =========================================================================
  for (const gr of S.GRANTS) {
    if (bi !== gr.beat) continue
    drawGrantMotion(ctx, gr, frac, { x: M.A_C.x - M.CELL_A.w / 2 + 30, y: M.A_C.y }, gr === S.GRANT_CLIMAX)
  }

  // B04 copy stream: Photos → OS → the code band (Program pulses unchanged)
  if (bi === S.B.code) {
    const heapH = S.heapHAt(bi, frac)
    const target = L.bandRect(0, heapH)
    const route: Vec2[] = [L.P_PHOTOS, L.P_OS, { x: target.x + target.w / 2, y: target.y + target.h / 2 }]
    for (const [f0, f1] of S.COPY_COMETS) {
      const k = ramp(frac, f0, f1)
      if (k <= 0 || k >= 1) continue
      const p = polylinePoint(route, easeInOutCubic(k))
      glow(ctx, p, M.COL.program, 28, 0.4)
      ctx.fillStyle = hexA('#d9f6ff', 0.9)
      ctx.beginPath()
      ctx.arc(p.x, p.y, 4.5, 0, TAU)
      ctx.fill()
    }
  }

  // B09/climax: the file handle's logical use-link (dashed — a grant, not a pipe)
  if ((bi === S.B.file && frac > S.GRANT_FILE.grow[0]) || (bi === S.B.climax)) {
    const useK =
      bi === S.B.file
        ? pulseK(frac, S.GRANT_FILE.grow[0], Math.min(1, S.GRANT_FILE.grow[1] + 0.14))
        : pulseK(frac, S.CLIMAX_FILE_USE.from, S.CLIMAX_FILE_USE.to)
    if (useK > 0.02) {
      const chip = L.dockChipA(0)
      const from = { x: chip.x, y: chip.y + chip.h / 2 }
      const to = L.fileC()
      ctx.save()
      ctx.strokeStyle = hexA(M.COL.os, 0.4 * useK)
      ctx.lineWidth = 1.4
      ctx.setLineDash([4, 7])
      ctx.beginPath()
      ctx.moveTo(from.x, from.y)
      ctx.lineTo(to.x + M.FILE_GLYPH.w / 2 + 4, to.y)
      ctx.stroke()
      ctx.setLineDash([])
      ctx.restore()
    }
  }

  // =========================================================================
  // Term pills
  // =========================================================================
  const asA =
    bi === S.B.addressSpace
      ? ramp(frac, S.PILL_AS.from, S.PILL_AS.to)
      : bi === S.B.file
        ? 1 - ramp(frac, 0, 0.2)
        : 0
  drawTermPill(ctx, L.pillConceptC(), S.AS_TERM.term, T(S.AS_TERM.sub, s.lang), M.COL.process, asA)

  const resA =
    bi === S.B.resources
      ? ramp(frac, S.PILL_RES.from, S.PILL_RES.to)
      : bi === S.B.exactPoint
        ? 1 - ramp(frac, 0, 0.2)
        : 0
  drawTermPill(ctx, L.pillConceptC(), S.RES_TERM.term, T(S.RES_TERM.sub, s.lang), M.COL.os, resA)

  const ecA =
    bi === S.B.execContext
      ? ramp(frac, S.PILL_EC.from, S.PILL_EC.to)
      : bi === S.B.anotherProgram
        ? 1 - ramp(frac, 0, 0.2)
        : 0
  drawTermPill(ctx, L.pillEcC(), S.EC_TERM.term, T(S.EC_TERM.sub, s.lang), M.COL.gold, ecA)
}

export const RENDERER_TABLE = {
  'storage-bay': drawStorageBay,
  'os-band': drawOsBand,
  'machine-bay': drawMachineBay,
  'process-field': drawProcessField,
}
