// content/topics/02-operating-systems/02-process-execution/assemble.ts
// The full declarative assembly of Topic 02 Chapter 02 (increment 1: Inside
// a Process) — everything except the meta import. Kept meta-free so the
// chapter can be built and verified outside Vite's asset pipeline (same
// pattern as CH01 and the Topic 01 chapters).
//
// ONE scene. The world is spatially stable for the whole chapter
// (VISUAL_LANGUAGE §6): the storage bay never moves, the OS never moves, and
// the two Process cells are born and stay where they were born.

import type {
  Chapter,
  ChapterMeta,
  EntityDescription,
  HitZone,
  SceneDescription,
  Vec2,
} from '../../../../chapter-loader/types'

import { storage, os, field, machine, PATH_WORLD, BBOX_WORLD, PHOTOS_HIT_RECT } from './scenes/01-world'
import { beats } from './narration/beats'
import {
  chapterTitle, waitingLine, startButton, sceneTag, tipText, doneLabel,
} from './narration/labels'
import type { PartSpec } from './types'
import { RENDERERS } from './renderers'

// ---- helpers ----------------------------------------------------------------
const toEntity = (p: PartSpec, sceneId: string): EntityDescription => ({
  id: p.id,
  kind: p.kind ?? p.id,
  pos: p.pos,
  color: p.color,
  name: p.name,
  gloss: p.gloss,
  scene: sceneId,
  extra: p.extra,
  labelSize: p.labelSize,
})

// ---- the world scene ----------------------------------------------------------
// Paint order: field first? No — the field cells sit east of the OS; painting
// storage → os → field → machine keeps labels above regional washes exactly
// as CH01 does (the field painter draws no backdrop wash).
const worldScene: SceneDescription = {
  id: 'world',
  bbox: BBOX_WORLD,
  cameraPad: 0.92,
  path: PATH_WORLD,
  entities: [
    toEntity(storage, 'world'),
    toEntity(os, 'world'),
    toEntity(field, 'world'),
    toEntity(machine, 'world'),
  ],
}

// ---- hit zone (the learner LAUNCHES Photos by clicking it) --------------------
const hitZones: HitZone[] = [
  {
    id: 'photos-tile',
    hits: (w: Vec2) =>
      w.x >= PHOTOS_HIT_RECT.x &&
      w.x <= PHOTOS_HIT_RECT.x + PHOTOS_HIT_RECT.w &&
      w.y >= PHOTOS_HIT_RECT.y &&
      w.y <= PHOTOS_HIT_RECT.y + PHOTOS_HIT_RECT.h,
  },
]

// ---- the assembled Chapter ------------------------------------------------------
export function assembleChapter(m: ChapterMeta): Chapter {
  return {
    meta: m,
    scenes: [worldScene],
    timeline: {
      beats,
      fadeDuration: 450,
    },
    hitZones,
    runtime: {
      // Single scene — the protagonist never crosses a seam, but the hook
      // keeps it anchored if a fade is ever triggered programmatically.
      seamPosition: (scene: string): Vec2 | null =>
        scene === 'world' ? PATH_WORLD[PATH_WORLD.length - 1] : null,
    },
    ui: {
      chapterTitle,
      waitingLine,
      startButton,
      sceneTag,
      tipText,
      doneLabel,
    },
    entityRenderers: RENDERERS,
  }
}
