// renderers/world.ts — the painters of Topic 02 Chapter 01's single world:
// the Program (a concrete app: icon + name, spatially persistent, NEVER
// moving, never morphing), the OS system panel (intake port → management core
// → creation port, with a title header and a quiet resource strip), the
// execution field (Process cells with birth pulses, breathing life, PID chips,
// the identity selector, death dissolves, the two term pills, the silent-climax
// comets), and the quiet Topic-01 machine emblem.
//
// Everything here is a pure function of (beatIndex, beatFraction) read from
// scenes/story.ts — deterministic by construction (VISUAL_LANGUAGE §15).
// Ambient breathing reads s.t exactly as the Topic-01 chapters' ambience does.
//
// LOAD-BEARING VISUAL ARGUMENTS (blueprint §3):
//   • The Process cell NEVER inherits the Program's geometry or colour —
//     creation, not transformation.
//   • The PID chip is drawn FROM ITS OWNING CELL's rect every frame — it can
//     never float, overlap another cell, or attach to the Program.
//   • Cells look IDENTICAL until the chips are disclosed — the identity
//     problem is real on screen, not narrated.
//   • Death dissolves locally; the Program's painter takes no input from any
//     Process state — immutability by construction.

import type { EntityRenderer } from '../../../../../rendering/types'
import type { Vec2, Lang } from '../../../../../chapter-loader/types'
import { rrPath, hexA } from '../../../../../rendering/primitives/canvas-utils'
import { glow } from '../../../../../rendering/primitives/glow'
import { drawName } from '../../../../../rendering/primitives/text'
import { TAU, clamp, easeInOutCubic, lerp } from '../../../../../shared/math'
import { polylinePoint } from '../../../../../shared/geometry'

import { beats } from '../narration/beats'
import * as M from '../scenes/metrics'
import * as L from '../scenes/layout'
import * as S from '../scenes/story'

// ---------------------------------------------------------------------------
// shared helpers
// ---------------------------------------------------------------------------
const DUR: Record<number, number> = Object.fromEntries(beats.map((b, i) => [i, b.duration]))
export const beatFrac = (s: { beatIndex: number; beatElapsed: number }): number =>
  clamp(s.beatElapsed / (DUR[s.beatIndex] ?? 3000), 0, 1)

const T = (txt: { en: string; vi: string }, lang: string) =>
  (lang as Lang) === 'vi' ? txt.vi : txt.en

const near = (a: Vec2, b: Vec2, r: number) => Math.hypot(a.x - b.x, a.y - b.y) <= r

function ramp(x: number, a: number, b: number): number {
  return clamp((x - a) / (b - a), 0, 1)
}

/** A window pulse: 0→1→0 over [from,to] of the beat fraction. */
function pulseK(frac: number, from: number, to: number): number {
  if (frac <= from || frac >= to) return 0
  const k = (frac - from) / (to - from)
  return Math.sin(k * Math.PI)
}

function label(
  ctx: CanvasRenderingContext2D,
  text: string,
  at: Vec2,
  opts: { size?: number; color?: string; align?: CanvasTextAlign; alpha?: number; weight?: number; mono?: boolean } = {},
) {
  if ((opts.alpha ?? 1) <= 0.01) return
  ctx.save()
  ctx.globalAlpha = opts.alpha ?? 1
  ctx.font = `${opts.weight ?? 700} ${opts.size ?? M.F.sub}px ${opts.mono ? M.MONO : M.FONT}`
  ctx.textAlign = opts.align ?? 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = opts.color ?? M.COL.dim
  ctx.fillText(text, at.x, at.y)
  ctx.restore()
}

/** Term pill (Topic-01 convention: term + plain sub, resolves after
 *  observation). */
function drawTermPill(
  ctx: CanvasRenderingContext2D,
  c: Vec2,
  term: string,
  sub: string,
  color: string,
  alpha: number,
) {
  if (alpha <= 0.01) return
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.font = `800 ${M.F.termPill}px ${M.FONT}`
  const w = ctx.measureText(term).width + 2 * M.TERM.padX
  rrPath(ctx, c.x - w / 2, c.y - M.TERM.h / 2, w, M.TERM.h, M.TERM.r)
  ctx.fillStyle = M.COL.panel
  ctx.fill()
  ctx.strokeStyle = hexA(color, 0.95)
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.fillStyle = '#ffffff'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(term, c.x, c.y + 1)
  label(ctx, sub, { x: c.x, y: c.y + M.TERM.h / 2 + M.BREATH + M.F.sub / 2 }, {
    size: M.F.sub, color: M.COL.dim, alpha,
  })
  ctx.restore()
}

/** The app glyph (sun + mountains) — shared by the Program icon (large) and
 *  the Process cell's program-identity marker (small), so the SAME icon
 *  propagates Program identity onto instances (Round 4 §1). */
function drawAppGlyph(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  s: number,
  lit: boolean,
) {
  ctx.fillStyle = hexA('#eaf6ff', lit ? 0.95 : 0.8)
  ctx.beginPath()
  ctx.arc(cx - s * 0.18, cy - s * 0.15, s * 0.1, 0, TAU)
  ctx.fill()
  ctx.beginPath()
  ctx.moveTo(cx - s * 0.32, cy + s * 0.24)
  ctx.lineTo(cx - s * 0.02, cy - s * 0.1)
  ctx.lineTo(cx + s * 0.32, cy + s * 0.24)
  ctx.closePath()
  ctx.fill()
  ctx.beginPath()
  ctx.moveTo(cx - s * 0.14, cy + s * 0.24)
  ctx.lineTo(cx + s * 0.06, cy - s * 0.02)
  ctx.lineTo(cx + s * 0.2, cy + s * 0.24)
  ctx.closePath()
  ctx.fillStyle = hexA('#cfe8ff', (lit ? 0.85 : 0.65) * 0.9)
  ctx.fill()
}

// ===========================================================================
// PROGRAM-CARD — the artifact. Spatially persistent; paint depends ONLY on
// (active, spark proximity, rupture window) — never on any Process state.
// ===========================================================================
export const drawProgramCard: EntityRenderer = (ctx, s, e, active) => {
  const r = L.programRect()
  const frac = beatFrac(s)
  const sparkNear = s.sparkScale > 0.1 && near(s.sparkPos, M.PROGRAM_C, M.SPARK_NEAR)
  const lit = active || sparkNear

  // the rupture pulse (B05): one restrained ring — salience without motion.
  // Two humps: the initial pulse, then a "look-back" pulse after the cell was
  // shown — "this is still here, unchanged".
  const rupK =
    s.beatIndex === S.B.rupture
      ? Math.min(
          1,
          pulseK(frac, S.RUPTURE.programPulse.from, S.RUPTURE.programPulse.to) +
            pulseK(frac, S.RUPTURE.lookBack.from, S.RUPTURE.lookBack.to),
        )
      : 0

  // the why-the-os pulse (B02): a soft glow only — "a stored artifact, inert,
  // by itself" — distinct from the rupture RING so the two beats can't blend.
  const whyK =
    s.beatIndex === S.B.osIntro
      ? pulseK(frac, S.OS_INTRO.programPulse.from, S.OS_INTRO.programPulse.to)
      : 0

  // the launch-request departure ripple (B03): a small expanding ring that
  // fades as the request LEAVES — "something departed from here", while the
  // tile itself stays put. Distinct from the rupture ring (different beat,
  // different size/opacity).
  const launchK =
    s.beatIndex === S.B.launch
      ? pulseK(frac, 0.06, 0.34)
      : 0

  ctx.save()
  if (lit) glow(ctx, e.pos, e.color, 120, 0.22)
  if (whyK > 0.02) glow(ctx, e.pos, e.color, 110, 0.26 * whyK)
  if (launchK > 0.02) {
    ctx.strokeStyle = hexA(e.color, 0.6 * launchK)
    ctx.lineWidth = 2
    rrPath(
      ctx,
      r.x - 4 - 16 * launchK,
      r.y - 4 - 16 * launchK,
      r.w + 8 + 32 * launchK,
      r.h + 8 + 32 * launchK,
      r.r + 6,
    )
    ctx.stroke()
  }

  // a recessed storage platform — the artifact SITS IN storage, not on an
  // empty void. A faint inset zone behind the tile + the shelf as its front
  // edge grounds "stored artifact" visually (no label needed to say it).
  rrPath(ctx, r.x - 14, r.y - 12, r.w + 28, r.h + 40, r.r + 6)
  ctx.fillStyle = 'rgba(10,14,32,0.35)'
  ctx.fill()
  if (rupK > 0) {
    ctx.strokeStyle = hexA(e.color, 0.85 * rupK)
    ctx.lineWidth = M.PULSE.ring
    rrPath(ctx, r.x - 10 * rupK, r.y - 10 * rupK, r.w + 20 * rupK, r.h + 20 * rupK, r.r + 6)
    ctx.stroke()
  }

  // the soft app tile (a stored APPLICATION, not an abstract document)
  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fillStyle = hexA(e.color, lit ? 0.1 : 0.06)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, lit ? 0.9 : 0.5)
  ctx.lineWidth = 2
  ctx.stroke()

  // the app icon — the Program's stable visual identity (a "photo" glyph)
  const icon = L.appIconRect()
  rrPath(ctx, icon.x, icon.y, icon.w, icon.h, icon.r)
  ctx.fillStyle = hexA(e.color, lit ? 0.24 : 0.16)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, lit ? 1 : 0.75)
  ctx.lineWidth = 2.5
  ctx.stroke()
  drawAppGlyph(ctx, icon.x + icon.w / 2, icon.y + icon.h / 2, icon.w, lit)

  // the app name — the SAME name every launch (identity, not instance)
  const namePos = L.appNamePos()
  label(ctx, T(S.CAP.appName, s.lang), namePos, {
    size: M.F.appName, color: hexA('#eaf0ff', lit ? 0.95 : 0.7), weight: 700,
  })

  // the shelf — "this artifact LIVES here"
  const [a, b] = L.shelfLine()
  ctx.strokeStyle = hexA('#aab4d0', 0.4)
  ctx.lineWidth = M.SHELF.h
  ctx.lineCap = 'round'
  ctx.beginPath()
  ctx.moveTo(a.x, a.y)
  ctx.lineTo(b.x, b.y)
  ctx.stroke()
  label(ctx, T(S.CAP.shelf, s.lang), { x: (a.x + b.x) / 2, y: a.y + M.LABEL_GAP + 2 }, {
    size: M.F.small, color: M.COL.dim,
  })
  ctx.restore()

  drawName(ctx, e.pos, e.name, e.color, lit, r.h / 2 + M.SHELF.dy + M.LABEL_GAP + M.LABEL_TEXT_H, M.F.partName)
}

// ===========================================================================
// OS — the management layer between programs and the machine.
// Internal structure (refinement §5–6, all geometry from layout.ts):
//   • intake port (west): where launch requests arrive
//   • management core: three function rows (create / identify / manage) —
//     visible as structure from the intro; their tiny labels are revealed
//     only AFTER each function has been observed (Knowledge Reveal Law,
//     windows in story.ts OS_ROW_LABEL_AT)
//   • creation port (east): where the creation signal leaves
//   • resource-context strip (base): CPU · RAM · I/O — the shared machine
//     the OS manages. Shown as context only; internals are later chapters'.
// MOTION = change: rows highlight only during their causal action; the OS
// stands as stable system geometry the rest of the time (refinement §15).
// ===========================================================================

/** Deterministic per-window row highlight for the OS core. */
function osRowGlow(bi: number, frac: number): [number, number, number] {
  const g: [number, number, number] = [0, 0, 0]
  // receive: the whole core wakes bottom-up (manage → identify → create)
  if (bi === S.B.osReceives) {
    const k = ramp(frac, S.OS_RECEIVE.coreWake.from, S.OS_RECEIVE.coreWake.to)
    g[S.OS_ROWS.manage] = ramp(k, 0, 0.4)
    g[S.OS_ROWS.identify] = ramp(k, 0.3, 0.7)
    g[S.OS_ROWS.create] = ramp(k, 0.6, 1)
  }
  // birth: the CREATE row works, then hands to the east port
  if (bi === S.B.birth) g[S.OS_ROWS.create] = 1 - ramp(frac, S.OS_CREATE.emit.to, 0.75)
  // later launches: create row pulses while the launch signal is inside
  // identity beat: the IDENTIFY row is lit for each chip's resolve window
  if (bi === S.B.pid) {
    for (const p of S.PROCS) {
      if (p.chipAt.beat !== S.B.pid) continue
      const k = ramp(frac, p.chipAt.frac, p.chipDockAt.frac)
      if (k > 0 && k < 1) g[S.OS_ROWS.identify] = Math.max(g[S.OS_ROWS.identify], pulseK(k, 0, 1))
    }
  }
  // lifetime + independence: the MANAGE row acknowledges (single soft pulse)
  if (bi === S.B.lifetime) g[S.OS_ROWS.manage] = pulseK(frac, 0.35, 0.75)
  return g
}

export const drawOsGate: EntityRenderer = (ctx, s, e, active) => {
  const r = L.osRect()
  const frac = beatFrac(s)
  const bi = s.beatIndex
  const lang = s.lang as Lang

  // ---- structural reveal (B02 osIntro): before it, the OS is a quiet
  // outline; the core resolves during the intro and stays forever. The
  // machine is NOT inside the OS — it is a separate far-east context region.
  const introSeen = bi > S.B.osIntro
  const coreA = introSeen ? 1 : bi === S.B.osIntro ? ramp(frac, S.OS_INTRO.core.from, S.OS_INTRO.core.to) : 0

  // ---- causal work level (drives boundary emphasis only) ----
  const sparkIn = s.sparkScale > 0.1 && near(s.sparkPos, M.OS_C, M.OS_BAND.w)
  let cometIn = 0
  if (bi === S.B.climax) {
    for (const c of S.CLIMAX_LAUNCHES) {
      const k = ramp(frac, c.from, c.to)
      if (k > 0.25 && k < 0.75) cometIn = Math.max(cometIn, pulseK(k, 0.25, 0.75))
    }
  }
  const intake = bi === S.B.osReceives ? pulseK(frac, S.OS_RECEIVE.intake.from, S.OS_RECEIVE.intake.to) : 0
  const emit = bi === S.B.birth ? pulseK(frac, S.OS_CREATE.emit.from, S.OS_CREATE.emit.to) : 0
  const work = Math.max(sparkIn ? 0.8 : 0, cometIn, intake, emit)
  const lit = active || work > 0.05

  ctx.save()
  if (lit) glow(ctx, e.pos, e.color, 150, 0.14 + 0.12 * work)

  // ---- outer boundary: the system-software body ----
  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fillStyle = hexA(e.color, 0.07 + 0.05 * work)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, lit ? 0.95 : 0.55)
  ctx.lineWidth = 2.5
  ctx.stroke()

  // ---- the title header: "OS" + "Operating System" (system software, not a
  // lone giant letter, not a machine part). The monogram is always present
  // (as it was before); the spelled-out subtitle appears only from the OS
  // introduction onward (Knowledge Reveal — no name before the beat). ----
  label(ctx, S.CAP.osLetters, { x: e.pos.x, y: r.y + M.OS_TITLE.dy }, {
    size: M.F.osTitle, color: hexA('#ffffff', lit ? 0.95 : 0.72), weight: 800,
  })
  const subA = introSeen ? 1 : bi === S.B.osIntro ? ramp(frac, S.OS_INTRO.core.from, S.OS_INTRO.core.to) : 0
  if (subA > 0.02) {
    label(ctx, T(S.CAP.osSubtitle, lang), { x: e.pos.x, y: r.y + M.OS_SUB.dy }, {
      size: M.F.micro, color: hexA('#eaf0ff', (lit ? 0.68 : 0.52) * subA), weight: 700,
    })
  }

  // ---- ports: intake (west) + creation (east), sockets on the boundary ----
  // No static directional arrows/chevrons here: a permanent arrow would read
  // as a network/data-flow pipeline or a hardware socket. Causality is carried
  // by the ANIMATED launch request (spark) and the creation pulse, not by a
  // drawn glyph. The ports are plain causal entry/exit points.
  const wp = L.osWestPortRect()
  rrPath(ctx, wp.x, wp.y, wp.w, wp.h, wp.r)
  ctx.fillStyle = hexA(e.color, 0.35 + 0.55 * intake + (sparkIn ? 0.3 : 0))
  ctx.fill()
  const ep = L.osEastPortRect()
  rrPath(ctx, ep.x, ep.y, ep.w, ep.h, ep.r)
  ctx.fillStyle = hexA(M.COL.process, 0.3 + 0.6 * emit)
  ctx.fill()
  if (emit > 0.02) {
    // the creation port emits: a brief expanding arc toward the field
    ctx.strokeStyle = hexA(M.COL.process, 0.7 * emit)
    ctx.lineWidth = 2.5
    ctx.beginPath()
    ctx.arc(L.osEastPort().x, L.osEastPort().y, 14 + 26 * emit, -Math.PI / 3, Math.PI / 3)
    ctx.stroke()
  }

  // ---- the management core: three function rows ----
  // Deliberately NOT a bordered sub-panel: a box inside the OS band reads as
  // "panel inside a panel" (a dashboard card). A soft BORDERLESS tint behind
  // the three tracks unifies them as ONE system area (functions of one OS),
  // without a card border. Each track lights only while its function acts.
  if (coreA > 0.02) {
    ctx.globalAlpha = coreA
    const c = L.osCoreRect()
    rrPath(ctx, c.x, c.y, c.w, c.h, c.r)
    ctx.fillStyle = hexA('#0b1026', 0.22)
    ctx.fill()
    const rowGlow = osRowGlow(bi, frac)
    for (let i = 0; i < 3; i++) {
      const row = L.osRowRect(i)
      const gk = rowGlow[i]
      rrPath(ctx, row.x, row.y, row.w, row.h, row.r)
      // idle = a faint visible track (no border) — the three action tracks
      // read as STRUCTURE ("this software has functions") while staying
      // clearly subordinate. The border + stronger fill appear only while the
      // row ACTS. Action states, not three modules.
      ctx.fillStyle = hexA(e.color, 0.07 + 0.22 * gk)
      ctx.fill()
      if (gk > 0.05) {
        ctx.strokeStyle = hexA(e.color, 0.25 + 0.55 * gk)
        ctx.lineWidth = 1.5
        ctx.stroke()
      }
      // function micro-label — revealed only AFTER the function was observed
      const lab = S.OS_ROW_LABEL_AT[i]
      const labelOn = S.after(bi, frac, lab)
      if (labelOn) {
        label(ctx, T(S.CAP.osRows[i], lang), { x: row.x + row.w / 2, y: row.y + row.h / 2 + 1 }, {
          size: M.F.micro, color: hexA('#eaf0ff', 0.55 + 0.35 * gk), weight: 700,
        })
      } else if (gk > 0.05) {
        // pre-label: the working row shows only a moving glint — action
        // without a name (observation before terminology)
        const gx = row.x + 8 + (row.w - 16) * gk
        ctx.fillStyle = hexA('#ffffff', 0.5 * gk)
        ctx.beginPath()
        ctx.arc(gx, row.y + row.h / 2, 2.5, 0, TAU)
        ctx.fill()
      }
    }
    ctx.globalAlpha = 1
  }

  ctx.restore()

  // the "PID" term pill lives south of the OS (the identity associator)
  const pidPillA =
    bi === S.B.pid
      ? ramp(frac, S.PID_PILL.from, S.PID_PILL.to)
      : bi === S.B.lifetime
        ? 1 - ramp(frac, 0, 0.25)
        : 0
  drawTermPill(ctx, L.pidPillC(), S.PID_TERM.term, T(S.PID_TERM.sub, s.lang), e.color, pidPillA)
}

// ===========================================================================
// MACHINE — the physical computer context (Round 8): a low-salience region
// holding three resource markers (CPU · RAM · I/O), each with a mini hardware
// glyph echoing the Topic-01 visual language (CPU chip with pins + core; RAM
// sticks; I/O port). It replaces the former standalone "CPU" emblem so the
// machine is represented in exactly ONE place, distinct from the OS (which
// holds software roles only). Static by design — the machine must not pulse
// continuously (that would imply CPU activity and contradict ALIVE ≠
// EXECUTING).
// ===========================================================================

/** Mini CPU chip (Topic-01 CH01 vocabulary): square body + pins + a glowing
 *  core dot. */
function drawCpuGlyph(ctx: CanvasRenderingContext2D, cx: number, cy: number, color: string) {
  const s = 22
  const x = cx - s / 2
  const y = cy - s / 2
  // pins (top + bottom, 4 per side)
  ctx.fillStyle = hexA(color, 0.85)
  for (let i = 0; i < 4; i++) {
    const px = x + 4 + i * ((s - 8) / 3)
    ctx.fillRect(px - 1.3, y - 4, 2.6, 4)
    ctx.fillRect(px - 1.3, y + s, 2.6, 4)
  }
  // body
  rrPath(ctx, x, y, s, s, 4.5)
  ctx.fillStyle = hexA(color, 0.22)
  ctx.fill()
  ctx.strokeStyle = hexA(color, 0.9)
  ctx.lineWidth = 1.8
  ctx.stroke()
  // core
  ctx.fillStyle = hexA('#fff3c0', 0.95)
  ctx.beginPath()
  ctx.arc(cx, cy, 5, 0, TAU)
  ctx.fill()
  ctx.fillStyle = hexA(color, 0.95)
  ctx.beginPath()
  ctx.arc(cx, cy, 2.6, 0, TAU)
  ctx.fill()
}

/** Mini RAM stick (Topic-01 CH01 vocabulary): rounded bar + memory segments. */
function drawRamGlyph(ctx: CanvasRenderingContext2D, cx: number, cy: number, color: string) {
  const w = 30
  const h = 20
  const x = cx - w / 2
  const y = cy - h / 2
  rrPath(ctx, x, y, w, h, 4.5)
  ctx.fillStyle = hexA(color, 0.22)
  ctx.fill()
  ctx.strokeStyle = hexA(color, 0.9)
  ctx.lineWidth = 1.8
  ctx.stroke()
  // memory segments (sticks)
  ctx.fillStyle = hexA(color, 0.9)
  for (let i = 0; i < 4; i++) {
    ctx.fillRect(x + 4.5 + i * 6, y + 4, 3.2, h - 8)
  }
}

/** Mini I/O port: a trapezoid connector with contact pins (matches the
 *  CPU/RAM hardware grammar). */
function drawIoGlyph(ctx: CanvasRenderingContext2D, cx: number, cy: number, color: string) {
  const w = 30
  const h = 18
  const x = cx - w / 2
  const y = cy - h / 2
  // port body (trapezoid connector)
  ctx.beginPath()
  ctx.moveTo(x, y + h)
  ctx.lineTo(x + 4.5, y)
  ctx.lineTo(x + w - 4.5, y)
  ctx.lineTo(x + w, y + h)
  ctx.closePath()
  ctx.fillStyle = hexA(color, 0.22)
  ctx.fill()
  ctx.strokeStyle = hexA(color, 0.9)
  ctx.lineWidth = 1.8
  ctx.stroke()
  // contact pins
  ctx.fillStyle = hexA(color, 0.9)
  for (let i = 0; i < 4; i++) {
    ctx.fillRect(x + 5 + i * 6, y + h, 3, 3.5)
  }
}

export const drawMachineDock: EntityRenderer = (ctx, s, e, active) => {
  const r = L.machineRect()
  const bi = s.beatIndex
  const frac = beatFrac(s)
  const lang = s.lang as Lang

  // during the OS intro, the resource slots light one by one (deterministic
  // stagger) — "the machine is shared" is shown, then the OS core resolves.
  const slotStagger = (i: number) =>
    bi === S.B.osIntro
      ? ramp(frac, S.OS_INTRO.machine.from + i * 0.06, S.OS_INTRO.machine.from + 0.12 + i * 0.06)
      : 1

  ctx.save()
  if (active) glow(ctx, e.pos, e.color, 110, 0.22)

  // container — a quiet context region, not a destination
  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fillStyle = hexA('#0b1026', 0.28)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.8 : 0.4)
  ctx.lineWidth = 1.5
  ctx.stroke()

  // title — "the machine" (physical context, always present from the intro)
  const titleA = bi > S.B.osIntro ? 1 : bi === S.B.osIntro ? ramp(frac, S.OS_INTRO.machine.from, S.OS_INTRO.machine.from + 0.1) : 0
  if (titleA > 0.02) {
    label(ctx, T(S.CAP.machineTitle, lang), { x: e.pos.x, y: r.y + 20 }, {
      size: M.F.machineTitle, color: hexA('#eaf0ff', 0.9 * titleA), weight: 700,
    })
  }

  // resource markers — CPU · RAM · I/O (T01 colours), static
  const resCols = [M.COL.machine, '#a78bfa', '#94a3b8']
  for (let i = 0; i < 3; i++) {
    const k = slotStagger(i)
    if (k <= 0.02) continue
    const slot = L.machineSlotRect(i)
    ctx.globalAlpha = k
    rrPath(ctx, slot.x, slot.y, slot.w, slot.h, slot.r)
    ctx.fillStyle = hexA(resCols[i], 0.12)
    ctx.fill()
    ctx.strokeStyle = hexA(resCols[i], 0.38)
    ctx.lineWidth = 1.2
    ctx.stroke()
    // mini hardware glyph (Topic-01 vocabulary) on the left
    const gx = slot.x + 20
    const gy = slot.y + slot.h / 2
    if (i === 0) drawCpuGlyph(ctx, gx, gy, resCols[i])
    else if (i === 1) drawRamGlyph(ctx, gx, gy, resCols[i])
    else drawIoGlyph(ctx, gx, gy, resCols[i])
    // label to the right of the glyph
    label(ctx, S.CAP.machineRes[i], { x: slot.x + 41, y: slot.y + slot.h / 2 + 1 }, {
      size: M.F.machineRes, color: hexA('#eaf0ff', 0.8), mono: true, align: 'left',
    })
    ctx.globalAlpha = 1
  }
  ctx.restore()
}

// ===========================================================================
// EXEC-FIELD — every Process cell, chip, pulse, selector, pill and comet.
// All lifecycle facts come from scenes/story.ts (declarative story data).
// ===========================================================================

function drawCell(
  ctx: CanvasRenderingContext2D,
  s: { t: number; lang: Lang },
  inst: S.ProcInst,
  st: S.CellState,
  nameKnown: boolean,
) {
  const r = L.cellRect(inst.spot)
  const c = L.cellC(inst.spot)

  if (st.phase === 'unborn' || st.phase === 'gone') return

  // ---- birth: creation pulse + boundary draw-in (creation, NOT morphing) --
  if (st.phase === 'birthing') {
    const k = st.k
    // local creation pulse (first half)
    const pk = pulseK(k, 0, 0.55)
    if (pk > 0) {
      ctx.strokeStyle = hexA(M.COL.process, 0.8 * pk)
      ctx.lineWidth = M.PULSE.ring
      ctx.beginPath()
      ctx.arc(c.x, c.y, 12 + M.PULSE.birthR * k, 0, TAU)
      ctx.stroke()
    }
    // center bloom — the entity MATERIALIZES from a point, so birth reads as
    // "something came into existence", not "a rectangle was drawn". A soft
    // radial fill that expands with the boundary and hands off to the body.
    if (k > 0.05 && k < 0.9) {
      const bloomR = (Math.max(r.w, r.h) / 2) * (0.35 + 0.65 * easeInOutCubic(k))
      const g = ctx.createRadialGradient(c.x, c.y, 0, c.x, c.y, bloomR)
      g.addColorStop(0, hexA(M.COL.process, 0.22 * Math.sin(k * Math.PI)))
      g.addColorStop(1, hexA(M.COL.process, 0))
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.arc(c.x, c.y, bloomR, 0, TAU)
      ctx.fill()
    }
    // boundary draws itself in — as the cell's OWN rounded-rect outline (a
    // dash-offset sweep along the real path), so the entity's shape forms
    // continuously instead of a circle that doesn't match the final cell.
    const sweep = easeInOutCubic(ramp(k, 0.25, 1))
    if (sweep > 0.02 && sweep < 0.999) {
      const rr = Math.min(M.CELL.r, r.w / 2, r.h / 2)
      const perim = 2 * (r.w - 2 * rr) + 2 * (r.h - 2 * rr) + TAU * rr
      ctx.save()
      ctx.strokeStyle = hexA(M.COL.process, 0.9)
      ctx.lineWidth = 2.5
      ctx.setLineDash([perim, perim])
      ctx.lineDashOffset = perim * (1 - sweep)
      rrPath(ctx, r.x, r.y, r.w, r.h, rr)
      ctx.stroke()
      ctx.setLineDash([])
      ctx.restore()
    }
    // interior condenses late in the birth
    const inA = ramp(k, 0.6, 1)
    if (inA > 0.02) drawCellBody(ctx, s, inst, r, c, inA, 1, nameKnown, st)
    return
  }

  // ---- dying: completion brightness → dissolve outward ---------------------
  if (st.phase === 'dying') {
    const k = st.k
    const bodyA = 1 - easeInOutCubic(ramp(k, 0.25, 1))
    const bright = 1 + 0.8 * pulseK(k, 0, 0.35)
    // the dissolve ring expands outward — the boundary releasing
    const dk = ramp(k, 0.3, 1)
    if (dk > 0 && dk < 1) {
      ctx.strokeStyle = hexA(M.COL.process, 0.6 * (1 - dk))
      ctx.lineWidth = M.PULSE.ring
      ctx.beginPath()
      ctx.arc(c.x, c.y, Math.max(r.w, r.h) / 2 + M.PULSE.dieR * dk, 0, TAU)
      ctx.stroke()
    }
    if (bodyA > 0.02) drawCellBody(ctx, s, inst, r, c, bodyA, bright, nameKnown, st)
    return
  }

  // ---- alive ---------------------------------------------------------------
  drawCellBody(ctx, s, inst, r, c, 1, 1, nameKnown, st)
}

function drawCellBody(
  ctx: CanvasRenderingContext2D,
  s: { t: number; lang: Lang },
  inst: S.ProcInst,
  r: L.Rect,
  c: Vec2,
  alpha: number,
  bright: number,
  nameKnown: boolean,
  st: S.CellState,
) {
  ctx.save()
  ctx.globalAlpha = alpha
  // Presence breathing — deliberately RESTRAINED (refinement Fix #1): a very
  // slow, low-amplitude boundary shimmer says "this entity persists", nothing
  // more. The interior is static: existence must not look like execution.
  const breathe = 0.5 + 0.5 * Math.sin(s.t * 0.0016 + inst.spot * 1.7)

  glow(ctx, c, M.COL.process, 90, 0.1 * bright + 0.03 * breathe)
  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fillStyle = hexA(M.COL.process, 0.1 * bright)
  ctx.fill()
  ctx.strokeStyle = hexA(M.COL.process, Math.min(1, (0.8 + 0.08 * breathe) * bright))
  ctx.lineWidth = 2.5
  ctx.stroke()

  // header — ONLY after the term has been earned (B06+): a three-layer
  // identity stack. Line 1 = CLASS (the entity's NAME — the title). Line 2 =
  // PROGRAM provenance (small dim cyan icon + name: which program this
  // Process is an instance of — a subordinate subtitle). The PID (instance
  // identity) is the chip below. Ordering makes the ontology explicit:
  // this is a PROCESS (title), sourced from Photos (subtitle), numbered by
  // its PID (chip) — never "a thing named Photos".
  if (nameKnown) {
    // class caption — the entity's name, primary (title)
    label(ctx, T(S.CAP.cellCaption, s.lang), { x: r.x + r.w / 2, y: r.y + M.CELL_CAPTION_Y }, {
      size: M.F.cellCaption, color: hexA('#eaf0ff', 0.78 * alpha), weight: 800,
    })
    // source marker — provenance cue, subordinate (subtitle, below the name)
    const idName = T(S.CAP.appName, s.lang)
    ctx.font = `600 ${M.F.sourceCue}px ${M.FONT}`
    const nameW = ctx.measureText(idName).width
    const ic = M.CELL_ID.icon
    const groupW = ic + M.CELL_ID.gap + nameW
    const gx0 = c.x - groupW / 2
    const line2Y = r.y + M.CELL_ID.y
    // mini app icon — the SAME icon, tiny, cyan (Program colour)
    rrPath(ctx, gx0, line2Y - ic / 2, ic, ic, 3)
    ctx.fillStyle = hexA(M.COL.program, 0.16 * alpha)
    ctx.fill()
    ctx.strokeStyle = hexA(M.COL.program, 0.5 * alpha)
    ctx.lineWidth = 1
    ctx.stroke()
    drawAppGlyph(ctx, gx0 + ic / 2, line2Y, ic * 0.72, true)
    // app name — provenance cue, restrained (smaller + dimmer than "Process")
    label(ctx, idName, { x: gx0 + ic + M.CELL_ID.gap, y: line2Y }, {
      size: M.F.sourceCue, color: hexA(M.COL.program, 0.55 * alpha), weight: 600, align: 'left',
    })
    // NOTE: no horizontal divider under the header. A divider line is a
    // "title-bar" affordance that reads as an application window — the
    // Process must read as an entity, not a window. Grouping is carried by
    // spacing + weight alone.
  }

  // content marks — STATIC by design (refinement Fix #1): short filled
  // segments that say "this instance has its own contents", identical for
  // every cell (the identity problem stays real). Deliberately NOT drawn as
  // progress bars (no track outline, no right rail): a track reads as a
  // "task bar", which would imply activity. They must also NOT animate:
  // motion here would teach "alive = the CPU is executing this right now".
  for (let i = 0; i < M.CELL_BARS.count; i++) {
    const bar = L.cellBarRect(inst.spot, i)
    rrPath(ctx, bar.x, bar.y, bar.w * (M.CELL_BAR_FRACS[i] ?? 0.6), bar.h, bar.h / 2)
    ctx.fillStyle = hexA(M.COL.process, 0.42)
    ctx.fill()
  }

  // ---- the PID chip — drawn FROM the owning cell's rect (never floats) ----
  if (st.chip === 'docked') {
    const chip = L.chipRect(inst.spot)
    rrPath(ctx, chip.x, chip.y, chip.w, chip.h, chip.r)
    ctx.fillStyle = hexA('#0b1026', 0.85)
    ctx.fill()
    ctx.strokeStyle = hexA(M.COL.os, 0.9)
    ctx.lineWidth = 1.5
    ctx.stroke()
    label(ctx, `${S.CAP.chipPrefix} ${inst.pid}`, L.chipC(inst.spot), {
      size: M.F.chipText, color: '#ffffff', weight: 800, mono: true,
    })
  }
  ctx.restore()
}

/** The identity ASSOCIATION (refinement §11/§23): not a physical packet.
 *  Sequence within the resolve window k∈(0,1):
 *    identity focus — a ring closes onto the owning cell (k 0→0.45)
 *    association line — a thin dashed link OS→cell draws in (k 0.15→0.55)
 *    PID resolves — the chip fades/scales IN at its dock (k 0.45→0.9)
 *    link releases — the line fades; chip stays docked (k 0.85→1)
 *  Nothing travels as an object; an abstract association becomes visible. */
function drawIdentityAssociation(ctx: CanvasRenderingContext2D, inst: S.ProcInst, k: number) {
  const cell = L.cellRect(inst.spot)
  const dock = L.chipC(inst.spot)
  const from = L.osEastPort()

  ctx.save()
  // 1 — identity focus: ring closes onto the owning cell (unambiguous owner)
  const fk = clamp(k / 0.45, 0, 1)
  if (fk > 0.02 && k < 0.9) {
    const spread = (1 - easeInOutCubic(fk)) * 36
    ctx.strokeStyle = hexA(M.COL.os, 0.55 * Math.min(1, fk * 2) * (k > 0.75 ? (0.9 - k) / 0.15 : 1))
    ctx.lineWidth = S.IDENTITY_FOCUS_RING.ring
    rrPath(
      ctx,
      cell.x - S.IDENTITY_FOCUS_RING.pad - spread,
      cell.y - S.IDENTITY_FOCUS_RING.pad - spread,
      cell.w + 2 * (S.IDENTITY_FOCUS_RING.pad + spread),
      cell.h + 2 * (S.IDENTITY_FOCUS_RING.pad + spread),
      cell.r + S.IDENTITY_FOCUS_RING.pad,
    )
    ctx.stroke()
  }
  // 2 — association line: draws OS → cell, then releases (dashed = logical)
  const lk = clamp((k - 0.15) / 0.4, 0, 1)
  const fade = k > 0.85 ? (1 - k) / 0.15 : 1
  if (lk > 0.02 && fade > 0.02) {
    const end = { x: lerp(from.x, dock.x, easeInOutCubic(lk)), y: lerp(from.y, dock.y, easeInOutCubic(lk)) }
    ctx.strokeStyle = hexA(M.COL.os, 0.5 * fade)
    ctx.lineWidth = 1.5
    ctx.setLineDash([5, 6])
    ctx.beginPath()
    ctx.moveTo(from.x, from.y)
    ctx.lineTo(end.x, end.y)
    ctx.stroke()
    ctx.setLineDash([])
  }
  // 3 — the PID resolves in place at its dock (fade + settle, no travel)
  const ck = clamp((k - 0.45) / 0.45, 0, 1)
  if (ck > 0.02) {
    const a = easeInOutCubic(ck)
    const scale = 1.12 - 0.12 * a
    const w = M.CHIP.w * scale
    const h = M.CHIP.h * scale
    ctx.globalAlpha = a
    glow(ctx, dock, M.COL.os, 40, 0.3 * a)
    rrPath(ctx, dock.x - w / 2, dock.y - h / 2, w, h, M.CHIP.r * scale)
    ctx.fillStyle = hexA('#0b1026', 0.9)
    ctx.fill()
    ctx.strokeStyle = hexA(M.COL.os, 1)
    ctx.lineWidth = 2
    ctx.stroke()
    label(ctx, `${S.CAP.chipPrefix} ${inst.pid}`, dock, {
      size: M.F.chipText, color: '#ffffff', weight: 800, mono: true, alpha: a,
    })
    ctx.globalAlpha = 1
  }
  ctx.restore()
}

export const drawExecField: EntityRenderer = (ctx, s, _e, _active) => {
  const bi = s.beatIndex
  const frac = beatFrac(s)
  const lang = s.lang as Lang
  const nameKnown =
    bi > S.B.nameProcess || (bi === S.B.nameProcess && frac >= S.PROCESS_PILL.from)

  // orientation chip (plain language, Topic-01 convention)
  ctx.save()
  ctx.font = `700 ${M.F.chip}px ${M.FONT}`
  const oText = T(S.CAP.orient, lang)
  const oW = ctx.measureText(oText).width
  const oc = L.orientChip(oW)
  rrPath(ctx, oc.x, oc.y, oc.w, oc.h, oc.r)
  ctx.fillStyle = hexA('#0b1026', 0.5)
  ctx.fill()
  ctx.strokeStyle = hexA(M.COL.process, 0.35)
  ctx.lineWidth = 1.5
  ctx.stroke()
  label(ctx, oText, { x: oc.x + oc.w / 2, y: oc.y + oc.h / 2 + 1 }, {
    size: M.F.chip, color: hexA('#cfe0ff', 0.8),
  })
  ctx.restore()

  // ---- cells (unborn/gone are simply not drawn — negative space is real) --
  for (const inst of S.PROCS) {
    const st = S.cellStateAt(inst, bi, frac)
    drawCell(ctx, { t: s.t, lang }, inst, st, nameKnown)
  }

  // ---- the rupture's cell pulse (B05): overlaps the Program's pulse so both
  // are salient at once — the coexistence proof, not a sequence ----------
  if (bi === S.B.rupture) {
    const k = pulseK(frac, S.RUPTURE.cellPulse.from, S.RUPTURE.cellPulse.to)
    if (k > 0) {
      const r = L.cellRect(S.FIRST.spot)
      ctx.strokeStyle = hexA(M.COL.process, 0.85 * k)
      ctx.lineWidth = M.PULSE.ring
      rrPath(ctx, r.x - 10 * k, r.y - 10 * k, r.w + 20 * k, r.h + 20 * k, r.r + 6)
      ctx.stroke()
    }
  }

  // ---- independence #1 (B08 second launch): Process A "still here" pulse ----
  if (bi === S.B.secondLaunch) {
    const k = pulseK(frac, S.INDEP_A_ACK.from, S.INDEP_A_ACK.to)
    if (k > 0) {
      const r = L.cellRect(S.FIRST.spot)
      ctx.strokeStyle = hexA(M.COL.process, 0.55 * k)
      ctx.lineWidth = M.PULSE.ring
      rrPath(ctx, r.x - 8 * k, r.y - 8 * k, r.w + 16 * k, r.h + 16 * k, r.r + 5)
      ctx.stroke()
    }
  }

  // ---- independence #2 (B10 lifetime): survivors "still alive" pulse ----
  if (bi === S.B.lifetime) {
    const k = pulseK(frac, S.SURVIVOR_ACK.from, S.SURVIVOR_ACK.to)
    if (k > 0) {
      for (const p of S.PROCS) {
        const st = S.cellStateAt(p, bi, frac)
        if (st.phase !== 'alive') continue
        const r = L.cellRect(p.spot)
        ctx.strokeStyle = hexA(M.COL.process, 0.55 * k)
        ctx.lineWidth = M.PULSE.ring
        rrPath(ctx, r.x - 8 * k, r.y - 8 * k, r.w + 16 * k, r.h + 16 * k, r.r + 5)
        ctx.stroke()
      }
    }
  }

  // ---- the identity selector (B08): a ring hops the trio, finds nothing ---
  if (bi === S.B.identityProblem && frac >= S.SELECTOR.from) {
    const k = ramp(frac, S.SELECTOR.from, S.SELECTOR.to)
    const hops = S.SELECTOR.hops
    const seg = Math.min(hops.length - 1, Math.floor(k * (hops.length - 1)))
    const segK = k * (hops.length - 1) - seg
    // the ring DWELLS at each cell (hesitation), snapping between them
    const spot = segK < 0.75 ? hops[seg] : hops[Math.min(seg + 1, hops.length - 1)]
    const r = L.cellRect(spot)
    const wob = 1 + 0.04 * Math.sin(s.t * 0.02)
    ctx.save()
    ctx.strokeStyle = hexA('#ffffff', 0.75)
    ctx.lineWidth = M.SELECTOR.ring
    ctx.setLineDash([8, 7])
    rrPath(
      ctx,
      r.x - M.SELECTOR.pad * wob,
      r.y - M.SELECTOR.pad * wob,
      r.w + 2 * M.SELECTOR.pad * wob,
      r.h + 2 * M.SELECTOR.pad * wob,
      r.r + M.SELECTOR.pad,
    )
    ctx.stroke()
    ctx.setLineDash([])
    // the question mark of the failed identification
    label(ctx, '?', { x: r.x + r.w / 2, y: r.y - M.SELECTOR.pad - 16 }, {
      size: M.F.mark, color: hexA('#ffffff', 0.8), weight: 800,
    })
    ctx.restore()
  }

  // ---- identity associations resolving (B10 + late births) ----------------
  for (const inst of S.PROCS) {
    const st = S.cellStateAt(inst, bi, frac)
    if (st.chip === 'flying') drawIdentityAssociation(ctx, inst, st.chipK)
  }

  // ---- the "Process" term pill (B06; fades by the identity beat) ----------
  const procPillA =
    bi === S.B.nameProcess
      ? ramp(frac, S.PROCESS_PILL.from, S.PROCESS_PILL.to)
      : bi === S.B.secondLaunch
        ? 1 - ramp(frac, 0, 0.2)
        : 0
  drawTermPill(
    ctx, L.processPillC(), S.PROCESS_TERM.term, T(S.PROCESS_TERM.sub, s.lang), M.COL.process, procPillA,
  )

  // ---- silent-climax comets: auxiliary launch signals (decayed weight §18) —
  if (bi === S.B.climax) {
    for (const cl of S.CLIMAX_LAUNCHES) {
      const k = ramp(frac, cl.from, cl.to)
      if (k <= 0 || k >= 1) continue
      const inst = S.PROCS.find((p) => p.id === cl.procId)!
      const route: Vec2[] = [L.P_PROGRAM, L.P_OS, L.cellC(inst.spot)]
      const p = polylinePoint(route, easeInOutCubic(k))
      ctx.save()
      glow(ctx, p, '#ffd24a', 30, 0.35)
      ctx.fillStyle = hexA('#fff3c0', 0.8)
      ctx.beginPath()
      ctx.arc(p.x, p.y, 5, 0, TAU)
      ctx.fill()
      ctx.restore()
    }
  }
}

export const RENDERER_TABLE = {
  'program-card': drawProgramCard,
  'os-gate': drawOsGate,
  'machine-dock': drawMachineDock,
  'exec-field': drawExecField,
}
