// content/topics/02-operating-systems/01-process-from-program-to-execution/types.ts
// Chapter-local types. The generic interfaces live in chapter-loader/types.

import type { LocalizedText, Vec2 } from '../../../../chapter-loader/types'

export type L = LocalizedText

/** The chapter has exactly one scene: the stable world. */
export type Scene = 'world'

export interface Rect {
  x: number
  y: number
  w: number
  h: number
}

/** A part as the chapter describes it (mirrors the PartSpec of Topic 01). */
export interface PartSpec {
  id: string
  kind?: string
  pos: Vec2
  color: string
  name: string
  gloss: LocalizedText
  labelSize?: number
  extra?: Record<string, unknown>
}
