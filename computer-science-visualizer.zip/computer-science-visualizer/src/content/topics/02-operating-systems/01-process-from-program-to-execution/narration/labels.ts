// narration/labels.ts — UI strings of Topic 02 Chapter 01 (the Viewer reads
// these via chapter.ui; every key the generic Viewer may look for is provided).

import type { LocalizedText } from '../../../../../chapter-loader/types'

export const chapterTitle: LocalizedText = {
  en: 'What does the OS actually create when you launch a program?',
  vi: 'OS thực sự tạo ra cái gì khi bạn khởi chạy một chương trình?',
}

export const waitingLine: LocalizedText = {
  en: 'The machine from Topic 1 keeps running, and a program sits quietly on storage. Launch it — and watch closely what actually appears.',
  vi: 'Cỗ máy của Topic 1 vẫn đang chạy, còn một chương trình nằm im trên bộ lưu trữ. Hãy khởi chạy nó — và quan sát kỹ xem thứ gì thực sự xuất hiện.',
}

export const startButton: LocalizedText = {
  en: 'Launch the program',
  vi: 'Khởi chạy chương trình',
}

export const sceneTag: LocalizedText = {
  en: 'Execution space',
  vi: 'Không gian thực thi',
}

export const tipText: LocalizedText = {
  en: 'Click the program to launch it. Use the < > buttons or the dots to step through.',
  vi: 'Bấm vào chương trình để khởi chạy. Dùng nút < > hoặc các chấm để tua tới lui.',
}

export const doneLabel: LocalizedText = { en: 'Done', vi: 'Xong' }
