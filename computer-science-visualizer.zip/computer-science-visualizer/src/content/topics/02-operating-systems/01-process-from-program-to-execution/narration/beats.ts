// narration/beats.ts — the storyboard of Topic 02 Chapter 01: 14 beats in one
// stable world, answering exactly one question — what does the OS actually
// create when you launch a program? — with the answer OBSERVED before it is
// ever named.
//
// Structure (mirrors the blueprint beat table):
//   ACT 1 (b0–b1):  cognitive replay — the T01 machine waits; the Program is
//                   a static artifact; "you launch it — what happens?"
//   ACT 2 (b2–b3):  the launch request goes to the OS — not into the machine.
//   ACT 3 (b4–b6):  a NEW entity appears in execution space; the learner sees
//                   Program AND entity together (the rupture); only THEN the
//                   name: Process.
//   ACT 4 (b7–b9):  a second and third launch; three identical cells; the
//                   identity search fails; PID is disclosed as the identity
//                   each Process received at creation.
//   ACT 5 (b10–b11): one Process ends — the Program remains; a relaunch makes
//                   a NEW Process with a NEW PID while the others live on.
//   ACT 6 (b12):    SILENT CLIMAX — births and endings interleave, out of
//                   creation order, while the Program never changes.
//   ACT 7 (b13):    quiet integration + the permitted open loop (Guardian T02
//                   §5 CH01): does a Process actually run the whole time?
//
// Authoring rules honoured here:
//   • Knowledge Reveal Law (NARRATIVE_FRAMING §13): "Process" is first spoken
//     in b6, after the rupture was watched; "PID" first in b9, after the
//     identity search visibly failed. The scope gate proves both orderings.
//   • No unlearning (PHILOSOPHY §3): b9 narrates PID as DISCLOSURE — each
//     Process got its number the moment it was created — never as a late gift.
//   • The climax (b12) carries NO narration, NO term, NO conclusion.
//   • Quantities spoken (three Processes, the PID values) derive from
//     scenes/story.ts PROCS (§4.5) — asserted by the smoke gate.
//   • Forbidden territory (Guardian T02 §5 CH01 non-goals): no Ready/Waiting
//     states, no context switch, no scheduling/queues, no threads, no address
//     space, no program-loading re-teach. Enforced by the scope gate.
//   • Silent beats use a non-breaking space so the narration panel keeps its
//     height while showing nothing.

import type { BeatDescription } from '../../../../../chapter-loader/types'
import { B, DURATIONS, TRAVELS, RESTS, TRIO_PIDS, RELAUNCH, FIRST } from '../scenes/story'

const SILENT: { en: string; vi: string } = { en: '\u00A0', vi: '\u00A0' }

/** Build travel/rest fields from the story tables (single source, §4.5). */
const move = (bi: number) => {
  const t = TRAVELS[bi]
  if (t) {
    return t.holdFrom !== undefined
      ? { travel: { from: t.from, to: t.to, holdAt: { index: t.to, from: t.holdFrom, to: 1 } } }
      : { travel: { from: t.from, to: t.to } }
  }
  return { rest: { at: RESTS[bi] ?? 0 } }
}

export const beats: BeatDescription[] = [
  // ===========================================================================
  // ACT 1 — the world as Topic 01 left it
  // ===========================================================================
  {
    id: 'the-question',
    scene: 'world',
    line: {
      en: 'Here is where Topic 1 left us. The machine on the far side is still at work, executing billions of instructions per second — and everything it executes had to enter from somewhere. On this side sits a program, stored and still. Topic 1 ended with the question: who decides what enters that machine?',
      vi: 'Đây là nơi Topic 1 dừng lại. Cỗ máy ở phía xa vẫn đang làm việc, thực thi hàng tỷ lệnh mỗi giây — và mọi thứ nó thực thi đều phải đi vào từ đâu đó. Còn bên này là một chương trình, nằm yên trong bộ lưu trữ. Topic 1 khép lại bằng câu hỏi: ai quyết định thứ gì được đi vào cỗ máy ấy?',
    },
    duration: DURATIONS[B.question], active: 'machine', ...move(B.question), emerge: true,
  },
  {
    id: 'the-program',
    scene: 'world',
    line: {
      en: 'Look at the program itself — here, a photo viewer called “Photos”. It is a file: an ordered list of instructions, written once, sitting on storage. It is not doing anything — and on its own, it never will. So when you launch it… what actually happens?',
      vi: 'Nhìn kỹ chương trình — ở đây là một ứng dụng xem ảnh tên “Photos”. Nó là một tệp: một danh sách lệnh có thứ tự, được ghi một lần, nằm trên bộ lưu trữ. Nó không làm gì cả — và tự nó sẽ không bao giờ làm gì. Vậy khi bạn khởi chạy nó… điều gì thực sự xảy ra?',
    },
    duration: DURATIONS[B.program], active: 'program', ...move(B.program),
  },
  {
    // The refinement's one NEW beat: WHY the OS exists — established BEFORE
    // it acts, so the creation later has an understandable actor. Kept as a
    // sub-question of the central question, not a resource-management lecture.
    id: 'why-the-os',
    scene: 'world',
    line: {
      en: 'The machine — its CPU, its memory, its devices — is shared by everything that wants to run, and a stored file cannot manage a whole machine by itself. So computers run one special piece of system software for exactly that job. It stands between programs and the machine: the OS.',
      vi: 'Cỗ máy — bộ xử lý, bộ nhớ, các thiết bị — được chia sẻ cho mọi thứ muốn chạy, mà một tệp nằm im thì không thể tự quản lý cả cỗ máy. Vì vậy máy tính chạy một phần mềm hệ thống đặc biệt cho đúng việc đó. Nó đứng giữa các chương trình và cỗ máy: đó là OS — hệ điều hành.',
    },
    duration: DURATIONS[B.osIntro], active: 'os', ...move(B.osIntro),
  },

  // ===========================================================================
  // ACT 2 — the OS intervenes
  // ===========================================================================
  {
    id: 'launch',
    scene: 'world',
    line: {
      en: 'You launch the program. Watch closely: the program itself stays on its shelf — what travels is only the launch request. And it does not go to the machine. It goes to the OS.',
      vi: 'Bạn khởi chạy chương trình. Hãy nhìn kỹ: bản thân chương trình vẫn nằm nguyên trên kệ — thứ di chuyển chỉ là yêu cầu khởi chạy. Và nó không đi đến cỗ máy. Nó đến OS.',
    },
    duration: DURATIONS[B.launch], active: 'os', ...move(B.launch),
  },
  {
    id: 'os-receives',
    scene: 'world',
    line: {
      en: 'The request enters through the intake. Inside, the management layer wakes up — the OS is doing its work.',
      vi: 'Yêu cầu đi vào qua cổng tiếp nhận. Bên trong, tầng quản lý thức dậy — OS đang làm việc của nó.',
    },
    duration: DURATIONS[B.osReceives], active: 'os', ...move(B.osReceives),
  },

  // ===========================================================================
  // ACT 3 — the birth, the rupture, the name
  // ===========================================================================
  {
    id: 'birth',
    scene: 'world',
    line: {
      en: 'The OS finishes its work — and watch its far side. Out in the open space, something new just came into existence. It was not hiding inside the program file. It was not there a moment ago. The OS created it.',
      vi: 'OS hoàn tất công việc — hãy nhìn phía bên kia của nó. Ngoài khoảng không, một thứ mới vừa xuất hiện. Nó không hề nằm sẵn trong tệp chương trình. Một khoảnh khắc trước, nó chưa tồn tại. Chính OS đã tạo ra nó.',
    },
    duration: DURATIONS[B.birth], active: null, ...move(B.birth),
  },
  {
    id: 'not-the-program',
    scene: 'world',
    line: {
      en: 'Now look at both at once. The program: still on storage, unchanged, every line exactly where it was. And the new entity: somewhere else entirely, existing on its own. If the program never left its shelf… then what did the OS create?',
      vi: 'Giờ hãy nhìn cả hai cùng lúc. Chương trình: vẫn trên bộ lưu trữ, không đổi, từng dòng y nguyên chỗ cũ. Còn thực thể mới kia: ở một nơi hoàn toàn khác, tồn tại độc lập. Nếu chương trình chưa bao giờ rời kệ… thì OS đã tạo ra thứ gì?',
    },
    duration: DURATIONS[B.rupture], active: 'program', ...move(B.rupture),
  },
  {
    id: 'the-name',
    scene: 'world',
    line: {
      en: 'This kind of entity has a name: a Process. The program stays what it always was — a stored list of instructions. A Process is an execution instance the OS creates from a program and keeps managing: a separate entity with an existence of its own.',
      vi: 'Loại thực thể này có một cái tên: Process (tiến trình). Chương trình vẫn là chính nó xưa nay — một danh sách lệnh được lưu. Còn Process là một thực thể thực thi mà OS tạo ra từ chương trình và tiếp tục quản lý: một thực thể riêng, có sự tồn tại của riêng nó.',
    },
    duration: DURATIONS[B.nameProcess], active: null, ...move(B.nameProcess),
  },

  // ===========================================================================
  // ACT 4 — multiplicity and the identity problem
  // ===========================================================================
  {
    id: 'second-launch',
    scene: 'world',
    line: {
      en: 'Launch the same program again. A second request takes the same route to the OS — and the OS creates a second Process, in its own place, with its own creation. The first one is still there, untouched. Launching one stored program twice caused the OS to create two independent Processes.',
      vi: 'Khởi chạy đúng chương trình đó một lần nữa. Một yêu cầu thứ hai đi đúng con đường ấy đến OS — và OS tạo ra một Process thứ hai, ở một chỗ riêng, với một lần khởi tạo riêng. Process đầu tiên vẫn ở đó, không hề bị ảnh hưởng. Khởi chạy một chương trình hai lần đã khiến OS tạo ra hai Process độc lập.',
    },
    duration: DURATIONS[B.secondLaunch], active: null, ...move(B.secondLaunch),
  },
  {
    id: 'identity-problem',
    scene: 'world',
    line: {
      en: 'And a third. Now look at them — three Processes, born from the same program, and they look identical. Try to point at one: which is which? The OS must manage each of them separately. How can it possibly tell them apart?',
      vi: 'Và một cái thứ ba. Giờ nhìn chúng xem — ba Process, sinh ra từ cùng một chương trình, và trông giống hệt nhau. Thử chỉ vào một cái: cái nào là cái nào? OS phải quản lý từng cái một cách riêng biệt. Làm sao nó phân biệt được chúng?',
    },
    duration: DURATIONS[B.identityProblem], active: null, ...move(B.identityProblem),
  },
  {
    id: 'pid',
    scene: 'world',
    line: {
      en: `Once several Process instances exist, the OS needs a way to distinguish them. It has one: each Process has an identifier, associated with it at creation. Watch the associations resolve: ${TRIO_PIDS[0]}. ${TRIO_PIDS[1]}. ${TRIO_PIDS[2]}. That identifier is the PID — it belongs to one Process, and no other.`,
      vi: `Khi đã có nhiều Process cùng tồn tại, OS cần một cách để phân biệt chúng. Và nó có: mỗi Process có một định danh, được gắn với nó từ lúc khởi tạo. Hãy xem các liên kết hiện ra: ${TRIO_PIDS[0]}. ${TRIO_PIDS[1]}. ${TRIO_PIDS[2]}. Định danh đó là PID — mã định danh tiến trình — thuộc về đúng một Process, không của cái nào khác.`,
    },
    duration: DURATIONS[B.pid], active: 'os', ...move(B.pid),
  },

  // ===========================================================================
  // ACT 5 — lifetime and independence
  // ===========================================================================
  {
    id: 'lifetime',
    scene: 'world',
    line: {
      en: `Process ${FIRST.pid} has finished its work. Watch what happens to it — and watch what does not happen to the program. The Process's execution lifetime has ended: it is gone. The program remains as the stored artifact — unchanged, and it can be launched again. The lifetime that ended belonged to the Process, not to the program.`,
      vi: `Process ${FIRST.pid} đã xong việc. Hãy xem điều gì xảy ra với nó — và điều gì KHÔNG xảy ra với chương trình. Vòng đời thực thi của Process đã kết thúc: nó biến mất. Chương trình vẫn còn đó, là bản lưu không đổi — và có thể được khởi chạy lần nữa. Vòng đời vừa kết thúc là của Process, không phải của chương trình.`,
    },
    duration: DURATIONS[B.lifetime], active: null, ...move(B.lifetime),
  },
  {
    id: 'independent',
    scene: 'world',
    line: {
      en: `Launch it once more. A new Process — and look at its number: ${RELAUNCH.pid}, not ${FIRST.pid}. This is not the old Process coming back. It is a new, separate Process with its own identity and its own lifetime — and the two existing Processes were never disturbed.`,
      vi: `Khởi chạy thêm một lần nữa. Một Process mới — và nhìn con số của nó: ${RELAUNCH.pid}, không phải ${FIRST.pid}. Đây không phải Process cũ quay lại. Đây là một Process mới, tách biệt, với danh tính riêng và vòng đời riêng — và hai Process đang tồn tại kia không hề bị ảnh hưởng.`,
    },
    duration: DURATIONS[B.independent], active: null, ...move(B.independent),
  },

  // ===========================================================================
  // ACT 6 — THE SILENT CLIMAX
  // ===========================================================================
  {
    id: 'climax',
    scene: 'world',
    line: SILENT,
    duration: DURATIONS[B.climax], active: null, ...move(B.climax), effect: 'loop',
  },

  // ===========================================================================
  // ACT 7 — quiet integration + the open loop
  // ===========================================================================
  {
    id: 'bridge',
    scene: 'world',
    line: {
      en: 'One program on the shelf. The OS creating, numbering, and reclaiming Processes around it — each with its own identity, each with its own lifetime. But a Process that exists… is it actually executing every moment it is alive? That is the next question.',
      vi: 'Một chương trình trên kệ. OS tạo ra, đánh số, rồi thu hồi các Process quanh nó — mỗi cái một danh tính, mỗi cái một vòng đời. Nhưng một Process đang tồn tại… liệu có thực sự thực thi trong từng khoảnh khắc nó sống? Đó là câu hỏi tiếp theo.',
    },
    duration: DURATIONS[B.bridge], active: null, ...move(B.bridge), effect: 'loop',
  },
]
