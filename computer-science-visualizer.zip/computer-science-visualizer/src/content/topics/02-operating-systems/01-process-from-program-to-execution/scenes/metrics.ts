// scenes/metrics.ts — Topic 02 Chapter 01 layout *primitives*: every bare
// number the geometry and the renderers use, named exactly once. PURE — no
// imports — so scene geometry and the derived layout system build on it
// without cycles (VISUAL_LANGUAGE §2.2 Derivable Geometry; Layout Derivation
// Law, 02_PRODUCTION_LIFECYCLE.md).
//
// GEOMETRY AS PEDAGOGY (blueprint §5): the world is one stable scene with
// three semantic regions on the Topic-01 west→east causality axis:
//   STORAGE (the Program shelf, west)
//   → OS band (the gate of canon C-10, middle)
//   → EXECUTION FIELD (open space where Processes live, east; the quiet
//     Topic-01 machine emblem sits at its far edge).
// The Program NEVER moves. Processes are born at SCATTERED spots — provably
// not a queue, row or pipeline (anti-queue proof in the layout gate).

// ---- global spacing scale -----------------------------------------------------
export const BREATH = 8 // min text↔edge / text↔text breathing (world units)
export const CLIP_INSET = 16 // min content inset from the scene bbox edge
export const LABEL_GAP = 12 // gap between a box edge and its name label
export const LABEL_TEXT_H = 20 // approx cap-height of a name label (bbox math)

// ---- canvas font families (single source, same as Topic 01 chapters) ----------
export const FONT = "'Quicksand', system-ui, sans-serif"
export const MONO = "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace"

// ---- type scale (world px) — one named size per role, never a literal ---------
export const F = {
  partName: 19,
  osTitle: 22,
  appName: 17,
  machineTitle: 16,
  machineRes: 14,
  cellCaption: 15,
  cellId: 12,
  sourceCue: 11,
  chipText: 14,
  termPill: 21,
  chip: 16,
  sub: 14,
  small: 13,
  micro: 11,
  mark: 24,
}

// ---- palette (cross-domain consistency, VISUAL_LANGUAGE §10) -------------------
// cpu/machine keeps its Topic-01 identity; the Program keeps the Topic-01
// storage cyan; the OS wears the Topic-02 accent; Process life is green.
export const COL = {
  machine: '#fb923c',
  program: '#22d3ee',
  os: '#f472b6',
  process: '#4ade80',
  chipText: '#e2e8f0',
  dim: 'rgba(170,180,208,0.72)',
  panel: 'rgba(10,14,32,0.92)',
}

// ==============================================================================
// REGION 1 — STORAGE (west): a CONCRETE app (icon + name) on its shelf.
// The Program is not a generic abstract rectangle: it is a recognisable
// application — an app icon (its visual IDENTITY) + a name — resting on the
// storage shelf. The icon/name NEVER change for the whole chapter; the same
// identity stays stable while the OS creates distinct Process instances
// (each with its own PID). The icon is NOT the Process, never carries a PID,
// and never travels.
// ==============================================================================
export const AXIS_Y = 380 // the causal axis all three regions share
export const PROGRAM_C = { x: 240, y: AXIS_Y } // card centre (never changes)
export const PROGRAM_CARD = { w: 158, h: 180, r: 18 } // soft app tile
export const APP_ICON = { size: 78, r: 18 } // the app icon (rounded square)
export const APP_NAME = { size: 17, gapY: 22 } // the app name under the icon
export const SHELF = { dy: 14, overhang: 18, h: 5 } // the shelf line under the card

// ==============================================================================
// REGION 2 — THE OS (middle): the management layer between programs and
// the machine. Not a decorative gate or a narrow appliance: it is a
// moderately-wide system-software panel with a title header
// ("OS" + "Operating System"), an intake port (west, where launch requests
// arrive), a management core (three function rows whose tiny labels are
// revealed only AFTER each function has been observed — Knowledge Reveal
// Law), a creation port (east, where creation signals leave), and a quiet
// resource-context strip (the machine it manages: CPU · RAM · devices —
// shown, never explained; their internals are later chapters').
// ==============================================================================
export const OS_C = { x: 555, y: AXIS_Y }
/** Squared system band (r=6): the OS is a system LAYER, not an app card —
 *  the rounded grammar is reserved for the Program tile (r=18) and the
 *  Process cell (r=16). Grammar, not label, distinguishes the three types.
 *  Height kept tight (not a tall hollow box) so it reads as a *band* of
 *  system software, not an empty card. */
export const OS_BAND = { w: 230, h: 232, r: 6 }
/** Title header: the "OS" monogram + "Operating System / hệ điều hành". */
export const OS_TITLE = { dy: 34, size: 26 }
export const OS_SUB = { dy: 58, size: 11 }
/** The management core — the inner "system software" body. The OS holds
 *  software roles only, never the physical machine (removed in Round 8). */
export const OS_CORE = { inset: 18, top: 70, h: 112, r: 12 }
/** The three function rows inside the core (create / identify / manage).
 *  Slim + dim on purpose: they read as *action slats* that light only during
 *  their causal action — NOT as a fixed taxonomy of three OS modules. */
export const OS_ROW = { h: 26, gap: 12, padX: 12, r: 6 }
/** Intake (west) and creation (east) ports on the causal axis — the visible
 *  entry/exit sockets of the mediation. */
export const OS_PORT = { w: 12, h: 44, r: 4 }

// ==============================================================================
// REGION 3 — THE EXECUTION FIELD (east)
// ==============================================================================
export const FIELD = { x: 780, y: 150, w: 800, h: 460 }
/** The Process cell (same box for every instance — identity must come from
 *  somewhere else: that IS the chapter's identity problem). */
export const CELL = { w: 190, h: 120, r: 16 }
export const CELL_HEAD_H = 42
/** The Program-identity marker inside the cell (Round 4; subordinated in
 *  Round 5; repositioned in Round 6): a small copy of the SAME app icon +
 *  the app name, in the Program's cyan. It is a PROVENANCE cue — which
 *  program this Process is an instance of — and sits on the SECOND line,
 *  BELOW the class name, so the entity's own name ("Process") is the title
 *  and the source ("Photos") is a subordinate subtitle. Hierarchy:
 *  Process (title, 13px) > PID (15px chip) > Photos (subtitle, 10px dim).
 *  Drawn only once the entity is named (B06+). */
export const CELL_ID = { icon: 13, gap: 5, y: 32 }
/** The class name ("Process") — the entity's NAME, so it is the header TITLE
 *  (top line), never below the source marker. */
export const CELL_CAPTION_Y = 14
export const CELL_BARS = { count: 2, h: 7, gap: 8, padX: 18 }
/** STATIC widths of the cell's content marks (fractions of the bar track).
 *  Deliberately constant and identical for every instance (refinement Fix #1):
 *  a Process's existence must NOT read as "the CPU is executing it right
 *  now" — the marks say "this instance has contents", never "it is moving".
 *  Whether an existing Process is executing at a given moment is the open
 *  question CH01 hands to CH03. */
export const CELL_BAR_FRACS = [0.86, 0.62]
/** SCATTERED spots (cell centres) — uneven spacing, non-collinear, no row,
 *  no queue (anti-queue proof in the layout gate). S3 (Process D / PID 4402)
 *  sits down-left, clear of the enlarged machine region. */
export const SPOTS: { x: number; y: number }[] = [
  { x: 942, y: 258 }, // S0
  { x: 1181, y: 233 }, // S1
  { x: 965, y: 401 }, // S2
  { x: 1213, y: 546 }, // S3
  { x: 925, y: 544 }, // S4
]

/** The PID chip — docked strictly INSIDE its owning cell (blueprint §5 G4). */
export const CHIP = { w: 104, h: 26, r: 13, dyFromCellTop: 76 }

/** The quiet Topic-01 machine emblem at the field's east edge (continuity). */
export const MACHINE_C = { x: 1500, y: AXIS_Y }
/** THE MACHINE context region (Round 8; enlarged on owner request to be
 *  comparable to / larger than the Program card) — the physical computer the
 *  OS manages. A low-salience container holding three resource markers
 *  (CPU · RAM · I/O), each drawn with a mini hardware glyph echoing the
 *  Topic-01 visual language (CPU chip with pins + core; RAM sticks; I/O
 *  port). Replaces the former standalone "CPU" emblem so the machine is
 *  represented in exactly ONE place, distinct from the OS. Static by design:
 *  the machine must not pulse (that would imply CPU activity and contradict
 *  ALIVE ≠ EXECUTING). */
export const MACHINE = { w: 150, h: 200, r: 8 }
export const MACHINE_SLOT = { w: 118, h: 38, gap: 14, topPad: 54 }

/** The 'execution space' orientation chip, top-left of the field. */
export const ORIENT = { h: 32, r: 16, padX: 16 }

// ---- animation feel ------------------------------------------------------------
export const PULSE = { birthR: 84, dieR: 96, ring: 3 }
export const SELECTOR = { pad: 10, ring: 3 }
export const TERM = { h: 44, r: 22, padX: 22 }
export const SPARK_NEAR = 130 // proximity radius: spark near a part ⇒ causal glow
