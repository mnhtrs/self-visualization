// scenes/01-world.ts — the single stable world of Topic 02 Chapter 01:
// STORAGE (the Program on its shelf, west) → OS band (the gate, middle) →
// EXECUTION FIELD (open space where Processes live; the quiet Topic-01
// machine emblem at its east edge). One scene, zero relocations
// (VISUAL_LANGUAGE §6 Spatial Stability). Every anchor derives from
// scenes/layout.ts (Layout Derivation Law).

import * as L from './layout'
import * as M from './metrics'
import type { Vec2 } from '../../../../../chapter-loader/types'
import type { PartSpec } from '../types'

// ---- entities ----------------------------------------------------------------

/** The execution field painter goes FIRST (background of the east region):
 *  it draws the field wash, the orientation chip, every Process cell, the
 *  PID chips, the selector, the pulses, the term pills and the climax comets
 *  — all read from scenes/story.ts. */
export const field: PartSpec = {
  id: 'field',
  kind: 'exec-field',
  pos: { x: M.FIELD.x + M.FIELD.w / 2, y: M.FIELD.y + M.FIELD.h / 2 },
  color: M.COL.process,
  name: '',
  gloss: { en: '', vi: '' },
}

export const program: PartSpec = {
  id: 'program',
  kind: 'program-card',
  pos: { ...M.PROGRAM_C },
  color: M.COL.program,
  name: 'Program',
  gloss: {
    en: 'A stored application — here, “Photos”: an ordered list of instructions, written once, doing nothing on its own. Exactly what Topic 1 called “a program”.',
    vi: 'Một ứng dụng được lưu — ở đây là “Photos”: danh sách lệnh có thứ tự, ghi một lần, tự nó không làm gì cả. Chính là “chương trình” như Topic 1 đã biết.',
  },
}

export const os: PartSpec = {
  id: 'os',
  kind: 'os-gate',
  pos: { ...M.OS_C },
  color: M.COL.os,
  name: 'OS',
  gloss: {
    en: 'The Operating System — the manager that stands between stored programs and the machine. Every launch request comes here first.',
    vi: 'Hệ điều hành — người quản lý đứng giữa các chương trình được lưu và cỗ máy. Mọi yêu cầu khởi chạy đều đến đây trước.',
  },
}

export const machine: PartSpec = {
  id: 'machine',
  kind: 'machine-dock',
  pos: { ...M.MACHINE_C },
  color: M.COL.machine,
  name: 'Machine',
  gloss: {
    en: 'The physical machine — its CPU, memory, and I/O devices. This is the hardware context the OS manages.',
    vi: 'Cỗ máy vật lý — bộ xử lý, bộ nhớ và các thiết bị I/O. Đây là phần cứng mà OS quản lý.',
  },
}

export const PATH_WORLD: Vec2[] = L.PATH_WORLD
export const BBOX_WORLD = L.bboxWorld()
export const PROGRAM_HIT_RECT = L.PROGRAM_HIT()
