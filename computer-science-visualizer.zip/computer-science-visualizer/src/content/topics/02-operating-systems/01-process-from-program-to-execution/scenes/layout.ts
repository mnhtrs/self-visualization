// scenes/layout.ts — the derived *layout system* for Topic 02 Chapter 01.
// Every rectangle and anchor the renderers draw derives HERE from named
// metrics + container functions — no inline literal coordinates (Layout
// Derivation Law; VISUAL_LANGUAGE §2.2).
//
// Imports metrics (pure) + nothing else; nothing imports this file back.

import * as M from './metrics'
import type { Vec2 } from '../../../../../chapter-loader/types'

export interface Rect { x: number; y: number; w: number; h: number; r: number }

// =============================================================================
// REGION 1 — the Program (a concrete app: icon + name), spatially persistent
// =============================================================================
export const programRect = (): Rect => ({
  x: M.PROGRAM_C.x - M.PROGRAM_CARD.w / 2,
  y: M.PROGRAM_C.y - M.PROGRAM_CARD.h / 2,
  w: M.PROGRAM_CARD.w,
  h: M.PROGRAM_CARD.h,
  r: M.PROGRAM_CARD.r,
})

/** The app icon (the Program's visual identity) — centred near the top. */
export const appIconRect = (): Rect => {
  const p = programRect()
  const s = M.APP_ICON.size
  return {
    x: p.x + (p.w - s) / 2,
    y: p.y + 24,
    w: s,
    h: s,
    r: M.APP_ICON.r,
  }
}

/** Where the app name sits (centred under the icon). */
export const appNamePos = (): Vec2 => {
  const p = programRect()
  const icon = appIconRect()
  return { x: p.x + p.w / 2, y: icon.y + icon.h + M.APP_NAME.gapY }
}

/** The shelf line under the card — "this thing HAS a place it lives". */
export const shelfLine = (): [Vec2, Vec2] => {
  const p = programRect()
  const y = p.y + p.h + M.SHELF.dy
  return [
    { x: p.x - M.SHELF.overhang, y },
    { x: p.x + p.w + M.SHELF.overhang, y },
  ]
}

// =============================================================================
// REGION 2 — the OS: management layer between programs and the machine.
// Derived internal structure: intake port (west) → management core (three
// function rows) → creation port (east) → resource-context strip (south).
// =============================================================================
export const osRect = (): Rect => ({
  x: M.OS_C.x - M.OS_BAND.w / 2,
  y: M.OS_C.y - M.OS_BAND.h / 2,
  w: M.OS_BAND.w,
  h: M.OS_BAND.h,
  r: M.OS_BAND.r,
})

/** The management core — the "system software" body inside the OS. */
export const osCoreRect = (): Rect => {
  const r = osRect()
  return {
    x: r.x + M.OS_CORE.inset,
    y: r.y + M.OS_CORE.top,
    w: r.w - 2 * M.OS_CORE.inset,
    h: M.OS_CORE.h,
    r: M.OS_CORE.r,
  }
}

/** Function row `i` (0 = create, 1 = identify, 2 = manage) inside the core. */
export const osRowRect = (i: number) => {
  const c = osCoreRect()
  const rows = 3
  const innerH = rows * M.OS_ROW.h + (rows - 1) * M.OS_ROW.gap
  const top = c.y + (c.h - innerH) / 2
  return {
    x: c.x + M.OS_ROW.padX,
    y: top + i * (M.OS_ROW.h + M.OS_ROW.gap),
    w: c.w - 2 * M.OS_ROW.padX,
    h: M.OS_ROW.h,
    r: M.OS_ROW.r,
  }
}

/** Where the creation signal leaves the OS (east port, on the axis). */
export const osEastPort = (): Vec2 => {
  const r = osRect()
  return { x: r.x + r.w, y: M.AXIS_Y }
}
/** Where a launch request enters the OS (west port, on the axis). */
export const osWestPort = (): Vec2 => {
  const r = osRect()
  return { x: r.x, y: M.AXIS_Y }
}
/** Port rectangles (drawn as sockets on the boundary). */
export const osWestPortRect = (): Rect => {
  const p = osWestPort()
  return { x: p.x - M.OS_PORT.w / 2, y: p.y - M.OS_PORT.h / 2, w: M.OS_PORT.w, h: M.OS_PORT.h, r: M.OS_PORT.r }
}
export const osEastPortRect = (): Rect => {
  const p = osEastPort()
  return { x: p.x - M.OS_PORT.w / 2, y: p.y - M.OS_PORT.h / 2, w: M.OS_PORT.w, h: M.OS_PORT.h, r: M.OS_PORT.r }
}

// =============================================================================
// REGION 3 — the execution field, its spots, cells and chips
// =============================================================================
export const fieldRect = () => ({ ...M.FIELD })

/** The Process cell at spot `s` (every instance identical by design —
 *  the identity problem is real, not decorative). */
export const cellRect = (s: number): Rect => ({
  x: M.SPOTS[s].x - M.CELL.w / 2,
  y: M.SPOTS[s].y - M.CELL.h / 2,
  w: M.CELL.w,
  h: M.CELL.h,
  r: M.CELL.r,
})

export const cellC = (s: number): Vec2 => ({ ...M.SPOTS[s] })

/** Activity bar `i` inside the cell at spot `s`. */
export const cellBarRect = (s: number, i: number) => {
  const c = cellRect(s)
  return {
    x: c.x + M.CELL_BARS.padX,
    y: c.y + M.CELL_HEAD_H + BARS_TOP_PAD + i * (M.CELL_BARS.h + M.CELL_BARS.gap),
    w: c.w - 2 * M.CELL_BARS.padX,
    h: M.CELL_BARS.h,
  }
}
const BARS_TOP_PAD = 8

/** The PID chip rect — strictly INSIDE its owning cell (blueprint G4). */
export const chipRect = (s: number): Rect => {
  const c = cellRect(s)
  return {
    x: c.x + (c.w - M.CHIP.w) / 2,
    y: c.y + M.CHIP.dyFromCellTop,
    w: M.CHIP.w,
    h: M.CHIP.h,
    r: M.CHIP.r,
  }
}

export const chipC = (s: number): Vec2 => {
  const r = chipRect(s)
  return { x: r.x + r.w / 2, y: r.y + r.h / 2 }
}

/** The quiet machine emblem (Topic-01 continuity anchor, east edge). */
export const machineRect = (): Rect => ({
  x: M.MACHINE_C.x - M.MACHINE.w / 2,
  y: M.MACHINE_C.y - M.MACHINE.h / 2,
  w: M.MACHINE.w,
  h: M.MACHINE.h,
  r: M.MACHINE.r,
})

/** Resource slot `i` (0=CPU, 1=RAM, 2=I/O) stacked vertically inside the
 *  machine region. */
export const machineSlotRect = (i: number): Rect => {
  const m = machineRect()
  return {
    x: m.x + (m.w - M.MACHINE_SLOT.w) / 2,
    y: m.y + M.MACHINE_SLOT.topPad + i * (M.MACHINE_SLOT.h + M.MACHINE_SLOT.gap),
    w: M.MACHINE_SLOT.w,
    h: M.MACHINE_SLOT.h,
    r: 4,
  }
}

/** The 'execution space' orientation chip, top-left inside the field. */
export const orientChip = (textW: number) => ({
  x: M.FIELD.x,
  y: M.FIELD.y - M.ORIENT.h - M.BREATH,
  w: textW + 2 * M.ORIENT.padX,
  h: M.ORIENT.h,
  r: M.ORIENT.r,
})

// =============================================================================
// Term pill anchors (Process at B06, PID at B09)
// =============================================================================
/** "Process" pill: names the CLASS of entity, not one instance (refinement
 *  §24) — so it sits in the concept band ABOVE the whole execution field,
 *  clear of every spot, while the small per-cell caption carries the class
 *  name onto each instance. */
export const processPillC = (): Vec2 => {
  const f = fieldRect()
  return { x: f.x + f.w / 2, y: f.y - M.TERM.h / 2 - M.BREATH }
}
/** "PID" pill: south of the OS band (the giver of identities). */
export const pidPillC = (): Vec2 => {
  const r = osRect()
  return { x: r.x + r.w / 2, y: r.y + r.h + M.TERM.h / 2 + M.BREATH * 4 }
}

// =============================================================================
// The protagonist path — the launch signal's world route.
// Anchors: 0=Program · 1=OS · 2=S0 · 3=Program · 4=OS · 5=S1 · 6=Program ·
//          7=OS · 8=S2 · 9=OS · 10=S0 · 11=Program · 12=OS · 13=S3.
// Every launch is the SAME causal route: Program → OS → an empty spot
// (Connection Identity §2.1: the launch route is one repeated, identical
// logical path — drawn as the same line each time).
// =============================================================================
export const P_PROGRAM: Vec2 = { ...M.PROGRAM_C }
export const P_OS: Vec2 = { ...M.OS_C }

export const PATH_WORLD: Vec2[] = [
  P_PROGRAM, P_OS, cellC(0), // launch 1 → Process A
  P_PROGRAM, P_OS, cellC(1), // launch 2 → Process B
  P_PROGRAM, P_OS, cellC(2), // launch 3 → Process C
  P_OS, cellC(0), // back to the OS (identity), then to A (lifetime)
  P_PROGRAM, P_OS, cellC(3), // launch 4 → Process D (independence)
]

// =============================================================================
// Scene bbox — derived from content + clip inset
// =============================================================================
export const bboxWorld = () => {
  const p = programRect()
  const os = osRect()
  const f = fieldRect()
  const pid = pidPillC()
  const minX = Math.min(p.x - M.SHELF.overhang, os.x) - M.CLIP_INSET
  const maxX = f.x + f.w + M.CLIP_INSET
  const minY = Math.min(f.y - M.ORIENT.h - M.BREATH, os.y, p.y) - M.CLIP_INSET - M.LABEL_TEXT_H
  const maxY =
    Math.max(
      f.y + f.h,
      os.y + os.h,
      shelfLine()[0].y + M.LABEL_GAP + M.LABEL_TEXT_H,
      pid.y + M.TERM.h / 2,
    ) + M.CLIP_INSET
  return { minX, maxX, minY, maxY }
}

/** The hit zone: the Program card (click to launch = click to start). */
export const PROGRAM_HIT = () => {
  const p = programRect()
  return { x: p.x, y: p.y, w: p.w, h: p.h }
}
