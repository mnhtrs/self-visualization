// scenes/story.ts — the single source of truth for every beat-driven fact of
// Topic 02 Chapter 01: the beat map, the Process instance lifecycle table
// (birth / chip / death windows), the PID values, the rupture pulses, the
// identity-selector schedule, the term-pill windows and the silent-climax
// event schedule. Everything is a pure function of (beatIndex, beatFraction),
// so scrubbing, pausing and stepping backwards stay deterministic
// (VISUAL_LANGUAGE §15).
//
// Quantity discipline (PEDAGOGICAL_SYSTEM §4.5): every number the narration
// speaks — "three Processes", 4312, 4318, 4331, 4402 — is DERIVED from the
// PROCS table below, never typed twice.
//
// Affirmative-state discipline (§4.6): a cell is 'alive' / 'dying' because its
// OWN lifecycle window says so — never as the negation of another state.
//
// SCOPE LOCK (Guardian T02 §5 CH01 non-goals): nothing here models Ready /
// Running / Waiting states, context switching, scheduling, queues, threads or
// address-space internals. A Process here has exactly what CH01 owns:
// existence, identity (PID) and lifetime.

// =============================================================================
// Beat index map
// =============================================================================
export const B = {
  question: 0, // cognitive replay of the T01 exit state + the debt question
  program: 1, // the Program is a static artifact
  osIntro: 2, // WHY an OS exists: shared machine, programs are artifacts,
  //             system software manages — the OS (hệ điều hành)
  launch: 3, // the launch REQUEST travels Program → OS (the Program stays)
  osReceives: 4, // the OS visibly takes over (intake → management core)
  birth: 5, // a NEW entity appears in execution space (creation port emits)
  rupture: 6, // Program AND new entity visible together — Program unchanged
  nameProcess: 7, // the term "Process (tiến trình)" lands — class, not instance
  secondLaunch: 8, // launching the same Program again ⇒ the OS creates another
  identityProblem: 9, // third Process; identical cells; the selector fails
  pid: 10, // identity disclosure — PID (mã định danh tiến trình)
  lifetime: 11, // Process A's execution lifetime ends; the Program remains
  independent: 12, // relaunch ⇒ NEW Process, NEW PID; others untouched
  climax: 13, // SILENT — the model at scale
  bridge: 14, // quiet integration + the permitted open loop
} as const

/** Beat durations (ms) — narration/beats.ts reads these; never typed twice. */
export const DURATIONS: number[] = [
  6500, // question
  6500, // program
  8500, // osIntro (the one new beat of the refinement — why the OS exists)
  5500, // launch
  5000, // osReceives
  7000, // birth
  7000, // rupture
  6000, // nameProcess
  7000, // secondLaunch
  8000, // identityProblem
  9000, // pid
  8000, // lifetime
  8000, // independent
  16000, // climax (silent)
  10000, // bridge
]

// =============================================================================
// The Process instances — identity, spot, and lifecycle windows.
// A window is (beat, frac). An instance is FULLY ALIVE from its aliveAt
// window onward and GONE from its goneAt window onward.
// =============================================================================
export interface ProcWindow {
  beat: number
  frac: number
}

export interface ProcInst {
  id: string
  /** Index into layout SPOTS — scattered, never a queue. */
  spot: number
  /** The identity the OS assigned AT CREATION (disclosed at B.pid). */
  pid: number
  /** Birth pulse begins (creation event starts). */
  birthAt: ProcWindow
  /** Boundary complete — the cell is persistent from here. */
  aliveAt: ProcWindow
  /** The PID chip starts flying from the OS (null = never shown … unused). */
  chipAt: ProcWindow
  /** The chip is docked inside the cell from here. */
  chipDockAt: ProcWindow
  /** Termination begins (null = still alive at chapter end). */
  dieAt: ProcWindow | null
  /** Fully gone from here. */
  goneAt: ProcWindow | null
}

export const PROCS: ProcInst[] = [
  {
    id: 'A', spot: 0, pid: 4312,
    birthAt: { beat: B.birth, frac: 0.35 }, aliveAt: { beat: B.birth, frac: 0.75 },
    chipAt: { beat: B.pid, frac: 0.12 }, chipDockAt: { beat: B.pid, frac: 0.3 },
    dieAt: { beat: B.lifetime, frac: 0.45 }, goneAt: { beat: B.lifetime, frac: 0.8 },
  },
  {
    id: 'B', spot: 1, pid: 4318,
    birthAt: { beat: B.secondLaunch, frac: 0.6 }, aliveAt: { beat: B.secondLaunch, frac: 0.88 },
    chipAt: { beat: B.pid, frac: 0.38 }, chipDockAt: { beat: B.pid, frac: 0.56 },
    dieAt: { beat: B.climax, frac: 0.68 }, goneAt: { beat: B.climax, frac: 0.74 },
  },
  {
    id: 'C', spot: 2, pid: 4331,
    birthAt: { beat: B.identityProblem, frac: 0.45 }, aliveAt: { beat: B.identityProblem, frac: 0.68 },
    chipAt: { beat: B.pid, frac: 0.62 }, chipDockAt: { beat: B.pid, frac: 0.8 },
    dieAt: { beat: B.climax, frac: 0.28 }, goneAt: { beat: B.climax, frac: 0.35 },
  },
  {
    id: 'D', spot: 3, pid: 4402,
    birthAt: { beat: B.independent, frac: 0.55 }, aliveAt: { beat: B.independent, frac: 0.78 },
    chipAt: { beat: B.independent, frac: 0.8 }, chipDockAt: { beat: B.independent, frac: 0.92 },
    dieAt: { beat: B.climax, frac: 0.92 }, goneAt: { beat: B.climax, frac: 0.98 },
  },
  {
    id: 'E', spot: 4, pid: 4417,
    birthAt: { beat: B.climax, frac: 0.1 }, aliveAt: { beat: B.climax, frac: 0.16 },
    chipAt: { beat: B.climax, frac: 0.17 }, chipDockAt: { beat: B.climax, frac: 0.21 },
    dieAt: { beat: B.climax, frac: 0.58 }, goneAt: { beat: B.climax, frac: 0.64 },
  },
  {
    id: 'F', spot: 0, pid: 4459,
    birthAt: { beat: B.climax, frac: 0.45 }, aliveAt: { beat: B.climax, frac: 0.52 },
    chipAt: { beat: B.climax, frac: 0.53 }, chipDockAt: { beat: B.climax, frac: 0.57 },
    dieAt: null, goneAt: null,
  },
  {
    id: 'G', spot: 2, pid: 4473,
    birthAt: { beat: B.climax, frac: 0.83 }, aliveAt: { beat: B.climax, frac: 0.9 },
    chipAt: { beat: B.climax, frac: 0.9 }, chipDockAt: { beat: B.climax, frac: 0.94 },
    dieAt: null, goneAt: null,
  },
]

/** The three Processes the identity problem is about (order of birth). */
export const IDENTITY_TRIO = ['A', 'B', 'C'] as const

// =============================================================================
// Time comparison on (beat, frac)
// =============================================================================
export const cmp = (beat: number, frac: number, w: ProcWindow): number =>
  beat !== w.beat ? beat - w.beat : frac - w.frac

export const after = (beat: number, frac: number, w: ProcWindow): boolean =>
  cmp(beat, frac, w) >= 0

/** Linear progress of (beat,frac) through the window [a, b] (same beat). */
export function winProgress(beat: number, frac: number, a: ProcWindow, b: ProcWindow): number {
  if (!after(beat, frac, a)) return 0
  if (after(beat, frac, b)) return 1
  if (beat !== a.beat) return 1
  const span = b.frac - a.frac
  return span <= 0 ? 1 : (frac - a.frac) / span
}

// =============================================================================
// The lifecycle state of one instance at (beat, frac)
// =============================================================================
export type CellPhase = 'unborn' | 'birthing' | 'alive' | 'dying' | 'gone'

export interface CellState {
  phase: CellPhase
  /** 0..1 progress through the current phase (birthing / dying). */
  k: number
  /** PID chip: 'hidden' | 'flying' | 'docked' — with flight progress. */
  chip: 'hidden' | 'flying' | 'docked'
  chipK: number
}

export function cellStateAt(inst: ProcInst, beat: number, frac: number): CellState {
  let phase: CellPhase
  let k = 0
  if (!after(beat, frac, inst.birthAt)) {
    phase = 'unborn'
  } else if (!after(beat, frac, inst.aliveAt)) {
    phase = 'birthing'
    k = winProgress(beat, frac, inst.birthAt, inst.aliveAt)
  } else if (inst.dieAt && inst.goneAt && after(beat, frac, inst.goneAt)) {
    phase = 'gone'
  } else if (inst.dieAt && inst.goneAt && after(beat, frac, inst.dieAt)) {
    phase = 'dying'
    k = winProgress(beat, frac, inst.dieAt, inst.goneAt)
  } else {
    phase = 'alive'
  }

  let chip: CellState['chip'] = 'hidden'
  let chipK = 0
  if (phase === 'alive' || phase === 'dying') {
    if (after(beat, frac, inst.chipDockAt)) {
      chip = 'docked'
      chipK = 1
    } else if (after(beat, frac, inst.chipAt)) {
      chip = 'flying'
      chipK = winProgress(beat, frac, inst.chipAt, inst.chipDockAt)
    }
  }
  // A dying cell's chip fades with the cell — the renderer reads phase for that.
  return { phase, k, chip, chipK }
}

/** All instances alive (incl. birthing past pulse-midpoint) at (beat, frac). */
export function aliveCount(beat: number, frac: number): number {
  let n = 0
  for (const p of PROCS) {
    const st = cellStateAt(p, beat, frac)
    if (st.phase === 'alive' || st.phase === 'dying' || st.phase === 'birthing') n++
  }
  return n
}

// =============================================================================
// Beat-local event windows (all fracs within their own beat)
// =============================================================================

/** B05 — the rupture: two restrained pulses + a still pause. */
/** B05 — the rupture: the Program and the Process must be seen TOGETHER.
 *  The pulses OVERLAP (true simultaneity = coexistence, the chapter's central
 *  distinction), then the eye is sent BACK to the Program once more ("it is
 *  still there, unchanged"). Sequential pulses would wrongly separate them in
 *  time; overlap is what proves "two things at once". */
export const RUPTURE = {
  programPulse: { from: 0.1, to: 0.42 }, // Program salient first
  cellPulse: { from: 0.3, to: 0.68 }, // then BOTH salient (overlap)
  lookBack: { from: 0.62, to: 0.88 }, // Program re-glows: "still unchanged"
}

/** B08 (second launch) — while Process B is born, Process A emits ONE
 *  restrained "still here, untouched" pulse: the second launch does NOT
 *  disturb the first instance. */
export const INDEP_A_ACK = { from: 0.62, to: 0.92 }

/** B10 (lifetime) — after Process A is gone, the surviving Processes (B, C)
 *  emit one restrained "still alive" pulse each: only A ended, the others and
 *  the Program were never touched. */
export const SURVIVOR_ACK = { from: 0.84, to: 0.97 }

/** B06 — the "Process" term pill resolves (after the rupture was watched). */
export const PROCESS_PILL = { beat: B.nameProcess, from: 0.25, to: 0.5 }

/** B08 — the identity selector: a ring hops A → B → C → A and finds nothing
 *  to read. The ambiguity must be OBSERVED before PID may appear. */
export const SELECTOR = {
  from: 0.7,
  to: 1.0,
  /** Spot sequence the ring visits (trio spots + back to the first). */
  hops: [0, 1, 2, 0],
}

/** B09 — the "PID" term pill (after all three chips were watched docking). */
export const PID_PILL = { beat: B.pid, from: 0.84, to: 0.95 }

/** B10 — Process A's completion shimmer before termination begins
 *  (an affirmative "work complete" state, §4.6 — never `!alive`). */
export const COMPLETION = { from: 0.25, to: 0.45 }

// =============================================================================
// The silent climax (B12) — auxiliary launch signals.
// The golden protagonist rests at the OS (ownership home); each climax launch
// is an auxiliary comet with decayed weight (VISUAL_LANGUAGE §18) that travels
// Program → OS → spot and hands over to the birth pulse of its instance.
// =============================================================================
export interface ClimaxLaunch {
  procId: string
  /** comet departs the Program at `from`, reaches the spot at `to` —
   *  `to` equals the instance's birthAt.frac by construction. */
  from: number
  to: number
}

export const CLIMAX_LAUNCHES: ClimaxLaunch[] = [
  { procId: 'E', from: 0.03, to: 0.1 },
  { procId: 'F', from: 0.38, to: 0.45 },
  { procId: 'G', from: 0.76, to: 0.83 },
]

// =============================================================================
// Pre-climax launch signals are the PROTAGONIST itself (engine travel beats).
// These tables are the single source the beats array derives from.
// PATH anchors (scenes/layout.ts PATH_WORLD):
//   0 P · 1 OS · 2 S0 · 3 P · 4 OS · 5 S1 · 6 P · 7 OS · 8 S2 ·
//   9 OS · 10 S0 · 11 P · 12 OS · 13 S3
// =============================================================================
export const PATH_ANCHORS = 14

export interface TravelSpec {
  from: number
  to: number
  /** The spark parks at `to` from this beat fraction on (engine holdAt). */
  holdFrom?: number
}

export const TRAVELS: Record<number, TravelSpec> = {
  [B.launch]: { from: 0, to: 1 }, // the launch REQUEST: Program → OS
  [B.birth]: { from: 1, to: 2, holdFrom: 0.35 }, // OS → S0, arrive at birth pulse
  [B.secondLaunch]: { from: 2, to: 5, holdFrom: 0.6 }, // S0 → P → OS → S1
  [B.identityProblem]: { from: 5, to: 8, holdFrom: 0.45 }, // S1 → P → OS → S2
  [B.pid]: { from: 8, to: 9, holdFrom: 0.1 }, // S2 → OS (the identity associator)
  [B.lifetime]: { from: 9, to: 10, holdFrom: 0.25 }, // OS → S0, watch A finish
  [B.independent]: { from: 10, to: 13, holdFrom: 0.55 }, // S0 → P → OS → S3
}

export const RESTS: Record<number, number> = {
  [B.question]: 0, // at the Program
  [B.program]: 0,
  [B.osIntro]: 0, // still at the Program — no launch has happened yet;
  //                the OS reveals its structure while the request waits
  [B.osReceives]: 1, // at the OS
  [B.rupture]: 2, // at cell A — the eye is sent west by the pulse order
  [B.nameProcess]: 2,
  [B.climax]: 12, // at the OS — the manager of the whole pattern
  [B.bridge]: 12,
}

// =============================================================================
// The OS internal causal sequence (refinement §5–6): the OS is a management
// layer with an intake port, a management core of three function rows, a
// creation port, and a resource-context strip. Every window below is a pure
// (beat, frac) fact the renderer reads — never re-derived in draw code.
// =============================================================================

/** B02 (osIntro): the machine context (far-east region) lights its resource
 *  slots in turn, the stored Program emits a restrained "inert artifact"
 *  pulse, then the OS's management core resolves in the middle. The three-part
 *  sequence makes the mediation visible: machine (shared) → Program (a stored
 *  file, by itself) → OS (system software standing between them). The machine
 *  is revealed as a SEPARATE physical context — the OS does not contain it. */
export const OS_INTRO = {
  machine: { from: 0.22, to: 0.42 }, // CPU · RAM · I/O slots light in turn
  programPulse: { from: 0.36, to: 0.5 }, // the Program: a stored artifact, inert
  core: { from: 0.5, to: 0.7 }, // the management core resolves
}

/** Which OS core function-row highlights during which causal action.
 *  Row 0 = creation, row 1 = identity, row 2 = management. */
export const OS_ROWS = {
  create: 0,
  identify: 1,
  manage: 2,
}

/** B04 (osReceives): intake port lights, then the core wakes row by row. */
export const OS_RECEIVE = {
  intake: { from: 0.08, to: 0.3 },
  coreWake: { from: 0.3, to: 0.75 },
}

/** B05 (birth): the creation row works, then the east port emits. */
export const OS_CREATE = {
  row: { from: 0.0, to: 0.3 },
  emit: { from: 0.18, to: 0.4 },
}

/** Knowledge Reveal for the OS row micro-labels: each function row gains its
 *  tiny label only AFTER the learner has WATCHED that function happen. */
export const OS_ROW_LABEL_AT: ProcWindow[] = [
  { beat: B.nameProcess, frac: 0.3 }, // "create" — after a creation was watched
  { beat: B.pid, frac: 0.85 }, // "identify" — after identity was disclosed
  { beat: B.independent, frac: 0.9 }, // "manage" — after lifetimes were managed
]

/** The identity association (refinement §11/23): during each chip's resolve
 *  window the OS's identify-row pulses and a focus ring closes on the owning
 *  cell — association, not physical delivery. */
export const IDENTITY_FOCUS_RING = { pad: 8, ring: 2.5 }

// =============================================================================
// Captions (bilingual, plain language) — single source for canvas text
// =============================================================================
export const CAP = {
  orient: { en: 'execution space', vi: 'không gian thực thi' },
  shelf: { en: 'storage', vi: 'bộ lưu trữ' },
  cellCaption: { en: 'Process', vi: 'Process' },
  chipPrefix: 'PID', // locked English term — appears only from B.pid onward
  osLetters: 'OS',
  /** The OS title header: monogram + plain-language subtitle. */
  osSubtitle: { en: 'Operating System', vi: 'Hệ điều hành' },
  /** The concrete app's name — the Program's stable visual identity.
   *  A proper noun, kept untranslated in both languages. */
  appName: { en: 'Photos', vi: 'Photos' },
  machineName: { en: 'CPU', vi: 'CPU' },
  /** OS core function rows — micro-labels revealed AFTER observation
   *  (windows: OS_ROW_LABEL_AT). Plain verbs, no jargon. */
  osRows: [
    { en: 'create', vi: 'tạo' },
    { en: 'identify', vi: 'định danh' },
    { en: 'manage', vi: 'quản lý' },
  ] as { en: string; vi: string }[],
  /** The resource-context strip: the shared machine the OS manages.
   *  Context only — internals belong to T01 (done) and later chapters. */
  /** THE MACHINE context region (Round 8): the physical computer the OS
   *  manages — CPU · RAM · I/O as lightweight resource markers. Shown in
   *  exactly ONE place (the far-east region), never inside the OS. */
  machineTitle: { en: 'the machine', vi: 'cỗ máy' },
  machineRes: ['CPU', 'RAM', 'I/O'],
}

export const PROCESS_TERM = {
  term: 'Process',
  sub: {
    en: 'an execution instance the OS created',
    vi: 'một thực thể thực thi do OS tạo ra',
  },
}

export const PID_TERM = {
  term: 'PID',
  sub: {
    en: 'the identifier of exactly one Process',
    vi: 'định danh của đúng một Process',
  },
}

/** Convenience: the trio's PIDs in birth order (narration derives from this). */
export const TRIO_PIDS: number[] = IDENTITY_TRIO.map(
  (id) => PROCS.find((p) => p.id === id)!.pid,
)
/** The relaunch instance (B11) — narration derives 4402 from here. */
export const RELAUNCH = PROCS.find((p) => p.id === 'D')!
/** The first instance (narration derives 4312 from here). */
export const FIRST = PROCS.find((p) => p.id === 'A')!
