// content/topics/02-operating-systems/01-process-from-program-to-execution/assemble.ts
// The full declarative assembly of Topic 02 Chapter 01 — everything except the
// meta import. Kept meta-free so the chapter can be built and verified outside
// Vite's asset pipeline (same pattern as the Topic 01 chapters' assemble.ts).
//
// ONE scene. The world is spatially stable for the whole chapter
// (VISUAL_LANGUAGE §6): the Program never moves, the OS never moves, and
// Processes are born and die in the execution field around them.

import type {
  Chapter,
  ChapterMeta,
  EntityDescription,
  HitZone,
  SceneDescription,
  Vec2,
} from '../../../../chapter-loader/types'

import {
  field, program, os, machine, PATH_WORLD, BBOX_WORLD, PROGRAM_HIT_RECT,
} from './scenes/01-world'
import { beats } from './narration/beats'
import {
  chapterTitle, waitingLine, startButton, sceneTag, tipText, doneLabel,
} from './narration/labels'
import type { PartSpec } from './types'
import { RENDERERS } from './renderers'

// ---- helpers ----------------------------------------------------------------
const toEntity = (p: PartSpec, sceneId: string): EntityDescription => ({
  id: p.id,
  kind: p.kind ?? p.id,
  pos: p.pos,
  color: p.color,
  name: p.name,
  gloss: p.gloss,
  scene: sceneId,
  extra: p.extra,
  labelSize: p.labelSize,
})

// ---- the world scene ----------------------------------------------------------
// Paint order: field first (cells live under the region parts' labels), then
// the three named parts west→east.
const worldScene: SceneDescription = {
  id: 'world',
  bbox: BBOX_WORLD,
  cameraPad: 0.92,
  path: PATH_WORLD,
  entities: [
    toEntity(field, 'world'),
    toEntity(program, 'world'),
    toEntity(os, 'world'),
    toEntity(machine, 'world'),
  ],
}

// ---- hit zone (the learner LAUNCHES the program by clicking it) ---------------
const hitZones: HitZone[] = [
  {
    id: 'program-card',
    hits: (w: Vec2) =>
      w.x >= PROGRAM_HIT_RECT.x &&
      w.x <= PROGRAM_HIT_RECT.x + PROGRAM_HIT_RECT.w &&
      w.y >= PROGRAM_HIT_RECT.y &&
      w.y <= PROGRAM_HIT_RECT.y + PROGRAM_HIT_RECT.h,
  },
]

// ---- the assembled Chapter ------------------------------------------------------
export function assembleChapter(m: ChapterMeta): Chapter {
  return {
    meta: m,
    scenes: [worldScene],
    timeline: {
      beats,
      fadeDuration: 450,
    },
    hitZones,
    runtime: {
      // Single scene — the protagonist never crosses a seam, but the hook
      // keeps it anchored if a fade is ever triggered programmatically.
      seamPosition: (scene: string): Vec2 | null =>
        scene === 'world' ? PATH_WORLD[PATH_WORLD.length - 1] : null,
    },
    ui: {
      chapterTitle,
      waitingLine,
      startButton,
      sceneTag,
      tipText,
      doneLabel,
    },
    entityRenderers: RENDERERS,
  }
}
