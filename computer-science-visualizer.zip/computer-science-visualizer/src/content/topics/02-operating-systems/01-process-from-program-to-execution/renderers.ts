// content/topics/02-operating-systems/01-process-from-program-to-execution/renderers.ts
//
// Chapter renderer barrel. The painters live in renderers/world.ts:
//   program-card — the artifact (spatially persistent; NEVER moves or morphs)
//   os-gate      — the causal actor (absorb → charge → emit; PID pill anchor)
//   machine-dock — the physical machine context (CPU · RAM · I/O), low-salience
//   exec-field   — every Process cell, PID chip, pulse, selector, term pill
//                  and climax comet, read from scenes/story.ts
//
// LAYOUT-SYSTEM DRIVEN: every coordinate is a named metric (scenes/metrics.ts)
// or derived in scenes/layout.ts (Layout Derivation Law). Every renderer is a
// pure function of (PresentationState, entity): all beat-driven content
// derives from s.beatIndex / s.beatElapsed, so scrubbing, pausing and
// stepping backwards stay deterministic (VISUAL_LANGUAGE §15).
//
// SCOPE LOCK (Guardian T02 §5 CH01 non-goals): nothing here draws Ready /
// Running / Waiting states, context switches, schedulers, queues, threads,
// address-space internals or program-loading. The chapter shows the FACT that
// the OS creates Processes — identity, lifetime, independent instances — and
// nothing else.

import { RENDERER_TABLE } from './renderers/world'

export const RENDERERS = RENDERER_TABLE
