// content/topics/02-operating-systems/01-process-from-program-to-execution/meta.ts
// Topic 02 Chapter 01 — question-based title, per the curriculum graph and
// CURRICULUM_GUARDIAN_T02_DRAFT.md §5 (CH01).

import type { ChapterMeta } from '../../../../chapter-loader/types'
import thumb from './assets/thumbnail.jpg'

const meta: ChapterMeta = {
  id: 'topic-02-operating-systems--ch-01-process-from-program-to-execution',
  slug: 'process-from-program-to-execution',
  order: 1,
  chapterOrder: 1,
  topicId: 'topic-02-operating-systems',
  topicSlug: 'operating-systems',
  topicOrder: 2,
  topicTitle: { en: 'Processes & Threads', vi: 'Tiến trình & Luồng' },
  status: 'available',
  thumbnail: thumb,
  title: {
    en: 'Process: From Program to Managed Execution',
    vi: 'Process: Từ chương trình đến thực thi được OS quản lý',
  },
  subtitle: {
    en: 'Launch a program and watch what the OS actually creates: not the program running, but a Process — a managed instance with its own identity and its own lifetime. Launch again, and another independent one is born.',
    vi: 'Khởi chạy một chương trình và xem OS thực sự tạo ra gì: không phải chương trình tự chạy, mà là một Process — một thực thể được quản lý với danh tính và vòng đời riêng. Khởi chạy lần nữa, một thực thể độc lập khác ra đời.',
  },
  accent: '#f472b6',
  loadStory: () => import('./index').then((m) => m.chapter),
}

export default meta
