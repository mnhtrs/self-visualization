// narration/beats.ts — the storyboard of Topic 01 Chapter 03: 26 beats over 7
// scenes, answering exactly one question: how does a CPU cache determine
// whether a memory request becomes a Cache Hit or a Cache Miss?
//
// Structure (mirrors 04_storyboard.json beat-for-beat):
//   Act 1  b0–b5    enter the cache; Cache Lines; the naive sweep and its cost
//   Act 2  b6–b12   Sets; Direct → Set Associative → Fully Associative by streams
//   Act 3  b13      the Memory Address is examined
//   Act 4  b14–b16  one complete Cache Lookup (Index → Set → Tag → Hit → Offset)
//   Act 5  b17–b19  the Miss and Cache Line Loading
//   Act 6  b20–b23  the full set: Replacement, FIFO, LRU
//   Act 7  b24–b25  the uninterrupted replay and the answer — NO new concepts
//
// Authoring rules honoured here:
//   • Knowledge Reveal Law (NARRATIVE_FRAMING §13): every term is spoken only
//     after its behaviour has been watched — "Cache Line" b2, "Set" b6,
//     "Direct Mapping" b9, "Set Associative Mapping" b11, "Fully Associative
//     Mapping" b12, "Memory Address" b13, "Index" b14, "Tag" b15,
//     "Word Offset" b16, "Cache Line Loading" b18, "Replacement" b20,
//     "FIFO" b21, "LRU" b22.
//   • One beat, one mutation (PEDAGOGICAL_SYSTEM §4.3).
//   • Scene is stated explicitly on EVERY beat.
//   • Quantities the narration speaks derive from scenes/story.ts (§4.5):
//     eight lines (ROWS), six + eight checks (SCANS), the four-request streams.
//   • Nothing from Chapter 02 is re-taught; black boxes from Chapter 02
//     (how a level answers, what it discards) are OPENED, not bypassed.
//   • Forbidden territory (owner spec): no write-through/write-back, MESI,
//     coherence, virtual memory, TLB, prefetch, branch prediction, multi-core,
//     and no bit-layout explanation anywhere. Enforced by the scope gate.

import type { BeatDescription } from '../../../../../chapter-loader/types'

export const beats: BeatDescription[] = [
  // ===========================================================================
  // ACT 1 — enter the cache
  // ===========================================================================
  {
    id: 'the-level-answers',
    scene: 'entry',
    line: {
      en: 'Pick up right where the last chapter left off: the CPU asks the nearest cache level first, and the level answers at once. Yes — or no.',
      vi: 'Ta tiếp tục ngay từ chỗ chapter trước dừng lại: CPU hỏi tầng cache gần nhất trước, và tầng đó trả lời ngay lập tức. Có — hoặc không.',
    },
    duration: 5200, active: 'cpu', rest: { at: 0 }, emerge: true,
  },
  {
    id: 'inside',
    scene: 'entry',
    line: {
      en: "This time we follow the memory request right to the level's door. It answered… but HOW does it know whether the value is inside? Let's go in after it.",
      vi: 'Lần này ta đi theo memory request tới tận cửa của tầng cache. Nó vẫn trả lời ngay… nhưng bằng cách nào nó BIẾT dữ liệu có ở trong hay không? Chui vào theo nó nào.',
    },
    duration: 5600, active: 'l1', travel: { from: 0, to: 1 },
  },

  // ===========================================================================
  // ACT 1 — Cache Lines and the naive sweep
  // ===========================================================================
  {
    id: 'rows-of-compartments',
    scene: 'interior',
    line: {
      en: 'So this is what one cache level looks like inside: a stack of identical compartments. Each one keeps a copy fetched from RAM — a chunk of memory that always travels together. Each of these compartments is called a Cache Line.',
      vi: 'Đây là bên trong một tầng cache trông như nào: một dãy ngăn giống hệt nhau. Mỗi ngăn giữ một bản sao được lấy từ RAM — một khối dữ liệu luôn đi cùng nhau. Mỗi ngăn này gọi là một Cache Line.',
    },
    duration: 6600, active: 'cache', rest: { at: 0 }, emerge: true,
  },
  {
    id: 'find-a',
    scene: 'interior',
    line: {
      en: 'A request arrives. Is the value it needs in one of these lines? The honest way to find out: check every line, one by one. Count the checks — one, two… six. Found it, in the sixth line.',
      vi: 'Một request tới. Dữ liệu nó cần có ở đây không? Cách thật thà nhất để biết: kiểm tra từng line một. Đếm số lần kiểm nào: một, hai… sáu. Tìm thấy rồi, ở line thứ sáu.',
    },
    duration: 7800, active: 'cache', travel: { from: 0, to: 7 },
  },
  {
    id: 'find-b',
    scene: 'interior',
    line: {
      en: 'Another request. Same drill: line by line… all eight lines this time. Found in the very last one. Every check takes work — and we just did fourteen of them for two requests.',
      vi: 'Thêm một request nữa. Lại lần lượt từng line… tám line luôn. May mà thấy ở line cuối cùng. Mỗi lần kiểm đều tốn công — mà vừa rồi là mười bốn lần kiểm chỉ cho hai request.',
    },
    duration: 7600, active: 'cache', travel: { from: 7, to: 16 },
  },
  {
    id: 'too-expensive',
    scene: 'interior',
    line: {
      en: 'If every request has to ask every line, answering will stay slow — far slower than this small fast store is supposed to be. There has to be a better place to START looking. Where should the cache look first?',
      vi: 'Nếu mỗi request đều phải hỏi tất cả các line, việc trả lời lúc nào cũng chậm — chậm hơn hẳn cái kho nhỏ mà nhanh này đáng lẽ phải thế. Phải có cách chọn sẵn chỗ để BẮT ĐẦU tìm. Cache nên nhìn vào đâu trước?',
    },
    duration: 5200, active: 'cache', rest: { at: 16 },
  },

  // ===========================================================================
  // ACT 2 — Sets and the three arrangements
  // ===========================================================================
  {
    id: 'into-groups',
    scene: 'mapping',
    line: {
      en: 'Try this: split the lines into small groups. Watch the two request cards with the same marking — both land in the same group, always. From now on a request only ever asks its own group. A group of lines like this is called a Set.',
      vi: 'Thử thế này: chia các line thành từng nhóm nhỏ. Nhìn hai thẻ request có cùng một dấu hiệu này — cả hai đều đi tới cùng một nhóm, lúc nào cũng vậy. Từ giờ một request chỉ hỏi đúng nhóm của NÓ thôi. Một nhóm line như vậy gọi là một Set.',
    },
    duration: 7800, active: 'cache', travel: { from: 0, to: 1 },
  },
  {
    id: 'how-many-per-set',
    scene: 'mapping',
    line: {
      en: 'Now a design question: how many lines should one Set hold? Start with the simplest choice there is — exactly one line in every set.',
      vi: 'Giờ tới một câu hỏi thiết kế: một Set nên chứa bao nhiêu line? Bắt đầu từ lựa chọn đơn giản nhất có thể — mỗi set đúng một line.',
    },
    duration: 5200, active: 'cache', rest: { at: 1 },
  },
  {
    id: 'one-line-stream',
    scene: 'mapping',
    line: {
      en: 'Four requests come in. Watch the set they both land in: one request settles into its single line… then the other same-marked one arrives, needs THE SAME single slot, and the first has to give it up. Then it happens all over again. Four requests, four misses — not one second visit is ever served.',
      vi: 'Bốn request lần lượt tới. Nhìn set mà cả hai cùng đi tới này: một request vào nằm ở line duy nhất… rồi request kia có CÙNG dấu hiệu tới, cũng cần ĐÚNG chỗ duy nhất đó, nên request trước đành nhường. Rồi y chang một lần nữa. Bốn request, bốn lần miss — chẳng ai quay lại lần hai mà được phục vụ cả.',
    },
    duration: 9000, active: 'cache', travel: { from: 1, to: 9 },
  },
  {
    id: 'name-direct',
    scene: 'mapping',
    line: {
      en: 'An arrangement with exactly one line per set is called Direct Mapping: every address has exactly one possible home. Simple — but two addresses that share a home can never live there at the same time.',
      vi: 'Cách sắp xếp mà mỗi set có đúng một line gọi là Direct Mapping (ánh xạ trực tiếp): mỗi địa chỉ có đúng một chỗ nó được phép ở. Đơn giản thật — nhưng hai địa chỉ chung một chỗ thì không bao giờ ở lại cùng nhau được.',
    },
    duration: 5400, active: 'cache', rest: { at: 9 },
  },
  {
    id: 'two-line-stream',
    scene: 'mapping',
    line: {
      en: 'Give every set a second line, and run the exact same four requests again. The second one arrives at the same set… and simply takes the line next to the first. They both stay! Same requests — two hits this time. (Meanwhile a few quieter requests fill the other sets for later.)',
      vi: 'Cho mỗi set thêm một line nữa, rồi chạy lại đúng bốn request ban nãy. Request thứ hai tới cùng một set… và cứ thế nằm vào line trống kế bên. Cả hai cùng ở lại! Vẫn các request đó mà lần này có tới hai hit. (Trong lúc đó vài request lặng lẽ hơn lấp các set khác, để lát nữa dùng.)',
    },
    duration: 9200, active: 'cache', travel: { from: 9, to: 21 },
  },
  {
    id: 'name-set-assoc',
    scene: 'mapping',
    line: {
      en: 'A set that holds several lines can keep several same-set addresses at once — this is Set Associative Mapping. Two lines per set, like here, is called a 2-way set associative cache.',
      vi: 'Một set chứa được nhiều line thì giữ được nhiều địa chỉ cùng set một lúc — đây là Set Associative Mapping (ánh xạ kết hợp theo tập hợp). Hai line một set như thế này gọi là cache 2-way set associative.',
    },
    duration: 5000, active: 'cache', rest: { at: 21 },
  },
  {
    id: 'one-giant-set',
    scene: 'mapping',
    line: {
      en: 'Now push it all the way: ONE set holding all eight lines. Any request may land anywhere — no two addresses can ever fight. But watch what answering costs: every request must compare against EVERY line at once. The old search is back — moved into the machinery. All lines in a single set: Fully Associative Mapping. Real caches settle in the middle.',
      vi: 'Giờ đẩy tới tận cùng: MỘT set chứa cả tám line. Request nào cũng muốn ở đâu thì ở — chẳng hai địa chỉ nào tranh nhau bao giờ. Nhưng nhìn cái giá của việc trả lời này: mỗi request phải so với TẤT CẢ các line cùng một lúc. Kiểu tìm kiếm ban nãy quay lại rồi — chỉ là chuyển vào trong phần cứng. Tất cả line chung một set: Fully Associative Mapping (ánh xạ kết hợp toàn phần). Cache thật thì nằm ở khoảng giữa.',
    },
    duration: 11000, active: 'cache', travel: { from: 21, to: 38 },
  },

  // ===========================================================================
  // ACTS 3–4 — the address opens; one complete lookup
  // ===========================================================================
  {
    id: 'the-address',
    scene: 'lookup',
    line: {
      en: 'Back to one single request. It has been carrying something the whole time: its Memory Address — the identity of the value the CPU wants. Look closely: an address is not one thing. It is several pieces of information packed together, because each piece has a different job.',
      vi: 'Giờ quay lại với một request duy nhất. Nãy giờ nó luôn mang theo một thứ: Memory Address — chính là địa chỉ của dữ liệu CPU đang cần. Nhìn kỹ nhé: địa chỉ không phải chỉ một thứ — nó là vài mảnh thông tin gói lại với nhau, vì mỗi mảnh làm một việc khác nhau.',
    },
    duration: 6200, active: 'cache', travel: { from: 0, to: 1 },
  },
  {
    id: 'the-index',
    scene: 'lookup',
    line: {
      en: 'The first piece breaks off and flies to one particular set. That set alone opens its lines; the others take no part. You have watched this piece work ever since the lines grouped — it is what routes a request. Its name is the Index.',
      vi: 'Mảnh thứ nhất tách ra và bay tới đúng một set. Chỉ set đó mở các line của nó ra; mấy set còn lại không liên quan. Mảnh này từ hồi chia nhóm đã hoạt động ngay trước mắt bạn rồi — nó là thứ dẫn đường cho request. Tên của nó là Index.',
    },
    duration: 6600, active: 'cache', travel: { from: 1, to: 3 },
  },
  {
    id: 'the-tag',
    scene: 'lookup',
    line: {
      en: 'The next piece visits the stored names inside that set: the first line answers not me — the second answers me. The piece being compared is the Tag — the name each line answers to. A matching tag IS a Cache Hit: that is what hit has always meant.',
      vi: 'Mảnh tiếp theo đi so với các cái tên đang cất trong set: line đầu trả lời không phải tôi — line thứ hai trả lời chính tôi. Mảnh được đem đi so sánh gọi là Tag — cái tên mà mỗi line nhận lấy. Tag trùng khớp — đó CHÍNH LÀ Cache Hit. Hoá ra suốt nãy giờ hit nghĩa là vậy.',
    },
    duration: 7200, active: 'cache', travel: { from: 3, to: 5 },
  },
  {
    id: 'the-offset',
    scene: 'lookup',
    line: {
      en: 'The last piece drops onto one word inside the open line — the Word Offset: which of the line’s words the CPU actually asked for. Off that word goes, home to the CPU. This whole question and answer, address to word, is a Cache Lookup.',
      vi: 'Mảnh cuối cùng đậu xuống đúng một từ bên trong line đang mở — Word Offset: chính xác là từ nào trong line mà CPU cần. Từ đó lập tức bay về CPU. Toàn bộ quá trình hỏi-đáp này, từ địa chỉ tới từ dữ liệu, gọi là một lần Cache Lookup.',
    },
    duration: 7000, active: 'cpu', travel: { from: 5, to: 8 },
  },

  // ===========================================================================
  // ACT 5 — the miss and the line that comes home
  // ===========================================================================
  {
    id: 'no-match',
    scene: 'miss',
    line: {
      en: 'Another request, another lookup. The index picks its set… the tag knocks on its lines: one is free, and the occupied one answers not me. No stored tag matches. That is what a Cache Miss is: the right set was asked, and nothing inside carried that name.',
      vi: 'Một request khác, một lần lookup khác. Index chọn set của nó… tag đi gõ cửa từng line: một line còn trống, còn line có chủ trả lời không phải tôi. Không tag nào khớp cả. Đó là bản chất của Cache Miss: đã hỏi đúng set rồi, nhưng bên trong không ai mang cái tên ấy.',
    },
    duration: 7000, active: 'cache', travel: { from: 0, to: 5 },
  },
  {
    id: 'fill-from-ram',
    scene: 'miss',
    line: {
      en: 'A miss never ends the story — the request rolls on to RAM, which always has the value. And watch what travels back: not just one word — the WHOLE line, tag and all its words together, settling into the set’s free line. This trip is called Cache Line Loading.',
      vi: 'Miss không có nghĩa là hết — request đi tiếp ra RAM, chỗ nào dữ liệu cũng có sẵn. Và nhìn xem thứ gì quay về này: không chỉ mỗi từ cần dùng — mà NGUYÊN cache line, tag và cả bốn từ cùng nhau, đậu vào line còn trống của set. Chuyến đi này gọi là Cache Line Loading.',
    },
    duration: 8000, active: 'ram', travel: { from: 5, to: 7 },
  },
  {
    id: 'serve-miss',
    scene: 'miss',
    line: {
      en: 'Now the line lives in the cache, and the lookup finishes like any hit: offset picks the word, the word goes home. A miss costs one RAM round trip — after that, requests for this line become hits.',
      vi: 'Giờ line đã nằm trong cache, lookup kết thúc y hệt một hit: offset chọn từ, từ bay về. Miss tốn đúng một chuyến đi-về RAM — sau đó, mọi request tới line này đều trở thành hit.',
    },
    duration: 5400, active: 'cpu', travel: { from: 7, to: 10 },
  },

  // ===========================================================================
  // ACT 6 — the full set: Replacement, FIFO, LRU
  // ===========================================================================
  {
    id: 'set-full',
    scene: 'replace',
    line: {
      en: 'One more request — and its set is FULL: both lines are occupied, no tag matches. The new line has to come in… but there is nowhere to put it. One of the two must leave. Choosing the one that leaves is called Replacement. But which one should it be?',
      vi: 'Thêm một request nữa — mà set của nó ĐẦY rồi: cả hai line đều có chủ, không tag nào khớp. Line mới bắt buộc phải vào… nhưng còn chỗ nào đâu mà đặt? Một trong hai line kia phải rời đi. Việc chọn line nào rời đi gọi là Replacement. Nhưng nên chọn ai?',
    },
    duration: 7000, active: 'cache', travel: { from: 0, to: 5 },
  },
  {
    id: 'fifo',
    scene: 'replace',
    line: {
      en: 'One simple answer: look at when each line arrived. The one that has been there LONGEST gives up its slot — the earliest arrival drifts away, and the new line settles in. First in, first out. That rule has a name: FIFO.',
      vi: 'Một câu trả lời đơn giản: nhìn xem mỗi line đến lúc nào. Line nào ở đó LÂU NHẤT thì nhường chỗ — line tới sớm nhất rời đi, line mới vào thay. Vào trước, ra trước. Quy tắc này tên là FIFO.',
    },
    duration: 8000, active: 'cache', travel: { from: 5, to: 6 },
  },
  {
    id: 'lru',
    scene: 'replace',
    line: {
      en: 'Rewind the same moment — and answer differently: look at when each line was last USED. The one untouched for the longest time leaves instead — notice it is the OTHER one. Least recently used out. That rule is LRU. Same full set, different rule, different victim.',
      vi: 'Tua lại đúng khoảnh khắc đó — và trả lời bằng cách khác: nhìn xem mỗi line được DÙNG gần nhất lúc nào. Line lâu nhất không ai đụng tới sẽ rời đi — kỳ này là line CÒN LẠI đấy. Ít được dùng gần đây nhất thì out. Quy tắc này là LRU. Cùng một set đầy, khác luật chơi, khác người phải đi.',
    },
    duration: 8800, active: 'cache', travel: { from: 7, to: 8 },
  },
  {
    id: 'serve-replaced',
    scene: 'replace',
    line: {
      en: 'With a slot free, the new line moves in and the lookup finishes: offset, word, home. Replacement only ever happens on a miss in a full set — a hit never disturbs anyone.',
      vi: 'Vừa có chỗ trống xong, line mới vào ở ngay và lookup kết thúc: offset, từ, về nhà. Replacement chỉ xảy ra khi miss trong một set đã đầy — còn hit thì chẳng làm phiền ai cả.',
    },
    duration: 4400, active: 'cpu', travel: { from: 8, to: 11 },
  },

  // ===========================================================================
  // ACT 7 — uninterrupted replay; the answer. NO new concepts.
  // ===========================================================================
  {
    id: 'full-pass',
    scene: 'replay',
    line: {
      en: 'Watch it once, all the way through, no interruptions: a request arrives… its index chooses a set… its tag compares… a match opens the line… the offset picks the word… and the word goes home. Every piece of this trip, you have already seen.',
      vi: 'Nhìn lại trọn vẹn một lần, không ngắt quãng: request tới… index chọn set… tag đi so… khớp thì line mở ra… offset chọn từ… và từ bay về nhà. Từng mảnh của chuyến đi này, bạn đều đã thấy rồi.',
    },
    duration: 8800, active: 'cache', travel: { from: 0, to: 6 },
  },
  {
    id: 'the-answer',
    scene: 'replay',
    line: {
      en: 'So how does a cache know? It never guesses. The address splits: the index finds the one set that might hold the value, the tag asks whether it is really there, and the offset carries the right word home. When no tag answers, the line comes up from RAM — and a full set gives one line up, by rule. That is everything behind every hit and every miss you will ever see.',
      vi: 'Vậy cache biết bằng cách nào? Nó không bao giờ đoán. Địa chỉ tách ra: index tìm đúng một set có thể chứa dữ liệu, tag hỏi xem nó có thật sự ở đó không, còn offset mang đúng từ cần dùng về. Nếu không tag nào trả lời, cả line được kéo lên từ RAM — và một set đầy sẽ nhường một line, theo luật chọn sẵn. Đó là tất cả những gì đứng sau mỗi hit và mỗi miss bạn sẽ gặp.',
    },
    duration: 9800, active: 'cpu', rest: { at: 6 }, effect: 'loop',
  },
]
