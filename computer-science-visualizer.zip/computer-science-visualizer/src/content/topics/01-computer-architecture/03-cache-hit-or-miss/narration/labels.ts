// narration/labels.ts — UI strings of Topic 01 Chapter 03 (the Viewer reads
// these via chapter.ui; every key the generic Viewer may look for is provided).

import type { LocalizedText } from '../../../../../chapter-loader/types'

export const chapterTitle: LocalizedText = {
  en: 'How does a cache decide Hit or Miss?',
  vi: 'Cache quyết định Hit hay Miss như thế nào?',
}

export const waitingLine: LocalizedText = {
  en: 'The CPU is about to send one more request. Start it, and follow the request inside.',
  vi: 'CPU sắp gửi thêm một request nữa. Cho nó chạy đi, rồi đi theo request vào bên trong.',
}

export const startButton: LocalizedText = {
  en: 'Send the request',
  vi: 'Gửi request',
}

export const sceneTag: LocalizedText = {
  en: 'Inside the cache',
  vi: 'Bên trong cache',
}

export const tipText: LocalizedText = {
  en: 'Click the CPU to begin. Use the < > buttons or the dots to step through.',
  vi: 'Bấm vào CPU để bắt đầu. Dùng nút < > hoặc các chấm để tua tới lui.',
}

export const doneLabel: LocalizedText = { en: 'Done', vi: 'Xong' }
