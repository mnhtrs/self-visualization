// scenes/story.ts — the single source of truth for every beat-driven fact:
// occupancy of the eight lines, the request streams, compare events, evict /
// load timings, cumulative counters, the tally board, term pills and their
// anchors. Everything is a pure function of (beatIndex, beatFraction), so
// scrubbing, pausing and stepping backwards stay deterministic
// (VISUAL_LANGUAGE §15).
//
// Quantity discipline (PEDAGOGICAL_SYSTEM §4.5): every number the narration
// speaks is DERIVED from the tables below — eight lines (ROWS), six + eight
// comparisons (SCANS), four requests in the mapping streams (STREAM_DIRECT /
// STREAM_TWO_WAY) — never typed twice.
//
// Affirmative-state discipline (§4.6): "full", "miss", "hit" states read from
// affirmative tables (OCCUPANCY, STREAM steps), never from inverted flags.

import * as M from './metrics'

// =============================================================================
// Beat index map (globally sequential across scenes)
// =============================================================================
export const B = {
  levelAnswers: 0,
  inside: 1,
  rowsOfCompartments: 2,
  findA: 3,
  findB: 4,
  tooExpensive: 5,
  intoGroups: 6,
  howManyPerSet: 7,
  oneLineStream: 8,
  nameDirect: 9,
  twoLineStream: 10,
  nameSetAssoc: 11,
  oneGiantSet: 12,
  theAddress: 13,
  theIndex: 14,
  theTag: 15,
  theOffset: 16,
  noMatch: 17,
  fillFromRam: 18,
  serveMiss: 19,
  setFull: 20,
  fifo: 21,
  lru: 22,
  serveReplaced: 23,
  fullPass: 24,
  theAnswer: 25,
} as const

// =============================================================================
// The request cards (addresses)
// =============================================================================
export interface CardSpec {
  id: string
  /** Card body colour (unique identity). */
  body: string
  /** Home set in the chapter's home arrangement (2 lines per set), or null
   *  for pre-set scenes. The stripe IS this marking. */
  homeSet: number | null
}
export const CARD = {
  sa: { id: 'X9', body: '#e2e8f0', homeSet: null }, // matches the row-5 chip
  sb: { id: 'J5', body: '#fbbf24', homeSet: null }, // matches the row-7 chip
  A2: { id: 'A2', body: '#f472b6', homeSet: 2 },
  B2: { id: 'B2', body: '#38bdf8', homeSet: 2 },
  C1: { id: 'C1', body: '#4ade80', homeSet: 1 },
  E1: { id: 'E1', body: '#c084fc', homeSet: 1 },
  D3: { id: 'D3', body: '#facc15', homeSet: 3 },
  F3: { id: 'F3', body: '#fb7185', homeSet: 3 },
  G2: { id: 'G2', body: '#e879f9', homeSet: 2 },
} as const satisfies Record<string, CardSpec>
export type CardId = keyof typeof CARD

export const cardById = (id: string): CardSpec => (CARD as Record<string, CardSpec>)[id] ?? CARD.sa

// =============================================================================
// Line occupancy — what each of the eight lines holds at the START of each beat
// =============================================================================
export interface LineState {
  /** Identity stored on the tag chip (null = empty line). */
  tag: string | null
  /** The card this tag belongs to (colour + stripe), when known. */
  card: CardId | null
  /** Set colouring for the tag chip; null = plain. */
  dim?: boolean
}
export const E = (): LineState => ({ tag: null, card: null })
export const T = (card: CardId, dim = false): LineState => ({ tag: CARD[card].id, card, dim })

/** Home arrangement contents, restored after the experiments (2 lines/set). */
export const HOME_OCCUPANCY: (LineState | null)[] = [
  E(), E(), T('C1'), T('E1'), T('A2'), T('B2'), E(), E(),
]

/** What the naive-sweep scene pre-loads (the visitors' matches live inside). */
const anon = (letter: string): LineState => ({ tag: letter, card: null })
export const SCAN_OCCUPANCY: (LineState | null)[] = [
  anon('M4'), anon('K9'), anon('Q2'), anon('S7'), anon('A6'), anon('X9'), anon('B3'), anon('J5'),
]

export type Occ = (LineState | null)[]

/** Occupancy at the START of each beat (beat -1 = before the panel exists). */
export function occupancyAt(beat: number): Occ {
  if (beat <= B.inside) return Array(M.ROWS).fill(null)
  if (beat <= B.tooExpensive) return SCAN_OCCUPANCY.slice()
  if (beat <= B.nameDirect) return Array(M.ROWS).fill(null) // experiments start empty
  if (beat === B.twoLineStream) return Array(M.ROWS).fill(null) // the replay is a fresh run
  if (beat <= B.nameSetAssoc) return HOME_OCCUPANCY.slice()
  if (beat === B.oneGiantSet) return HOME_OCCUPANCY.slice() // morph clears it inside the beat
  // D3 landed at row 7 during the giant stream (its own home set) and never
  // left: from the lookup act on, set 3 = one resident (D3) + one free line
  // (row 6 — exactly where the miss will load F3). Enacted, not asserted.
  if (beat <= B.serveMiss) return HOME_AFTER_GIANT.slice()
  if (beat === B.fifo) return [...HOME_OCCUPANCY.slice(0, 6), T('F3'), T('D3')]
  if (beat === B.lru) return [...HOME_OCCUPANCY.slice(0, 6), T('F3'), T('D3')]
  // the LRU verdict is the one the chapter keeps: A2 stays (touched last),
  // B2 was evicted and its block rests in RAM — so G2 holds row 5 from the
  // serve on. Serving G2's word from B2's freshly-evicted line would lie.
  return [...HOME_OCCUPANCY.slice(0, 5), T('G2'), T('F3'), T('D3')]
}

/** Home arrangement after the giant experiment: the giant stream's D3 was a
 *  genuine load into its home set's second line; the morph back keeps it. */
const HOME_AFTER_GIANT: Occ = [...HOME_OCCUPANCY.slice(0, 7), T('D3')]

// =============================================================================
// In-beat load / evict events — { at, row, card | null } (card=null = evictout)
// =============================================================================
export interface OccEvent {
  at: number
  row: number
  card: CardId | null
}
export const OCC_EVENTS: Record<number, OccEvent[]> = {
  [B.oneLineStream]: [
    { at: 0.16, row: 4, card: 'A2' },
    { at: 0.38, row: 4, card: null }, // B2's request: the single slot frees
    { at: 0.46, row: 4, card: 'B2' },
    { at: 0.64, row: 4, card: null }, // A2 returns and must take it back
    { at: 0.72, row: 4, card: 'A2' },
    { at: 0.84, row: 4, card: null },
    { at: 0.9, row: 4, card: 'B2' },
  ],
  [B.twoLineStream]: [
    { at: 0.14, row: 4, card: 'A2' },
    { at: 0.3, row: 5, card: 'B2' }, // coexist: the second line of set 2
    { at: 0.72, row: 2, card: 'C1' }, // quiet loads seeding set 1 for later scenes
    { at: 0.84, row: 3, card: 'E1' },
  ],
  [B.oneGiantSet]: [
    { at: 0.06, row: 2, card: null }, // the experiment resets: home occupants
    { at: 0.06, row: 3, card: null }, // fade as the single giant brace forms
    { at: 0.06, row: 4, card: null },
    { at: 0.06, row: 5, card: null },
    { at: 0.16, row: 0, card: 'A2' }, // four fresh requests land ANYWHERE
    { at: 0.26, row: 1, card: 'B2' },
    { at: 0.36, row: 5, card: 'C1' },
    { at: 0.46, row: 7, card: 'D3' },
    // morph back to pairs: the experiment chips dissolve in place (they were
    // never rule-victims — see paintVictimFlights), fully clearing BEFORE…
    { at: 0.92, row: 0, card: null },
    { at: 0.92, row: 1, card: null },
    { at: 0.92, row: 5, card: null },
    { at: 0.92, row: 7, card: null },
    // …the home arrangement re-seats the moment the return morph settles —
    // fade-out completes strictly before fade-in, so no tag slot ever shows
    // two cards at once (post-freeze residual fix, owner-directed)
    { at: 0.97, row: 2, card: 'C1' },
    { at: 0.97, row: 3, card: 'E1' },
    { at: 0.97, row: 4, card: 'A2' },
    { at: 0.97, row: 5, card: 'B2' },
    { at: 0.97, row: 7, card: 'D3' }, // D3 stays where its set's home is (set 3)
  ],
  [B.fillFromRam]: [{ at: 0.7, row: 6, card: 'F3' }], // the caravan plugs in
  [B.fifo]: [
    { at: 0.62, row: 4, card: null }, // A2 (the first arrival) drifts out
    { at: 0.74, row: 4, card: 'G2' }, // G2 takes the freed line
  ],
  [B.lru]: [
    { at: 0.12, row: 4, card: 'A2' }, // rewind: the first rule's victim returns…
    { at: 0.12, row: 5, card: 'B2' }, // (its own state restored)
    // note: G2 implicitly absent again because occupancyAt(lru) never held it
    { at: 0.64, row: 5, card: null }, // B2 (untouched longest) drifts out
    { at: 0.76, row: 5, card: 'G2' }, // G2 takes THAT line instead
  ],
}

/** Occupancy at (beat, fraction) — start state plus all triggered events. */
export function occupancy(beat: number, lin: number): Occ {
  const rows = occupancyAt(beat).slice()
  for (const ev of OCC_EVENTS[beat] ?? []) {
    if (lin >= ev.at) rows[ev.row] = ev.card ? T(ev.card) : E()
  }
  return rows
}

// =============================================================================
// Compare events — { at, row, result, beam? } — the lookup's working heart
// =============================================================================
export interface CompareEvent {
  at: number
  row: number
  result: 'fail' | 'match'
  /** 'visit' = the chip physically visits; 'beam' = a fan-out wire lights. */
  kind: 'visit' | 'beam'
  /** true = the probed line is FREE (no stored tag sits there): the slot
   *  brightens as "nobody home to compare", never a ✕ against emptiness. */
  empty?: boolean
}
export const COMPARES: Record<number, CompareEvent[]> = {
  [B.findA]: [0, 1, 2, 3, 4, 5].map((row, i) => ({
    at: 0.1 + i * 0.14, row, result: row === 5 ? 'match' : 'fail', kind: 'visit',
  })),
  [B.findB]: [0, 1, 2, 3, 4, 5, 6, 7].map((row, i) => ({
    at: 0.08 + i * 0.105, row, result: row === 7 ? 'match' : 'fail', kind: 'visit',
  })),
  [B.oneLineStream]: [
    { at: 0.32, row: 4, result: 'fail', kind: 'visit' }, // B2 vs the lone occupant
    { at: 0.58, row: 4, result: 'fail', kind: 'visit' }, // A2 again
    { at: 0.82, row: 4, result: 'fail', kind: 'visit' }, // B2 again
  ],
  [B.twoLineStream]: [
    { at: 0.24, row: 4, result: 'fail', kind: 'visit' }, // B2 checks A2's line…
    { at: 0.4, row: 4, result: 'match', kind: 'visit' }, // A2 returns: found
    { at: 0.54, row: 5, result: 'match', kind: 'visit' }, // B2 returns: found
  ],
  [B.oneGiantSet]: [
    // the fan-out round: EVERY stored tag is wired for each returning request
    ...([0, 1, 5, 7] as const).flatMap((row, k) =>
      [0, 1, 5, 7].map((wired) => ({
        at: 0.56 + k * 0.085 + 0.015, row: wired, result: wired === row ? ('match' as const) : ('fail' as const), kind: 'beam' as const,
      })),
    ),
  ],
  [B.theTag]: [
    // probe grammar: the incoming Tag hovers at its set; each probe lands,
    // and the answered line speaks — both answers stay co-visible
    { at: 0.34, row: 2, result: 'fail', kind: 'visit' },
    { at: 0.58, row: 3, result: 'match', kind: 'visit' },
  ],
  [B.noMatch]: [
    // set 3 holds ONE free line (row 6, its slot brightens — nothing to
    // compare) and ONE resident (row 7, D3 from the giant stream — answers)
    { at: 0.52, row: 6, result: 'fail', kind: 'visit', empty: true },
    { at: 0.64, row: 7, result: 'fail', kind: 'visit' },
  ],
  [B.setFull]: [
    { at: 0.5, row: 4, result: 'fail', kind: 'visit' },
    { at: 0.64, row: 5, result: 'fail', kind: 'visit' },
  ],
  [B.fullPass]: [{ at: 0.5, row: 2, result: 'match', kind: 'visit' }],
}

// =============================================================================
// Counters — cumulative comparisons, derived from COMPARES
// =============================================================================
export const countCompares = (beat: number, lin: number): number =>
  (COMPARES[beat] ?? []).filter((c) => lin >= c.at).length

/** Sweep-scene cumulative counter (find-a carries 0, find-b continues).
 *  After find-b the sweep is DONE: the counter holds the full fourteen
 *  (the cost the too-expensive beat asks about), not an abandoned partial. */
export const scanCounter = (beat: number, lin: number): number => {
  if (beat === B.findA) return countCompares(beat, lin)
  if (beat === B.findB) return 6 + countCompares(beat, lin)
  if (beat > B.findB) return SCAN_TOTAL
  return 0
}
/** how many comparisons the sweep spent in total (narration says 'fourteen'). */
export const SCAN_TOTAL = COMPARES[B.findA].length + COMPARES[B.findB].length // 14 ✓

// =============================================================================
// The mapping tally board — requests / hits / misses, derived from streams
// =============================================================================
export interface StreamStep {
  card: CardId
  at: number // request becomes visible
  result: 'miss' | 'hit'
  dim?: boolean // auxiliary (not part of "the four" the narration counts)
}
export const STREAM_DIRECT: StreamStep[] = [
  { card: 'A2', at: 0.06, result: 'miss' },
  { card: 'B2', at: 0.28, result: 'miss' },
  { card: 'A2', at: 0.5, result: 'miss' },
  { card: 'B2', at: 0.7, result: 'miss' },
]
export const STREAM_TWO_WAY: StreamStep[] = [
  { card: 'A2', at: 0.07, result: 'miss' },
  { card: 'B2', at: 0.2, result: 'miss' },
  { card: 'A2', at: 0.36, result: 'hit' },
  { card: 'B2', at: 0.5, result: 'hit' },
  { card: 'C1', at: 0.68, result: 'miss', dim: true },
  { card: 'E1', at: 0.8, result: 'miss', dim: true },
]
export const STREAM_GIANT_FIRST: StreamStep[] = [
  { card: 'A2', at: 0.14, result: 'miss' },
  { card: 'B2', at: 0.24, result: 'miss' },
  { card: 'C1', at: 0.34, result: 'miss' },
  { card: 'D3', at: 0.44, result: 'miss' },
]
export const STREAM_GIANT_SECOND: StreamStep[] = [
  { card: 'A2', at: 0.56, result: 'hit' },
  { card: 'B2', at: 0.645, result: 'hit' },
  { card: 'C1', at: 0.73, result: 'hit' },
  { card: 'D3', at: 0.815, result: 'hit' },
]

export interface Tally { req: number; hit: number; miss: number }
export const tallyFor = (beat: number, lin: number): Tally => {
  const acc = (steps: StreamStep[]): Tally => ({
    req: steps.filter((s) => !s.dim && lin >= s.at).length,
    hit: steps.filter((s) => !s.dim && s.result === 'hit' && lin >= s.at).length,
    miss: steps.filter((s) => !s.dim && s.result === 'miss' && lin >= s.at).length,
  })
  if (beat === B.oneLineStream) return acc(STREAM_DIRECT)
  if (beat === B.nameDirect) return { req: 4, hit: 0, miss: 4 }
  if (beat === B.twoLineStream) return acc(STREAM_TWO_WAY)
  if (beat === B.nameSetAssoc) return { req: 4, hit: 2, miss: 2 }
  if (beat === B.oneGiantSet) {
    const a = acc(STREAM_GIANT_FIRST)
    const b = acc(STREAM_GIANT_SECOND)
    return { req: a.req + b.req, hit: a.hit + b.hit, miss: a.miss + b.miss }
  }
  return { req: 0, hit: 0, miss: 0 }
}

// =============================================================================
// Which frame arrangement holds per beat, with morph metadata
// =============================================================================
export type FrameConfig = 'none' | 'pairs' | 'singles' | 'giant'
export interface FrameState {
  from: FrameConfig
  to: FrameConfig
  /** fraction window over which the morph happens (undefined = settled). */
  morph?: [number, number]
}
export const FRAME_STATE: Record<number, FrameState> = {
  [B.intoGroups]: { from: 'none', to: 'pairs', morph: [0.06, 0.34] },
  [B.howManyPerSet]: { from: 'pairs', to: 'singles', morph: [0.18, 0.5] },
  [B.oneLineStream]: { from: 'singles', to: 'singles' },
  [B.nameDirect]: { from: 'singles', to: 'singles' },
  [B.twoLineStream]: { from: 'singles', to: 'pairs', morph: [0.02, 0.18] },
  [B.nameSetAssoc]: { from: 'pairs', to: 'pairs' },
  [B.oneGiantSet]: { from: 'pairs', to: 'giant', morph: [0.02, 0.12] },
  [B.theAddress]: { from: 'pairs', to: 'pairs' },
}
/** Frames for beats after mapping stays 'pairs' (all lookup scenes). */
export const frameStateOf = (beat: number): FrameState =>
  FRAME_STATE[beat] ?? (beat > B.oneGiantSet ? { from: 'pairs', to: 'pairs' } : { from: 'none', to: 'none' })

/** Giant → pairs morph happens inside oneGiantSet's tail (not a separate beat). */
export const GIANT_RETURN: [number, number] = [0.88, 0.97]

// =============================================================================
// Set emphasis — which set glows / whose tags lift / who dims per beat
// =============================================================================
export const ACTIVE_SET: Record<number, number | null> = {
  [B.intoGroups]: 2,
  [B.oneLineStream]: 2,
  [B.nameDirect]: 2,
  [B.twoLineStream]: 2,
  [B.nameSetAssoc]: 2,
  [B.theIndex]: 1,
  [B.theTag]: 1,
  [B.theOffset]: 1,
  [B.noMatch]: 3,
  [B.fillFromRam]: 3,
  [B.serveMiss]: 3,
  [B.setFull]: 2,
  [B.fifo]: 2,
  [B.lru]: 2,
  [B.serveReplaced]: 2,
  [B.fullPass]: 1,
}
export const DIM_OTHERS_FROM = 0.45 // shared emph window (lookup acts)

// =============================================================================
// Line open state — the matched line swings open to expose its word cells
// =============================================================================
export const OPEN_ROW: Record<number, { row: number; from: number } | null> = {
  [B.findA]: { row: 5, from: 0.85 }, // the sweep's match opens, like any hit
  [B.findB]: { row: 7, from: 0.85 },
  [B.theTag]: { row: 3, from: 0.78 },
  [B.theOffset]: { row: 3, from: 0 },
  [B.serveMiss]: { row: 6, from: 0.02 },
  [B.serveReplaced]: { row: 5, from: 0 },
  [B.fullPass]: { row: 2, from: 0.58 },
}

// =============================================================================
// Verdict pills — attached to the rows they describe, after the trip resolves
// =============================================================================
export interface VerdictPill { kind: 'hit' | 'miss'; at: number; row: number }
export const VERDICTS: Record<number, VerdictPill | null> = {
  [B.theTag]: { kind: 'hit', at: 0.82, row: 3 },
  [B.noMatch]: { kind: 'miss', at: 0.72, row: 6 },
  [B.setFull]: { kind: 'miss', at: 0.68, row: 4 },
  [B.fullPass]: { kind: 'hit', at: 0.78, row: 2 },
}

// =============================================================================
// Term pills — terminology lands AFTER behaviour (NARRATIVE_FRAMING §13)
// =============================================================================
export interface TermPill {
  term: string // locked English term (NARRATIVE_FRAMING §15)
  sub: { en: string; vi: string }
  at: number
  anchor: 'panel' | 'stage' | 'row' | 'set' | 'counter' | 'east'
  anchorIndex?: number
  /** Secondary pill in the same beat (e.g. 'Cache Lookup' beside 'Word Offset'). */
  term2?: { term: string; sub: { en: string; vi: string } }
}
export const TERMS: Record<number, TermPill | null> = {
  [B.rowsOfCompartments]: {
    at: 0.66, term: 'Cache Line',
    sub: { en: 'one compartment: a tag + the words that travel together', vi: 'một ngăn: gồm tag và các từ luôn đi cùng nhau' },
    anchor: 'row', anchorIndex: 3,
  },
  [B.intoGroups]: {
    at: 0.72, term: 'Set',
    sub: { en: 'a group of lines — an address belongs to exactly one', vi: 'một nhóm line — mỗi địa chỉ thuộc về đúng một nhóm' },
    anchor: 'set', anchorIndex: 0,
  },
  [B.nameDirect]: {
    at: 0.3, term: 'Direct Mapping',
    sub: { en: 'one line per set: exactly one possible home per address', vi: 'ánh xạ trực tiếp: mỗi địa chỉ đúng một chỗ' },
    anchor: 'panel',
  },
  [B.nameSetAssoc]: {
    at: 0.34, term: 'Set Associative Mapping',
    sub: { en: 'several lines per set — this one is 2-way', vi: 'ánh xạ kết hợp theo tập hợp: nhiều line mỗi set' },
    anchor: 'panel',
  },
  [B.oneGiantSet]: {
    at: 0.845, term: 'Fully Associative Mapping',
    sub: { en: 'one set holding every line: land anywhere, compare everywhere', vi: 'ánh xạ kết hợp toàn phần: một set chứa mọi line' },
    anchor: 'panel',
  },
  [B.theAddress]: {
    at: 0.52, term: 'Memory Address',
    sub: { en: 'the identity the request carries — packed with jobs', vi: 'danh tính mà request mang theo — gói nhiều nhiệm vụ trong một' },
    anchor: 'stage',
  },
  [B.theIndex]: {
    at: 0.72, term: 'Index',
    sub: { en: 'which Set this address belongs to', vi: 'địa chỉ này thuộc về Set nào' },
    anchor: 'stage',
  },
  [B.theTag]: {
    at: 0.8, term: 'Tag',
    sub: { en: 'which line in the set it is', vi: 'là line nào trong set' },
    anchor: 'stage',
  },
  [B.theOffset]: {
    at: 0.3, term: 'Word Offset',
    sub: { en: 'which word of the line the CPU asked for', vi: 'CPU cần từ nào trong line' },
    anchor: 'stage',
    term2: {
      term: 'Cache Lookup',
      sub: { en: 'the whole address-to-word journey', vi: 'toàn bộ hành trình từ địa chỉ tới từ dữ liệu' },
    },
  },
  [B.fillFromRam]: {
    at: 0.5, term: 'Cache Line Loading',
    sub: { en: 'the whole line comes home — tag and words together', vi: 'cả line đi về cùng nhau — tag lẫn các từ' },
    anchor: 'east',
  },
  [B.setFull]: {
    at: 0.86, term: 'Replacement',
    sub: { en: 'a full set must choose which line leaves', vi: 'set đầy phải chọn xem line nào rồi đi' },
    anchor: 'east',
  },
  [B.fifo]: {
    at: 0.8, term: 'FIFO',
    sub: { en: 'first in, first out — the earliest arrival leaves', vi: 'vào trước, ra trước — ai tới sớm nhất thì đi' },
    anchor: 'east',
  },
  [B.lru]: {
    at: 0.82, term: 'LRU',
    sub: { en: 'least recently used — the one untouched longest leaves', vi: 'ít dùng gần đây nhất — ai lâu không được đụng tới thì đi' },
    anchor: 'east',
  },
}

// =============================================================================
// Question pills — problems raised BEFORE their solutions (spec: problem → need)
// =============================================================================
export const QUESTIONS: Record<number, { en: string; vi: string } | null> = {
  [B.inside]: { en: 'How does it KNOW?', vi: 'Làm sao nó BIẾT?' },
  [B.tooExpensive]: { en: 'Where should the cache look first?', vi: 'Cache nên bắt đầu tìm ở đâu trước?' },
  [B.howManyPerSet]: { en: 'How many lines should a Set hold?', vi: 'Một Set nên chứa bao nhiêu line?' },
  [B.setFull]: { en: 'No free line — which one should leave?', vi: 'Hết chỗ trống — line nào phải rồi đi?' },
}
/** On-canvas [appear, gone] windows for the north-dock question pills (b1's
 *  question lives in the entry renderer; theAnswer re-shows b1's). */
export const QUESTION_WINDOWS: Record<number, [number, number]> = {
  [B.tooExpensive]: [0.56, 1],
  [B.howManyPerSet]: [0.12, 0.9],
  [B.setFull]: [0.74, 0.98], // after both probes answered and the miss verdict
}
/** Compare-counter handoff windows: the instrument yields the north band as a
 *  question / term pill rises (one voice on the band at a time). [start, done]
 *  A handoff is a RELAY, not a cross-fade: the counter is fully gone before
 *  the question starts rising (b5). */
export const COUNTER_EXIT: Record<number, [number, number]> = {
  [B.tooExpensive]: [0.42, 0.54], // fully gone before the question enters at 0.56
  [B.oneGiantSet]: [0.78, 0.84], // fully gone before 'Fully Associative' enters at 0.845
}
/** Address-card fold-away windows [start, done]: the card steps aside once its
 *  chips carry the story, clearing the north band before anything else uses it. */
export const CARD_FOLD: Record<number, [number, number]> = {
  [B.noMatch]: [0.55, 0.68],
  [B.setFull]: [0.44, 0.54], // fully folded before the 'no free line?' question enters at 0.6
}

// =============================================================================
// FIFO / LRU evidence (replace scene) — numbered arrival badges and last-used
// marks painted ON the tag chips (adjacent text pills would crowd the rows).
// Badges/stamps ride the line they belong to: when that line leaves, its mark
// leaves too (til = fade-out start) — a departing mark must never re-appear
// on the line that takes the freed slot.
// =============================================================================
export interface LineMark {
  row: number
  from: number
  /** optional beat-fraction when the mark fades away (its line departed). */
  til?: number
}
export const RIBBONS: (LineMark & { order: number })[] = [
  { row: 4, order: 1, from: 0.08, til: 0.66 }, // A2 arrived first — and leaves @0.62
  { row: 5, order: 2, from: 0.08 }, // B2 arrived second (mapping stream order ✓)
]
/** LRU adds one enacted fact inside the rewind: the same stream touched A2
 *  again (the 2-way replay's third request was A2's) — so at this moment A2
 *  is the recent one and B2 the line untouched longest. */
export const LRU_TOUCH = { card: 'A2' as CardId, row: 4, at: 0.22 } as const
export const STAMPS: (LineMark & { recent: boolean })[] = [
  { row: 4, recent: true, from: 0.44 }, // A2: touched again just now (LRU_TOUCH)
  { row: 5, recent: false, from: 0.44, til: 0.7 }, // B2: idle longest — leaves @0.64
]

// =============================================================================
// The replay checkpoint chain (Act 7 — known terms, no new knowledge)
// =============================================================================
export const CHECKPOINTS: { at: number; text: { en: string; vi: string } }[] = [
  { at: 0.12, text: { en: 'Memory Address splits', vi: 'Memory Address tách ra' } },
  { at: 0.3, text: { en: 'Index selects one Set', vi: 'Index chọn một Set' } },
  { at: 0.5, text: { en: 'Tag compares', vi: 'Tag đi so sánh' } },
  { at: 0.58, text: { en: 'the matching Cache Line opens', vi: 'Cache Line trùng mở ra' } },
  { at: 0.66, text: { en: 'Word Offset picks the word', vi: 'Word Offset chọn từ' } },
  { at: 0.85, text: { en: 'the word goes home', vi: 'từ bay về CPU' } },
]

// =============================================================================
// On-canvas captions (bilingual)
// =============================================================================
export const CAP = {
  orientChip: { en: 'inside L1 Cache', vi: 'bên trong L1 Cache' },
  counter: { en: 'checks so far', vi: 'số lần so đến giờ' },
  counterOne: { en: 'check so far', vi: 'số lần so đến giờ' },
  tallyReq: { en: 'requests', vi: 'request' },
  tallyHit: { en: 'hits', vi: 'hit' },
  tallyMiss: { en: 'misses', vi: 'miss' },
  tallyTitle: { en: 'the four requests', vi: 'bốn request đó' },
  tallyTitleGiant: { en: 'the four requests, twice', vi: 'bốn request đó, hai lượt' },
  notMe: { en: 'not me', vi: 'không phải tôi' },
  me: { en: 'me!', vi: 'chính tôi!' },
  victim: { en: 'gives up its slot', vi: 'nhường chỗ' },
}

// =============================================================================
// Entry scene — remembered contents (mirror of Chapter 02's closing state)
// =============================================================================
export interface ValueSpec { id: string; color: string; glyph: string }
export const VALUES: ValueSpec[] = [
  { id: 'v1', color: '#facc15', glyph: '◆' },
  { id: 'v2', color: '#f472b6', glyph: '▲' },
  { id: 'v3', color: '#4ade80', glyph: '■' },
  { id: 'v4', color: '#38bdf8', glyph: '●' },
]
export const valueById = (id: string): ValueSpec => VALUES.find((v) => v.id === id) ?? VALUES[0]
/** Chapter 02 ended with these in the ladder; the entry scene re-enters them. */
export const ENTRY_L1 = ['v1', 'v2', 'v3']
export const ENTRY_DEEP = ['v1', 'v2']
