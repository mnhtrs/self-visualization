// scenes/layout.ts — the derived *layout system* for the panel scenes. Every
// container interior the renderers draw into (rows, tag chips, word cells,
// set braces, the address stage, the counter, the tally board, the RAM block)
// is computed HERE from named metrics + container rects, so the renderers
// hold no eyeballed arithmetic (Layout Derivation Law).
//
// Imports metrics (pure) + nothing else; nothing imports this file back.

import * as M from './metrics'
import type { Vec2 } from '../../../../../chapter-loader/types'
import type { TermPill } from './story'

// =============================================================================
// The cache panel — one level magnified
// =============================================================================
export const PANEL = {
  x: M.PANEL_X,
  y: M.PANEL_Y,
  w: M.PANEL_W,
  h: M.PANEL_H,
  r: 20,
}

/** Title baseline zone inside the panel header band. */
export const panelTitlePos = (): Vec2 => ({
  x: PANEL.x + M.PANEL_PAD.x,
  y: PANEL.y + M.PANEL_TITLE_H / 2,
})

/** Orientation chip at the panel header's right edge ('inside L1 Cache'). */
export const orientChip = (textW: number) => {
  const w = textW + 2 * M.ORIENT.padX
  return {
    x: PANEL.x + PANEL.w - M.PANEL_PAD.x - w,
    y: PANEL.y + (M.PANEL_TITLE_H - M.ORIENT.h) / 2,
    w,
    h: M.ORIENT.h,
    r: M.ORIENT.r,
  }
}

/** Top edge of Cache Line row `i`. */
export const rowTop = (i: number): number =>
  PANEL.y + M.PANEL_TITLE_H + M.PANEL_PAD.top + i * (M.ROW.h + M.ROW.gap)

export const rowRect = (i: number) => ({
  x: PANEL.x + M.PANEL_PAD.x,
  y: rowTop(i),
  w: M.ROW_W,
  h: M.ROW.h,
  r: M.ROW.r,
})

/** Row visual centre across its full width (spark waypoints, open states). */
export const rowC = (i: number): Vec2 => ({
  x: PANEL.x + PANEL.w / 2,
  y: rowTop(i) + M.ROW.h / 2,
})

export const tagChipRect = (i: number) => ({
  x: PANEL.x + M.PANEL_PAD.x + M.ROW.padX,
  y: rowTop(i) + (M.ROW.h - M.TAG.h) / 2,
  w: M.TAG.w,
  h: M.TAG.h,
  r: M.TAG.r,
})

export const tagC = (i: number): Vec2 => {
  const r = tagChipRect(i)
  return { x: r.x + r.w / 2, y: r.y + r.h / 2 }
}

/** Word cell `k` (0..3) of Cache Line `i`. */
export const wordCellRect = (i: number, k: number) => {
  const t = tagChipRect(i)
  return {
    x: t.x + t.w + M.TAG_GAP + k * (M.WORD.w + M.WORD.gap),
    y: rowTop(i) + (M.ROW.h - M.WORD.h) / 2,
    w: M.WORD.w,
    h: M.WORD.h,
    r: M.WORD.r,
  }
}

export const wordC = (i: number, k: number): Vec2 => {
  const r = wordCellRect(i, k)
  return { x: r.x + r.w / 2, y: r.y + r.h / 2 }
}

// =============================================================================
// Set braces — three arrangements, identical row positions underneath
// =============================================================================
// The grouping is the mechanism, so it is the BRACES that regroup; rows never
// move (Spatial Stability §6). A brace wraps the rows of its set with SET_PAD.
export interface Brace {
  x: number
  y: number
  w: number
  h: number
  r: number
  /** Which arrangement this brace belongs to. */
  config: 'pairs' | 'singles' | 'giant'
  /** Set id inside its arrangement (for set-coloured strokes). */
  setId: number
}

export const braceAround = (fromRow: number, toRow: number, setId: number, config: Brace['config']): Brace => ({
  x: PANEL.x + M.PANEL_PAD.x - M.SET_PAD,
  y: rowTop(fromRow) - M.SET_PAD,
  w: M.ROW_W + 2 * M.SET_PAD,
  h: rowTop(toRow) + M.ROW.h - rowTop(fromRow) + 2 * M.SET_PAD,
  r: M.SET_R,
  config,
  setId,
})

/** The chapter's home arrangement: 4 sets × 2 lines. */
export const PAIR_BRACES: Brace[] = [0, 1, 2, 3].map((s) => braceAround(2 * s, 2 * s + 1, s, 'pairs'))
/** Direct experiment: 8 sets × 1 line (set id doubles as a neutral index). */
export const SINGLE_BRACES: Brace[] = Array.from({ length: M.ROWS }, (_, i) => braceAround(i, i, i, 'singles'))
/** Fully associative experiment: 1 set × 8 lines. */
export const GIANT_BRACE: Brace = braceAround(0, M.ROWS - 1, 0, 'giant')

/** Centre of a pair-set's brace (spark anchor for routing). */
export const setC = (s2: number): Vec2 => ({
  x: PANEL.x + PANEL.w / 2,
  y: (rowTop(2 * s2) + rowTop(2 * s2 + 1) + M.ROW.h) / 2,
})

// =============================================================================
// The address stage — north of the panel, where the card becomes three chips
// =============================================================================
export const STAGE = M.STAGE_POS

/** The unsplit address card (three seamless zones in one rounded rect). */
export const cardRect = () => {
  const w = 3 * M.CHIP.w + 2 * M.CHIP.gap + 2 * M.CARD.r
  return { x: STAGE.x - w / 2, y: STAGE.y - M.CARD.h / 2, w, h: M.CARD.h, r: M.CARD.r }
}

/** Resting position of chip `k` after the split (0 = Index, 1 = Tag, 2 = Offset).
 *  The chips RISE out of the card (SPLIT_TRAVEL upward) and form up above it in
 *  the free air north of the panel — clear of the card, the panel header and
 *  the orientation chip (Layout Derivation Law: BREATH between neighbours). */
export const chipAt = (k: number): Vec2 => {
  const c = cardRect()
  return {
    x: c.x + M.CARD.r + M.CHIP.w / 2 + k * (M.CHIP.w + M.CHIP.gap),
    y: STAGE.y - M.SPLIT_TRAVEL,
  }
}

// =============================================================================
// Instruments
// =============================================================================
/** The comparison counter hugging the panel's north-east corner. */
export const counterRect = (textW: number) => {
  const w = Math.max(M.COUNTER.minW, textW + 2 * M.COUNTER.padX)
  return {
    x: PANEL.x + PANEL.w - w,
    y: PANEL.y - M.COUNTER.h - M.BREATH * 2,
    w,
    h: M.COUNTER.h,
    r: M.COUNTER.r,
  }
}

/** The tally board east of the panel (mapping scene only). */
export const tallyBoard = () => ({
  x: M.TALLY.x,
  y: PANEL.y + (PANEL.h - M.TALLY_H) / 2,
  w: M.TALLY.w,
  h: M.TALLY_H,
  r: M.TALLY.r,
})

export const tallyPill = (k: number) => {
  const b = tallyBoard()
  return {
    x: b.x + M.TALLY.padY,
    y: b.y + M.TALLY.padY + k * (M.TALLY.pillH + M.TALLY.gap),
    w: b.w - 2 * M.TALLY.padY,
    h: M.TALLY.pillH,
    r: M.TALLY.pillH / 2,
  }
}

/** Terminology pill anchored beneath the panel (term lands after behaviour). */
export const termPillPos = (anchorX: number): Vec2 => ({
  x: anchorX,
  y: PANEL.y + PANEL.h + M.TERM.gap + M.TERM.h / 2,
})

// =============================================================================
// Pill docks — every on-canvas pill (term / verdict / question / ticker) lives
// at a named dock, so the layout proof can assert containment + disjointness.
// `valign` says which edge of the (possibly taller, wrapped) pill `pos` pins:
// north pills grow UP from the panel roof, south pills hang DOWN from the
// floor, the east 'row' pill centres on its row.
// =============================================================================
export interface Dock {
  pos: Vec2
  valign: 'top' | 'bottom' | 'center'
}

/** North band: questions and the mapping-scene term names. Bottom edge rests
 *  BREATH above the panel roof; the pill grows upward if its sub wraps. */
export const dockNorth = (): Dock => ({
  pos: { x: PANEL.x + PANEL.w / 2, y: PANEL.y - M.BREATH },
  valign: 'bottom',
})

/** South dock under the panel, at column `x`. The pill hangs from `pos.y`. */
export const dockSouth = (x: number): Dock => ({
  pos: { x, y: PANEL.y + PANEL.h + M.BREATH },
  valign: 'top',
})

/** Where terms land per anchor (Knowledge Reveal: after behaviour; never
 *  floating over rows, braces, the card or another instrument). */
export const termDock = (t: TermPill): Dock => {
  switch (t.anchor) {
    case 'row': {
      const i = t.anchorIndex ?? 0
      // east of the panel, centred beside the row it names; bboxCache({term})
      // reserves exactly BREATH + TERM.maxW for this dock.
      return {
        pos: { x: PANEL.x + PANEL.w + M.BREATH + M.TERM.maxW / 2, y: rowTop(i) + M.ROW.h / 2 },
        valign: 'center',
      }
    }
    case 'set':
    case 'panel':
      // mapping beats: the north band is free of cards while sets regroup
      return dockNorth()
    case 'east':
      // miss/replace acts: south dock, weighted toward the RAM side
      return dockSouth((PANEL.x + PANEL.w + M.RAM_PANEL.x) / 2)
    case 'stage':
    default:
      // lookup acts: the address card owns the north band — terms wait below
      return dockSouth(PANEL.x + PANEL.w / 2)
  }
}

/** The verdict dock: south dock one chip-width west of the tag column it
 *  passes judgement on — clear of the centre/east term docks that share
 *  these beats. */
export const verdictDock = (): Dock => dockSouth(tagC(0).x - M.CHIP.w - M.BREATH)

/** The masthead at the address stage: the replay ticker and the returning
 *  opening question take turns here. */
export const mastheadDock = (): Dock => ({
  pos: { x: STAGE.x, y: STAGE.y },
  valign: 'center',
})

// =============================================================================
// RAM (miss / replace scenes)
// =============================================================================
export const RAM_PANEL_RECT = {
  x: M.RAM_PANEL.x,
  y: M.RAM_PANEL.y,
  w: M.RAM_PANEL.w,
  h: M.RAM_PANEL_H,
  r: M.RAM_PANEL.r,
}

export const ramCellRect = (col: number, row: number) => ({
  x: M.RAM_PANEL.x + M.RAM_PANEL.padX + col * (M.RAM_CELL.cell + M.RAM_CELL.gap),
  y: M.RAM_PANEL.y + M.RAM_PANEL.titleH + M.RAM_CELL.cell / 2 + row * (M.RAM_CELL.cell + M.RAM_CELL.gap),
  w: M.RAM_CELL.cell,
  h: M.RAM_CELL.cell,
})

/** The exposed RAM block: the exact interior span of a cache line, derived
 *  from the grid rows it covers (RAM_BLOCK_ROWS) so it always lives INSIDE
 *  the RAM panel it belongs to — a cache-line-sized stretch of memory. */
export const ramBlockRect = () => {
  const top = ramCellRect(0, M.RAM_BLOCK_ROWS[0]).y - M.RAM_CELL.gap / 2
  const bottom = ramCellRect(0, M.RAM_BLOCK_ROWS[1]).y + M.RAM_CELL.cell + M.RAM_CELL.gap / 2
  return {
    x: M.RAM_PANEL.x + M.RAM_PANEL.padX,
    y: top,
    w: M.RAM_PANEL.w - 2 * M.RAM_PANEL.padX,
    h: bottom - top,
    r: M.ROW.r,
  }
}

/** The caravan: tag + words flying home keep their line formation. */
export const ramBlockCenter = (): Vec2 => {
  const r = ramBlockRect()
  return { x: r.x + r.w / 2, y: r.y + r.h / 2 }
}

// =============================================================================
// Scene bounding boxes — the camera plan (fit-to-content per scene)
// =============================================================================
const C = M.CLIP_INSET

/** The pill docks' vertical reach: a north pill rises up to termHMax above
 *  the panel roof; a south pill hangs up to termHMax below the floor. */
const TERM_H_MAX = M.TERM.h + 2 * (M.F.sub + 6)
const NORTH_PAD = M.BREATH + TERM_H_MAX
const SOUTH_PAD = M.BREATH + TERM_H_MAX

/** Cache-only scenes (interior / mapping-with-tally / lookup / replay).
 *  `term` widens the east edge for the interior scene's east-anchored term
 *  pill ('Cache Line', beside the row it names). */
export const bboxCache = (opts: { tally?: boolean; stage?: boolean; term?: boolean }) => {
  const minX = Math.min(M.CPU_DOCK_POS.x - M.DOCK_BOX.w / 2, PANEL.x)
  const maxX = opts.tally
    ? tallyBoard().x + tallyBoard().w
    : opts.term
      ? PANEL.x + PANEL.w + M.BREATH + M.TERM.maxW
      : PANEL.x + PANEL.w
  const stageTop = STAGE.y - M.CARD.h / 2 - M.CHIP.h - M.SPLIT_TRAVEL
  const minY = opts.stage ? Math.min(PANEL.y - NORTH_PAD, stageTop) : PANEL.y - NORTH_PAD
  const maxY = PANEL.y + PANEL.h + SOUTH_PAD
  return { minX: minX - C, maxX: maxX + C, minY: minY - C, maxY: maxY + C }
}

/** Scenes that must keep RAM in frame (miss / replace). */
export const bboxCacheAndRam = () => {
  const b = bboxCache({ stage: true })
  return { ...b, maxX: M.RAM_PANEL.x + M.RAM_PANEL.w + C }
}
