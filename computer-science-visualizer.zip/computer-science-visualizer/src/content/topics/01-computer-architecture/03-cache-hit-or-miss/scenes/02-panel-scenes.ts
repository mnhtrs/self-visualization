// scenes/02-panel-scenes.ts — geometry for the six panel scenes (interior,
// mapping, lookup, miss, replace, replay). One cache level, magnified, holds
// centre stage while the acts change around it: the tally board appears only
// for mapping, RAM only where the journey reaches RAM, the address stage only
// where the address opens (Visual Economy — PEDAGOGICAL_SYSTEM §2.2).
//
// Every anchor derives from scenes/layout.ts. Each scene's path is the full
// journey of its beats, sliced per beat by travel {from,to} — exactly the
// Chapter-02 pattern (PATH_B). Rows never move; only braces regroup.

import * as L from './layout'
import * as M from './metrics'
import type { Vec2 } from '../../../../../chapter-loader/types'
import type { PartSpec } from '../types'

// ---- shared anchors -------------------------------------------------------------
export const DOCK: Vec2 = M.DOCK_POS
export const CPU_DOCK: Vec2 = M.CPU_DOCK_POS
export const STAGE: Vec2 = L.STAGE
export const setA = (s2: number): Vec2 => L.setC(s2)
export const tagA = (row: number): Vec2 => L.tagC(row)
export const wordA = (row: number, k: number): Vec2 => L.wordC(row, k)
export const rowA = (row: number): Vec2 => L.rowC(row)
export const RAM_BLOCK_A: Vec2 = L.ramBlockCenter()

// =============================================================================
// PATH — interior (the naive sweep)
// =============================================================================
export const PATH_INTERIOR: Vec2[] = [
  DOCK, //          0  b2 emerges here
  tagA(0), tagA(1), tagA(2), tagA(3), tagA(4), tagA(5), // 1-6  b3 visit rows 0..5
  DOCK, //          7  b3 returns home (found at line 6)
  tagA(0), tagA(1), tagA(2), tagA(3), tagA(4), tagA(5), tagA(6), tagA(7), // 8-15 b4 all eight
  DOCK, //         16  b4 returns; b5 rests here
]

// =============================================================================
// PATH — mapping (sets and the three set-size experiments)
// =============================================================================
export const PATH_MAPPING: Vec2[] = [
  DOCK, //          0  scene entry
  setA(2), //        1  b6: two same-stripe demonstrations land here; b7 rests here
  DOCK, tagA(4), DOCK, tagA(4), DOCK, tagA(4), DOCK, tagA(4), // 2-9  b8: direct stream A2 B2 A2 B2
  DOCK, tagA(4), DOCK, tagA(5), DOCK, tagA(4), DOCK, tagA(5), // 10-17 b10: 2-way stream
  DOCK, tagA(2), DOCK, tagA(3), // 18-21 b10 tail: quiet C1/E1 loads
  DOCK, tagA(0), DOCK, tagA(1), DOCK, tagA(5), DOCK, tagA(7), // 22-29 b12: anywhere loads
  DOCK, tagA(0), DOCK, tagA(1), DOCK, tagA(5), DOCK, tagA(7), // 30-37 b12: the fan-out repeat round
  DOCK, //         38  b12 ends home; braces settle back to pairs
]

// =============================================================================
// PATH — lookup (one full hit)
// =============================================================================
export const PATH_LOOKUP: Vec2[] = [
  DOCK, //          0  seam from mapping
  STAGE, //         1  b13: the address is examined
  STAGE, //         2  dup — b14 lets the split settle before the chips fly
  setA(1), //       3  b14: the Index lands; set 1 opens
  tagA(2), //       4  b15: first stored tag — not me
  tagA(3), //       5  b15: second stored tag — me (match, line opens)
  wordA(3, 2), //   6  b16: the Word Offset lands on word 2
  DOCK, //          7  the word starts home
  CPU_DOCK, //      8  returned
]

// =============================================================================
// PATH — miss (no tag matches; the line comes from RAM)
// =============================================================================
export const PATH_MISS: Vec2[] = [
  CPU_DOCK, //      0  seam from lookup
  DOCK, //          1
  STAGE, //         2  the address splits again (known behaviour)
  setA(3), //       3  the Index selects set 3
  tagA(6), //       4  first stored tag — not me
  tagA(7), //       5  second — not me (Cache Miss)
  RAM_BLOCK_A, //   6  on to RAM: the matching block
  rowA(6), //       7  the whole line lands in set 3's free line
  wordA(6, 2), //   8  the Word Offset picks word 2
  DOCK, //          9
  CPU_DOCK, //     10  returned
]

// =============================================================================
// PATH — replace (the full set: FIFO, then LRU on rewind)
// =============================================================================
export const PATH_REPLACE: Vec2[] = [
  CPU_DOCK, //      0  seam from miss
  DOCK, //          1
  STAGE, //         2
  setA(2), //       3  the Index selects set 2 — already full
  tagA(4), //       4  first stored tag — not me
  tagA(5), //       5  second — not me (Cache Miss, and no free line)
  rowA(4), //       6  b21 FIFO: the earliest arrival left; G2 settles row 4
  setA(2), //       7  rest between policies
  rowA(5), //       8  b22 LRU: the least recently used left; G2 settles row 5
  wordA(5, 3), //   9  b23: the Word Offset picks word 3
  DOCK, //         10
  CPU_DOCK, //     11  returned
]

// =============================================================================
// PATH — replay (the continuous full pass)
// =============================================================================
export const PATH_REPLAY: Vec2[] = [
  CPU_DOCK, //      0  seam from replace
  STAGE, //         1  address splits (silently known)
  setA(1), //       2  index → set 1
  tagA(2), //       3  tag → match at the first stored tag
  wordA(2, 0), //   4  offset → word 0
  DOCK, //          5
  CPU_DOCK, //      6  home — b25 rests here
]

// =============================================================================
// Entities — the same cast every panel scene shares
// =============================================================================
export const cpuDock: PartSpec = {
  id: 'cpu',
  kind: 'proc-dock',
  pos: CPU_DOCK,
  color: '#fb923c',
  name: 'CPU',
  gloss: {
    en: 'The requester. It cannot see inside the cache — it sends a request in, and a word comes back. How the middle works is what we are inside of.',
    vi: 'Bên gửi request. Nó không nhìn thấy gì bên trong cache — nó gửi request vào, và một từ dữ liệu quay về. Phần ở giữa mới chính là thứ ta đang chìm vào.',
  },
}

export const cacheFrame: PartSpec = {
  id: 'cache',
  kind: 'cache-frame',
  pos: { x: L.PANEL.x + L.PANEL.w / 2, y: L.PANEL.y + L.PANEL.h / 2 },
  color: '#22d3ee',
  name: 'L1 Cache',
  gloss: {
    en: 'One cache level, seen from the inside. Everything this chapter explains happens within these walls: the lines, the sets, the comparisons, the arrivals and the departures.',
    vi: 'Một tầng cache nhìn từ bên trong. Mọi thứ chapter này giải thích đều xảy ra trong bức tường này: các line, các set, các lần so sánh, ra vào.',
  },
}

export const ramPanel: PartSpec = {
  id: 'ram',
  kind: 'ram-panel',
  pos: {
    x: L.RAM_PANEL_RECT.x + L.RAM_PANEL_RECT.w / 2,
    y: L.RAM_PANEL_RECT.y + L.RAM_PANEL_RECT.h / 2,
  },
  color: '#a78bfa',
  name: 'RAM',
  gloss: {
    en: 'The far memory, kept in frame because a miss means going there. It always has the value — the trip is what costs.',
    vi: 'Bộ nhớ xa, giữ trong khung hình vì miss nghĩa là phải đi ra đó. Lúc nào nó cũng có dữ liệu — cái tốn là quãng đường.',
  },
}

/** Labelless painter per panel scene (same kind everywhere; story tables
 *  decide what it paints from the beat index). */
export const cacheStage = (id: string): PartSpec => ({
  id,
  kind: 'cache-stage',
  pos: { x: L.PANEL.x + L.PANEL.w / 2, y: L.PANEL.y + 60 },
  color: '#22d3ee',
  name: '',
  gloss: { en: '', vi: '' },
})
