// scenes/metrics.ts — the Chapter's layout *primitives*: every bare number the
// geometry and the renderers use, named exactly once. PURE — no imports — so
// scene geometry and the derived layout system build on it without cycles.
//
// Doctrine (docs/constitution/VISUAL_LANGUAGE.md §2.2 Derivable Geometry, and
// docs/pipeline/02_PRODUCTION_LIFECYCLE.md Layout Derivation Law): an inline
// literal coordinate is a defect. Every drawn coordinate must be a named metric
// or a function of a container rect + measured text.
//
// Container EXTENTS are derived from the content they hold, never hand-typed
// (PLATFORM_ENGINE §2.4) — see PANEL / RAM_PANEL / TALLY below.
//
// CONTINUITY (owner spec: "reuse the ending of Chapter 02 — the camera should
// naturally zoom into the cache already shown"). The entry scene mirrors the
// Chapter-02 ladder primitives verbatim (axis, rung boxes, gaps, slots), so
// the learner re-enters the remembered world unchanged.

// ---- global spacing scale -----------------------------------------------------
export const BREATH = 8 // min text↔edge / text↔text breathing (world units)
export const CLIP_INSET = 14 // min content inset from a scene bbox edge
export const LABEL_GAP = 12 // gap between a box edge and its name label
export const LABEL_TEXT_H = 20 // approx cap-height of a name label (for bbox math)

// ---- canvas font families (single source, same as Chapter 02) -------------------
export const FONT = "'Quicksand', system-ui, sans-serif"
export const MONO = "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace"

// ---- type scale (world px) — one named size per role, never a literal -----------
export const F = {
  partName: 19,
  panelTitle: 22,
  termPill: 21,
  question: 24,
  verdict: 20,
  counter: 17,
  chip: 16,
  sub: 14,
}

// ==============================================================================
// SCENE `entry` — the remembered memory ladder (mirrors Chapter 02 Scene B)
// ==============================================================================
export const AXIS_Y = 372
export const LADDER_START_X = 120
export const CPU_BOX = { w: 196, h: 168, r: 18 }
export const RAM_BOX = { w: 280, h: 240, r: 16 }
export const RUNG_R = 14
export interface RungSpec {
  id: string
  w: number
  h: number
  gapBefore: number
  slots: number
}
export const RUNGS: RungSpec[] = [
  { id: 'cpu', w: CPU_BOX.w, h: CPU_BOX.h, gapBefore: 0, slots: 0 },
  { id: 'l1', w: 132, h: 92, gapBefore: 104, slots: 3 },
  { id: 'l2', w: 176, h: 116, gapBefore: 148, slots: 4 },
  { id: 'l3', w: 224, h: 142, gapBefore: 196, slots: 5 },
  { id: 'ram', w: RAM_BOX.w, h: RAM_BOX.h, gapBefore: 300, slots: 0 },
]
export const SLOT = { padX: 13, gap: 7, h: 30, r: 5 }
export const CPU_PINS = { count: 5, len: 11, w: 4, inset: 26 }
export const CPU_CORE = { half: 34, r: 8 }
export const RAM_GRID = { cols: 16, rows: 12, cell: 9, gap: 4 }
export const RAM_TARGET = { col: 9, row: 5 }
export const VALUE = { size: 15, ring: 13 }
export const BUS = { width: 5, activeWidth: 7, dash: [2, 16] }
/** The protagonist's drawn radius (rendering/primitives/spark.ts: R = 44*scale).
 *  Resting docks sit one radius clear of a container face so the glow never
 *  covers evidence (same rule as Chapter 02). */
export const SPARK = { r: 44, dockGap: 44 + BREATH }
/** The question pill above the nearest level — the chapter's own question. */
export const ASK = { h: 46, r: 23, padX: 26, dy: -64 }

// ==============================================================================
// The cache interior — one level magnified (shared by all panel scenes)
// ==============================================================================
export const ROWS = 8 // countable Cache Lines
export const WORDS_PER_LINE = 4
export const PANEL_PAD = { x: 30, top: 26, bottom: 26 }
export const PANEL_TITLE_H = 44
export const ROW = { h: 56, r: 14, gap: 20, padX: 14 }
export const TAG = { w: 108, h: 40, r: 10 }
export const TAG_GAP = 16
export const WORD = { w: 82, h: 40, r: 8, gap: 10 }
/** 'you are here' orientation chip: the level this interior belongs to (§17). */
export const ORIENT = { h: 34, r: 17, padX: 16, gap: 14 }

// Width of a row's interior content: pad + tag + gap + 4 words + 3 gaps + pad
export const ROW_INNER_W =
  ROW.padX * 2 + TAG.w + TAG_GAP + WORDS_PER_LINE * WORD.w + (WORDS_PER_LINE - 1) * WORD.gap
export const PANEL_W = 2 * PANEL_PAD.x + ROW_INNER_W
export const ROW_W = PANEL_W - 2 * PANEL_PAD.x
export const PANEL_H =
  PANEL_TITLE_H + PANEL_PAD.top + ROWS * ROW.h + (ROWS - 1) * ROW.gap + PANEL_PAD.bottom

export const PANEL_X = 430
export const PANEL_Y = 150
/** The CPU the request came from — a small dock west of the panel. */
export const DOCK_BOX = { w: 128, h: 108, r: 16 }
export const CPU_DOCK_POS = { x: 196, y: 492 }
/** Where the protagonist waits between hops (one spark-radius clear of the panel). */
export const DOCK_POS = { x: PANEL_X - SPARK.dockGap - 20, y: 492 }
/** The link segment from the CPU dock to the request dock (a distinct path §2.1). */
export const WEST_LINK: [number, number] = [CPU_DOCK_POS.x + DOCK_BOX.w / 2, PANEL_X - 2]

// ==============================================================================
// Sets — braces around groups of rows
// ==============================================================================
export const SET_PAD = 10 // brace inset around its rows
export const SET_R = 18
export const SET_COLORS = ['#818cf8', '#34d399', '#fb7185', '#fbbf24'] as const
export const SETS_OF_TWO = 4 // sets in the chapter's home arrangement (2 lines each)

// ==============================================================================
// The address stage (lookup act) — north of the panel
// ==============================================================================
export const STAGE_POS = { x: PANEL_X + PANEL_W / 2, y: 92 }
export const CARD = { h: 52, r: 12 }
export const CHIP = { w: 96, h: 44, r: 10, gap: 14 }
/** How far the chips RISE out of the card when the address splits (the card's
 *  three jobs form up above it, ready to fly down to their stations). Chosen so
 *  the parked chip row clears the card top edge by exactly BREATH. */
export const SPLIT_TRAVEL = 56

// ==============================================================================
// Instruments — comparison counter and the mapping tally board
// ==============================================================================
export const COUNTER = { h: 40, r: 20, padX: 18, minW: 236 }
export const TALLY = { x: PANEL_X + PANEL_W + 44, w: 268, pillH: 46, gap: 14, padY: 14, r: 14 }
export const TALLY_H = 2 * TALLY.padY + 3 * TALLY.pillH + 2 * TALLY.gap // board fits its 3 pills

// ==============================================================================
// RAM (miss / replace scenes) — the far memory, east of the panel
// ==============================================================================
export const RAM_PANEL = { x: 1152, y: 200, w: 396, r: 16, titleH: 44, padX: 26, padY: 24 }
export const RAM_CELL = { cell: 13, gap: 6, cols: 8, rows: 10 }
export const RAM_PANEL_H =
  RAM_PANEL.titleH + RAM_PANEL.padY + RAM_CELL.rows * RAM_CELL.cell + (RAM_CELL.rows - 1) * RAM_CELL.gap + RAM_PANEL.padY
/** The exposed block the miss targets spans these grid rows (derived in layout). */
export const RAM_BLOCK_ROWS: [number, number] = [4, 6]

// ---- compare / verdict / term pills ------------------------------------------------
export const PILL = { h: 34, r: 17, padX: 16, gap: 12 }
export const VERDICT = { h: 40, r: 20, padX: 18, gap: 14 }
/** maxW: the widest term pill (locked term OR its plain-language sub, either
 *  language) may span — the bbox for scenes with an east 'row'-anchored term
 *  derives from it, and the layout proof asserts every term pill fits. */
export const TERM = { h: 44, r: 22, padX: 22, gap: 18, maxW: 400 }

// ---- victim exit: a displaced line drifts WEST, away from every path ---------------
export const VICTIM_DX = 200
export const CARAVAN_GAP = 10 // tag↔word spacing while a whole line travels
