// scenes/01-entry.ts — Scene `entry` geometry: the Chapter-02 memory ladder,
// re-entered unchanged. One horizontal axis, the CPU on the west, RAM far to
// the east, and the three cache rungs between them — same axis, same rung
// order, same sizes, same colours as the learner remembers (Orientation
// Preservation §17; the owner spec's "enter the cache, don't start a new
// lesson"). Everything DERIVES from scenes/metrics.ts primitives.
//
// The protagonist's path is two anchors long: form at the CPU, hop to the
// nearest level's dock — the door the whole chapter walks through.

import * as M from './metrics'
import type { Vec2 } from '../../../../../chapter-loader/types'
import type { PartSpec, Rect } from '../types'

export interface Rung {
  id: string
  pos: Vec2
  w: number
  h: number
  west: number
  east: number
  slots: number
}

function buildRungs(): Rung[] {
  const out: Rung[] = []
  let cursor = M.LADDER_START_X
  for (const spec of M.RUNGS) {
    const west = cursor + spec.gapBefore
    const pos: Vec2 = { x: west + spec.w / 2, y: M.AXIS_Y }
    out.push({ id: spec.id, pos, w: spec.w, h: spec.h, west, east: west + spec.w, slots: spec.slots })
    cursor = west + spec.w
  }
  return out
}

export const RUNGS: Rung[] = buildRungs()
export const rungById = (id: string): Rung => RUNGS.find((r) => r.id === id) ?? RUNGS[0]
export const CPU_RUNG = rungById('cpu')
export const L1_RUNG = rungById('l1')
export const RAM_RUNG = rungById('ram')

/** The dock the request hops to: a spark-radius clear of L1's west face. */
export const L1_DOCK: Vec2 = { x: L1_RUNG.west - M.SPARK.dockGap, y: M.AXIS_Y }

/** Link segments between consecutive rungs (each hop is its own drawn path §2.1). */
export const LINKS: [Vec2, Vec2][] = RUNGS.slice(0, -1).map((r, i) => [
  { x: r.east, y: M.AXIS_Y },
  { x: RUNGS[i + 1].west, y: M.AXIS_Y },
])

/** The chapter's question hangs over the nearest level the request knocks on. */
export const ASK_POS: Vec2 = {
  x: L1_RUNG.pos.x,
  y: L1_RUNG.pos.y - L1_RUNG.h / 2 + M.ASK.dy,
}

/** Protagonist waypoints: 0 = the CPU core; 1 = the level's door. */
export const PATH_ENTRY: Vec2[] = [CPU_RUNG.pos, L1_DOCK]

// ---- scene bbox derived from content + clip inset --------------------------------
const CONTENT_MIN_Y = Math.min(
  M.AXIS_Y - M.RAM_BOX.h / 2,
  ASK_POS.y - M.ASK.h / 2,
)
const CONTENT_MAX_Y = M.AXIS_Y + M.RAM_BOX.h / 2 + M.LABEL_GAP + M.LABEL_TEXT_H
export const BBOX_ENTRY = {
  minX: CPU_RUNG.west - M.CLIP_INSET,
  maxX: RAM_RUNG.east + M.CLIP_INSET,
  minY: CONTENT_MIN_Y - M.CLIP_INSET,
  maxY: CONTENT_MAX_Y + M.CLIP_INSET,
}

/** The hotspot that starts the chapter: the CPU box. */
export const CPU_RECT: Rect = {
  x: CPU_RUNG.pos.x - CPU_RUNG.w / 2,
  y: CPU_RUNG.pos.y - CPU_RUNG.h / 2,
  w: CPU_RUNG.w,
  h: CPU_RUNG.h,
}

// ---- entities ----------------------------------------------------------------------
export const cpu: PartSpec = {
  id: 'cpu',
  kind: 'proc-core',
  pos: CPU_RUNG.pos,
  color: '#fb923c',
  name: 'CPU',
  gloss: {
    en: 'The same processor as always. Its rule of thumb from last chapter: ask the nearest cache level first, only go further out if you have to.',
    vi: 'Vẫn con CPU quen thuộc. Nguyên tắc từ chapter trước: hỏi tầng cache gần nhất trước, bất đắc dĩ mới phải đi xa hơn.',
  },
}

const rungGloss = (en: string, vi: string) => ({ en, vi })

export const l1: PartSpec = {
  id: 'l1',
  kind: 'cache-rung',
  pos: L1_RUNG.pos,
  color: '#22d3ee',
  name: 'L1 Cache',
  gloss: rungGloss(
    'The nearest level, the one the CPU always asks first. Last chapter it answered "yes" or "no" without showing why — this chapter walks in through its door.',
    'Tầng gần nhất, tầng mà CPU luôn hỏi đầu tiên. Chapter trước nó trả lời "có" hoặc "không" mà chưa từng cho thấy vì sao — chapter này sẽ đi qua cửa của nó.',
  ),
  extra: { rungId: 'l1' },
}

export const l2: PartSpec = {
  id: 'l2',
  kind: 'cache-rung',
  pos: rungById('l2').pos,
  color: '#22d3ee',
  name: 'L2 Cache',
  gloss: rungGloss(
    'A step further out, a step larger — asked only when L1 comes up empty.',
    'Xa hơn một nấc, lớn hơn một nấc — chỉ bị hỏi khi L1 không có.',
  ),
  extra: { rungId: 'l2' },
}

export const l3: PartSpec = {
  id: 'l3',
  kind: 'cache-rung',
  pos: rungById('l3').pos,
  color: '#22d3ee',
  name: 'L3 Cache',
  gloss: rungGloss(
    'The last stop before RAM — largest and furthest of the three.',
    'Chặng cuối trước khi ra RAM — lớn nhất và xa nhất trong ba tầng.',
  ),
  extra: { rungId: 'l3' },
}

export const ram: PartSpec = {
  id: 'ram',
  kind: 'ram-bank',
  pos: RAM_RUNG.pos,
  color: '#a78bfa',
  name: 'RAM',
  gloss: rungGloss(
    'The far memory. Everything ultimately lives here — cache only ever keeps copies of a few things it lent out.',
    'Bộ nhớ xa. Mọi thứ cuối cùng đều nằm ở đây — cache chỉ giữ bản sao của vài thứ mượn từ nó.',
  ),
}

/** Labelless painter: the links, the question pill, the forming request card. */
export const entryStage: PartSpec = {
  id: 'entry-stage',
  kind: 'entry-stage',
  pos: { x: L1_RUNG.pos.x, y: M.AXIS_Y },
  color: '#22d3ee',
  name: '',
  gloss: { en: '', vi: '' },
}
