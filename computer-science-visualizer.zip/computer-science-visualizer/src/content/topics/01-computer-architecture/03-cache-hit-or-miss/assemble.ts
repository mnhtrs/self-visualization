// content/topics/01-computer-architecture/03-cache-hit-or-miss/assemble.ts
// The full declarative assembly of Topic 01 Chapter 03 — everything except the
// meta import. Kept meta-free so the chapter can be built and verified outside
// Vite's asset pipeline (same pattern as Ch-02's assemble.ts).

import type {
  Chapter,
  ChapterMeta,
  EntityDescription,
  HitZone,
  SceneDescription,
  Vec2,
} from '../../../../chapter-loader/types'

import {
  BBOX_ENTRY, PATH_ENTRY, CPU_RECT,
  cpu, l1, l2, l3, ram, entryStage,
} from './scenes/01-entry'
import {
  PATH_INTERIOR, PATH_MAPPING, PATH_LOOKUP, PATH_MISS, PATH_REPLACE, PATH_REPLAY,
  cpuDock, cacheFrame, ramPanel, cacheStage, DOCK,
} from './scenes/02-panel-scenes'
import * as L from './scenes/layout'
import { beats } from './narration/beats'
import {
  chapterTitle, waitingLine, startButton, sceneTag, tipText, doneLabel,
} from './narration/labels'
import type { PartSpec } from './types'
import { RENDERERS } from './renderers'

// ---- helpers ----------------------------------------------------------------
const toEntity = (
  p: PartSpec,
  sceneId: string,
  extra?: Record<string, unknown>,
): EntityDescription => ({
  id: p.id,
  kind: p.kind ?? p.id,
  pos: p.pos,
  color: p.color,
  name: p.name,
  gloss: p.gloss,
  scene: sceneId,
  extra: { ...p.extra, ...extra },
  labelSize: p.labelSize,
})

// ---- scene 1: entry — the remembered ladder --------------------------------------
const entryScene: SceneDescription = {
  id: 'entry',
  bbox: BBOX_ENTRY,
  cameraPad: 0.95,
  path: PATH_ENTRY,
  entities: [
    toEntity(entryStage, 'entry'),
    toEntity(cpu, 'entry'),
    toEntity(l3, 'entry'),
    toEntity(l2, 'entry'),
    toEntity(l1, 'entry'),
    toEntity(ram, 'entry'),
  ],
}

// ---- scene 2: interior — one level magnified --------------------------------------
const interiorScene: SceneDescription = {
  id: 'interior',
  bbox: L.bboxCache({ term: true }),
  cameraPad: 0.94,
  path: PATH_INTERIOR,
  entities: [
    toEntity(cacheFrame, 'interior'),
    toEntity(cacheStage('interior-stage'), 'interior'),
    toEntity(cpuDock, 'interior'),
  ],
}

// ---- scene 3: mapping — sets and the three arrangements ----------------------------
const mappingScene: SceneDescription = {
  id: 'mapping',
  bbox: L.bboxCache({ tally: true }),
  cameraPad: 0.94,
  path: PATH_MAPPING,
  entities: [
    toEntity(cacheFrame, 'mapping'),
    toEntity(cacheStage('mapping-stage'), 'mapping'),
    toEntity(cpuDock, 'mapping'),
  ],
}

// ---- scene 4: lookup — one complete Cache Lookup -----------------------------------
const lookupScene: SceneDescription = {
  id: 'lookup',
  bbox: L.bboxCache({ stage: true }),
  cameraPad: 0.94,
  path: PATH_LOOKUP,
  entities: [
    toEntity(cacheFrame, 'lookup'),
    toEntity(cacheStage('lookup-stage'), 'lookup'),
    toEntity(cpuDock, 'lookup'),
  ],
}

// ---- scene 5: miss — no tag matches; the line comes home ----------------------------
const missScene: SceneDescription = {
  id: 'miss',
  bbox: L.bboxCacheAndRam(),
  cameraPad: 0.94,
  path: PATH_MISS,
  entities: [
    toEntity(cacheFrame, 'miss'),
    toEntity(ramPanel, 'miss'),
    toEntity(cacheStage('miss-stage'), 'miss'),
    toEntity(cpuDock, 'miss'),
  ],
}

// ---- scene 6: replace — the full set: FIFO, then LRU --------------------------------
const replaceScene: SceneDescription = {
  id: 'replace',
  bbox: L.bboxCacheAndRam(),
  cameraPad: 0.94,
  path: PATH_REPLACE,
  entities: [
    toEntity(cacheFrame, 'replace'),
    toEntity(ramPanel, 'replace'),
    toEntity(cacheStage('replace-stage'), 'replace'),
    toEntity(cpuDock, 'replace'),
  ],
}

// ---- scene 7: replay — the whole lookup, uninterrupted -------------------------------
const replayScene: SceneDescription = {
  id: 'replay',
  bbox: L.bboxCache({ stage: true }),
  cameraPad: 0.94,
  path: PATH_REPLAY,
  entities: [
    toEntity(cacheStage('replay-stage'), 'replay'),
    toEntity(cacheFrame, 'replay'),
    toEntity(cpuDock, 'replay'),
  ],
}

// ---- hit zone (the learner sends the request off) -------------------------------------
const hitZones: HitZone[] = [
  {
    id: 'cpu-box',
    hits: (w: Vec2) =>
      w.x >= CPU_RECT.x &&
      w.x <= CPU_RECT.x + CPU_RECT.w &&
      w.y >= CPU_RECT.y &&
      w.y <= CPU_RECT.y + CPU_RECT.h,
  },
]

// ---- the assembled Chapter -------------------------------------------------------------
export function assembleChapter(m: ChapterMeta): Chapter {
  return {
    meta: m,
    scenes: [entryScene, interiorScene, mappingScene, lookupScene, missScene, replaceScene, replayScene],
    timeline: {
      beats,
      fadeDuration: 450,
    },
    hitZones,
    runtime: {
      // The protagonist holds at each scene's exit anchor during fade-out, so it
      // stays traceable across every seam (VISUAL_LANGUAGE §13). The next
      // scene's first waypoint resumes the same journey.
      seamPosition: (scene: string): Vec2 | null => {
        if (scene === 'entry') return PATH_ENTRY[PATH_ENTRY.length - 1]
        if (scene === 'interior') return PATH_INTERIOR[PATH_INTERIOR.length - 1]
        if (scene === 'mapping') return PATH_MAPPING[PATH_MAPPING.length - 1]
        if (scene === 'lookup') return PATH_LOOKUP[PATH_LOOKUP.length - 1]
        if (scene === 'miss') return PATH_MISS[PATH_MISS.length - 1]
        if (scene === 'replace') return PATH_REPLACE[PATH_REPLACE.length - 1]
        if (scene === 'replay') return PATH_REPLAY[PATH_REPLAY.length - 1]
        return null
      },
    },
    ui: {
      chapterTitle,
      waitingLine,
      startButton,
      sceneTag,
      tipText,
      doneLabel,
    },
    entityRenderers: RENDERERS,
  }
}

// re-exported for tooling / QA scripts
export { DOCK }
