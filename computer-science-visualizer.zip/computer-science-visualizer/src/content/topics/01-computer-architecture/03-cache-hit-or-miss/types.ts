// content/topics/01-computer-architecture/03-cache-hit-or-miss/types.ts
// Chapter-local types. The generic interfaces live in chapter-loader/types.

import type { LocalizedText, Vec2 } from '../../../../chapter-loader/types'

/** Legacy alias so narration/geometry code reads like the earlier chapters. */
export type L = LocalizedText

/** The seven scenes of the lookup journey. */
export type Scene = 'entry' | 'interior' | 'mapping' | 'lookup' | 'miss' | 'replace' | 'replay'

export interface Rect {
  x: number
  y: number
  w: number
  h: number
}

/** A part as the chapter describes it (mirrors the PartSpec of Ch-01/Ch-02). */
export interface PartSpec {
  id: string
  kind?: string
  pos: Vec2
  color: string
  name: string
  gloss: LocalizedText
  labelSize?: number
  extra?: Record<string, unknown>
}
