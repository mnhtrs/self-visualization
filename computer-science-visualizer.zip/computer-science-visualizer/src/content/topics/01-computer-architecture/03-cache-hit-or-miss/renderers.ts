// content/topics/01-computer-architecture/03-cache-hit-or-miss/renderers.ts
//
// Chapter renderer barrel. The painters themselves live in /renderers, split
// by scene family:
//   entry.ts       — Scene 1's remembered ladder (proc-core, cache-rung,
//                    ram-bank, entry-stage: links, question pill, mini-cards)
//   panel.ts       — the magnified single level (proc-dock, cache-frame,
//                    ram-panel)
//   cache-stage.ts — the labelless narrative painter for every interior scene
//                    (rows, sets, address parts, compares, counters, tally,
//                    routing demos, victim flights, ribbons, stamps, replay)
//
// LAYOUT-SYSTEM DRIVEN: every coordinate in those files is a named metric
// (scenes/metrics.ts) or a value derived in scenes/layout.ts from a container
// rect + measured text (Layout Derivation Law). Every renderer is a pure
// function of (PresentationState, entity.extra): all beat-driven content
// derives from s.beatIndex / s.beatElapsed, so scrubbing, pausing and
// stepping backwards stay deterministic (VISUAL_LANGUAGE §15).
//
// SCOPE LOCK (owner spec, forbidden topics): nothing here draws write policy,
// coherence, virtual memory, TLB, branch prediction, prefetching, multi-core
// behaviour, or bit layouts. The chapter shows THE FACT that an address has
// three parts with three purposes — never a bit-width decomposition.

import { drawProcCore, drawCacheRung, drawRamBank, drawEntryStage } from './renderers/entry'
import { drawProcDock, drawCacheFrame, drawRamPanel } from './renderers/panel'
import { drawCacheStage } from './renderers/cache-stage'

export const RENDERERS = {
  'proc-core': drawProcCore,
  'cache-rung': drawCacheRung,
  'ram-bank': drawRamBank,
  'entry-stage': drawEntryStage,
  'proc-dock': drawProcDock,
  'cache-frame': drawCacheFrame,
  'ram-panel': drawRamPanel,
  'cache-stage': drawCacheStage,
}
