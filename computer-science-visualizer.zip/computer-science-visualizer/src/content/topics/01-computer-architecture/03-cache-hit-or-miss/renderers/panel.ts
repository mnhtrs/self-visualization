// renderers/panel.ts — the quiet furniture of the panel scenes: the CPU dock
// west of the panel, the cache panel's own frame (bg, title, orientation
// chip), and the RAM panel east of it (miss / replace scenes). All dynamic
// content lives in cache-stage.ts.

import type { EntityRenderer } from '../../../../../rendering/types'
import type { Lang } from '../../../../../chapter-loader/types'
import { rrPath, hexA } from '../../../../../rendering/primitives/canvas-utils'
import { glow } from '../../../../../rendering/primitives/glow'
import { drawName } from '../../../../../rendering/primitives/text'
import { clamp, easeInOutCubic } from '../../../../../shared/math'

import * as M from '../scenes/metrics'
import * as L from '../scenes/layout'
import * as S from '../scenes/story'
import { beatFrac } from './entry'

// ===========================================================================
// PROC-DOCK — the small CPU west of the panel. It glows again whenever a word
// comes home; it never sees inside the cache.
// ===========================================================================
export const drawProcDock: EntityRenderer = (ctx, s, e, active) => {
  const box = M.DOCK_BOX
  const x = e.pos.x - box.w / 2
  const y = e.pos.y - box.h / 2

  // the CPU brightens when its word is flying / has flown home
  const bi = s.beatIndex
  const lin = beatFrac(s)
  const HOME_BEATS: Record<number, number> = {
    [S.B.theOffset]: 0.6,
    [S.B.serveMiss]: 0.5,
    [S.B.serveReplaced]: 0.5,
    [S.B.fullPass]: 0.85,
    [S.B.theAnswer]: 0,
  }
  const homeFrom = HOME_BEATS[bi]
  const wordHome =
    bi === S.B.theAnswer || (homeFrom !== undefined && lin >= homeFrom)
      ? bi === S.B.theAnswer
        ? 1
        : easeInOutCubic(clamp((lin - homeFrom) / 0.3, 0, 1))
      : 0

  ctx.save()
  ctx.globalAlpha = active || wordHome > 0 ? 1 : 0.72
  if (wordHome > 0) glow(ctx, e.pos, e.color, 110, 0.42 * wordHome + 0.1 * Math.sin(s.t * 0.01))
  else if (active) glow(ctx, e.pos, e.color, 100, 0.24)

  rrPath(ctx, x, y, box.w, box.h, box.r)
  ctx.fillStyle = hexA(e.color, wordHome > 0 ? 0.18 + 0.06 * wordHome : 0.1)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active || wordHome > 0 ? 0.95 : 0.42)
  ctx.lineWidth = 2.5
  ctx.stroke()

  // simple face: two small slots of work
  const cy = e.pos.y
  ctx.fillStyle = hexA(e.color, 0.5 + 0.3 * wordHome)
  rrPath(ctx, x + box.w * 0.2, cy - M.WORD.h / 2, box.w * 0.26, M.WORD.h * 0.62, 6)
  ctx.fill()
  rrPath(ctx, x + box.w * 0.54, cy - M.WORD.h / 2, box.w * 0.26, M.WORD.h * 0.62, 6)
  ctx.fill()
  ctx.restore()

  drawName(ctx, e.pos, e.name, e.color, active || wordHome > 0, box.h / 2 + M.LABEL_GAP, M.F.partName)
}

// ===========================================================================
// CACHE-FRAME — the panel's background, header title and orientation chip
// ===========================================================================
export const drawCacheFrame: EntityRenderer = (ctx, s, e, active) => {
  const bi = s.beatIndex
  const lin = beatFrac(s)
  let appear = 1
  if (bi === S.B.rowsOfCompartments) {
    // the level unfolds as the protagonist arrives inside it
    appear = easeInOutCubic(clamp(lin / 0.3, 0, 1))
  }
  if (appear <= 0.01) return

  const p = L.PANEL
  ctx.save()
  ctx.globalAlpha = appear * (active ? 1 : 0.92)
  if (active) glow(ctx, { x: p.x + p.w / 2, y: p.y + p.h / 2 }, e.color, p.w * 0.62, 0.16)

  rrPath(ctx, p.x, p.y, p.w, p.h, p.r)
  ctx.fillStyle = hexA(e.color, 0.08)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.85 : 0.5)
  ctx.lineWidth = 2.5
  ctx.stroke()

  // header title — the level's name, never a lesson (orientation, §17)
  const tp = L.panelTitlePos()
  ctx.fillStyle = hexA('#e2e8f0', 0.9)
  ctx.font = `800 ${M.F.panelTitle}px ${M.FONT}`
  ctx.textAlign = 'left'
  ctx.textBaseline = 'middle'
  ctx.fillText(e.name, tp.x, tp.y)

  // 'you are here' chip
  const chipText = S.CAP.orientChip[s.lang as Lang]
  ctx.font = `700 ${M.F.sub}px ${M.FONT}`
  const chipR = L.orientChip(ctx.measureText(chipText).width)
  rrPath(ctx, chipR.x, chipR.y, chipR.w, chipR.h, chipR.r)
  ctx.fillStyle = 'rgba(12,16,36,0.9)'
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, 0.6)
  ctx.lineWidth = 1.4
  ctx.stroke()
  ctx.fillStyle = hexA('#e2e8f0', 0.85)
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(chipText, chipR.x + chipR.w / 2, chipR.y + chipR.h / 2)
  ctx.restore()
}

// ===========================================================================
// RAM-PANEL — far memory, drawn only in the scenes whose journey reaches RAM
// ===========================================================================
export const drawRamPanel: EntityRenderer = (ctx, s, e, active) => {
  const bi = s.beatIndex
  const lin = beatFrac(s)
  const r = L.RAM_PANEL_RECT

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.6
  if (active) glow(ctx, e.pos, e.color, 200, 0.3 + 0.08 * Math.sin(s.t * 0.004))

  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fillStyle = hexA(e.color, active ? 0.14 : 0.08)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.95 : 0.45)
  ctx.lineWidth = 2
  ctx.stroke()

  ctx.fillStyle = hexA('#e2e8f0', 0.9)
  ctx.font = `800 ${M.F.panelTitle}px ${M.FONT}`
  ctx.textAlign = 'left'
  ctx.textBaseline = 'middle'
  ctx.fillText('RAM', r.x + M.RAM_PANEL.padX, r.y + M.RAM_PANEL.titleH / 2)

  // dense silent cells — the crowd of everything else that lives in RAM
  for (let row = 0; row < M.RAM_CELL.rows; row++) {
    for (let col = 0; col < M.RAM_CELL.cols; col++) {
      const c = L.ramCellRect(col, row)
      ctx.fillStyle = hexA(e.color, active ? 0.38 : 0.24)
      ctx.fillRect(c.x, c.y, c.w, c.h)
    }
  }

  // the one block the miss request targets — revealed exactly when needed
  const exposeFrom = bi === S.B.fillFromRam ? 0.02 : bi === S.B.fifo ? 0.58 : bi === S.B.lru ? 0.6 : -1
  const expose = exposeFrom >= 0 ? easeInOutCubic(clamp((lin - exposeFrom) / 0.12, 0, 1)) : 0
  if (expose > 0.01) {
    const b = L.ramBlockRect()
    rrPath(ctx, b.x, b.y, b.w, b.h, b.r)
    ctx.fillStyle = hexA('#facc15', 0.1 + 0.08 * expose)
    ctx.fill()
    ctx.strokeStyle = hexA('#facc15', 0.85 * expose)
    ctx.lineWidth = 2
    ctx.stroke()
    // mark its tag + word cells (same recipe as a cache line's interior)
    ctx.fillStyle = hexA('#facc15', 0.5 * expose)
    ctx.font = `700 ${M.F.sub}px ${M.FONT}`
    ctx.textAlign = 'left'
    ctx.textBaseline = 'middle'
    ctx.fillText('the matching block', b.x + M.BREATH, b.y - M.BREATH - M.F.sub / 2)
  }
  ctx.restore()
}
