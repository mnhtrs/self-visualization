// renderers/cache-stage.ts — the labelless painter of every panel scene: set
// braces, cache lines with their tags and words, travelling request cards,
// compare ticks, fan-out beams, the counter, the tally board, verdict pills,
// term pills, the caravan, and the replay checkpoints.
//
// Everything here is a pure function of (beatIndex, beatFraction) read from
// scenes/story.ts — deterministic by construction (VISUAL_LANGUAGE §15).
// Process over diagram: nothing merely appears; things travel, compare, open,
// regroup and settle (owner spec, VISUAL REQUIREMENTS).

import type { EntityRenderer } from '../../../../../rendering/types'
import type { Vec2, Lang } from '../../../../../chapter-loader/types'
import { rrPath, hexA } from '../../../../../rendering/primitives/canvas-utils'
import { TAU, clamp, easeInOutCubic, lerp } from '../../../../../shared/math'

import * as M from '../scenes/metrics'
import * as L from '../scenes/layout'
import * as S from '../scenes/story'
import { COL, beatFrac, drawPill, drawMiniCard } from './entry'

// ---------------------------------------------------------------------------
// small text helpers
// ---------------------------------------------------------------------------
const T = (txt: { en: string; vi: string }, lang: string) =>
  (lang as Lang) === 'vi' ? txt.vi : txt.en

function label(
  ctx: CanvasRenderingContext2D,
  text: string,
  at: Vec2,
  opts: { size?: number; color?: string; align?: CanvasTextAlign; alpha?: number; weight?: number } = {},
) {
  if ((opts.alpha ?? 1) <= 0.01) return
  ctx.save()
  ctx.globalAlpha = opts.alpha ?? 1
  ctx.font = `${opts.weight ?? 700} ${opts.size ?? M.F.sub}px ${M.FONT}`
  ctx.textAlign = opts.align ?? 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = opts.color ?? COL.dim
  ctx.fillText(text, at.x, at.y)
  ctx.restore()
}

/** Two-line terminology pill: the locked English term over a plain-language sub. */
/** Wrap the plain-language sub into at most two lines that each fit inside
 *  TERM.maxW's inner width — the pill's drawn width never exceeds TERM.maxW,
 *  so every dock and bbox computed from maxW stays valid in any font. */
function wrapSub(ctx: CanvasRenderingContext2D, sub: string, maxTextW: number): string[] {
  ctx.font = `600 ${M.F.sub}px ${M.FONT}`
  if (ctx.measureText(sub).width <= maxTextW) return [sub]
  const words = sub.split(' ')
  const lines: string[] = []
  let cur = ''
  for (const w of words) {
    const next = cur ? `${cur} ${w}` : w
    if (ctx.measureText(next).width <= maxTextW || !cur) cur = next
    else {
      lines.push(cur)
      cur = w
    }
  }
  if (cur) lines.push(cur)
  if (lines.length <= 2) return lines
  // rebalance into two lines (still within maxW: a 3+ split means the sub is
  // long; two even lines stay narrower than the greedy first cut)
  const half = Math.ceil(words.length / 2)
  return [words.slice(0, half).join(' '), words.slice(half).join(' ')]
}

function termPill(
  ctx: CanvasRenderingContext2D,
  dock: L.Dock,
  term: string,
  sub: string,
  color: string,
  alpha: number,
) {
  if (alpha <= 0.01) return
  const maxTextW = M.TERM.maxW - 2 * M.TERM.padX
  const subLines = wrapSub(ctx, sub, maxTextW)
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.font = `800 ${M.F.termPill}px ${M.FONT}`
  const w1 = ctx.measureText(term).width
  ctx.font = `600 ${M.F.sub}px ${M.FONT}`
  const wSub = Math.max(...subLines.map((l) => ctx.measureText(l).width))
  const w = Math.min(M.TERM.maxW, Math.max(w1, wSub) + 2 * M.TERM.padX)
  const subStep = M.F.sub + 6
  const h = M.TERM.h + subLines.length * subStep
  const y0 =
    dock.valign === 'top' ? dock.pos.y : dock.valign === 'bottom' ? dock.pos.y - h : dock.pos.y - h / 2
  rrPath(ctx, dock.pos.x - w / 2, y0, w, h, M.TERM.r)
  ctx.fillStyle = 'rgba(12,16,36,0.95)'
  ctx.fill()
  ctx.strokeStyle = hexA(color, 0.9)
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = color
  ctx.font = `800 ${M.F.termPill}px ${M.FONT}`
  ctx.fillText(term, dock.pos.x, y0 + M.TERM.h / 2)
  ctx.fillStyle = hexA('#e2e8f0', 0.85)
  ctx.font = `600 ${M.F.sub}px ${M.FONT}`
  subLines.forEach((line, i) => {
    ctx.fillText(line, dock.pos.x, y0 + M.TERM.h + subStep * (i + 0.5))
  })
  ctx.restore()
}

function questionPill(
  ctx: CanvasRenderingContext2D,
  center: Vec2,
  text: string,
  alpha: number,
) {
  drawPill(
    ctx, center, text, `800 ${M.F.question}px ${M.FONT}`, M.ASK.padX, M.ASK.h,
    hexA('#facc15', 0.9), 'rgba(12,16,36,0.95)', '#facc15', alpha,
  )
}

// ---------------------------------------------------------------------------
// chips and cells
// ---------------------------------------------------------------------------
/** A stored tag chip: the identity a cache line answers to. */
function drawStoredTag(
  ctx: CanvasRenderingContext2D,
  center: Vec2,
  tag: string,
  cardId: string | null,
  alpha: number,
  bright = 0,
) {
  if (alpha <= 0.01) return
  const card = cardId ? S.cardById(cardId) : null
  const col = card ? card.body : '#94a3b8'
  ctx.save()
  ctx.globalAlpha = alpha
  rrPath(ctx, center.x - M.TAG.w / 2, center.y - M.TAG.h / 2, M.TAG.w, M.TAG.h, M.TAG.r)
  ctx.fillStyle = hexA(col, 0.16 + 0.14 * bright)
  ctx.fill()
  ctx.strokeStyle = hexA(col, 0.55 + 0.45 * bright)
  ctx.lineWidth = 1.6 + bright
  ctx.stroke()
  ctx.fillStyle = hexA(card ? card.body : '#cbd5e1', 0.95)
  ctx.font = `800 ${M.F.chip}px ${M.FONT}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(tag, center.x, center.y)
  if (card && card.homeSet !== null) {
    ctx.fillStyle = hexA(M.SET_COLORS[card.homeSet], 0.95)
    const bw = M.TAG.w - 14
    rrPath(ctx, center.x - bw / 2, center.y + M.TAG.h / 2 - 9, bw, 4, 2)
    ctx.fill()
  }
  ctx.restore()
}

/** One word cell of a cache line. */
function drawWordCell(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  alpha: number,
  open: number,
  picked: number,
) {
  if (alpha <= 0.01) return
  ctx.save()
  ctx.globalAlpha = alpha
  rrPath(ctx, x, y, M.WORD.w, M.WORD.h, M.WORD.r)
  ctx.fillStyle = hexA('#e2e8f0', 0.05 + 0.1 * open + 0.12 * picked)
  ctx.fill()
  ctx.strokeStyle = picked > 0 ? hexA(COL.exec, 0.95) : hexA('#e2e8f0', 0.22 + 0.5 * open)
  ctx.lineWidth = 1.2 + open * 0.8 + picked * 0.6
  ctx.stroke()
  // the word's payload mark — a small square of data
  ctx.fillStyle = picked > 0 ? hexA(COL.exec, 0.9) : hexA('#cbd5e1', 0.28 + 0.4 * open)
  const g = 12 + 2 * open
  ctx.fillRect(x + M.WORD.w / 2 - g / 2, y + M.WORD.h / 2 - g / 2, g, g)
  ctx.restore()
}

/** The detached word glyph that flies home to the CPU. */
function drawFlyingWord(ctx: CanvasRenderingContext2D, center: Vec2, alpha: number, scale = 1) {
  if (alpha <= 0.01) return
  ctx.save()
  ctx.globalAlpha = alpha
  const w = 34 * scale
  rrPath(ctx, center.x - w / 2, center.y - w / 2, w, w, 8 * scale)
  ctx.fillStyle = hexA(COL.exec, 0.28)
  ctx.fill()
  ctx.strokeStyle = hexA(COL.exec, 0.95)
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.fillStyle = hexA('#eafff3', 0.95)
  const g = 12 * scale
  ctx.fillRect(center.x - g / 2, center.y - g / 2, g, g)
  ctx.restore()
}

// ---------------------------------------------------------------------------
// an address chip (Index / Tag / Word Offset) — one third of a Memory Address
// ---------------------------------------------------------------------------
type ChipKind = 'index' | 'tag' | 'offset'
function drawChip(
  ctx: CanvasRenderingContext2D,
  center: Vec2,
  kind: ChipKind,
  cardId: string,
  alpha: number,
  nameShown: boolean,
  scale = 1,
) {
  if (alpha <= 0.01) return
  const card = S.cardById(cardId)
  const col = kind === 'index' ? M.SET_COLORS[card.homeSet ?? 0] : kind === 'tag' ? card.body : '#eab308'
  ctx.save()
  ctx.globalAlpha = alpha
  // a chip hovering INSIDE the panel (at its set) draws slightly smaller so
  // both stored tags beside it stay fully readable (probe grammar, ch-review)
  ctx.translate(center.x, center.y)
  ctx.scale(scale, scale)
  ctx.translate(-center.x, -center.y)
  const w = M.CHIP.w
  const h = M.CHIP.h
  rrPath(ctx, center.x - w / 2, center.y - h / 2, w, h, M.CHIP.r)
  ctx.fillStyle = 'rgba(12,16,36,0.94)'
  ctx.fill()
  ctx.strokeStyle = hexA(col, 0.9)
  ctx.lineWidth = 1.8
  ctx.stroke()
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  if (kind === 'index') {
    ctx.fillStyle = hexA(col, 0.95)
    const bw = w - 18
    rrPath(ctx, center.x - bw / 2, center.y - 8, bw, 10, 5)
    ctx.fill()
    if (nameShown) {
      ctx.fillStyle = '#e2e8f0'
      ctx.font = `800 ${M.F.sub}px ${M.FONT}`
      ctx.fillText('Index', center.x, center.y + h / 4 + 2)
    }
  } else if (kind === 'tag') {
    ctx.fillStyle = col
    ctx.font = `800 ${M.F.chip}px ${M.FONT}`
    ctx.fillText(card.id, center.x, center.y - (nameShown ? 4 : 0))
    if (nameShown) {
      ctx.fillStyle = '#e2e8f0'
      ctx.font = `800 ${M.F.sub}px ${M.FONT}`
      ctx.fillText('Tag', center.x, center.y + h / 4 + 3)
    }
  } else {
    // the offset: four dots — which one of the line's words, shown positionally
    for (let k = 0; k < M.WORDS_PER_LINE; k++) {
      const dx = (k - (M.WORDS_PER_LINE - 1) / 2) * 14
      ctx.fillStyle = k === OFFSET_WORD_IDX ? '#facc15' : hexA('#e2e8f0', 0.4)
      ctx.beginPath()
      ctx.arc(center.x + dx, center.y - (nameShown ? 5 : 0), 4, 0, TAU)
      ctx.fill()
    }
    if (nameShown) {
      ctx.fillStyle = '#e2e8f0'
      ctx.font = `800 ${M.F.sub}px ${M.FONT}`
      ctx.fillText('Offset', center.x, center.y + h / 4 + 3)
    }
  }
  ctx.restore()
}

/** which word the chapter's hit/lookup stories all request (the narration
 *  never numbers it — positional dots carry the idea). */
const OFFSET_WORD_IDX = 2

// ===========================================================================
// THE STAGE RENDERER
// ===========================================================================
export const drawCacheStage: EntityRenderer = (ctx, s, _e, _active) => {
  if (s.phase === 'waiting') return
  const bi = s.beatIndex
  const lin = beatFrac(s)
  const lang = s.lang as Lang
  const occ = S.occupancy(bi, lin)
  const scene = s.scene

  ctx.save()

  drawBraces(ctx, bi, lin)
  drawRows(ctx, bi, lin, occ, lang)
  drawOtherActors(ctx, s, bi, lin, lang, scene)

  ctx.restore()
}

// ---------------------------------------------------------------------------
// set braces with morph crossfades and set emphasis
// ---------------------------------------------------------------------------
function bracesFor(config: 'pairs' | 'singles' | 'giant'): L.Brace[] {
  if (config === 'pairs') return L.PAIR_BRACES
  if (config === 'singles') return L.SINGLE_BRACES
  return [L.GIANT_BRACE]
}

function drawBraces(ctx: CanvasRenderingContext2D, bi: number, lin: number) {
  const fs = S.frameStateOf(bi)
  let fromA = 1
  let toA = 1
  if (fs.morph) {
    const m = clamp((lin - fs.morph[0]) / (fs.morph[1] - fs.morph[0]), 0, 1)
    fromA = 1 - m
    toA = m
  }
  // the giant experiment returns to pairs inside the same beat (tail morph)
  if (bi === S.B.oneGiantSet) {
    const m = clamp((lin - S.GIANT_RETURN[0]) / (S.GIANT_RETURN[1] - S.GIANT_RETURN[0]), 0, 1)
    if (lin >= S.GIANT_RETURN[0]) {
      paintBraceSet(ctx, bracesFor('pairs'), easeInOutCubic(m), bi, lin)
      paintBraceSet(ctx, bracesFor('giant'), 1 - easeInOutCubic(m), bi, lin)
      return
    }
  }
  if (fs.from !== 'none' && fromA > 0.01) paintBraceSet(ctx, bracesFor(fs.from), easeInOutCubic(fromA), bi, lin)
  if (toA > 0.01) paintBraceSet(ctx, bracesFor(fs.to === 'none' ? 'pairs' : fs.to), easeInOutCubic(toA), bi, lin)
}

function paintBraceSet(
  ctx: CanvasRenderingContext2D,
  braces: L.Brace[],
  alpha: number,
  bi: number,
  lin: number,
) {
  if (alpha <= 0.01) return
  const activeSet = S.ACTIVE_SET[bi] ?? null
  const dimWindow = bi >= S.B.theIndex ? clamp((lin - S.DIM_OTHERS_FROM) / 0.2, 0, 1) : 0
  for (const b of braces) {
    const isActive = b.config === 'pairs' && activeSet !== null && b.setId === activeSet
    const dim = activeSet !== null && !isActive ? dimWindow : 0
    const col = b.config === 'pairs' ? M.SET_COLORS[b.setId] : '#7dd3fc'
    let a = alpha * (0.55 + 0.45 * (isActive ? 1 : 0)) * (1 - 0.6 * dim)
    if (b.config !== 'pairs') a = alpha * 0.75
    ctx.save()
    ctx.globalAlpha = a
    if (isActive) {
      ctx.shadowColor = col
      ctx.shadowBlur = 18
    }
    rrPath(ctx, b.x, b.y, b.w, b.h, b.r)
    ctx.strokeStyle = hexA(col, isActive ? 0.95 : 0.5)
    ctx.lineWidth = isActive ? 3 : 1.6
    ctx.stroke()
    ctx.restore()
  }
}

// ---------------------------------------------------------------------------
// the eight cache lines: frames, stored tags, word cells, compare ticks
// ---------------------------------------------------------------------------
function drawRows(
  ctx: CanvasRenderingContext2D,
  bi: number,
  lin: number,
  occ: S.Occ,
  lang: Lang,
) {
  const activeSet = S.ACTIVE_SET[bi] ?? null
  const openSpec = S.OPEN_ROW[bi] ?? null
  const compares = S.COMPARES[bi] ?? []

  for (let i = 0; i < M.ROWS; i++) {
    const r = L.rowRect(i)
    const line = occ[i] ?? null
    // row frame alpha: rows fade in during the interior reveal beat
    let appear = 1
    if (bi === S.B.rowsOfCompartments) {
      appear = easeInOutCubic(clamp((lin - 0.12 - i * 0.05) / 0.3, 0, 1))
    }
    if (appear <= 0.01) continue

    const inActiveSet = activeSet !== null && Math.floor(i / 2) === activeSet
    const open = openSpec && openSpec.row === i ? easeInOutCubic(clamp((lin - openSpec.from) / 0.22, 0, 1)) : 0

    // the line's own frame
    ctx.save()
    ctx.globalAlpha = appear
    rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
    ctx.fillStyle = hexA('#22d3ee', 0.05 + 0.05 * open)
    ctx.fill()
    ctx.strokeStyle = hexA('#22d3ee', line ? 0.5 : 0.24 + 0.2 * (inActiveSet ? 1 : 0))
    ctx.lineWidth = 1.4
    ctx.stroke()
    ctx.restore()

    // its tag chip — every line EXPOSES its tag
    if (line && line.tag) {
      const compare = compares.find((c) => c.row === i && Math.abs(lin - c.at) < 0.1)
      const bright = inActiveSet || (compare ? 1 : 0) ? 1 : 0
      drawStoredTag(ctx, L.tagC(i), line.tag, line.card, appear * (line.dim ? 0.55 : 1), bright ? 1 : 0)
    } else {
      // an empty tag slot: structure, not state (§4)
      const c = L.tagC(i)
      ctx.save()
      ctx.globalAlpha = appear * 0.5
      rrPath(ctx, c.x - M.TAG.w / 2, c.y - M.TAG.h / 2, M.TAG.w, M.TAG.h, M.TAG.r)
      ctx.strokeStyle = hexA('#94a3b8', 0.35)
      ctx.setLineDash([4, 5])
      ctx.lineWidth = 1.2
      ctx.stroke()
      ctx.restore()
    }

    // its words — closed rows show quiet cells; a matched line OPENS
    const hasContent = !!line || bi <= S.B.tooExpensive
    for (let k = 0; k < M.WORDS_PER_LINE; k++) {
      const wc = L.wordCellRect(i, k)
      const picked = open > 0 && k === OFFSET_WORD_IDX && openWordPickedAt(bi, lin) ? 1 : 0
      drawWordCell(ctx, wc.x, wc.y, appear * (hasContent ? 1 : 0.4), open, picked)
    }
  }

  paintProbes(ctx, bi, lin)
  paintCompares(ctx, bi, lin, occ, lang)
}

/** Does the open row's chosen word already read as picked in this beat? */
function openWordPickedAt(bi: number, lin: number): boolean {
  if (bi === S.B.theOffset) return lin >= 0.1 && lin <= 0.4
  if (bi === S.B.serveMiss) return lin >= 0.06 && lin <= 0.34
  if (bi === S.B.serveReplaced) return lin >= 0.06 && lin <= 0.34
  if (bi === S.B.fullPass) return lin >= 0.62 && lin <= 0.8
  return false
}

// ---------------------------------------------------------------------------
// the probe grammar of lookup beats (theTag / noMatch / setFull): from the
// incoming Tag hovering at its set, a beam runs to the candidate line; the
// answer marker fires when it lands (COMPARES.at is the same clock), the
// line's answer speaks pinned to its own chip, and the residue lingers so
// EVERY side of the comparison stays on stage at once (ch-review R1/R2).
// ---------------------------------------------------------------------------
/** The request card whose Tag probes in a given lookup beat. */
const PROBE_CARD: Record<number, S.CardId> = {
  [S.B.theTag]: 'E1',
  [S.B.noMatch]: 'F3',
  [S.B.setFull]: 'G2',
}
/** How long a fail marker lingers in the probe beats (both answers visible at
 *  the verdict); stream scenes keep the quick 0.09 fade. */
const LOOK_FAIL_HOLD: Record<number, number> = {
  [S.B.theTag]: 0.3,
  [S.B.noMatch]: 0.26,
  [S.B.setFull]: 0.3,
}

function paintProbes(ctx: CanvasRenderingContext2D, bi: number, lin: number) {
  const cardId = PROBE_CARD[bi]
  if (!cardId) return
  const set = S.ACTIVE_SET[bi]
  if (set == null) return
  const from = L.setC(set)
  const col = S.cardById(cardId).body
  for (const c of S.COMPARES[bi] ?? []) {
    // flight leaves 0.08 before the event lands (probe grammar: flight, then
    // the marker on arrival); the travelled beam dissolves right after
    const f = easeInOutCubic(clamp((lin - (c.at - 0.08)) / 0.08, 0, 1))
    const tail = lin < c.at ? 1 : clamp(1 - (lin - c.at) / 0.05, 0, 1)
    if (f <= 0 || tail <= 0.01) continue
    const to = L.tagC(c.row)
    const head = { x: lerp(from.x, to.x, f), y: lerp(from.y, to.y, f) }
    ctx.save()
    ctx.globalAlpha = 0.55 * tail
    ctx.strokeStyle = hexA(col, 0.9)
    ctx.lineWidth = 2
    ctx.lineCap = 'round'
    ctx.beginPath()
    ctx.moveTo(from.x, from.y)
    ctx.lineTo(head.x, head.y)
    ctx.stroke()
    if (f < 1) {
      ctx.globalAlpha = 0.95 * tail
      ctx.shadowColor = col
      ctx.shadowBlur = 10
      ctx.fillStyle = hexA(col, 0.95)
      ctx.beginPath()
      ctx.arc(head.x, head.y, 5, 0, TAU)
      ctx.fill()
    }
    ctx.restore()
  }
}

/** one compare mark on a stored tag: a ✓ ring where it matched, a ✕ where not. */
function paintCompareMark(
  ctx: CanvasRenderingContext2D,
  center: Vec2,
  result: 'fail' | 'match',
  grow: number,
  hold: number,
) {
  const col = result === 'match' ? COL.exec : COL.wait
  ctx.save()
  ctx.globalAlpha = hold * grow
  ctx.strokeStyle = hexA(col, 0.95)
  ctx.lineWidth = 2.4
  ctx.beginPath()
  const rr = M.TAG.h * 0.72 * grow
  ctx.arc(center.x, center.y, rr, 0, TAU)
  ctx.stroke()
  ctx.fillStyle = hexA(col, 0.95)
  ctx.font = `900 ${18 * grow}px ${M.FONT}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(result === 'match' ? '✓' : '✕', center.x, center.y - 1)
  ctx.restore()
}

/** A line's own answer ('me!' / 'not me'), pinned to ITS chip by a short stem
 *  so the binding is structural, not guessed from nearness: even (upper) rows
 *  answer ABOVE their chip, odd (lower) rows BELOW it — away from the set's
 *  other line, never near a neighbouring row's identity. */
function paintAnswer(
  ctx: CanvasRenderingContext2D,
  chipC: Vec2,
  row: number,
  text: string,
  color: string,
  alpha: number,
) {
  if (alpha <= 0.01) return
  const up = row % 2 === 0
  const dy = M.TAG.h / 2 + M.BREATH + M.F.sub / 2
  const y = chipC.y + (up ? -dy : dy)
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.strokeStyle = hexA(color, 0.9)
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.moveTo(chipC.x, chipC.y + (up ? -M.TAG.h / 2 : M.TAG.h / 2))
  ctx.lineTo(chipC.x, y + (up ? M.F.sub / 2 + 3 : -M.F.sub / 2 - 3))
  ctx.stroke()
  ctx.restore()
  label(ctx, text, { x: chipC.x, y }, { color, alpha, weight: 800 })
}

/** compare ticks: a ✕ where a tag failed, a ✓ ring where one matched. */
function paintCompares(
  ctx: CanvasRenderingContext2D,
  bi: number,
  lin: number,
  occ: S.Occ,
  lang: Lang,
) {
  const compares = S.COMPARES[bi] ?? []
  const failHold = LOOK_FAIL_HOLD[bi] ?? 0.09
  const speaks = LOOK_FAIL_HOLD[bi] !== undefined
  for (const c of compares) {
    const age = lin - c.at
    if (age < 0) continue
    const center = L.tagC(c.row)
    if (c.empty) {
      // knocking on a FREE line: the dashed slot brightens — nobody is there
      // to compare. A miss reads as "no stored tag answered", never ✕ on air.
      const pulse =
        easeInOutCubic(clamp(age / 0.05, 0, 1)) * clamp(1 - (age - 0.1) / 0.08, 0, 1)
      if (pulse > 0.01) {
        ctx.save()
        ctx.globalAlpha = 0.9 * pulse
        rrPath(ctx, center.x - M.TAG.w / 2, center.y - M.TAG.h / 2, M.TAG.w, M.TAG.h, M.TAG.r)
        ctx.strokeStyle = hexA('#94a3b8', 0.9)
        ctx.setLineDash([4, 5])
        ctx.lineWidth = 2.4
        ctx.stroke()
        ctx.restore()
      }
      continue
    }
    const hold = c.result === 'match' ? 1 : clamp(1 - (age - failHold) / 0.06, 0, 1)
    if (hold <= 0.01) continue
    paintCompareMark(ctx, center, c.result, easeInOutCubic(clamp(age / 0.04, 0, 1)), hold)
    if (speaks) {
      const stored = occ[c.row]
      paintAnswer(
        ctx,
        center,
        c.row,
        c.result === 'match' ? T(S.CAP.me, lang) : T(S.CAP.notMe, lang),
        c.result === 'match' ? COL.exec : stored?.card ? S.cardById(stored.card).body : '#94a3b8',
        hold,
      )
    } else if (c.result === 'match') {
      paintAnswer(ctx, center, c.row, T(S.CAP.me, lang), COL.exec, hold)
    }
  }
}

// ---------------------------------------------------------------------------
// everything else that moves: actors of the current beat
// ---------------------------------------------------------------------------
function drawOtherActors(
  ctx: CanvasRenderingContext2D,
  s: Parameters<EntityRenderer>[1],
  bi: number,
  lin: number,
  lang: Lang,
  scene: string,
) {
  const spark = s.sparkPos

  // ---- the request card riding the protagonist -------------------------------
  const rider = riderOf(bi, lin)
  if (rider && s.sparkScale > 0.05 && bi < S.B.theAddress) {
    drawMiniCard(ctx, spark, rider.card, rider.alpha, rider.dim ? { scale: 0.8 } : {})
  }

  // ---- scan instrument: the comparison counter --------------------------------
  // It yields its corner to the "where should it look first?" pill the moment
  // that question rises (b5): one idea on the north band at a time (§2.2).
  if (scene === 'interior' && bi >= S.B.findA) {
    const w = S.COUNTER_EXIT[S.B.tooExpensive]
    const out = bi === S.B.tooExpensive ? easeInOutCubic(clamp((lin - w[0]) / (w[1] - w[0]), 0, 1)) : 0
    if (out < 0.99) {
      const n = S.scanCounter(bi, lin)
      const txt = `${n} ${T(n === 1 ? S.CAP.counterOne : S.CAP.counter, lang)}`
      ctx.font = `800 ${M.F.counter}px ${M.FONT}`
      const cr = counterRectFor(ctx, txt)
      const pulse = bi === S.B.tooExpensive ? (0.35 + 0.25 * Math.sin(s.t * 0.008)) * (1 - out) : 0
      ctx.save()
      ctx.globalAlpha = 1 - out
      rrPath(ctx, cr.x, cr.y, cr.w, cr.h, cr.r)
      ctx.fillStyle = 'rgba(12,16,36,0.92)'
      ctx.fill()
      ctx.strokeStyle = hexA(pulse > 0 ? '#fbbf24' : '#e2e8f0', 0.55 + pulse)
      ctx.lineWidth = 2
      ctx.stroke()
      label(ctx, txt, { x: cr.x + cr.w / 2, y: cr.y + cr.h / 2 }, { size: M.F.counter, color: '#e2e8f0' })
      ctx.restore()
    }
  }
  // giant experiment: the cost of comparing everywhere, counted live. It bows
  // out as the arrangement earns its name ('Fully Associative', north dock).
  if (bi === S.B.oneGiantSet && lin >= 0.56) {
    const w = S.COUNTER_EXIT[S.B.oneGiantSet]
    const out = easeInOutCubic(clamp((lin - w[0]) / (w[1] - w[0]), 0, 1))
    if (out < 0.99) {
      const n = S.countCompares(bi, lin)
      const txt = `${n} ${T(n === 1 ? S.CAP.counterOne : S.CAP.counter, lang)}`
      ctx.font = `800 ${M.F.counter}px ${M.FONT}`
      const cr = counterRectFor(ctx, txt)
      ctx.save()
      ctx.globalAlpha = 1 - out
      rrPath(ctx, cr.x, cr.y, cr.w, cr.h, cr.r)
      ctx.fillStyle = 'rgba(12,16,36,0.92)'
      ctx.fill()
      ctx.strokeStyle = hexA('#fbbf24', 0.8)
      ctx.lineWidth = 2
      ctx.stroke()
      label(ctx, txt, { x: cr.x + cr.w / 2, y: cr.y + cr.h / 2 }, { size: M.F.counter, color: '#facc15' })
      ctx.restore()
    }
  }

  // ---- mapping: the tally board (empty from scene entry — §2.5 evidence board) --
  if (scene === 'mapping') drawTally(ctx, bi, lin, lang)

  // ---- mapping b6: two same-stripe demonstrations (behaviour BEFORE 'Set') ----
  if (bi === S.B.intoGroups) paintRoutingDemos(ctx, lin)

  // ---- evictions: victims drift WEST, mechanically, never named ----------------
  paintVictimFlights(ctx, bi, lin, lang)

  // ---- lookup scenes: the address, its chips, the caravan, word flights --------
  if (bi >= S.B.theAddress && bi <= S.B.theOffset) paintLookupHit(ctx, s, bi, lin, lang)
  if (bi >= S.B.noMatch && bi <= S.B.serveMiss) paintLookupMiss(ctx, s, bi, lin, lang)
  if (bi >= S.B.setFull && bi <= S.B.serveReplaced) paintLookupReplace(ctx, s, bi, lin, lang)
  if (bi >= S.B.fullPass) paintReplay(ctx, s, bi, lin, lang)

  // ---- question pills (problem BEFORE solution) --------------------------------
  paintQuestions(ctx, bi, lin, lang)

  // ---- verdict + term pills -----------------------------------------------------
  paintVerdicts(ctx, bi, lin, lang)
  paintTerms(ctx, bi, lin, lang)
}

// ---------------------------------------------------------------------------
function counterRectFor(ctx: CanvasRenderingContext2D, txt: string) {
  return L.counterRect(ctx.measureText(txt).width)
}

/** Which card rides the spark in a given beat/fraction (auxiliaries dimmed). */
function riderOf(bi: number, lin: number): { card: string; alpha: number; dim?: boolean } | null {
  if (bi === S.B.findA) return { card: 'sa', alpha: lin <= 0.94 ? 1 : clamp(1 - (lin - 0.94) / 0.04, 0, 1) }
  if (bi === S.B.findB) return { card: 'sb', alpha: lin <= 0.94 ? 1 : clamp(1 - (lin - 0.94) / 0.04, 0, 1) }
  if (bi === S.B.intoGroups) return lin >= 0.3 && lin <= 0.64 ? { card: 'A2', alpha: 0.9 } : null
  const stream =
    bi === S.B.oneLineStream ? S.STREAM_DIRECT :
    bi === S.B.twoLineStream ? S.STREAM_TWO_WAY :
    bi === S.B.oneGiantSet ? [...S.STREAM_GIANT_FIRST, ...S.STREAM_GIANT_SECOND] : null
  if (stream) {
    let cur: S.StreamStep | null = null
    for (const step of stream) if (lin >= step.at) cur = step
    if (!cur) cur = stream[0]
    return { card: cur.card, alpha: cur.dim ? 0.6 : 1, dim: cur.dim }
  }
  return null
}

/** b6 routing demo: two same-stripe cards both land in set 2 (no narration yet
 *  — the learner WATCHES it). First card rides the spark; the second is a dim
 *  auxiliary echo (VISUAL_LANGUAGE §18). */
function paintRoutingDemos(ctx: CanvasRenderingContext2D, lin: number) {
  const out = clamp(1 - (lin - 0.88) / 0.09, 0, 1)
  // FIRST demo: A2 rides the protagonist in (riderOf, [0.30,0.64]), then its
  // ghost keeps standing in the group it chose — set-stripe marking visible —
  // so the second arrival is judged against a VISIBLE first one.
  const t1 = easeInOutCubic(clamp((lin - 0.62) / 0.08, 0, 1)) * out
  if (t1 > 0.01) drawStoredTag(ctx, L.tagC(4), 'A2', 'A2', 0.6 * t1)
  // SECOND demo: the same-marked B2 echoes the exact same route while A2's
  // ghost still stands there — same marking, same group, seen at once.
  const f = easeInOutCubic(clamp((lin - 0.52) / 0.18, 0, 1))
  if (f > 0 && f < 1) {
    const pos = { x: lerp(M.DOCK_POS.x, L.setC(2).x, f), y: lerp(M.DOCK_POS.y, L.setC(2).y, f) }
    drawMiniCard(ctx, pos, 'B2', 0.7, { scale: 0.85 })
  }
  const t2 = easeInOutCubic(clamp((lin - 0.7) / 0.08, 0, 1)) * out
  if (t2 > 0.01) drawStoredTag(ctx, L.tagC(5), 'B2', 'B2', 0.6 * t2)
  // …and the OTHER groups sink behind a veil: from now on a request only ever
  // asks its own group — the searching space visibly shrinks to one set.
  const veil = easeInOutCubic(clamp((lin - 0.7) / 0.14, 0, 1)) * clamp(1 - (lin - 0.88) / 0.06, 0, 1)
  if (veil > 0.01) {
    ctx.save()
    ctx.fillStyle = `rgba(7,10,28,${0.45 * veil})`
    for (const b of [L.PAIR_BRACES[0], L.PAIR_BRACES[1], L.PAIR_BRACES[3]]) {
      rrPath(ctx, b.x, b.y, b.w, b.h, b.r)
      ctx.fill()
    }
    ctx.restore()
  }
}

/** Displaced occupants drift WEST out of the panel and fade: the observable
 *  FACT of leaving, with no rule implied by the direction (ch-02 precedent). */
function paintVictimFlights(ctx: CanvasRenderingContext2D, bi: number, lin: number, lang: Lang) {
  const events = S.OCC_EVENTS[bi] ?? []
  for (let ei = 0; ei < events.length; ei++) {
    const ev = events[ei]
    if (ev.card !== null) continue
    // Giant experiment's morph-back tail: these chips were never evicted by a
    // rule — the experiment simply ends — so they are NOT victims. They
    // dissolve in place (no west drift, no victim label) and fully clear
    // before the home arrangement re-seats, so no tag slot ever carries two
    // cards at once (post-freeze residual fix, owner-directed).
    if (bi === S.B.oneGiantSet && ev.at >= S.GIANT_RETURN[0]) {
      const fd = clamp((lin - ev.at) / 0.04, 0, 1)
      if (fd <= 0 || fd >= 1) continue
      const beforeD = S.occupancy(bi, ev.at - 0.001)[ev.row]
      if (!beforeD || !beforeD.tag) continue
      drawStoredTag(ctx, L.tagC(ev.row), beforeD.tag, beforeD.card, 1 - easeInOutCubic(fd))
      continue
    }
    const f = clamp((lin - ev.at) / 0.14, 0, 1)
    if (f <= 0 || f >= 1) continue
    // who used to live there? The occupancy JUST BEFORE the eviction happened.
    const before = S.occupancy(bi, ev.at - 0.001)[ev.row]
    if (!before || !before.tag) continue
    const home = L.tagC(ev.row)
    const pos = { x: home.x - M.VICTIM_DX * easeInOutCubic(f), y: home.y }
    drawStoredTag(ctx, pos, before.tag, before.card, 1 - f * 0.9)
    label(ctx, T(S.CAP.victim, lang), { x: pos.x, y: pos.y - M.TAG.h / 2 - M.BREATH - 2 }, { alpha: (1 - f) * 0.8, color: '#fecdd3', size: M.F.sub })
  }
}

// ---------------------------------------------------------------------------
// ACT 4 — the hit lookup, staged chip by chip
// ---------------------------------------------------------------------------
function paintLookupHit(
  ctx: CanvasRenderingContext2D,
  s: Parameters<EntityRenderer>[1],
  bi: number,
  lin: number,
  _lang: Lang,
) {
  const spark = s.sparkPos
  const cardId = 'E1' // the request revisits E1's address: tag matches row 3

  if (bi === S.B.theAddress) {
    paintWholeCard(ctx, cardId, clamp((lin - 0.1) / 0.25, 0, 1), clamp((lin - 0.45) / 0.2, 0, 1))
    return
  }
  // the three chips exist from now on
  const names = bi >= S.B.theOffset ? { index: true, tag: true, offset: lin >= 0.3 } : {
    index: bi > S.B.theIndex || (bi === S.B.theIndex && lin >= 0.72),
    tag: bi > S.B.theTag || (bi === S.B.theTag && lin >= 0.8),
    offset: false,
  }
  // parked positions
  const parkIndex = { x: L.PAIR_BRACES[1].x - M.CHIP.w / 2 - M.BREATH * 2, y: L.setC(1).y }
  const parkTag = L.tagC(3)
  const parkOffsetStage = L.chipAt(2)

  if (bi === S.B.theIndex) {
    const fl = clamp(lin / 0.18, 0, 1)
    // split completes early, then the Index chip rides the protagonist
    drawChip(ctx, lerpPos(L.chipAt(1), parkIndex, 0), 'tag', cardId, 1 - fl * 0.4, false)
    drawChip(ctx, parkOffsetStage, 'offset', cardId, 1 - fl * 0.4, false)
    const idxPos = lin < 0.2 ? L.chipAt(0) : spark
    drawChip(ctx, idxPos, 'index', cardId, 1, names.index)
    if (lin >= 0.9) drawChip(ctx, parkIndex, 'index', cardId, 1, names.index)
    return
  }
  if (bi === S.B.theTag) {
    drawChip(ctx, parkIndex, 'index', cardId, 1, true)
    drawChip(ctx, parkOffsetStage, 'offset', cardId, 0.8, false)
    // The Tag leaves the formation and hovers BETWEEN the set's two lines —
    // both stored tags stay fully visible the whole time. Probes run from it
    // (paintProbes); the answers linger (paintCompares). On the match it goes
    // HOME, dissolving into the stored tag it equals.
    const travel = easeInOutCubic(clamp((lin - 0.06) / 0.14, 0, 1))
    const homeF = easeInOutCubic(clamp((lin - 0.86) / 0.12, 0, 1))
    const out = easeInOutCubic(clamp((lin - 0.94) / 0.06, 0, 1))
    const atSet = lerpPos(L.chipAt(1), L.setC(1), travel)
    const pos = homeF > 0 ? lerpPos(atSet, parkTag, homeF) : atSet
    drawChip(ctx, pos, 'tag', cardId, 1 - out, names.tag, 1 - 0.15 * travel * (1 - homeF))
    return
  }
  if (bi === S.B.theOffset) {
    drawChip(ctx, parkIndex, 'index', cardId, 1, true)
    // offset falls onto word 2 of the open line, then the word itself flies
    const fall = easeInOutCubic(clamp((lin - 0.02) / 0.3, 0, 1))
    const offPos = fall < 1 ? lerpPos(parkOffsetStage, L.wordC(3, OFFSET_WORD_IDX), fall) : null
    if (offPos) drawChip(ctx, offPos, 'offset', cardId, 1, names.offset)
    if (fall < 1) drawChip(ctx, parkOffsetStage, 'offset', cardId, 1 - fall, false)
    if (lin >= 0.34 && lin <= 0.95) drawFlyingWord(ctx, spark, 1)
    return
  }
}

// ---------------------------------------------------------------------------
// ACT 5 — the miss lookup and the line that comes home
// ---------------------------------------------------------------------------
function paintLookupMiss(
  ctx: CanvasRenderingContext2D,
  s: Parameters<EntityRenderer>[1],
  bi: number,
  lin: number,
  _lang: Lang,
) {
  const spark = s.sparkPos
  const cardId = 'F3'
  const parkIndex = { x: L.PAIR_BRACES[3].x - M.CHIP.w / 2 - M.BREATH * 2, y: L.setC(3).y }

  if (bi === S.B.noMatch) {
    // the card is examined and split, then steps aside (its chips carry on);
    // the north band is clear before the miss verdict resolves
    const w = S.CARD_FOLD[S.B.noMatch]
    const out = clamp(1 - (lin - w[0]) / (w[1] - w[0]), 0, 1)
    const whole = clamp((lin - 0.02) / 0.16, 0, 1) * out
    const seams = clamp((lin - 0.16) / 0.1, 0, 1) * out
    paintWholeCard(ctx, cardId, whole, seams)
    // the Index docks at ITS set's west tab and stops there (its job ends at
    // the set) — a labeled chip never parks inside the lines themselves
    const pick = easeInOutCubic(clamp((lin - 0.22) / 0.18, 0, 1))
    if (pick > 0) drawChip(ctx, lerpPos(L.chipAt(0), parkIndex, pick), 'index', cardId, 1, pick >= 1)
    // the Tag hovers between set 3's lines and knocks (probe grammar): one
    // free line brightens, the resident answers — the miss is WATCHED
    const in2 = easeInOutCubic(clamp((lin - 0.28) / 0.16, 0, 1))
    if (in2 > 0)
      drawChip(ctx, lerpPos(L.chipAt(1), L.setC(3), in2), 'tag', cardId, 1, false, 1 - 0.15 * in2)
    return
  }
  if (bi === S.B.fillFromRam) {
    drawChip(ctx, parkIndex, 'index', cardId, 1, true)
    // the Tag steps back to the formation as the line itself comes home
    const back = easeInOutCubic(clamp((lin - 0.02) / 0.12, 0, 1))
    drawChip(ctx, lerpPos(L.setC(3), L.chipAt(1), back), 'tag', cardId, 0.85, back >= 1, 1 - 0.15 * (1 - back))
    // the caravan: tag + all four words travel home as one line
    const f = easeInOutCubic(clamp((lin - 0.2) / 0.5, 0, 1))
    if (f > 0 && f < 1) {
      const from = L.ramBlockCenter()
      const to = L.rowC(6)
      drawCaravan(ctx, lerpPos(from, to, f), cardId, 1)
    }
    return
  }
  if (bi === S.B.serveMiss) {
    drawChip(ctx, parkIndex, 'index', cardId, 1, true)
    drawChip(ctx, L.chipAt(1), 'tag', cardId, 0.85, true) // the tag stays put (no blip)
    const fall = easeInOutCubic(clamp((lin - 0.02) / 0.28, 0, 1))
    if (fall < 1) {
      drawChip(ctx, lerpPos(L.chipAt(2), L.wordC(6, OFFSET_WORD_IDX), fall), 'offset', cardId, 1, true)
    }
    if (lin >= 0.32 && lin <= 0.95) drawFlyingWord(ctx, spark, 1)
    return
  }
}

// ---------------------------------------------------------------------------
// ACT 6 — the full set: FIFO, then LRU (mini replay with a different victim)
// ---------------------------------------------------------------------------
function paintLookupReplace(
  ctx: CanvasRenderingContext2D,
  s: Parameters<EntityRenderer>[1],
  bi: number,
  lin: number,
  lang: Lang,
) {
  const spark = s.sparkPos
  const cardId = 'G2'
  const parkIndex = { x: L.PAIR_BRACES[2].x - M.CHIP.w / 2 - M.BREATH * 2, y: L.setC(2).y }

  if (bi === S.B.setFull) {
    // the card folds away before the "no free line?" question takes the north
    // dock (problem → need, §2.2: one voice on the band at a time)
    const w = S.CARD_FOLD[S.B.setFull]
    const out = clamp(1 - (lin - w[0]) / (w[1] - w[0]), 0, 1)
    const whole = clamp((lin - 0.02) / 0.14, 0, 1) * out
    const seams = clamp((lin - 0.14) / 0.08, 0, 1) * out
    paintWholeCard(ctx, cardId, whole, seams)
    // same grammar as every lookup: Index docks west of its set, then the
    // Tag hovers between the two OCCUPIED lines and both answer not me
    const pick = easeInOutCubic(clamp((lin - 0.24) / 0.16, 0, 1))
    if (pick > 0) drawChip(ctx, lerpPos(L.chipAt(0), parkIndex, pick), 'index', cardId, 1, pick >= 1)
    const in2 = easeInOutCubic(clamp((lin - 0.3) / 0.16, 0, 1))
    if (in2 > 0)
      drawChip(
        ctx,
        lerpPos(L.chipAt(1), L.setC(2), in2),
        'tag',
        cardId,
        1 - easeInOutCubic(clamp((lin - 0.9) / 0.08, 0, 1)),
        false,
        1 - 0.15 * in2,
      )
    return
  }
  if (bi === S.B.fifo) {
    drawChip(ctx, parkIndex, 'index', cardId, 1, true)
    paintRibbons(ctx, lin)
    // the new line comes from RAM into the freed slot
    const f = easeInOutCubic(clamp((lin - 0.6) / 0.14, 0, 1))
    if (f > 0 && f < 1) drawCaravan(ctx, lerpPos(L.ramBlockCenter(), L.rowC(4), f), cardId, 1)
    return
  }
  if (bi === S.B.lru) {
    drawChip(ctx, parkIndex, 'index', cardId, 1, true)
    // rewind wash — the learner is told the moment is replayed
    const rw = clamp(1 - (lin - 0.02) / 0.1, 0, 1)
    if (rw > 0.01) {
      label(ctx, T({ en: 'same moment, replayed', vi: 'khoảnh khắc đó, chạy lại' }, lang),
        L.mastheadDock().pos, { alpha: rw * 0.9, size: M.F.sub, color: '#facc15' })
    }
    // the use-touch: re-enacting this stream's own history — the 2-way
    // replay's third request was A2's, so A2's line answers "used recently"
    // while B2's has stood untouched since its load. THEN the rule looks at
    // last use and points at the OTHER line (enacted, never asserted).
    const touch = S.LRU_TOUCH
    const brush = easeInOutCubic(clamp((lin - 0.14) / 0.08, 0, 1))
    if (brush > 0 && brush < 1)
      drawMiniCard(ctx, lerpPos(M.DOCK_POS, L.setC(2), brush), touch.card, 0.65, { scale: 0.85 })
    const tAge = lin - touch.at
    if (tAge >= 0) {
      const tHold = clamp(1 - (tAge - 0.16) / 0.06, 0, 1)
      if (tHold > 0.01) {
        const center = L.tagC(touch.row)
        paintCompareMark(ctx, center, 'match', easeInOutCubic(clamp(tAge / 0.04, 0, 1)), tHold)
        paintAnswer(ctx, center, touch.row, T(S.CAP.me, lang), COL.exec, tHold)
      }
    }
    paintStamps(ctx, lin)
    const f = easeInOutCubic(clamp((lin - 0.66) / 0.12, 0, 1))
    if (f > 0 && f < 1) drawCaravan(ctx, lerpPos(L.ramBlockCenter(), L.rowC(5), f), cardId, 1)
    return
  }
  if (bi === S.B.serveReplaced) {
    drawChip(ctx, parkIndex, 'index', cardId, 1, true)
    const fall = easeInOutCubic(clamp((lin - 0.02) / 0.28, 0, 1))
    if (fall < 1) drawChip(ctx, lerpPos(L.chipAt(2), L.wordC(5, 3), fall), 'offset', cardId, 1, true)
    if (lin >= 0.32 && lin <= 0.95) drawFlyingWord(ctx, spark, 1)
    return
  }
}

/** Badge corner: inside the tag chip's own north-east corner (badges overlay
 *  their container's corner — no pill may float over a neighbouring row). */
function badgeCorner(row: number): Vec2 {
  const home = L.tagC(row)
  return { x: home.x + M.TAG.w / 2 - 14, y: home.y - M.TAG.h / 2 + 14 }
}

/** arrival-order badges (FIFO evidence): ① on the line that arrived first,
 *  ② on the one that arrived second; the chosen victim's badge ignites gold. */
function paintRibbons(ctx: CanvasRenderingContext2D, lin: number) {
  for (const rb of S.RIBBONS) {
    const a =
      easeInOutCubic(clamp((lin - rb.from) / 0.16, 0, 1)) *
      (rb.til !== undefined ? clamp(1 - (lin - rb.til) / 0.06, 0, 1) : 1)
    if (a <= 0.01) continue
    const p = badgeCorner(rb.row)
    const selected = lin >= 0.3 && lin <= 0.42 && rb.order === 1
    ctx.save()
    ctx.globalAlpha = a
    ctx.beginPath()
    ctx.arc(p.x, p.y, 11, 0, TAU)
    ctx.fillStyle = selected ? '#fbbf24' : 'rgba(12,16,36,0.95)'
    ctx.fill()
    ctx.strokeStyle = hexA(selected ? '#fbbf24' : '#94a3b8', 0.9)
    ctx.lineWidth = 2
    ctx.stroke()
    label(ctx, String(rb.order), p, { size: M.F.sub - 2, color: selected ? '#241a04' : '#cbd5e1', weight: 800 })
    ctx.restore()
  }
}

/** last-used stamps (LRU evidence): a filled gold dot on the line touched just
 *  now, a hollow ring on the one left stale; the stale ring flashes when the
 *  rule names it. */
function paintStamps(ctx: CanvasRenderingContext2D, lin: number) {
  for (const st of S.STAMPS) {
    const a =
      easeInOutCubic(clamp((lin - st.from) / 0.14, 0, 1)) *
      (st.til !== undefined ? clamp(1 - (lin - st.til) / 0.06, 0, 1) : 1)
    if (a <= 0.01) continue
    const p = badgeCorner(st.row)
    const selected = lin >= 0.54 && lin <= 0.62 && !st.recent
    ctx.save()
    ctx.globalAlpha = a
    ctx.beginPath()
    ctx.arc(p.x, p.y, 10, 0, TAU)
    if (st.recent) {
      ctx.fillStyle = hexA('#fbbf24', selected ? 0.4 : 0.9)
      ctx.fill()
    } else {
      ctx.fillStyle = 'rgba(12,16,36,0.9)'
      ctx.fill()
    }
    ctx.strokeStyle = hexA(selected ? '#fbbf24' : st.recent ? '#fbbf24' : '#94a3b8', 0.9)
    ctx.lineWidth = selected ? 3 : 2
    ctx.stroke()
    ctx.restore()
  }
}

// ---------------------------------------------------------------------------
// ACT 7 — the continuous pass and the consolidation
// ---------------------------------------------------------------------------
function paintReplay(
  ctx: CanvasRenderingContext2D,
  s: Parameters<EntityRenderer>[1],
  bi: number,
  lin: number,
  lang: Lang,
) {
  const spark = s.sparkPos
  if (bi === S.B.fullPass) {
    if (s.sparkScale > 0.05 && lin <= 0.82) drawMiniCard(ctx, spark, 'C1', 1)
    if (lin >= 0.66 && lin <= 0.95) drawFlyingWord(ctx, spark, 1)
    // the checkpoint ticker: as the request passes each station of the journey,
    // that station's KNOWN name takes the masthead (zero new concepts; one
    // label at a time — a simultaneous chain would crowd the band)
    const k = S.CHECKPOINTS.reduce((acc, cp, i) => (lin >= cp.at ? i : acc), -1)
    if (k >= 0) {
      const cp = S.CHECKPOINTS[k]!
      const a = easeInOutCubic(clamp((lin - cp.at) / 0.05, 0, 1))
      drawPill(
        ctx, L.mastheadDock().pos, T(cp.text, lang),
        `700 ${M.F.sub}px ${M.FONT}`, M.PILL.padX, M.PILL.h,
        hexA('#7dd3fc', 0.8), 'rgba(12,16,36,0.9)', '#bae6fd', a,
      )
    }
    return
  }
  // theAnswer: the final checkpoint bows out … then the chapter's opening
  // question returns to the same masthead — answered — and fades (no overlap).
  const last = S.CHECKPOINTS[S.CHECKPOINTS.length - 1]!
  const outA = clamp(1 - (lin - 0.12) / 0.18, 0, 1)
  if (outA > 0.01) {
    drawPill(
      ctx, L.mastheadDock().pos, T(last.text, lang),
      `700 ${M.F.sub}px ${M.FONT}`, M.PILL.padX, M.PILL.h,
      hexA('#7dd3fc', 0.8), 'rgba(12,16,36,0.9)', '#bae6fd', outA,
    )
  }
  const q = S.QUESTIONS[S.B.inside]!
  const qa = easeInOutCubic(clamp((lin - 0.4) / 0.2, 0, 1)) * clamp(1 - (lin - 0.85) / 0.15, 0, 1)
  questionPill(ctx, L.mastheadDock().pos, q[lang], qa)
}

// ---------------------------------------------------------------------------
// shared: whole address card, caravan, questions, verdicts, terms, tally
// ---------------------------------------------------------------------------
/** The unsplit Memory Address: one card, three zones, seams appearing. */
function paintWholeCard(
  ctx: CanvasRenderingContext2D,
  cardId: string,
  appear: number,
  seams: number,
) {
  if (appear <= 0.01) return
  const c = L.cardRect()
  const card = S.cardById(cardId)
  ctx.save()
  ctx.globalAlpha = appear
  rrPath(ctx, c.x, c.y, c.w, c.h, c.r)
  ctx.fillStyle = 'rgba(12,16,36,0.94)'
  ctx.fill()
  ctx.strokeStyle = hexA(card.body, 0.9)
  ctx.lineWidth = 2
  ctx.stroke()
  // zone tints (the three jobs hide inside one address)
  const zones = [M.SET_COLORS[card.homeSet ?? 0], card.body, '#eab308']
  for (let k = 0; k < 3; k++) {
    const zx = c.x + M.CARD.r + k * (M.CHIP.w + M.CHIP.gap)
    rrPath(ctx, zx, c.y + 6, M.CHIP.w, c.h - 12, M.CHIP.r)
    ctx.fillStyle = hexA(zones[k], 0.1 + 0.06 * seams)
    ctx.fill()
  }
  // the seams themselves
  if (seams > 0.01) {
    ctx.globalAlpha = appear * seams
    ctx.strokeStyle = hexA('#e2e8f0', 0.7)
    ctx.lineWidth = 1
    for (let k = 1; k < 3; k++) {
      const sx = c.x + M.CARD.r + k * M.CHIP.w + (k - 0.5) * M.CHIP.gap
      ctx.beginPath()
      ctx.moveTo(sx, c.y + 4)
      ctx.lineTo(sx, c.y + c.h - 4)
      ctx.stroke()
    }
  }
  ctx.restore()
}

/** A whole cache line in flight: its tag chip with four word cells trailing. */
function drawCaravan(ctx: CanvasRenderingContext2D, center: Vec2, cardId: string, alpha: number) {
  const card = S.cardById(cardId)
  ctx.save()
  ctx.globalAlpha = alpha
  // anchor EVERYTHING to the drawn tag: previously the word cells were placed
  // relative to `center` while the tag sat at the row's left-inner slot, so
  // the four words flew one tag-offset east of their chip — hanging outside
  // the panel and never registering with the row grid (owner's frame
  // report). Anchoring to tagX keeps the formation grid-true: at dock each
  // word lands exactly on its own wordCellRect.
  const tagX = center.x - (M.ROW_INNER_W / 2 - M.TAG.w / 2 - M.ROW.padX)
  const refTag = L.tagC(6)
  drawStoredTag(ctx, { x: tagX, y: center.y }, card.id, cardId, 1, 1)
  for (let k = 0; k < M.WORDS_PER_LINE; k++) {
    const refWord = L.wordC(6, k) // formation reference (relative offsets)
    drawWordCell(
      ctx,
      tagX + (refWord.x - refTag.x) - M.WORD.w / 2,
      center.y + (refWord.y - refTag.y) - M.WORD.h / 2,
      1,
      0.4,
      0,
    )
  }
  ctx.restore()
}

function paintQuestions(ctx: CanvasRenderingContext2D, bi: number, lin: number, lang: Lang) {
  const q = S.QUESTIONS[bi]
  if (!q || bi === S.B.inside) return // b1's pill belongs to the entry renderer
  const w = S.QUESTION_WINDOWS[bi]
  if (!w) return
  const dock = L.dockNorth()
  const a = easeInOutCubic(clamp((lin - w[0]) / 0.2, 0, 1)) * clamp(1 - (lin - w[1]) / 0.1, 0, 1)
  questionPill(ctx, { x: dock.pos.x, y: dock.pos.y - M.ASK.h / 2 }, q[lang], a)
}

// The verdict pill carries its second fact in the same breath (ch-review):
// the free-line miss says "still has a free line", the full-set miss says
// "every line said not me" — one pill, sentence case, no extra props.
const VERDICT_SUB: Record<number, { txt: { en: string; vi: string }; col: string } | undefined> = {
  [S.B.noMatch]: { txt: { en: 'still has a free line', vi: 'Set còn dòng trống' }, col: '#facc15' },
  [S.B.setFull]: { txt: { en: 'every line said not me', vi: 'cả hai dòng đều không khớp' }, col: COL.wait },
}

function paintVerdicts(ctx: CanvasRenderingContext2D, bi: number, lin: number, lang: Lang) {
  const v = S.VERDICTS[bi]
  if (!v) return
  const a = easeInOutCubic(clamp((lin - v.at) / 0.14, 0, 1))
  if (a <= 0.01) return
  const dock = L.verdictDock()
  const col = v.kind === 'hit' ? COL.exec : COL.wait
  const title = v.kind === 'hit' ? 'Cache Hit' : 'Cache Miss'
  const sub = VERDICT_SUB[bi]
  const subTxt = sub ? T(sub.txt, lang) : ''
  ctx.save()
  ctx.globalAlpha = a
  ctx.font = `800 ${M.F.verdict}px ${M.FONT}`
  const w1 = ctx.measureText(title).width
  ctx.font = `600 ${M.F.sub}px ${M.FONT}`
  const w2 = subTxt ? ctx.measureText(subTxt).width + 1 : 0
  const w = Math.max(w1, w2) + 2 * M.VERDICT.padX
  const h = M.VERDICT.h
  const y0 = dock.pos.y
  rrPath(ctx, dock.pos.x - w / 2, y0, w, h, M.VERDICT.r)
  ctx.fillStyle = 'rgba(12,16,36,0.95)'
  ctx.fill()
  ctx.strokeStyle = hexA(col, 0.9)
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = col
  ctx.font = `800 ${M.F.verdict}px ${M.FONT}`
  ctx.fillText(title, dock.pos.x, y0 + (subTxt ? h / 2 - 8 : h / 2))
  if (subTxt) {
    ctx.fillStyle = hexA(sub!.col, 0.95)
    ctx.font = `600 ${M.F.sub}px ${M.FONT}`
    ctx.fillText(subTxt, dock.pos.x, y0 + h / 2 + 11)
  }
  ctx.restore()
}

function paintTerms(ctx: CanvasRenderingContext2D, bi: number, lin: number, lang: Lang) {
  const t = S.TERMS[bi]
  if (!t) return
  const dock = L.termDock(t)
  // A second term in the same beat TIME-SHARES the dock: the first names its
  // piece and steps aside as the wider concept takes the same stage (§13).
  const out1 = t.term2 ? clamp(1 - (lin - (t.at + 0.34)) / 0.12, 0, 1) : 1
  const a1 = easeInOutCubic(clamp((lin - t.at) / 0.16, 0, 1)) * out1
  if (a1 > 0.01) termPill(ctx, dock, t.term, T(t.sub, lang), '#7dd3fc', a1)
  if (t.term2) {
    const a2 = easeInOutCubic(clamp((lin - (t.at + 0.46)) / 0.16, 0, 1))
    termPill(ctx, dock, t.term2.term, T(t.term2.sub, lang), '#7dd3fc', a2)
  }
}

// Pill docks now live in scenes/layout.ts (termDock / verdictDock / dockNorth /
// mastheadDock) so the layout proof can assert containment and disjointness on
// the exact rects the renderers use (Layout Derivation Law, §2.2).

function drawTally(ctx: CanvasRenderingContext2D, bi: number, lin: number, lang: Lang) {
  const board = L.tallyBoard()
  const values = S.tallyFor(bi, lin)
  const inGiant = bi === S.B.oneGiantSet
  ctx.save()
  rrPath(ctx, board.x, board.y, board.w, board.h, board.r)
  ctx.fillStyle = 'rgba(10,14,32,0.88)'
  ctx.fill()
  ctx.strokeStyle = 'rgba(226,232,240,0.2)'
  ctx.lineWidth = 1.6
  ctx.stroke()
  label(ctx, T(inGiant ? S.CAP.tallyTitleGiant : S.CAP.tallyTitle, lang),
    { x: board.x + board.w / 2, y: board.y - M.BREATH - M.F.sub / 2 }, { size: M.F.sub })
  const rows: [string, number, string][] = [
    [T(S.CAP.tallyReq, lang), values.req, '#e2e8f0'],
    [T(S.CAP.tallyHit, lang), values.hit, COL.exec],
    [T(S.CAP.tallyMiss, lang), values.miss, COL.wait],
  ]
  rows.forEach(([name, val, col], k) => {
    const p = L.tallyPill(k)
    rrPath(ctx, p.x, p.y, p.w, p.h, p.r)
    ctx.fillStyle = hexA(col, 0.08)
    ctx.fill()
    ctx.strokeStyle = hexA(col, val > 0 ? 0.6 : 0.3)
    ctx.lineWidth = 1.4
    ctx.stroke()
    ctx.fillStyle = hexA(col, val > 0 ? 0.95 : 0.4)
    ctx.font = `800 ${M.F.sub}px ${M.FONT}`
    ctx.textAlign = 'left'
    ctx.textBaseline = 'middle'
    ctx.fillText(name, p.x + M.TERM.padX, p.y + p.h / 2)
    ctx.textAlign = 'right'
    ctx.font = `900 ${M.F.termPill}px ${M.FONT}`
    ctx.fillText(String(val), p.x + p.w - M.TERM.padX, p.y + p.h / 2)
  })
  ctx.restore()
}

// ---------------------------------------------------------------------------
// small geometry helpers
// ---------------------------------------------------------------------------
function lerpPos(a: Vec2, b: Vec2, t: number): Vec2 {
  const f = easeInOutCubic(clamp(t, 0, 1))
  return { x: lerp(a.x, b.x, f), y: lerp(a.y, b.y, f) }
}
