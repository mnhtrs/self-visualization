// renderers/entry.ts — the `entry` scene's entity renderers: the remembered
// memory ladder from Chapter 02 (same axis, same rung order, same colours),
// plus the chapter's own question pill. LAYOUT-SYSTEM DRIVEN: every coordinate
// derives from scenes/metrics.ts + scenes/01-entry.ts (Layout Derivation Law).

import type { EntityRenderer } from '../../../../../rendering/types'
import type { Vec2, Lang } from '../../../../../chapter-loader/types'
import { rrPath, hexA } from '../../../../../rendering/primitives/canvas-utils'
import { glow } from '../../../../../rendering/primitives/glow'
import { drawName } from '../../../../../rendering/primitives/text'
import { clamp, easeInOutCubic } from '../../../../../shared/math'

import { beats } from '../narration/beats'
import * as M from '../scenes/metrics'
import { LINKS, rungById } from '../scenes/01-entry'
import * as S from '../scenes/story'

// ---------------------------------------------------------------------------
// shared helpers (also used by the panel renderer)
// ---------------------------------------------------------------------------
export const DUR: Record<number, number> = Object.fromEntries(beats.map((b, i) => [i, b.duration]))
export const beatFrac = (s: { beatIndex: number; beatElapsed: number }, bi = s.beatIndex) =>
  clamp(s.beatElapsed / (DUR[bi] ?? 3000), 0, 1)

export const COL = {
  exec: '#4ade80',
  wait: '#fb7185',
  cache: '#22d3ee',
  cpu: '#fb923c',
  ram: '#a78bfa',
  dim: 'rgba(170,180,208,0.72)',
  panel: 'rgba(10,14,32,0.92)',
  chip: '#e2e8f0',
}

const nameDy = (hh: number) => hh + M.LABEL_GAP

export function drawPill(
  ctx: CanvasRenderingContext2D,
  center: Vec2,
  text: string,
  font: string,
  padX: number,
  h: number,
  stroke: string,
  fill: string,
  textColor: string,
  alpha = 1,
) {
  if (alpha <= 0.01) return
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.font = font
  const w = ctx.measureText(text).width + 2 * padX
  rrPath(ctx, center.x - w / 2, center.y - h / 2, w, h, h / 2)
  ctx.fillStyle = fill
  ctx.fill()
  ctx.strokeStyle = stroke
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.fillStyle = textColor
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(text, center.x, center.y)
  ctx.restore()
}

// ===========================================================================
// PROC-CORE — the CPU of the entry scene (same drawing language as Chapter 02)
// ===========================================================================
export const drawProcCore: EntityRenderer = (ctx, s, e, active) => {
  const box = M.CPU_BOX
  const x = e.pos.x - box.w / 2
  const y = e.pos.y - box.h / 2
  const working = s.phase !== 'waiting'

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.72
  if (working) glow(ctx, e.pos, e.color, 130, 0.4 + 0.12 * Math.sin(s.t * 0.01))
  else if (active) glow(ctx, e.pos, e.color, 110, 0.2)

  ctx.fillStyle = hexA(e.color, working ? 0.6 : 0.3)
  for (let i = 0; i < M.CPU_PINS.count; i++) {
    const fx = x + M.CPU_PINS.inset + (i / (M.CPU_PINS.count - 1)) * (box.w - 2 * M.CPU_PINS.inset)
    ctx.fillRect(fx - M.CPU_PINS.w / 2, y - M.CPU_PINS.len, M.CPU_PINS.w, M.CPU_PINS.len)
    ctx.fillRect(fx - M.CPU_PINS.w / 2, y + box.h, M.CPU_PINS.w, M.CPU_PINS.len)
    const fy = y + M.CPU_PINS.inset + (i / (M.CPU_PINS.count - 1)) * (box.h - 2 * M.CPU_PINS.inset)
    ctx.fillRect(x - M.CPU_PINS.len, fy - M.CPU_PINS.w / 2, M.CPU_PINS.len, M.CPU_PINS.w)
    ctx.fillRect(x + box.w, fy - M.CPU_PINS.w / 2, M.CPU_PINS.len, M.CPU_PINS.w)
  }

  rrPath(ctx, x, y, box.w, box.h, box.r)
  ctx.fillStyle = hexA(e.color, working ? 0.2 : 0.09)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, working ? 0.95 : 0.42)
  ctx.lineWidth = 2.5
  ctx.stroke()

  const c = M.CPU_CORE
  rrPath(ctx, e.pos.x - c.half, e.pos.y - c.half, c.half * 2, c.half * 2, c.r)
  if (working) {
    const g = ctx.createRadialGradient(e.pos.x, e.pos.y, 2, e.pos.x, e.pos.y, c.half)
    g.addColorStop(0, hexA('#fff3c0', 0.95))
    g.addColorStop(1, hexA(e.color, 0.22))
    ctx.fillStyle = g
  } else {
    ctx.fillStyle = 'rgba(28,34,62,0.9)'
  }
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, working ? 0.95 : 0.35)
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.restore()

  drawName(ctx, e.pos, e.name, e.color, active || working, nameDy(box.h / 2), M.F.partName)
}

// ===========================================================================
// CACHE-RUNG — one rung of the remembered ladder, with its remembered contents
// ===========================================================================
export const drawCacheRung: EntityRenderer = (ctx, s, e, active) => {
  const rungId = String((e.extra ?? {}).rungId ?? 'l1')
  const rung = rungById(rungId)
  const contents = rungId === 'l1' ? S.ENTRY_L1 : S.ENTRY_DEEP

  const x = rung.pos.x - rung.w / 2
  const y = rung.pos.y - rung.h / 2

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.72
  if (active) glow(ctx, rung.pos, e.color, rung.w, 0.34 + 0.1 * Math.sin(s.t * 0.008))

  rrPath(ctx, x, y, rung.w, rung.h, M.RUNG_R)
  ctx.fillStyle = hexA(e.color, active ? 0.18 : 0.1)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.95 : 0.45)
  ctx.lineWidth = 2
  ctx.stroke()

  // countable slots with the Chapter-02 closing contents — the world continued
  for (let i = 0; i < rung.slots; i++) {
    const r = slotRect(rung.pos, rung.w, rung.slots, i)
    const held = contents[i] ?? null
    rrPath(ctx, r.x, r.y, r.w, r.h, M.SLOT.r)
    ctx.fillStyle = hexA(e.color, held ? 0.2 : 0.1)
    ctx.fill()
    ctx.strokeStyle = hexA(e.color, held ? 0.7 : 0.34)
    ctx.lineWidth = 1.3
    ctx.stroke()
    if (held) {
      const v = S.valueById(held)
      ctx.fillStyle = v.color
      ctx.font = `700 ${M.VALUE.size}px ${M.FONT}`
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillText(v.glyph, r.x + r.w / 2, r.y + r.h / 2)
    }
  }
  ctx.restore()

  drawName(ctx, rung.pos, e.name, e.color, active, nameDy(rung.h / 2), M.F.partName)
}

export function slotRect(center: Vec2, boxW: number, count: number, i: number) {
  const innerW = boxW - 2 * M.SLOT.padX
  const w = (innerW - (count - 1) * M.SLOT.gap) / count
  return {
    x: center.x - innerW / 2 + i * (w + M.SLOT.gap),
    y: center.y - M.SLOT.h / 2,
    w,
    h: M.SLOT.h,
  }
}

// ===========================================================================
// RAM-BANK — the far memory of the entry scene
// ===========================================================================
export const drawRamBank: EntityRenderer = (ctx, s, e, active) => {
  const box = { w: M.RAM_BOX.w, h: M.RAM_BOX.h }
  const x = e.pos.x - box.w / 2
  const y = e.pos.y - box.h / 2

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.6
  if (active) glow(ctx, e.pos, e.color, 150, 0.32 + 0.1 * Math.sin(s.t * 0.004))

  rrPath(ctx, x, y, box.w, box.h, M.RAM_BOX.r)
  ctx.fillStyle = hexA(e.color, active ? 0.16 : 0.09)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.95 : 0.45)
  ctx.lineWidth = 2
  ctx.stroke()

  const g = M.RAM_GRID
  const totalW = g.cols * g.cell + (g.cols - 1) * g.gap
  const totalH = g.rows * g.cell + (g.rows - 1) * g.gap
  for (let row = 0; row < g.rows; row++) {
    for (let col = 0; col < g.cols; col++) {
      const isTarget = col === M.RAM_TARGET.col && row === M.RAM_TARGET.row
      ctx.fillStyle = isTarget
        ? hexA('#facc15', 0.5 + 0.3 * Math.sin(s.t * 0.008))
        : hexA(e.color, active ? 0.4 : 0.26)
      ctx.fillRect(
        e.pos.x - totalW / 2 + col * (g.cell + g.gap),
        e.pos.y - totalH / 2 + row * (g.cell + g.gap),
        g.cell,
        g.cell,
      )
    }
  }
  ctx.restore()

  drawName(ctx, e.pos, e.name, e.color, active, nameDy(box.h / 2), M.F.partName)
}

// ===========================================================================
// ENTRY-STAGE — the links, the travelling request card, the question pill
// ===========================================================================
export const drawEntryStage: EntityRenderer = (ctx, s, _e, _active) => {
  const bi = s.beatIndex
  const lin = beatFrac(s)

  ctx.save()
  LINKS.forEach(([a, b], i) => {
    const onIt =
      s.sparkScale > 0.05 &&
      s.sparkPos.x >= Math.min(a.x, b.x) - M.BREATH &&
      s.sparkPos.x <= Math.max(a.x, b.x) + M.BREATH &&
      s.sparkPos.y > M.AXIS_Y - M.BREATH * 3 &&
      s.sparkPos.y < M.AXIS_Y + M.BREATH * 3
    const color = i === LINKS.length - 1 ? COL.ram : COL.cache
    ctx.save()
    ctx.lineCap = 'round'
    if (onIt) {
      ctx.shadowColor = color
      ctx.shadowBlur = 16
    }
    ctx.strokeStyle = hexA(color, 0.22 + 0.62 * (onIt ? 1 : 0))
    ctx.lineWidth = M.BUS.width + (M.BUS.activeWidth - M.BUS.width) * (onIt ? 1 : 0)
    if (onIt) {
      ctx.setLineDash(M.BUS.dash)
      ctx.lineDashOffset = -s.t * 0.06
    }
    ctx.beginPath()
    ctx.moveTo(a.x, a.y)
    ctx.lineTo(b.x, b.y)
    ctx.stroke()
    ctx.setLineDash([])
    ctx.restore()
  })

  // the request's identity card rides the protagonist from the moment it forms
  if (bi <= S.B.inside && s.sparkScale > 0.05 && s.phase !== 'waiting') {
    drawMiniCard(ctx, s.sparkPos, 'A2', bi === S.B.levelAnswers ? easeInOutCubic(clamp(lin / 0.5, 0, 1)) : 1)
  }

  // the chapter's question rises between b1's midpoint and the scene fade
  if (bi === S.B.inside) {
    const a = easeInOutCubic(clamp((lin - 0.42) / 0.3, 0, 1))
    const q = S.QUESTIONS[S.B.inside]!
    drawPill(
      ctx,
      { x: rungById('l1').pos.x, y: rungById('l1').pos.y - rungById('l1').h / 2 + M.ASK.dy },
      q[s.lang as Lang],
      `800 ${M.F.question}px ${M.FONT}`,
      M.ASK.padX,
      M.ASK.h,
      hexA('#facc15', 0.9),
      'rgba(12,16,36,0.95)',
      '#facc15',
      a,
    )
  }
  ctx.restore()
}

// ---------------------------------------------------------------------------
// mini card glyph — the request's identity chip (used everywhere)
// ---------------------------------------------------------------------------
export function drawMiniCard(
  ctx: CanvasRenderingContext2D,
  center: Vec2,
  cardId: string,
  alpha: number,
  opts: { stripe?: number | null; scale?: number } = {},
) {
  if (alpha <= 0.01) return
  const card = S.cardById(cardId)
  const sc = opts.scale ?? 1
  const w = 40 * sc
  const h = 30 * sc
  const stripe = opts.stripe === undefined ? card.homeSet : opts.stripe
  ctx.save()
  ctx.globalAlpha = alpha
  rrPath(ctx, center.x - w / 2, center.y - h / 2, w, h, 7 * sc)
  ctx.fillStyle = 'rgba(12,16,36,0.94)'
  ctx.fill()
  ctx.strokeStyle = hexA(card.body, 0.95)
  ctx.lineWidth = 1.6
  ctx.stroke()
  ctx.fillStyle = card.body
  ctx.font = `800 ${13 * sc}px ${M.FONT}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(card.id, center.x, center.y)
  if (stripe !== null) {
    // the home-set stripe: the SAME marking the routing demo matches braces by
    ctx.fillStyle = hexA(M.SET_COLORS[stripe], 0.95)
    const bw = w - 8 * sc
    rrPath(ctx, center.x - bw / 2, center.y + h / 2 - 7 * sc, bw, 3.4 * sc, 1.7 * sc)
    ctx.fill()
  }
  ctx.restore()
}

export { beatFrac as frac }
