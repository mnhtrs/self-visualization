// content/topics/01-computer-architecture/03-cache-hit-or-miss/meta.ts
// Topic 01 Chapter 03 — question-based title, per the curriculum graph and
// the owner's official production specification.

import type { ChapterMeta } from '../../../../chapter-loader/types'
import thumb from './assets/thumbnail.jpg'

const meta: ChapterMeta = {
  id: 'topic-01-computer-architecture--ch-03-cache-hit-or-miss',
  slug: 'how-cache-decides-hit-or-miss',
  order: 3,
  chapterOrder: 3,
  topicId: 'topic-01-computer-architecture',
  topicSlug: 'computer-architecture',
  topicOrder: 1,
  topicTitle: { en: 'Computer Architecture', vi: 'Kiến trúc Máy tính' },
  status: 'available',
  thumbnail: thumb,
  title: {
    en: 'How does a CPU cache decide hit or miss?',
    vi: 'Cache quyết định Hit hay Miss như thế nào?',
  },
  subtitle: {
    en: 'One memory request enters the cache. The camera follows it inside to see how the cache decides whether it can answer — and what it must give up to make room.',
    vi: 'Một yêu cầu bộ nhớ đi vào cache. Camera đi theo nó vào bên trong để xem cache quyết định có trả lời được hay không — và nó phải nhường điều gì để dọn chỗ.',
  },
  accent: '#fb923c',
  loadStory: () => import('./index').then((m) => m.chapter),
}

export default meta
