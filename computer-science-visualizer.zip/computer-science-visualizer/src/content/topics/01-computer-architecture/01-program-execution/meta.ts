// content/chapter-01-program-execution/meta.ts — FROZEN (thumbnail + animation)
// Question-based title kept to match new curriculum

import type { ChapterMeta } from '../../../../chapter-loader/types'
import thumb from './assets/thumbnail.jpg'

const meta: ChapterMeta = {
  id: 'topic-01-computer-architecture--ch-01-program-execution',
  slug: 'program-execution',
  order: 1,
  chapterOrder: 1,
  topicId: 'topic-01-computer-architecture',
  topicSlug: 'computer-architecture',
  topicOrder: 1,
  topicTitle: { en: 'Computer Architecture', vi: 'Kiến trúc Máy tính' },
  status: 'available',
  thumbnail: thumb,
  title: {
    en: 'How does a program actually start running?',
    vi: 'Chương trình thực sự bắt đầu chạy như thế nào?',
  },
  subtitle: {
    en: 'Follow a single task from click to pixel.',
    vi: 'Theo dấu một tác vụ từ cú click đến điểm ảnh.',
  },
  accent: '#fb923c',
  loadStory: () => import('./index').then((m) => m.chapter),
}

export default meta
