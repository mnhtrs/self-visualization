// narration/labels.ts — UI strings of Topic 01 Chapter 02 (the Viewer reads
// these via chapter.ui; every key the generic Viewer may look for is provided).

import type { LocalizedText } from '../../../../../chapter-loader/types'

export const chapterTitle: LocalizedText = {
  en: 'How does the CPU avoid waiting for memory?',
  vi: 'CPU tránh phải chờ bộ nhớ như thế nào?',
}

export const waitingLine: LocalizedText = {
  en: 'The CPU is ready to go. Click it, then keep an eye on the board below.',
  vi: 'CPU sẵn sàng rồi. Bấm vào đi, rồi để mắt tới cái bảng phía dưới.',
}

export const startButton: LocalizedText = {
  en: 'Start the CPU',
  vi: 'Chạy CPU',
}

export const sceneTag: LocalizedText = {
  en: 'Between the CPU and RAM',
  vi: 'Giữa CPU và RAM',
}

export const tipText: LocalizedText = {
  en: 'Click the CPU to begin. Use the < > buttons or the dots to step through.',
  vi: 'Bấm vào CPU để bắt đầu. Dùng nút < > hoặc các chấm để tua tới lui.',
}

export const doneLabel: LocalizedText = { en: 'Done', vi: 'Xong' }
