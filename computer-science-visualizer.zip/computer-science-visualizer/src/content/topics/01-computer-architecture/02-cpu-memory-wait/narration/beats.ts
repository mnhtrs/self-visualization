// narration/beats.ts — the storyboard of Topic 01 Chapter 02: 17 beats over 2
// scenes, answering exactly one question: how does the CPU reduce waiting for
// slow memory?
//
// Structure:
//   Phase 1  b0–b3   the problem — the CPU stops, and we watch it stop
//   Phase 2  b4–b5   why that is bad — waiting dominates the run
//   Phase 3  b6–b7   the idea — a copy kept close, and the SAME time re-run
//   Phase 4  b8      the ladder — closer is quicker, further holds more
//   Phase 5  b9–b10  the first access — the walk, the haul, the copy back
//   Phase 6  b11     the second access — nearly free
//   Phase 7  b12–b15 the program keeps running: the box fills, something is
//                    displaced, and the waiting comes back
//   Phase 8  b16     the complete mental model
//
// Authoring rules honoured here:
//   • Knowledge Reveal Law (NARRATIVE_FRAMING §13): "Cache" is not spoken until
//     b7, after the short trip has been counted. "Cache Miss" and "Cache Hit"
//     land in b10/b11 as labels for cell ranges already on the strip.
//   • One beat, one mutation (PEDAGOGICAL_SYSTEM §4.3).
//   • Scene is stated explicitly on EVERY beat (scene is non-sticky by contract).
//   • Rule A-01: a chapter never names a future chapter.
//   • Nothing from Chapter 01 is re-explained.
//
// SCOPE LOCK (Chapter 03 boundary). Beats 12–15 show THAT the box fills, THAT
// something leaves when it is full, and THAT a later request therefore misses.
// No line explains WHICH entry leaves or WHY, and no line asks the learner to
// wonder about it — the question must form on its own. Narration states facts.

import type { BeatDescription } from '../../../../../chapter-loader/types'

export const beats: BeatDescription[] = [
  // ===========================================================================
  // PHASE 1 — the problem
  // ===========================================================================
  {
    id: 'running',
    scene: 'gap',
    line: {
      en: 'Think of the timeline at the bottom as your clock. Each square is a single slice of time.',
      vi: 'Các bạn nhìn xuống cái thanh mốc thời gian ở bên dưới nhé. Mỗi ô vuông ở đây tương ứng với một nhịp thời gian.',
    },
    duration: 3600, active: 'cpu', rest: { at: 0 }, emerge: true,
  },
  {
    id: 'needs-value',
    scene: 'gap',
    line: {
      en: 'CPU is executing code, but suddenly it needs a variable stored far away in RAM. The little \u25C6 riding the road is that value \u2014 one piece of the program\u2019s data. Watch how far it has to travel.',
      vi: 'CPU đang chạy thì khựng lại vì thiếu dữ liệu. Ký hiệu \u25C6 bé nhỏ đang đi trên đường chính là giá trị cần lấy \u2014 một mẩu dữ liệu của chương trình. Mà dữ liệu này lại nằm tận ngoài RAM. Hãy nhìn xem quãng đường di chuyển xa tới mức nào.',
    },
    duration: 3800, active: 'ram', travel: { from: 0, to: 2 },
  },
  {
    id: 'the-wait',
    scene: 'gap',
    line: {
      en: 'RAM stores tons of data, but finding things in a huge warehouse takes time. Every red block is time the CPU sits completely idle.',
      vi: 'RAM dung lượng lớn nhưng tốc độ truy cập chậm hơn CPU rất nhiều. CPU phải đứng đợi cho đến khi dữ liệu về. Mỗi ô đỏ trên thanh đó là một khoảng thời gian CPU không xử lý được lệnh nào.',
    },
    duration: 4600, active: 'ram', travel: { from: 2, to: 3, holdAt: { index: 3, from: 0.34, to: 0.99 } },
  },
  {
    id: 'again-and-again',
    scene: 'gap',
    line: {
      en: 'It gets the value, runs just ONE step, and immediately needs another value from RAM. The whole painful trip starts all over.',
      vi: 'Lấy được dữ liệu về, CPU chạy đúng 1 bước thì gặp lệnh kế tiếp cần dữ liệu khác. Lại phải quay ra RAM. Cứ vậy lặp đi lặp lại.',
    },
    duration: 5600, active: 'ram', travel: { from: 3, to: 12 },
  },

  // ===========================================================================
  // PHASE 2 — why waiting is bad
  // ===========================================================================
  {
    id: 'read-the-board',
    scene: 'gap',
    line: {
      en: 'Look at the ratio on screen. The CPU is ultra-fast, but it spends most of its life waiting on a slow road.',
      vi: 'Nhìn vào tỉ lệ trên thanh thống kê xem: CPU cực kỳ nhanh, nhưng phần lớn thời gian lại chết dí một chỗ chỉ vì quãng đường truyền quá xa.',
    },
    duration: 5000, active: 'cpu', rest: { at: 12 },
  },

  // ===========================================================================
  // PHASE 3 — the idea, and the same time re-run
  // ===========================================================================
  {
    id: 'the-idea',
    scene: 'gap',
    line: {
      en: 'So here is the trick: keep a tiny, high-speed storage box right next to the CPU core. Whenever we fetch data from RAM, leave a copy inside it.',
      vi: 'Vậy giải pháp là gì? Ta đặt một chiếc hộp siêu nhanh ngay sát bên cạnh CPU. Mỗi lần lấy dữ liệu từ RAM về, ta chép lại một bản vào chiếc hộp này.',
    },
    duration: 5000, active: 'cache', rest: { at: 12 },
  },
  {
    id: 'same-time-again',
    scene: 'gap',
    line: {
      en: 'Now replay the exact same code! The first access still takes time, but subsequent requests grab data instantly from this box. We call this Cache.',
      vi: 'Bây giờ cho chạy lại đúng đoạn code đó: lần đầu vẫn phải ra RAM, nhưng từ lần sau CPU lấy thẳng từ hộp gần đó, không cần đi xa nữa. Chiếc hộp này chính là Cache.',
    },
    duration: 6600, active: 'cache', travel: { from: 12, to: 14 },
  },

  // ===========================================================================
  // PHASE 4 — the memory hierarchy
  // ===========================================================================
  {
    id: 'the-ladder',
    scene: 'ladder',
    line: {
      en: 'Modern CPUs use multiple cache levels: L1, L2, and L3. Rule of thumb: the closer to the core, the faster it is, but the smaller its capacity. The shapes sitting in the slots are values \u2014 \u25C6 \u25B2 \u25A0 \u25CF are just different pieces of data the program works with.',
      vi: 'Thực tế người ta chia làm nhiều tầng: L1, L2, L3. Nguyên lý nằm lòng: Càng nằm gần nhân CPU thì càng nhanh nhưng dung lượng lại càng nhỏ. Các ký hiệu nằm trong ô chính là các giá trị \u2014 \u25C6 \u25B2 \u25A0 \u25CF chỉ là những mẩu dữ liệu khác nhau chương trình đang dùng.',
    },
    duration: 6800, active: 'ladder-stage', rest: { at: 0 }, emerge: true,
  },

  // ===========================================================================
  // PHASE 5 — the first memory access
  // ===========================================================================
  {
    id: 'the-walk',
    scene: 'ladder',
    line: {
      en: 'When CPU needs new data, it checks L1 first. Not there? It checks L2, then L3, gradually stepping outward.',
      vi: 'Khi cần dữ liệu mới, CPU sẽ hỏi L1 trước. Không có? Nó hỏi tiếp L2, rồi L3, cứ lần lượt tìm từ trong ra ngoài.',
    },
    duration: 5000, active: 'l1', travel: { from: 0, to: 3 },
  },
  {
    id: 'haul-and-copy',
    scene: 'ladder',
    line: {
      en: 'If none of the caches have it, CPU must fetch it all the way from RAM. On the way back, it saves a copy into Cache. This is called a Cache Miss.',
      vi: 'Nếu cả 3 tầng cache đều không có, CPU phải truy xuất thẳng từ RAM. Trên đường về, dữ liệu đó được sao chép và lưu lại vào cache. Đây gọi là Cache Miss.',
    },
    duration: 6400, active: 'ram-rung', travel: { from: 3, to: 8, holdAt: { index: 4, from: 0.3, to: 0.5 } },
  },

  // ===========================================================================
  // PHASE 6 — the second memory access
  // ===========================================================================
  {
    id: 'the-hit',
    scene: 'ladder',
    line: {
      en: 'Next time the CPU needs that same data, it finds it immediately in L1 Cache. Zero waiting time! This is a Cache Hit.',
      vi: 'Lần sau CPU cần đúng dữ liệu đó, kiểm tra L1 là thấy ngay, không cần đi đâu thêm. Không mất thời gian chờ. Đây gọi là Cache Hit.',
    },
    duration: 5000, active: 'l1', travel: { from: 8, to: 10 },
  },

  // ===========================================================================
  // PHASE 7 — the program keeps running
  // ===========================================================================
  {
    id: 'it-fills',
    scene: 'ladder',
    line: {
      en: 'As the program runs, CPU fetches more variables and fills up the Cache.',
      vi: 'Chương trình tiếp tục chạy, CPU liên tục lấy thêm dữ liệu mới và lấp đầy dần vào Cache.',
    },
    duration: 6000, active: 'l1', travel: { from: 10, to: 11 },
  },
  {
    id: 'no-room',
    scene: 'ladder',
    line: {
      en: 'Because Cache is small, it quickly gets full. To store new data, older data must be kicked out.',
      vi: 'Vì Cache rất nhỏ nên nó mau chóng bị đầy. Muốn nhét thêm dữ liệu mới vào, nó buộc phải đá bớt dữ liệu cũ ra.',
    },
    duration: 5600, active: 'l1', rest: { at: 11 },
  },
  {
    id: 'the-recall',
    scene: 'ladder',
    line: {
      en: 'Now, what if the CPU suddenly needs that old evicted data again?',
      vi: 'Thế điều gì sẽ xảy ra nếu CPU đột nhiên cần lại chính cái dữ liệu vừa bị đá ra ngoài?',
    },
    duration: 4200, active: 'l1', rest: { at: 11 },
  },
  {
    id: 'waiting-returns',
    scene: 'ladder',
    line: {
      en: 'Cache Miss again! CPU has to travel all the way back to RAM. Caches improve speed, but they cannot eliminate memory waiting entirely.',
      vi: 'Lại bị Cache Miss. CPU phải truy xuất thẳng từ RAM một lần nữa. Cache giúp giảm thời gian chờ đáng kể, nhưng không loại bỏ được hoàn toàn.',
    },
    duration: 6600, active: 'ram-rung', travel: { from: 11, to: 14 },
  },

  // ===========================================================================
  // PHASE 8 — one complete mental model
  // ===========================================================================
  {
    id: 'why-three',
    scene: 'ladder',
    line: {
      en: 'Why not just build one giant, super-fast Cache? Because physics prohibits it: bigger storage is inherently slower. So hardware engineers balance speed and size using multi-level Caches.',
      vi: 'Tại sao không làm một cache duy nhất thật lớn? Vì về mặt vật lý, bộ nhớ càng lớn thì độ trễ truy cập càng cao. Vì vậy phần cứng chia thành nhiều tầng L1, L2, L3 để cân bằng giữa tốc độ và dung lượng.',
    },
    duration: 6200, active: 'ladder-stage', rest: { at: 15 },
  },
  {
    id: 'recap',
    scene: 'ladder',
    line: {
      en: 'To recap: CPU checks L1, L2, L3 before ever touching RAM. Caches store temporary copies of frequently used data to keep the CPU running at full throttle!',
      vi: 'Tóm lại: CPU kiểm tra L1, L2, L3 trước khi truy cập RAM. Cache lưu bản sao tạm của dữ liệu đang dùng, giúp CPU không phải ra RAM mỗi lần.',
    },
    duration: 9000, active: 'cpu-rung', rest: { at: 15 }, effect: 'loop',
  },
]
