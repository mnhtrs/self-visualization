// content/topics/01-computer-architecture/02-cpu-memory-wait/types.ts
// Chapter-local types. The generic interfaces live in chapter-loader/types.

import type { LocalizedText, Vec2 } from '../../../../chapter-loader/types'

/** Legacy alias so narration/geometry code reads like Ch-01/02/03. */
export type L = LocalizedText

/** Two scenes: the wide shot of the gap, and the memory ladder inside it. */
export type Scene = 'gap' | 'ladder'

export interface Rect {
  x: number
  y: number
  w: number
  h: number
}

/** A part as the chapter describes it (mirrors Ch-01/02/03 PartSpec). */
export interface PartSpec {
  id: string
  kind?: string
  pos: Vec2
  color: string
  name: string
  gloss: LocalizedText
  labelSize?: number
  extra?: Record<string, unknown>
}

/** One block on the execution strip: work actually done, or time spent waiting. */
export type SlotKind = 'exec' | 'wait'

/** What a cache level is doing during a given beat. */
export type ProbeState = 'idle' | 'probing' | 'empty' | 'filled' | 'found'
