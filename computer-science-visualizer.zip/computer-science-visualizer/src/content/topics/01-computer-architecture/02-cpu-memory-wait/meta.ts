// content/topics/01-computer-architecture/02-cpu-memory-wait/meta.ts
// Topic 01 Chapter 02 — question-based title, per the curriculum graph.

import type { ChapterMeta } from '../../../../chapter-loader/types'
import thumb from './assets/thumbnail.jpg'

const meta: ChapterMeta = {
  id: 'topic-01-computer-architecture--ch-02-cpu-memory-wait',
  slug: 'how-cpu-avoids-waiting-for-memory',
  order: 2,
  chapterOrder: 2,
  topicId: 'topic-01-computer-architecture',
  topicSlug: 'computer-architecture',
  topicOrder: 1,
  topicTitle: { en: 'Computer Architecture', vi: 'Kiến trúc Máy tính' },
  status: 'available',
  thumbnail: thumb,
  title: {
    en: 'How does the CPU avoid waiting for memory?',
    vi: 'CPU tránh chờ bộ nhớ như thế nào?',
  },
  subtitle: {
    en: 'The CPU works far faster than RAM can hand over data. This chapter looks at the small memory layer that cuts down the waiting.',
    vi: 'CPU xử lý nhanh hơn nhiều so với tốc độ RAM đưa dữ liệu ra. Chương này tìm hiểu lớp nhớ nhỏ giúp giảm thời gian chờ đó.',
  },
  accent: '#fb923c',
  loadStory: () => import('./index').then((m) => m.chapter),
}

export default meta
