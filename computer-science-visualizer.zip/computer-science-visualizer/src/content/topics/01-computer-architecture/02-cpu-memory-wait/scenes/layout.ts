// scenes/layout.ts — the derived *layout system*. Every container interior the
// renderers draw into (the strip's cell grid, the ratio bar, the probe badges,
// the cache slot rows, the RAM grid, the size bars) is computed HERE from named
// metrics + a container rect, so the renderers hold no eyeballed arithmetic.
//
// Imports metrics (pure) + the two geometry files; nothing imports this file
// back, so there is no cycle.

import * as M from './metrics'
import { CPU_POS, CACHE_POS, RAM_POS } from './01-the-gap'
import { LEVELS } from './02-the-ladder'
import type { Vec2 } from '../../../../../chapter-loader/types'

// =============================================================================
// The execution strip — one instrument, used in both scenes
// =============================================================================

export interface StripSpec {
  x: number
  y: number
  w: number
  h: number
  r: number
  cells: number
  rows: number
  cellH: number
}

/** The strip's inner content box (inside padding, below the caption band). */
export function stripInner(S: StripSpec) {
  return {
    x: S.x + M.STRIP_PAD.x,
    y: S.y + M.STRIP_PAD.y + M.STRIP_TAG_H,
    w: S.w - 2 * M.STRIP_PAD.x,
    h: S.h - 2 * M.STRIP_PAD.y - M.STRIP_TAG_H,
  }
}

/** Caption baseline inside the strip's header band. */
export function stripTag(S: StripSpec): Vec2 {
  return { x: S.x + M.STRIP_PAD.x, y: S.y + M.STRIP_PAD.y + M.STRIP_TAG_H / 2 }
}

/** One cell pitch, derived so `cells` cells + gaps exactly fill the inner width. */
export function cellW(S: StripSpec): number {
  return (stripInner(S).w - (S.cells - 1) * M.CELL.gap) / S.cells
}

/** Top edge of row `r`, which begins with its own label band. */
export function rowTop(S: StripSpec, r: number): number {
  return stripInner(S).y + r * (M.RUN_LABEL_H + S.cellH + M.STRIP_ROW_GAP)
}

/** The run label sits above its row of cells. */
export function rowLabelPos(S: StripSpec, r: number): Vec2 {
  return { x: stripInner(S).x, y: rowTop(S, r) + M.RUN_LABEL_H / 2 }
}

/** Rect of time-cell `i` in row `r`. */
export function cellRect(S: StripSpec, r: number, i: number) {
  const w = cellW(S)
  return {
    x: stripInner(S).x + i * (w + M.CELL.gap),
    y: rowTop(S, r) + M.RUN_LABEL_H,
    w,
    h: S.cellH,
  }
}

/** The ratio bar hangs under a row, spanning the same inner width. */
export function ratioBar(S: StripSpec, r: number) {
  const c = cellRect(S, r, 0)
  return {
    x: stripInner(S).x,
    y: c.y + S.cellH + M.RATIO.topGap,
    w: stripInner(S).w,
    h: M.RATIO.h,
  }
}

/** A verdict pill centred over the cell range it labels, below the row. */
export function verdictPos(S: StripSpec, r: number, from: number, to: number): Vec2 {
  const a = cellRect(S, r, from)
  const b = cellRect(S, r, to)
  return {
    x: (a.x + b.x + b.w) / 2,
    y: a.y + S.cellH + M.VERDICT.gap + M.VERDICT.h / 2,
  }
}

// =============================================================================
// SCENE A — badges and the near box
// =============================================================================

export const STALL_POS: Vec2 = {
  x: CPU_POS.x,
  y: CPU_POS.y - M.CPU_BOX.h / 2 + M.STALL.dy,
}

export const ASK_POS: Vec2 = {
  x: (CPU_POS.x + RAM_POS.x) / 2,
  y: M.AXIS_Y - M.CPU_BOX.h / 2 + M.STALL.dy,
}

// =============================================================================
// Cache slot rows — shared by the Scene-A box and every ladder rung
// =============================================================================
// A level's slots are its capacity made countable. The learner can see at a
// glance how many things fit and how many are occupied — which is what makes
// "no free slot" an observation rather than a claim.

export function slotRect(
  center: Vec2,
  boxW: number,
  count: number,
  i: number,
) {
  const innerW = boxW - 2 * M.SLOT.padX
  const w = (innerW - (count - 1) * M.SLOT.gap) / count
  return {
    x: center.x - innerW / 2 + i * (w + M.SLOT.gap),
    y: center.y - M.SLOT.h / 2,
    w,
    h: M.SLOT.h,
  }
}

/** Scene A's box carries the same slot row as a ladder rung (one visual
 *  language for "a place values are kept"). */
export const CACHE_A_SLOTS = 3
export function cacheSlotRect(i: number) {
  return slotRect(CACHE_POS, M.CACHE_BOX.w, CACHE_A_SLOTS, i)
}

// =============================================================================
// SCENE B — RAM grid, probe badges, size bars
// =============================================================================

/** RAM's interior: a dense grid whose cell count dwarfs any cache slot row.
 *  Scale is carried by countable density, not by narration. */
export function ramCellRect(center: Vec2, col: number, row: number) {
  const g = M.RAM_GRID
  const totalW = g.cols * g.cell + (g.cols - 1) * g.gap
  const totalH = g.rows * g.cell + (g.rows - 1) * g.gap
  return {
    x: center.x - totalW / 2 + col * (g.cell + g.gap),
    y: center.y - totalH / 2 + row * (g.cell + g.gap),
    w: g.cell,
    h: g.cell,
  }
}
export const RAM_CELL_COUNT = M.RAM_GRID.cols * M.RAM_GRID.rows

/** The probe badge hovers above a rung, clear of its top edge. */
export function probePos(rung: { pos: Vec2; h: number }): Vec2 {
  return { x: rung.pos.x, y: rung.pos.y - rung.h / 2 + M.PROBE.dy }
}

/** The size bar hangs under a cache rung; its width IS the rung's width. */
export function sizeBar(rung: { pos: Vec2; w: number; h: number }) {
  return {
    x: rung.pos.x - rung.w / 2,
    y: rung.pos.y + rung.h / 2 + M.LABEL_GAP + M.LABEL_TEXT_H + M.SIZE_BAR.gap,
    w: rung.w,
    h: M.SIZE_BAR.h,
  }
}

export const WIDEST_LEVEL = Math.max(...LEVELS.map((r) => r.w))
