// scenes/metrics.ts — the Chapter's layout *primitives*: every bare number the
// geometry and the renderers use, named exactly once. PURE — no imports — so
// both the scene geometry (01/02) and the derived layout system (layout.ts) can
// build on it without cycles.
//
// Doctrine (docs/constitution/VISUAL_LANGUAGE.md §2.2 Derivable Geometry, and
// docs/pipeline/02_PRODUCTION_LIFECYCLE.md Layout Derivation Law): an inline
// literal coordinate is a defect. Every drawn coordinate must be a named metric
// or a function of a container rect + measured text.
//
// Container EXTENTS are derived from the content they hold, never hand-typed
// (PLATFORM_ENGINE §2.4) — see STRIP_A / STRIP_B below.

// ---- global spacing scale -----------------------------------------------------
export const BREATH = 8 // min text↔edge / text↔text breathing (world units)
export const CLIP_INSET = 14 // min content inset from a scene bbox edge
export const LABEL_GAP = 12 // gap between a box edge and its name label
export const LABEL_TEXT_H = 20 // approx cap-height of a name label (for bbox math)

// ---- canvas font families (single source) -------------------------------------
export const FONT = "'Quicksand', system-ui, sans-serif"
export const MONO = "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace"

// ---- type scale (world px) — one named size per role, never a literal ---------
export const F = {
  partName: 19,
  cacheName: 18,
  stripTag: 16,
  runLabel: 15,
  verdict: 20,
  question: 24,
  probe: 16,
  sizeTag: 13,
  ratio: 17,
}

// ---- element box sizes (one spec each; interiors are derived from these) ------
export const CPU_BOX = { w: 196, h: 168, r: 18 }
/** RAM is deliberately the largest object in the chapter. Scale IS the lesson:
 *  the learner must never be able to read cache and RAM as the same size class. */
export const RAM_BOX = { w: 280, h: 240, r: 16 }
export const CACHE_BOX = { w: 148, h: 112, r: 14 }

/** CPU die interior: the pin comb + the core square. */
export const CPU_PINS = { count: 5, len: 11, w: 4, inset: 26 }
export const CPU_CORE = { half: 34, r: 8 }
/** Work-tick dots sit BELOW the core; rowY derived so they can never collide. */
export const CPU_TICK = { r: 4.5, pitch: 15, rowY: CPU_CORE.half + BREATH + 5 }

/** RAM interior: a dense grid. 192 cells against a cache level's 3 slots — the
 *  size relationship is carried by countable density, not by narration. */
export const RAM_GRID = { cols: 16, rows: 12, cell: 9, gap: 4 }
/** The one cell a request actually targets (a value lives somewhere specific). */
export const RAM_TARGET = { col: 9, row: 5 }

/** A stored value's glyph inside a cache slot. */
export const VALUE = { size: 15, ring: 13 }

/** Cache slot interior spec — shared by the Scene-A box and every ladder rung. */
export const SLOT = { padX: 13, gap: 7, h: 30, r: 5 }

// ---- SCENE A: the gap between a fast CPU and slow RAM -------------------------
export const AXIS_Y = 330
export const CPU_X = 260
export const RAM_X = 1560
/** Cache sits between the two, but deliberately HUGGING the CPU side. */
export const CACHE_GAP = 122

// ---- the execution strip — the chapter's single instrument ---------------------
// One visual language for "time spent", used in both scenes. Scene A runs the
// same stretch of time TWICE (without the box, then with it) so the payoff is
// counted rather than asserted. Scene B runs one continuous timeline.
export const CELL = { gap: 5, r: 5 }
export const RUN_LABEL_H = 20
export const STRIP_PAD = { x: 22, y: 16 }
export const STRIP_TAG_H = 26
export const STRIP_ROW_GAP = 18

const stripHeight = (rows: number, cellH: number, extra = 0) =>
  2 * STRIP_PAD.y +
  STRIP_TAG_H +
  rows * (RUN_LABEL_H + cellH) +
  (rows - 1) * STRIP_ROW_GAP +
  extra +
  BREATH

export const STRIP_A = {
  x: 170,
  y: 600,
  w: 1480,
  r: 18,
  cells: 21,
  rows: 2,
  cellH: 52,
  get h() {
    return stripHeight(2, 52)
  },
}

/** The verdict pill (Cache Miss / Cache Hit) labels a range of cells directly
 *  on the strip — the term is attached to the evidence it names. */
export const VERDICT = { h: 34, r: 17, padX: 16, gap: 12 }

export const STRIP_B = {
  x: 170,
  y: 640,
  w: 1520,
  r: 18,
  cells: 28,
  rows: 1,
  cellH: 58,
  get h() {
    return stripHeight(1, 58, VERDICT.gap + VERDICT.h)
  },
}

/** The ratio bar that summarises a Scene-A run. */
export const RATIO = { h: 14, r: 7, topGap: 12, labelGap: 8 }

// ---- SCENE B: the memory ladder ------------------------------------------------
/** Every ladder rung: box size + the gap separating it from the previous rung.
 *  The gap encodes DISTANCE (= trip time); the box encodes SIZE. Both grow as we
 *  move away from the CPU — and RAM dwarfs all of them. */
export interface RungSpec {
  id: string
  w: number
  h: number
  gapBefore: number
  /** How many values this level can hold. Bigger box ⇒ more slots. */
  slots: number
}
export const LADDER_START_X = 120
export const LADDER_AXIS_Y = 372
export const RUNGS: RungSpec[] = [
  { id: 'cpu', w: CPU_BOX.w, h: CPU_BOX.h, gapBefore: 0, slots: 0 },
  { id: 'l1', w: 132, h: 92, gapBefore: 104, slots: 3 },
  { id: 'l2', w: 176, h: 116, gapBefore: 148, slots: 4 },
  { id: 'l3', w: 224, h: 142, gapBefore: 196, slots: 5 },
  { id: 'ram', w: RAM_BOX.w, h: RAM_BOX.h, gapBefore: 300, slots: 0 },
]
export const RUNG_R = 14

/** The "probe" badge that pops on a level while it is being checked. */
export const PROBE = { w: 96, h: 30, r: 15, dy: -20, padX: 12 }
/** The size bar hanging under each cache rung. */
export const SIZE_BAR = { h: 10, r: 5, gap: 14 }

// ---- shared connector / payload metrics ----------------------------------------
export const BUS = { width: 5, activeWidth: 7, dash: [2, 16] }

/** The protagonist's drawn radius (rendering/primitives/spark.ts: R = 44 * scale).
 *  DOCK_GAP is the clearance a resting spark needs from a container face so its
 *  glow never falls on that container's interior. Slot rows are the chapter's
 *  educational evidence; the protagonist must never cover them, so every
 *  waypoint that would sit ON a box is derived as a dock OUTSIDE its west face. */
export const SPARK = { r: 44, dockGap: 44 + BREATH }
/** The stall badge over the CPU while it cannot make progress. */
export const STALL = { w: 172, h: 40, r: 20, dy: -34, padX: 14 }
/** The question pill used to pose the chapter's own question. */
export const ASK = { h: 46, r: 23, padX: 26 }
