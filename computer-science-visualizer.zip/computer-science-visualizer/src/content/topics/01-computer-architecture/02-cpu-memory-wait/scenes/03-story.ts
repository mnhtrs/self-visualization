// scenes/03-story.ts — the micro-content the renderers animate: the execution
// strip's time cells, the ladder reveal schedule, the per-level probe windows,
// the copy-back, and the fill / displacement sequence.
//
// One file = one source of truth for the beat-driven data. Everything here is a
// pure function of (beatIndex, beatFraction), so scrubbing, pausing and stepping
// backwards are deterministic by construction (VISUAL_LANGUAGE §15).
//
// SCOPE LOCK. This chapter shows THAT cache is limited, THAT something leaves
// when it is full, and THAT a later request can therefore miss. It never shows
// HOW the departing entry is chosen, and never depicts a search. Those are
// Chapter 03's subject. See the staging constraints on DISPLACE below.

import type { SlotKind } from '../types'

// =============================================================================
// The values the program uses
// =============================================================================
// Distinct, recognisable, and deliberately UNLABELLED — no addresses, no names,
// no numbering. The learner must be able to tell values apart (so "several
// things are in there" is observable) without being given any identity scheme
// (which would pre-empt Tag).
export interface ValueSpec {
  id: string
  color: string
  glyph: string
}
export const VALUES: ValueSpec[] = [
  { id: 'v1', color: '#facc15', glyph: '\u25C6' }, // diamond — the protagonist value
  { id: 'v2', color: '#f472b6', glyph: '\u25B2' }, // triangle
  { id: 'v3', color: '#4ade80', glyph: '\u25A0' }, // square
  { id: 'v4', color: '#38bdf8', glyph: '\u25CF' }, // circle
]
export const valueById = (id: string): ValueSpec =>
  VALUES.find((v) => v.id === id) ?? VALUES[0]

// =============================================================================
// SCENE A — the execution strip, run twice
// =============================================================================
// Row 0: the same stretch of time WITHOUT the near box.
// Row 1: the same stretch of time WITH it.
// Same length, same cells, same colours — so the payoff is counted, not claimed.

/** Row 0 — what the learner watches happen in beats 0-4. */
export const RUN_SLOW: SlotKind[] = [
  'exec', 'exec', 'exec',
  'wait', 'wait', 'wait', 'wait', 'wait',
  'exec',
  'wait', 'wait', 'wait', 'wait', 'wait',
  'exec',
  'wait', 'wait', 'wait', 'wait', 'wait',
  'exec',
]

/** Row 1 — the identical work, with the near box answering the repeats. The
 *  first trip still costs full price (nothing is in the box yet); the repeats
 *  cost almost nothing. */
export const RUN_FAST: SlotKind[] = [
  'exec', 'exec', 'exec',
  'wait', 'wait', 'wait', 'wait', 'wait',
  'exec',
  'wait',
  'exec', 'exec', 'exec',
  'wait',
  'exec', 'exec', 'exec', 'exec', 'exec', 'exec', 'exec',
]

export const SLOTS = RUN_SLOW // legacy alias: Scene A row 0
export const EXEC_CELLS = RUN_SLOW.filter((k) => k === 'exec').length
export const WAIT_CELLS = RUN_SLOW.length - EXEC_CELLS
export const FAST_EXEC_CELLS = RUN_FAST.filter((k) => k === 'exec').length
export const FAST_WAIT_CELLS = RUN_FAST.length - FAST_EXEC_CELLS

/** Cells of ROW 0 laid down at the start/end of each Scene-A beat. */
export const FILL_AT_BEAT: Record<number, [number, number]> = {
  0: [0, 3],
  1: [3, 4],
  2: [4, 8],
  3: [8, 20], // the pattern repeats and the row completes
  4: [20, 21], // the row is whole; the ratio can be read
  5: [21, 21], // the box appears and receives a copy
  6: [21, 21], // row 1 runs (see FAST_FILL_AT_BEAT)
}

/** Cells of ROW 1 — only beat 7 writes to it. This is the measured payoff. */
export const FAST_FILL_AT_BEAT: Record<number, [number, number]> = {
  6: [0, 21],
}

const spanFill = (
  table: Record<number, [number, number]>,
  bi: number,
  lin: number,
  fullAfter: number,
  total: number,
): number => {
  const span = table[bi]
  if (!span) return bi > fullAfter ? total : 0
  return span[0] + (span[1] - span[0]) * lin
}

export const cellsFilled = (bi: number, lin: number): number =>
  spanFill(FILL_AT_BEAT, bi, lin, 6, RUN_SLOW.length)

export const fastCellsFilled = (bi: number, lin: number): number => {
  if (bi < 6) return 0
  return spanFill(FAST_FILL_AT_BEAT, bi, lin, 6, RUN_FAST.length)
}

/** Which row is being written right now (drives row emphasis). */
export const activeRun = (bi: number): 0 | 1 | null =>
  bi <= 4 ? 0 : bi === 6 ? 1 : null

function slotAt(kinds: SlotKind[], n: number): SlotKind | null {
  const idx = Math.floor(n)
  if (n <= 0 || idx >= kinds.length) return null
  return kinds[idx]
}

/** The last Scene-A beat inside the measured stretch of time. */
export const MEASURED_UNTIL_BEAT = 4

export const cpuWorking = (bi: number, lin: number): boolean => {
  if (bi === 6) return slotAt(RUN_FAST, fastCellsFilled(bi, lin)) === 'exec'
  if (bi > MEASURED_UNTIL_BEAT) return true
  return slotAt(RUN_SLOW, cellsFilled(bi, lin)) === 'exec'
}

/** Stalled is asserted, never inferred as "not working" (PEDAGOGY §4.6). */
export const cpuStalled = (bi: number, lin: number): boolean => {
  if (bi === 6) return slotAt(RUN_FAST, fastCellsFilled(bi, lin)) === 'wait'
  if (bi > MEASURED_UNTIL_BEAT) return false
  return slotAt(RUN_SLOW, cellsFilled(bi, lin)) === 'wait'
}

/** The ratio bar for row 0 appears once that row is complete. */
export const RATIO_FROM_BEAT = 4

// ---- Scene A: the road and the near box ----------------------------------------
export const CACHE_REVEAL_BEAT = 5
export const SPLIT_LINK_FROM_BEAT = 5
export const ASK_BEATS = [4]

/** During b6 a copy travels from RAM into the box: the learner watches the box
 *  RECEIVE what it will later hand back, so it is never a magic container. */
export const COPY_IN_AT = 0.42

/** Is the Scene-A box holding the value at (beat, fraction)? */
export const cacheHoldsA = (bi: number, lin: number): boolean =>
  bi > CACHE_REVEAL_BEAT || (bi === CACHE_REVEAL_BEAT && lin >= COPY_IN_AT)

// =============================================================================
// SCENE B — the ladder
// =============================================================================

export const RUNG_REVEAL: Record<string, number> = {
  cpu: 0, l1: 0.16, l2: 0.36, l3: 0.56, ram: 0.76,
}
export const LADDER_BEAT = 7
/** The level names appear once the shapes have been seen (same beat, later). */
export const NAME_AT = 0.9

export interface Probe {
  level: string
  from: number
  to: number
  found: boolean
}

/** Level checks per beat. A probe shows a level ANSWERING — never searching.
 *  The verdict is instantaneous by design: no slot-by-slot sweep is ever drawn,
 *  because that would depict associative lookup (Chapter 03). */
export const PROBE_BEATS: Record<number, Probe[]> = {
  8: [
    { level: 'l1', from: 0.06, to: 0.3, found: false },
    { level: 'l2', from: 0.34, to: 0.58, found: false },
    { level: 'l3', from: 0.62, to: 0.86, found: false },
  ],
  10: [{ level: 'l1', from: 0.08, to: 0.34, found: true }],
  // the fill sequence: other values, each missing at first
  11: [{ level: 'l1', from: 0.05, to: 0.2, found: false }],
  // the displaced value is asked for again — and is gone
  13: [{ level: 'l1', from: 0.12, to: 0.62, found: false }],
}

export const RAM_TRIP_BEAT = 9
export const COPY_BEAT = 9
/** On the way home the value settles into L3, then L2, then L1. */
export const COPY_DROPS: { level: string; at: number }[] = [
  { level: 'l3', at: 0.52 },
  { level: 'l2', at: 0.66 },
  { level: 'l1', at: 0.8 },
]

// ---- the fill / displacement sequence -------------------------------------------
/** b12 — the program asks for other values. Each is fetched and kept, and the
 *  learner watches L1's slots occupy one after another. */
export const FILL_ARRIVALS: { value: string; at: number }[] = [
  { value: 'v2', at: 0.3 },
  { value: 'v3', at: 0.68 },
]

/** b13 — one more value arrives at an L1 that has no free slot.
 *
 *  STAGING CONSTRAINT (binding). The FACT of displacement is shown; the
 *  SELECTION is not, and must not be inferable:
 *    · `victim` is v2 — the MIDDLE occupant. Not the oldest (would read as
 *      FIFO), not the least-recently-used (would read as LRU), not the leftmost
 *      or rightmost (would read as a positional rule).
 *    · the victim's slot index is not correlated with arrival order on screen.
 *    · no counter, age marker, timestamp or usage tally is ever rendered.
 *    · narration states the fact and never asks "which one?" — the question
 *      must form in the learner, not on screen.
 */
export const DISPLACE_BEAT = 12
export const DISPLACE = { incoming: 'v4', victim: 'v2', at: 0.55 }

/** b14 — the program wants the displaced value back. It is gone. */
export const RECALL = { value: 'v2' }

/** Which values L1 holds at the START of each beat (order = slot order). */
export const L1_AT_BEAT: Record<number, string[]> = {
  7: [], 8: [], 9: [], 10: ['v1'], 11: ['v1'],
  12: ['v1', 'v2', 'v3'],
  13: ['v1', 'v4', 'v3'], // v2 is gone; v4 took a slot
  14: ['v1', 'v4', 'v3'], // the long trip runs again
  15: ['v1', 'v2', 'v3'], // v2 came home, displacing v4 in turn
  16: ['v1', 'v2', 'v3'],
}

/** Deeper levels keep the first value throughout (they are larger). */
export const DEEP_AT_BEAT: Record<number, string[]> = {
  7: [], 8: [], 9: [], 10: ['v1'], 11: ['v1'],
  12: ['v1', 'v2'], 13: ['v1', 'v2'], 14: ['v1', 'v2'],
  15: ['v1', 'v2'], 16: ['v1', 'v2'],
}

/** L1 contents at (beat, fraction) — mid-beat arrivals and the displacement. */
export function l1Contents(bi: number, lin: number): (string | null)[] {
  const base = (L1_AT_BEAT[bi] ?? []).slice()
  if (bi === COPY_BEAT) {
    const drop = COPY_DROPS.find((d) => d.level === 'l1')!
    return lin >= drop.at ? ['v1'] : []
  }
  if (bi === 11) {
    const out = ['v1']
    for (const a of FILL_ARRIVALS) if (lin >= a.at) out.push(a.value)
    return out
  }
  if (bi === 12) {
    if (lin < DISPLACE.at) return ['v1', 'v2', 'v3']
    return ['v1', DISPLACE.incoming, 'v3']
  }
  if (bi === 14) {
    // the recalled value comes home and takes the newcomer's place in turn
    return lin >= 0.78 ? ['v1', 'v2', 'v3'] : ['v1', 'v4', 'v3']
  }
  return base
}

export function deepContents(bi: number, lin: number): string[] {
  if (bi === COPY_BEAT) {
    return lin >= COPY_DROPS[0].at ? ['v1'] : []
  }
  return DEEP_AT_BEAT[bi] ?? []
}

/** Scene-B beats where the core genuinely cannot proceed. */
export const STALL_BEATS_LADDER = [8, 9, 13, 14]
export const CORE_WORK_FROM: Record<number, number> = {
  7: 0, 9: 0.9, 10: 0.72, 11: 0, 12: 0, 14: 0.82, 15: 0, 16: 0,
}
export const coreWorkingLadder = (bi: number, lin: number): boolean => {
  const from = CORE_WORK_FROM[bi]
  return from !== undefined && lin >= from
}
export const coreStalledLadder = (bi: number, lin: number): boolean =>
  STALL_BEATS_LADDER.includes(bi) && !coreWorkingLadder(bi, lin)

/** The beat that answers "why not one giant cache?" */
export const SIZE_BEAT = 15

// =============================================================================
// The Scene-B strip — one continuous timeline, same instrument as Scene A
// =============================================================================
// Green where work happens, red where the CPU waits. The learner reads the
// whole of Scene B as one stretch of time: a long red miss, a green run of
// hits, then red RETURNING after the displaced value is asked for again.
export const RUN_B: SlotKind[] = [
  'wait', 'wait', 'wait', 'wait', 'wait', 'wait', // 0-5   the level walk + long haul
  'exec', 'exec', 'exec', //                        6-8   the hit: work flows
  'wait', 'wait', //                               9-10  fetching other values
  'exec', 'exec', 'exec', //                       11-13
  'wait', 'wait', //                               14-15 one more value
  'exec', 'exec', //                               16-17 still fast
  'wait', 'wait', 'wait', 'wait', 'wait', 'wait', //18-23 the recall: waiting is BACK
  'exec', 'exec', 'exec', 'exec', //               24-27
]

export const FILL_B_AT_BEAT: Record<number, [number, number]> = {
  7: [0, 0], //   the ladder is revealed; the board is empty
  8: [0, 4], //   the walk
  9: [4, 6], //   the long haul + copy back
  10: [6, 9], //  the hit — green
  11: [9, 14], // other values: short waits, work between
  12: [14, 18], // the fourth value arrives, something is displaced
  13: [18, 21], // the recall misses — red returns
  14: [21, 24], // the long trip again
  15: [24, 26],
  16: [26, 28],
}

export const cellsFilledB = (bi: number, lin: number): number =>
  spanFill(FILL_B_AT_BEAT, bi, lin, 16, RUN_B.length)

/** Verdict pills sit ON the strip, labelling the exact cells they describe.
 *  Each appears only after its run of cells has been laid down. */
export interface Verdict {
  label: string
  from: number
  to: number
  beat: number
  at: number
  kind: 'miss' | 'hit'
}
export const VERDICTS: Verdict[] = [
  { label: 'Cache Miss', from: 0, to: 5, beat: 9, at: 0.68, kind: 'miss' },
  { label: 'Cache Hit', from: 6, to: 8, beat: 10, at: 0.6, kind: 'hit' },
  { label: 'Cache Miss', from: 18, to: 23, beat: 14, at: 0.45, kind: 'miss' },
]

// =============================================================================
// On-canvas text — plain description only, never a question
// =============================================================================
export const STRIP_CAPTION: { en: string; vi: string } = {
  en: 'same job, same amount of work',
  vi: 'bài toán như nhau, xem tốn bao nhiêu ô',
}
export const STRIP_B_CAPTION: { en: string; vi: string } = {
  en: 'green = running, red = stalled',
  vi: 'xanh là CPU đang chạy, đỏ là đang ngồi chờ',
}
export const RUN_LABEL_SLOW: { en: string; vi: string } = {
  en: 'no cache yet',
  vi: 'chưa có cache',
}
export const RUN_LABEL_FAST: { en: string; vi: string } = {
  en: 'now with cache',
  vi: 'lần này có cache',
}
export const RATIO_LABEL: { en: string; vi: string } = { en: 'running', vi: 'chạy được' }
export const RATIO_LABEL_WAIT: { en: string; vi: string } = { en: 'waiting', vi: 'bị chờ' }

export const SIZE_CAPTION: Record<string, { en: string; vi: string }> = {
  l1: { en: 'smallest, closest, fastest', vi: 'nhỏ nhất, gần nhất, nhanh nhất' },
  l2: { en: 'bigger, sits a step further out', vi: 'to hơn một chút, cũng xa hơn một chút' },
  l3: { en: 'largest of the three, furthest out', vi: 'to nhất trong ba, nhưng cũng xa nhất' },
}

export const PROBE_ASK: { en: string; vi: string } = { en: 'got it?', vi: 'mày có không?' }
export const PROBE_NO: { en: string; vi: string } = { en: 'nope', vi: 'không có đây' }
export const PROBE_YES: { en: string; vi: string } = { en: 'yes!', vi: 'có, lấy đây!' }

export const STALL_TEXT: { en: string; vi: string } = {
  en: 'waiting on memory',
  vi: 'đứng chờ, chưa có dữ liệu',
}
export const ASK_TEXT: { en: string; vi: string } = {
  en: 'Every single request goes all the way out there?',
  vi: 'Hỏi gì cũng phải chạy ra tận RAM sao?',
}
/** Shown on the emptied slot at the moment of displacement. States the fact of
 *  absence — deliberately NOT a question, and carries no reason. */
export const GONE_TEXT: { en: string; vi: string } = { en: 'evicted', vi: 'bị đá ra rồi' }
export const FULL_TEXT: { en: string; vi: string } = { en: 'full!', vi: 'hết chỗ rồi!' }
