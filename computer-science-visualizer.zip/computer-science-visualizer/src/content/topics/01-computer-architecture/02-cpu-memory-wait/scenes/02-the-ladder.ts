// scenes/02-the-ladder.ts — Scene B geometry: the memory ladder.
//
// The same horizontal axis as Scene A (Orientation Preservation §17): the CPU
// stays on the west, RAM stays far east. What changes is that the road between
// them is now resolved into rungs — L1, L2, L3 — and the learner can SEE why
// they are ordered that way: each rung is drawn further from the CPU and larger
// than the one before it.
//
// Every rung position is accumulated from M.RUNGS (box widths + gaps), so the
// distances the learner reads off the screen are literally the numbers in the
// metrics table. No coordinate is eyeballed.

import * as M from './metrics'
import type { Vec2 } from '../../../../../chapter-loader/types'
import type { PartSpec } from '../types'

export interface Rung {
  id: string
  pos: Vec2
  w: number
  h: number
  west: number
  east: number
  /** How many values this level can hold (0 for CPU / RAM). */
  slots: number
}

// ---- accumulate the rungs west → east -------------------------------------------
function buildRungs(): Rung[] {
  const out: Rung[] = []
  let cursor = M.LADDER_START_X
  for (const spec of M.RUNGS) {
    const west = cursor + spec.gapBefore
    const pos: Vec2 = { x: west + spec.w / 2, y: M.LADDER_AXIS_Y }
    out.push({ id: spec.id, pos, w: spec.w, h: spec.h, west, east: west + spec.w, slots: spec.slots })
    cursor = west + spec.w
  }
  return out
}

export const RUNGS: Rung[] = buildRungs()
export const rungById = (id: string): Rung => RUNGS.find((r) => r.id === id) ?? RUNGS[0]

export const CPU_RUNG = rungById('cpu')
export const L1 = rungById('l1')
export const L2 = rungById('l2')
export const L3 = rungById('l3')
export const RAM_RUNG = rungById('ram')

/** The cache levels only, in check order (the renderers loop over this). */
export const LEVELS: Rung[] = [L1, L2, L3]

/** Where the protagonist STANDS when it visits a rung.
 *
 *  A rung's slot row is this chapter's educational evidence: the learner must be
 *  able to count occupied slots, watch one become empty, and see the displaced
 *  value leave. The spark is drawn last and has an opaque core, so a waypoint at
 *  a rung's centre hides exactly what the beat is about (Freeze Audit B1).
 *
 *  The dock is therefore derived OUTSIDE the rung's west face, one spark-radius
 *  clear, so the protagonist still reads as "arrived at this level" while the
 *  interior stays fully legible. Travel timing is unchanged: the dock lies on
 *  the same axis and on the same incoming link the spark already used. */
export const dockOf = (r: Rung): Vec2 => ({
  x: r.west - M.SPARK.dockGap,
  y: M.LADDER_AXIS_Y,
})
export const L1_DOCK = dockOf(L1)
export const L2_DOCK = dockOf(L2)
export const L3_DOCK = dockOf(L3)

/** Link segments between consecutive rungs — each is its own drawn path, because
 *  each is a physically distinct hop the request actually makes (§2.1). */
export const LINKS: [Vec2, Vec2][] = RUNGS.slice(0, -1).map((r, i) => [
  { x: r.east, y: M.LADDER_AXIS_Y },
  { x: RUNGS[i + 1].west, y: M.LADDER_AXIS_Y },
])

// ---- protagonist waypoints -------------------------------------------------------
// Phase 5 (the miss) walks the whole ladder out and back. Phase 6 (the hit)
// travels only to L1 and returns — and the learner can measure the difference
// with their eyes, because it is the same path on the same axis.
export const PATH_B: Vec2[] = [
  CPU_RUNG.pos, // 0  the core (b7: the ladder is revealed, spark rests here)
  L1_DOCK, //      1  check L1 (b8)
  L2_DOCK, //      2  check L2
  L3_DOCK, //      3  check L3
  RAM_RUNG.pos, // 4  only RAM has it (b9 haul)
  L3_DOCK, //      5  the value comes home, leaving a copy behind (b9)
  L2_DOCK, //      6
  L1_DOCK, //      7
  CPU_RUNG.pos, // 8  execution resumes (b9 ends)
  L1_DOCK, //      9  the second request: L1 answers immediately (b10)
  CPU_RUNG.pos, //10  straight back — no RAM trip at all (b10 ends)
  L1_DOCK, //     11  the box fills, then displaces (b11-b13 rest here)
  RAM_RUNG.pos, //12  the recall misses: the long trip runs AGAIN (b14)
  L1_DOCK, //     13  the value comes home a second time
  CPU_RUNG.pos, //14  work resumes (b14 ends)
  CPU_RUNG.pos, //15  dup — b15/b16 rest here (sizes, recap)
]

// ---- scene bbox derived from content + clip inset ----------------------------------
const TALLEST = Math.max(...M.RUNGS.map((r) => r.h))
const CONTENT_MIN_X = Math.min(CPU_RUNG.west, M.STRIP_B.x)
const CONTENT_MAX_X = Math.max(RAM_RUNG.east, M.STRIP_B.x + M.STRIP_B.w)
// north: the probe badge floats above the tallest rung; south: the meter floor,
// plus the size bars that hang under the cache rungs.
const CONTENT_MIN_Y = M.LADDER_AXIS_Y - TALLEST / 2 + M.PROBE.dy - M.PROBE.h
export const BBOX_LADDER = {
  minX: CONTENT_MIN_X - M.CLIP_INSET,
  maxX: CONTENT_MAX_X + M.CLIP_INSET,
  minY: CONTENT_MIN_Y - M.CLIP_INSET,
  maxY: M.STRIP_B.y + M.STRIP_B.h + M.CLIP_INSET,
}

// ---- the entities -------------------------------------------------------------------
const levelGloss = (
  en: string,
  vi: string,
): { en: string; vi: string } => ({ en, vi })

export const cpuRung: PartSpec = {
  id: 'cpu-rung',
  kind: 'proc-core',
  pos: CPU_RUNG.pos,
  color: '#fb923c',
  name: 'CPU',
  gloss: levelGloss(
    'Still the same processor. Every request starts here \u2014 and whatever it was in the middle of stops until the value comes back.',
    'Vẫn con CPU đó. Mọi yêu cầu đều xuất phát từ đây \u2014 và nó đang làm dở việc gì cũng phải dừng, chờ giá trị về mới chạy tiếp.',
  ),
}

export const l1: PartSpec = {
  id: 'l1',
  kind: 'cache-level',
  pos: L1.pos,
  color: '#22d3ee',
  name: 'L1 Cache',
  gloss: levelGloss(
    'The closest level to the CPU, and the first one checked \u2014 nothing is quicker to reach. It is also the smallest, which is the same reason: small is what makes it quick, and small is why it fills up first.',
    'Tầng sát CPU nhất, cũng là tầng được hỏi đầu tiên \u2014 không đâu tới nhanh bằng. Nó cũng nhỏ nhất, mà cũng chính vì thế: nhỏ nên mới nhanh, và nhỏ nên cũng đầy trước tiên.',
  ),
  extra: { rungId: 'l1', rank: 0 },
}

export const l2: PartSpec = {
  id: 'l2',
  kind: 'cache-level',
  pos: L2.pos,
  color: '#22d3ee',
  name: 'L2 Cache',
  gloss: levelGloss(
    'A step further out, a step larger. It holds more than L1, so it catches some of what L1 misses \u2014 but the trip there is longer.',
    'Lùi ra một nấc, và cũng lớn hơn một nấc. Chứa nhiều hơn L1 nên đỡ được mấy trường hợp L1 chịu thua \u2014 bù lại đi tới đó thì lâu hơn.',
  ),
  extra: { rungId: 'l2', rank: 1 },
}

export const l3: PartSpec = {
  id: 'l3',
  kind: 'cache-level',
  pos: L3.pos,
  color: '#22d3ee',
  name: 'L3 Cache',
  gloss: levelGloss(
    'The last stop before RAM. Largest of the three, and slowest of the three \u2014 and still nowhere near as slow as going all the way out.',
    'Chặng cuối trước khi ra RAM. Lớn nhất trong ba tầng, và cũng chậm nhất trong ba tầng \u2014 nhưng vẫn còn xa mới chậm bằng việc đi tuốt ra ngoài.',
  ),
  extra: { rungId: 'l3', rank: 2 },
}

export const ramRung: PartSpec = {
  id: 'ram-rung',
  kind: 'ram-bank',
  pos: RAM_RUNG.pos,
  color: '#a78bfa',
  name: 'RAM',
  gloss: levelGloss(
    'The far end of the ladder. Everything the program uses is kept here \u2014 which is why it dwarfs the boxes in front of it, and why the CPU only comes this far once everything nearer has come up empty.',
    'Đầu xa nhất của cái thang. Chương trình dùng gì thì đều nằm ở đây \u2014 nên nó lớn hơn hẳn mấy cái hộp phía trước, và nên CPU chỉ ra tới đây khi mấy chặng gần hơn đều không có.',
  ),
}

/** Labelless painter: links, probe badges, the copy-back, the round-trip meter. */
export const ladderStage: PartSpec = {
  id: 'ladder-stage',
  kind: 'ladder-stage',
  pos: { x: M.STRIP_B.x + M.STRIP_B.w / 2, y: M.STRIP_B.y + M.STRIP_B.h / 2 },
  color: '#22d3ee',
  name: '',
  gloss: { en: '', vi: '' },
}
