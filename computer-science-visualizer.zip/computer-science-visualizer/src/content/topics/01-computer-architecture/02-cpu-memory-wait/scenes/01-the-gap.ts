// scenes/01-the-gap.ts — Scene A geometry: the wide shot of the conflict.
//
// One horizontal axis. The CPU on the west, RAM far to the east, and the long
// road between them. Everything here is DERIVED from scenes/metrics.ts: the box
// faces, the bus endpoints, the protagonist's path and the scene bbox are all
// functions of named primitives (Layout Derivation Law — an inline literal
// coordinate is a defect).
//
// Continuity contract (CURRICULUM_GRAPH §3, chapter-01 → chapter-02): the CPU,
// RAM and the golden execution spark are carried over verbatim from Chapter 01,
// including their colours. The learner re-enters a world they already know.

import * as M from './metrics'
import type { Vec2 } from '../../../../../chapter-loader/types'
import type { PartSpec, Rect } from '../types'

// ---- the two machines on the axis ---------------------------------------------
export const CPU_POS: Vec2 = { x: M.CPU_X, y: M.AXIS_Y }
export const RAM_POS: Vec2 = { x: M.RAM_X, y: M.AXIS_Y }

/** Box faces (every connector terminates ON a face — Connection Identity §2.1). */
export const CPU_EAST = CPU_POS.x + M.CPU_BOX.w / 2
export const RAM_WEST = RAM_POS.x - M.RAM_BOX.w / 2

/** The Cache appears only in Phase 3 — close to the CPU, on the road to RAM. */
export const CACHE_POS: Vec2 = {
  x: CPU_EAST + M.CACHE_GAP + M.CACHE_BOX.w / 2,
  y: M.AXIS_Y,
}
export const CACHE_WEST = CACHE_POS.x - M.CACHE_BOX.w / 2
export const CACHE_EAST = CACHE_POS.x + M.CACHE_BOX.w / 2

/** Where the protagonist STANDS when it visits the near box.
 *
 *  The box's slot row is educational evidence — the learner must see the copy
 *  arrive and occupy a slot. The spark is drawn last and has an opaque core, so
 *  a waypoint at the box centre would hide it (Freeze Audit B1). The dock is
 *  derived one spark-radius west of the box face: the spark still reads as
 *  "arrived", and the interior stays legible. */
export const CACHE_DOCK: Vec2 = { x: CACHE_WEST - M.SPARK.dockGap, y: M.AXIS_Y }

// ---- the road: two structurally distinct segments ------------------------------
// Before the Cache exists the learner sees ONE road (CPU → RAM). After it is
// revealed the same space reads as two distinct links — a short one the CPU can
// reach quickly, and the long one it wants to avoid. Both are painted by the
// `gap-stage` renderer (not by static infrastructure) so the reveal can animate.
export const BUS_FROM: Vec2 = { x: CPU_EAST, y: M.AXIS_Y }
export const BUS_TO: Vec2 = { x: RAM_WEST, y: M.AXIS_Y }
export const NEAR_LINK: [Vec2, Vec2] = [BUS_FROM, { x: CACHE_WEST, y: M.AXIS_Y }]
export const FAR_LINK: [Vec2, Vec2] = [{ x: CACHE_EAST, y: M.AXIS_Y }, BUS_TO]

// ---- protagonist waypoints (the spark = the CPU's forward progress) ------------
// The spark IS the CPU getting work done. When the CPU must go out to memory the
// spark itself leaves the core — which is why, while it is away, the core sits
// visibly dark. Nothing is moving forward. That is the whole antagonist.
const OUT: Vec2 = { x: CPU_EAST + M.BREATH, y: M.AXIS_Y }
const DOOR: Vec2 = { x: RAM_WEST - M.BREATH, y: M.AXIS_Y }

export const PATH_A: Vec2[] = [
  CPU_POS, //   0  the core, executing (b0)
  OUT, //       1  out through the east face (b1)
  DOOR, //      2  the long haul east (b1 ends here)
  RAM_POS, //   3  RAM: the value is found (b2 — the CPU is dark meanwhile)
  DOOR, //      4  dup — the value starts home (b3)
  OUT, //       5
  CPU_POS, //   6  back in the core; one instruction moves (b3 ends)
  OUT, //       7  and it happens again (b4)
  DOOR, //      8
  RAM_POS, //   9
  DOOR, //     10
  OUT, //      11
  CPU_POS, //  12  home again (b4 ends; b5 + b6 rest here)
  CACHE_DOCK, //13  the short trip to the new box (b5 ends / b6)
  CPU_POS, //  14  and straight back (b7 ends — the seam into Scene B)
]

// ---- scene bbox derived from content + clip inset -------------------------------
// West: the CPU box face. East: the RAM box face. North: the stall badge that
// pops above the CPU. South: the execution strip's floor.
const CONTENT_MIN_X = Math.min(CPU_POS.x - M.CPU_BOX.w / 2, M.STRIP_A.x)
const CONTENT_MAX_X = Math.max(RAM_POS.x + M.RAM_BOX.w / 2, M.STRIP_A.x + M.STRIP_A.w)
const CONTENT_MIN_Y = M.AXIS_Y - M.CPU_BOX.h / 2 + M.STALL.dy - M.STALL.h
export const BBOX_GAP = {
  minX: CONTENT_MIN_X - M.CLIP_INSET,
  maxX: CONTENT_MAX_X + M.CLIP_INSET,
  minY: CONTENT_MIN_Y - M.CLIP_INSET,
  maxY: M.STRIP_A.y + M.STRIP_A.h + M.CLIP_INSET,
}

// ---- hit zone: the learner starts the CPU ---------------------------------------
export const CPU_RECT: Rect = {
  x: CPU_POS.x - M.CPU_BOX.w / 2,
  y: CPU_POS.y - M.CPU_BOX.h / 2,
  w: M.CPU_BOX.w,
  h: M.CPU_BOX.h,
}

// ---- the entities ----------------------------------------------------------------
export const cpu: PartSpec = {
  id: 'cpu',
  kind: 'proc-core',
  pos: CPU_POS,
  color: '#fb923c',
  name: 'CPU',
  gloss: {
    en: 'The same processor from Chapter 1. It gets through an enormous number of instructions in the time you blink \u2014 so long as the next value it needs is already close by.',
    vi: 'Vẫn con CPU ở Chapter 1. Một cái chớp mắt là nó chạy xong cả đống lệnh, miễn là giá trị nó cần đã nằm sẵn đâu đó gần bên.',
  },
}

export const ram: PartSpec = {
  id: 'ram',
  kind: 'ram-bank',
  pos: RAM_POS,
  color: '#a78bfa',
  name: 'RAM',
  gloss: {
    en: 'The working memory you already know. It holds far more than any cache, and it answers everything it is asked \u2014 just never as fast as the CPU would like.',
    vi: 'Bộ nhớ làm việc bạn đã biết. Nó chứa nhiều hơn hẳn mấy cái cache, và hỏi gì nó cũng trả lời \u2014 chỉ là không bao giờ kịp tốc độ CPU muốn.',
  },
}

export const cache: PartSpec = {
  id: 'cache',
  kind: 'cache-box',
  pos: CACHE_POS,
  color: '#22d3ee',
  name: 'Cache',
  gloss: {
    en: 'A small, very fast store sitting right beside the CPU. Not extra memory \u2014 everything inside is a copy of something that is still in RAM as well. Keeping it close is what saves the trip.',
    vi: 'Một kho nhỏ mà rất nhanh, nằm sát ngay CPU. Không phải bộ nhớ gắn thêm \u2014 mọi thứ bên trong đều là bản sao của thứ vẫn còn trong RAM. Nhờ để gần mà đỡ được cả chuyến đi.',
  },
}

/** Labelless painter: the links, the travelling request, the execution strip. */
export const gapStage: PartSpec = {
  id: 'gap-stage',
  kind: 'gap-stage',
  pos: { x: M.STRIP_A.x + M.STRIP_A.w / 2, y: M.STRIP_A.y + M.STRIP_A.h / 2 },
  color: '#fb923c',
  name: '',
  gloss: { en: '', vi: '' },
}
