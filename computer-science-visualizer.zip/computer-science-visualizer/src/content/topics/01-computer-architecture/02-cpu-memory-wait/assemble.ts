// content/topics/01-computer-architecture/02-cpu-memory-wait/assemble.ts
// The full declarative assembly of Topic 01 Chapter 02 — everything except the
// meta import. Kept meta-free so the chapter can be built and verified outside
// Vite's asset pipeline (mirrors Ch-02/Ch-03's assemble.ts).

import type {
  Chapter,
  ChapterMeta,
  EntityDescription,
  HitZone,
  SceneDescription,
  Vec2,
} from '../../../../chapter-loader/types'

import {
  BBOX_GAP, PATH_A, CPU_RECT, CPU_POS, CACHE_DOCK,
  cpu, ram, cache, gapStage,
} from './scenes/01-the-gap'
import {
  BBOX_LADDER, PATH_B, CPU_RUNG, L1,
  cpuRung, l1, l2, l3, ramRung, ladderStage,
} from './scenes/02-the-ladder'
import { beats } from './narration/beats'
import {
  chapterTitle, waitingLine, startButton, sceneTag, tipText, doneLabel,
} from './narration/labels'
import type { PartSpec } from './types'
import { RENDERERS } from './renderers'

// ---- helpers ----------------------------------------------------------------
const toEntity = (
  p: PartSpec,
  sceneId: string,
  extra?: Record<string, unknown>,
): EntityDescription => ({
  id: p.id,
  kind: p.kind ?? p.id,
  pos: p.pos,
  color: p.color,
  name: p.name,
  gloss: p.gloss,
  scene: sceneId,
  extra: { ...p.extra, ...extra },
  labelSize: p.labelSize,
})

// ---- scene A: the gap between a fast CPU and slow RAM -------------------------
// Only three named things exist here, because only three are needed to make the
// conflict visible: the processor that wants to continue, the memory that
// cannot answer fast enough, and (later) the small box between them.
const gapScene: SceneDescription = {
  id: 'gap',
  bbox: BBOX_GAP,
  cameraPad: 0.94,
  path: PATH_A,
  entities: [
    toEntity(gapStage, 'gap'),
    toEntity(cpu, 'gap'),
    toEntity(cache, 'gap'),
    toEntity(ram, 'gap'),
  ],
}

// ---- scene B: the memory ladder -------------------------------------------------
// Same axis, same protagonist, same two endpoints — the space between them is
// simply resolved into its steps (Orientation Preservation §17).
const ladderScene: SceneDescription = {
  id: 'ladder',
  bbox: BBOX_LADDER,
  cameraPad: 0.95,
  path: PATH_B,
  entities: [
    toEntity(ladderStage, 'ladder'),
    toEntity(cpuRung, 'ladder'),
    toEntity(l1, 'ladder'),
    toEntity(l2, 'ladder'),
    toEntity(l3, 'ladder'),
    toEntity(ramRung, 'ladder'),
  ],
}

// ---- hit zone (the learner starts the processor) ----------------------------------
const hitZones: HitZone[] = [
  {
    id: 'cpu-box',
    hits: (w: Vec2) =>
      w.x >= CPU_RECT.x &&
      w.x <= CPU_RECT.x + CPU_RECT.w &&
      w.y >= CPU_RECT.y &&
      w.y <= CPU_RECT.y + CPU_RECT.h,
  },
]

// ---- the assembled Chapter ----------------------------------------------------------
export function assembleChapter(m: ChapterMeta): Chapter {
  return {
    meta: m,
    scenes: [gapScene, ladderScene],
    timeline: {
      beats,
      fadeDuration: 450,
    },
    hitZones,
    runtime: {
      // The spark holds at the near box's DOCK while fading out of `gap` and at
      // the CPU rung while fading out of `ladder`, so the protagonist stays
      // traceable across the seam (§13) without covering the box interior.
      seamPosition: (scene: string): Vec2 | null => {
        if (scene === 'gap') return CACHE_DOCK
        if (scene === 'ladder') return CPU_RUNG.pos
        return null
      },
    },
    ui: {
      chapterTitle,
      waitingLine,
      startButton,
      sceneTag,
      tipText,
      doneLabel,
    },
    entityRenderers: RENDERERS,
  }
}

// re-exported for tooling / future revisions
export { CPU_POS, L1 }
