// content/topics/01-computer-architecture/02-cpu-memory-wait/renderers.ts
//
// Chapter entity renderers. LAYOUT-SYSTEM DRIVEN: every coordinate is a named
// metric (scenes/metrics.ts) or a value derived in scenes/layout.ts from a
// container rect + measured text. No eyeballed pixel arithmetic lives in this
// file — only named specs, formulas of specs, loop indices, alpha bounds and
// colours (Layout Derivation Law).
//
// Every renderer is a pure function of (PresentationState, entity.extra): all
// beat-driven content derives from s.beatIndex / s.beatElapsed, so scrubbing,
// pausing and stepping backwards stay deterministic (VISUAL_LANGUAGE §15).
//
// SCOPE LOCK (Chapter 03 boundary). Cache levels answer instantly and never
// display a search: no slot-by-slot sweep, no comparison animation, no ordering
// cue, no age or usage marker. The learner sees THAT a level answers and THAT a
// full level displaces something — never HOW either is decided.

import type { EntityRenderer } from '../../../../rendering/types'
import type { Vec2, Lang } from '../../../../chapter-loader/types'
import { rrPath, hexA } from '../../../../rendering/primitives/canvas-utils'
import { glow } from '../../../../rendering/primitives/glow'
import { drawName } from '../../../../rendering/primitives/text'
import { TAU, clamp, easeInOutCubic, lerp } from '../../../../shared/math'

import { beats } from './narration/beats'
import * as M from './scenes/metrics'
import * as L from './scenes/layout'
import { CACHE_POS, NEAR_LINK, FAR_LINK, BUS_FROM, BUS_TO } from './scenes/01-the-gap'
import {
  RUNGS as LADDER_RUNGS, RAM_RUNG, LINKS, rungById,
} from './scenes/02-the-ladder'
import * as S from './scenes/03-story'
import type { SlotKind } from './types'

// ---------------------------------------------------------------------------
// shared helpers
// ---------------------------------------------------------------------------
const DUR: Record<number, number> = Object.fromEntries(beats.map((b, i) => [i, b.duration]))
const beatFrac = (s: { beatIndex: number; beatElapsed: number }, bi = s.beatIndex) =>
  clamp(s.beatElapsed / (DUR[bi] ?? 3000), 0, 1)
const nameDy = (hh: number) => hh + M.LABEL_GAP

const COL = {
  exec: '#4ade80',
  wait: '#fb7185',
  cache: '#22d3ee',
  ram: '#a78bfa',
  dim: 'rgba(170,180,208,0.72)',
  panel: 'rgba(10,14,32,0.92)',
}

const inLadder = (s: { scene: string }) => s.scene === 'ladder'

function drawPill(
  ctx: CanvasRenderingContext2D,
  center: Vec2,
  text: string,
  font: string,
  padX: number,
  h: number,
  stroke: string,
  fill: string,
  textColor: string,
  alpha = 1,
) {
  if (alpha <= 0.01) return
  ctx.font = font
  const w = ctx.measureText(text).width + 2 * padX
  ctx.save()
  ctx.globalAlpha = alpha
  rrPath(ctx, center.x - w / 2, center.y - h / 2, w, h, h / 2)
  ctx.fillStyle = fill
  ctx.fill()
  ctx.strokeStyle = stroke
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.fillStyle = textColor
  ctx.font = font
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(text, center.x, center.y)
  ctx.restore()
}

/** One stored value, drawn identically wherever it lives. Distinguishable by
 *  shape + colour, and deliberately never labelled with an identity scheme. */
function drawValue(
  ctx: CanvasRenderingContext2D,
  center: Vec2,
  valueId: string,
  alpha: number,
  scale = 1,
) {
  if (alpha <= 0.01) return
  const v = S.valueById(valueId)
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.fillStyle = v.color
  ctx.font = `700 ${M.VALUE.size * scale}px ${M.FONT}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(v.glyph, center.x, center.y)
  ctx.restore()
}

// ===========================================================================
// PROC-CORE — the CPU. Bright while work completes, dark while stalled.
// ===========================================================================
export const drawProcCore: EntityRenderer = (ctx, s, e, active) => {
  const bi = s.beatIndex
  const lin = beatFrac(s)
  const working = inLadder(s) ? S.coreWorkingLadder(bi, lin) : S.cpuWorking(bi, lin)
  const stalled =
    s.phase !== 'waiting' &&
    (inLadder(s) ? S.coreStalledLadder(bi, lin) : S.cpuStalled(bi, lin))

  const box = M.CPU_BOX
  const x = e.pos.x - box.w / 2
  const y = e.pos.y - box.h / 2

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.72
  if (working) glow(ctx, e.pos, e.color, 130, 0.42 + 0.12 * Math.sin(s.t * 0.01))
  else if (active) glow(ctx, e.pos, e.color, 110, 0.2)

  ctx.fillStyle = hexA(e.color, working ? 0.6 : 0.3)
  for (let i = 0; i < M.CPU_PINS.count; i++) {
    const fx = x + M.CPU_PINS.inset + (i / (M.CPU_PINS.count - 1)) * (box.w - 2 * M.CPU_PINS.inset)
    ctx.fillRect(fx - M.CPU_PINS.w / 2, y - M.CPU_PINS.len, M.CPU_PINS.w, M.CPU_PINS.len)
    ctx.fillRect(fx - M.CPU_PINS.w / 2, y + box.h, M.CPU_PINS.w, M.CPU_PINS.len)
    const fy = y + M.CPU_PINS.inset + (i / (M.CPU_PINS.count - 1)) * (box.h - 2 * M.CPU_PINS.inset)
    ctx.fillRect(x - M.CPU_PINS.len, fy - M.CPU_PINS.w / 2, M.CPU_PINS.len, M.CPU_PINS.w)
    ctx.fillRect(x + box.w, fy - M.CPU_PINS.w / 2, M.CPU_PINS.len, M.CPU_PINS.w)
  }

  rrPath(ctx, x, y, box.w, box.h, box.r)
  ctx.fillStyle = hexA(e.color, working ? 0.2 : 0.09)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, working ? 0.95 : 0.42)
  ctx.lineWidth = 2.5
  ctx.stroke()

  const c = M.CPU_CORE
  rrPath(ctx, e.pos.x - c.half, e.pos.y - c.half, c.half * 2, c.half * 2, c.r)
  if (working) {
    const g = ctx.createRadialGradient(e.pos.x, e.pos.y, 2, e.pos.x, e.pos.y, c.half)
    g.addColorStop(0, hexA('#fff3c0', 0.95))
    g.addColorStop(1, hexA(e.color, 0.22))
    ctx.fillStyle = g
  } else {
    ctx.fillStyle = 'rgba(28,34,62,0.9)'
  }
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, working ? 0.95 : 0.35)
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.restore()

  if (stalled && s.phase !== 'waiting' && s.fading === 'none') {
    const pos: Vec2 = { x: e.pos.x, y: e.pos.y - box.h / 2 + M.STALL.dy }
    const pulse = 0.55 + 0.35 * Math.sin(s.t * 0.006)
    drawPill(
      ctx, pos, S.STALL_TEXT[s.lang as Lang],
      `700 ${M.F.probe}px ${M.FONT}`, M.STALL.padX, M.STALL.h,
      hexA(COL.wait, pulse + 0.2), 'rgba(12,16,36,0.94)', hexA('#fecdd3', 0.95),
    )
  }

  drawName(ctx, e.pos, e.name, e.color, active || working, nameDy(box.h / 2), M.F.partName)
}

// ===========================================================================
// RAM-BANK — the largest object in the chapter. Its dense cell grid, against a
// cache level's 3-5 countable slots, carries the size relationship visually.
// ===========================================================================
export const drawRamBank: EntityRenderer = (ctx, s, e, active) => {
  const bi = s.beatIndex
  const lin = beatFrac(s)
  const box = inLadder(s) ? { w: RAM_RUNG.w, h: RAM_RUNG.h } : { w: M.RAM_BOX.w, h: M.RAM_BOX.h }
  const x = e.pos.x - box.w / 2
  const y = e.pos.y - box.h / 2
  const dSpark = Math.hypot(s.sparkPos.x - e.pos.x, s.sparkPos.y - e.pos.y)
  const busy = clamp(1 - dSpark / (box.w * 1.2), 0, 1)

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.6
  if (active) glow(ctx, e.pos, e.color, 150, 0.32 + 0.1 * Math.sin(s.t * 0.004))
  if (busy > 0.02) glow(ctx, e.pos, e.color, 160, 0.28 * busy)

  rrPath(ctx, x, y, box.w, box.h, M.RAM_BOX.r)
  ctx.fillStyle = hexA(e.color, active ? 0.16 : 0.09)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.95 : 0.45)
  ctx.lineWidth = 2
  ctx.stroke()

  // the dense grid: RAM_CELL_COUNT cells, always visible, always countable
  const g = M.RAM_GRID
  for (let row = 0; row < g.rows; row++) {
    for (let col = 0; col < g.cols; col++) {
      const r = L.ramCellRect(e.pos, col, row)
      const isTarget = col === M.RAM_TARGET.col && row === M.RAM_TARGET.row
      // the ONE cell the request targets — a value lives somewhere specific.
      // No numbering, no decomposition: only "it has a place".
      const targetLit = isTarget && (busy > 0.05 || (inLadder(s) && bi >= S.RAM_TRIP_BEAT))
      ctx.fillStyle = targetLit
        ? hexA('#facc15', 0.55 + 0.4 * Math.sin(s.t * 0.008))
        : hexA(e.color, active ? 0.42 : 0.26)
      ctx.fillRect(r.x, r.y, r.w, r.h)
    }
  }

  // the original stays in RAM after the copy leaves (cache holds COPIES)
  const showOriginal = inLadder(s)
    ? bi >= S.RAM_TRIP_BEAT
    : S.cacheHoldsA(bi, lin)
  if (showOriginal) {
    const t = L.ramCellRect(e.pos, M.RAM_TARGET.col, M.RAM_TARGET.row)
    drawValue(ctx, { x: t.x + t.w / 2, y: t.y + t.h / 2 }, 'v1', 0.95, 0.8)
  }
  ctx.restore()
  drawName(ctx, e.pos, e.name, e.color, active, nameDy(box.h / 2), M.F.partName)
}

// ===========================================================================
// CACHE-BOX — Scene A's near box. It is drawn with countable slots and it
// visibly RECEIVES a copy before it ever answers: never a magic container.
// ===========================================================================
export const drawCacheBox: EntityRenderer = (ctx, s, e, active) => {
  const bi = s.beatIndex
  const lin = beatFrac(s)
  let appear = 0
  if (bi > S.CACHE_REVEAL_BEAT) appear = 1
  else if (bi === S.CACHE_REVEAL_BEAT) appear = easeInOutCubic(clamp(lin / 0.32, 0, 1))
  if (appear <= 0.01) return

  const box = M.CACHE_BOX
  const x = e.pos.x - box.w / 2
  const y = e.pos.y - box.h / 2
  const holds = S.cacheHoldsA(bi, lin)

  ctx.save()
  ctx.globalAlpha = appear * (active ? 1 : 0.78)
  ctx.translate(e.pos.x, e.pos.y)
  ctx.scale(lerp(0.7, 1, appear), lerp(0.7, 1, appear))
  ctx.translate(-e.pos.x, -e.pos.y)
  if (active) glow(ctx, e.pos, e.color, 120, 0.4 + 0.12 * Math.sin(s.t * 0.008))

  rrPath(ctx, x, y, box.w, box.h, box.r)
  ctx.fillStyle = hexA(e.color, active ? 0.2 : 0.11)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.95 : 0.5)
  ctx.lineWidth = 2.5
  ctx.stroke()

  // countable slots — capacity is visible from first contact
  for (let i = 0; i < L.CACHE_A_SLOTS; i++) {
    const r = L.cacheSlotRect(i)
    rrPath(ctx, r.x, r.y, r.w, r.h, M.SLOT.r)
    ctx.fillStyle = hexA(e.color, 0.14)
    ctx.fill()
    ctx.strokeStyle = hexA(e.color, 0.42)
    ctx.lineWidth = 1.3
    ctx.stroke()
    if (holds && i === 0) {
      drawValue(ctx, { x: r.x + r.w / 2, y: r.y + r.h / 2 }, 'v1', 1)
    }
  }
  ctx.restore()

  // the copy travelling in from RAM during b6 — the box is SEEN to be filled
  if (bi === S.CACHE_REVEAL_BEAT) {
    const f = clamp((lin - 0.16) / (S.COPY_IN_AT - 0.16), 0, 1)
    if (f > 0.01 && f < 1) {
      const from: Vec2 = { x: BUS_TO.x, y: M.AXIS_Y }
      const slot = L.cacheSlotRect(0)
      const to: Vec2 = { x: slot.x + slot.w / 2, y: slot.y + slot.h / 2 }
      const p = easeInOutCubic(f)
      drawValue(ctx, { x: lerp(from.x, to.x, p), y: lerp(from.y, to.y, p) }, 'v1', 1, 1.1)
    }
  }

  const named = bi > S.CACHE_REVEAL_BEAT
  ctx.save()
  ctx.globalAlpha = appear
  drawName(ctx, e.pos, named ? e.name : '', e.color, active, nameDy(box.h / 2), M.F.cacheName)
  ctx.restore()
}

// ===========================================================================
// GAP-STAGE — Scene A's labelless painter: the road, the question pill, and
// the two-row execution strip.
// ===========================================================================
export const drawGapStage: EntityRenderer = (ctx, s, _e, _active) => {
  const bi = s.beatIndex
  const lin = beatFrac(s)
  const split = bi >= S.SPLIT_LINK_FROM_BEAT

  ctx.save()

  const drawLink = (a: Vec2, b: Vec2, hot: number, color: string) => {
    ctx.save()
    ctx.lineCap = 'round'
    if (hot > 0.02) {
      ctx.shadowColor = color
      ctx.shadowBlur = 16 * hot
    }
    ctx.strokeStyle = hexA(color, 0.22 + 0.6 * hot)
    ctx.lineWidth = M.BUS.width + (M.BUS.activeWidth - M.BUS.width) * hot
    if (hot > 0.3) {
      ctx.setLineDash(M.BUS.dash)
      ctx.lineDashOffset = -s.t * 0.06
    }
    ctx.beginPath()
    ctx.moveTo(a.x, a.y)
    ctx.lineTo(b.x, b.y)
    ctx.stroke()
    ctx.setLineDash([])
    ctx.restore()
  }
  const sparkOn = (a: Vec2, b: Vec2) => {
    const x = s.sparkPos.x
    if (x < Math.min(a.x, b.x) - M.BREATH || x > Math.max(a.x, b.x) + M.BREATH) return 0
    return s.sparkScale > 0.05 ? 1 : 0
  }

  if (!split) {
    drawLink(BUS_FROM, BUS_TO, sparkOn(BUS_FROM, BUS_TO), COL.ram)
  } else {
    drawLink(NEAR_LINK[0], NEAR_LINK[1], sparkOn(NEAR_LINK[0], NEAR_LINK[1]), COL.cache)
    drawLink(FAR_LINK[0], FAR_LINK[1], sparkOn(FAR_LINK[0], FAR_LINK[1]), COL.ram)
  }

  if (S.ASK_BEATS.includes(bi)) {
    const a = easeInOutCubic(clamp((lin - 0.3) / 0.3, 0, 1))
    drawPill(
      ctx, L.ASK_POS, S.ASK_TEXT[s.lang as Lang],
      `800 ${M.F.question}px ${M.FONT}`, M.ASK.padX, M.ASK.h,
      hexA('#facc15', 0.9), 'rgba(12,16,36,0.95)', '#facc15', a,
    )
  }

  drawStripA(ctx, s, bi, lin)
  ctx.restore()
}

/** Shared cell painter: empty slot = structure, filled block = state. */
function paintCells(
  ctx: CanvasRenderingContext2D,
  spec: L.StripSpec,
  row: number,
  kinds: SlotKind[],
  filled: number,
  t: number,
  dim: number,
) {
  for (let i = 0; i < kinds.length; i++) {
    const r = L.cellRect(spec, row, i)
    rrPath(ctx, r.x, r.y, r.w, r.h, M.CELL.r)
    ctx.fillStyle = 'rgba(255,255,255,0.03)'
    ctx.fill()
    ctx.strokeStyle = 'rgba(226,232,240,0.12)'
    ctx.lineWidth = 1
    ctx.stroke()
    const grow = clamp(filled - i, 0, 1)
    if (grow <= 0.01) continue
    const h = r.h * easeInOutCubic(grow)
    const color = kinds[i] === 'exec' ? COL.exec : COL.wait
    rrPath(ctx, r.x, r.y + r.h - h, r.w, h, M.CELL.r)
    ctx.fillStyle = hexA(color, (kinds[i] === 'exec' ? 0.85 : 0.42) * dim)
    ctx.fill()
    ctx.strokeStyle = hexA(color, 0.95 * dim)
    ctx.lineWidth = 1.4
    ctx.stroke()
    if (grow < 1) {
      ctx.strokeStyle = hexA(color, 0.4 + 0.4 * Math.sin(t * 0.01))
      ctx.lineWidth = 2.4
      ctx.stroke()
    }
  }
}

function drawRatio(
  ctx: CanvasRenderingContext2D,
  spec: L.StripSpec,
  row: number,
  kinds: SlotKind[],
  lang: Lang,
  alpha: number,
) {
  if (alpha <= 0.01) return
  const bar = L.ratioBar(spec, row)
  const execN = kinds.filter((k) => k === 'exec').length
  const waitN = kinds.length - execN
  ctx.save()
  ctx.globalAlpha = alpha
  rrPath(ctx, bar.x, bar.y, bar.w, bar.h, M.RATIO.r)
  ctx.fillStyle = hexA(COL.wait, 0.34)
  ctx.fill()
  ctx.strokeStyle = hexA(COL.wait, 0.7)
  ctx.lineWidth = 1.3
  ctx.stroke()
  rrPath(ctx, bar.x, bar.y, bar.w * (execN / kinds.length), bar.h, M.RATIO.r)
  ctx.fillStyle = hexA(COL.exec, 0.9)
  ctx.fill()
  ctx.font = `700 ${M.F.ratio}px ${M.FONT}`
  ctx.textBaseline = 'middle'
  ctx.textAlign = 'left'
  ctx.fillStyle = hexA(COL.exec, 0.95)
  ctx.fillText(`${execN} ${S.RATIO_LABEL[lang]}`, bar.x, bar.y + bar.h + M.RATIO.labelGap + M.F.ratio / 2)
  ctx.textAlign = 'right'
  ctx.fillStyle = hexA('#fecdd3', 0.95)
  ctx.fillText(`${waitN} ${S.RATIO_LABEL_WAIT[lang]}`, bar.x + bar.w, bar.y + bar.h + M.RATIO.labelGap + M.F.ratio / 2)
  ctx.restore()
}

/** Scene A's strip: the same stretch of time, run twice. */
function drawStripA(
  ctx: CanvasRenderingContext2D,
  s: { t: number; lang: string },
  bi: number,
  lin: number,
) {
  const spec = M.STRIP_A as L.StripSpec
  const lang = s.lang as Lang
  ctx.save()
  rrPath(ctx, spec.x, spec.y, spec.w, spec.h, spec.r)
  ctx.fillStyle = COL.panel
  ctx.fill()
  ctx.strokeStyle = 'rgba(226,232,240,0.2)'
  ctx.lineWidth = 2
  ctx.stroke()

  const tag = L.stripTag(spec)
  ctx.fillStyle = COL.dim
  ctx.font = `700 ${M.F.stripTag}px ${M.FONT}`
  ctx.textAlign = 'left'
  ctx.textBaseline = 'middle'
  ctx.fillText(S.STRIP_CAPTION[lang], tag.x, tag.y)

  const act = S.activeRun(bi)
  const rowLabels = [S.RUN_LABEL_SLOW[lang], S.RUN_LABEL_FAST[lang]]
  const rowKinds = [S.RUN_SLOW, S.RUN_FAST]
  const rowFilled = [S.cellsFilled(bi, lin), S.fastCellsFilled(bi, lin)]

  for (let row = 0; row < spec.rows; row++) {
    // row 1's label only appears once that run begins — the second row is not
    // promised before it is earned
    if (row === 1 && rowFilled[1] <= 0) continue
    const lp = L.rowLabelPos(spec, row)
    ctx.fillStyle = act === row ? hexA('#e2e8f0', 0.95) : hexA('#aab4d0', 0.5)
    ctx.font = `700 ${M.F.runLabel}px ${M.FONT}`
    ctx.textAlign = 'left'
    ctx.textBaseline = 'middle'
    ctx.fillText(rowLabels[row], lp.x, lp.y)
    paintCells(ctx, spec, row, rowKinds[row], rowFilled[row], s.t, act === null || act === row ? 1 : 0.62)
  }

  // row 0's ratio: only while row 0 is the subject (it is replaced by the
  // direct two-row comparison once row 1 exists — one idea at a time)
  if (bi >= S.RATIO_FROM_BEAT && bi < 6) {
    drawRatio(ctx, spec, 0, S.RUN_SLOW, lang,
      easeInOutCubic(clamp(bi === S.RATIO_FROM_BEAT ? lin / 0.45 : 1, 0, 1)))
  }
  ctx.restore()
}

// ===========================================================================
// CACHE-LEVEL — one rung of the ladder. Slots are countable; occupancy is
// visible; a full level displaces. No search is ever depicted.
// ===========================================================================
export const drawCacheLevel: EntityRenderer = (ctx, s, e, active) => {
  const bi = s.beatIndex
  const lin = beatFrac(s)
  const rungId = String((e.extra ?? {}).rungId ?? 'l1')
  const rung = rungById(rungId)

  let appear = 1
  if (bi < S.LADDER_BEAT) appear = 0
  else if (bi === S.LADDER_BEAT) {
    const from = S.RUNG_REVEAL[rungId] ?? 0
    appear = easeInOutCubic(clamp((lin - from) / 0.16, 0, 1))
  }
  if (appear <= 0.01) return

  const probes = S.PROBE_BEATS[bi] ?? []
  const probe = probes.find((p) => p.level === rungId)
  const probing = !!probe && lin >= probe.from && lin <= probe.to
  const answered = !!probe && lin > probe.to

  // contents: L1 has the full fill/displace story; deeper levels hold the
  // values that passed through them (they are larger, so they keep more)
  const contents: (string | null)[] =
    rungId === 'l1' ? S.l1Contents(bi, lin) : S.deepContents(bi, lin)

  const x = rung.pos.x - rung.w / 2
  const y = rung.pos.y - rung.h / 2

  ctx.save()
  ctx.globalAlpha = appear * (active || probing ? 1 : 0.72)
  if (probing) glow(ctx, rung.pos, e.color, rung.w, 0.45 + 0.15 * Math.sin(s.t * 0.014))
  else if (active) glow(ctx, rung.pos, e.color, rung.w * 0.9, 0.28)
  else if (contents.length) glow(ctx, rung.pos, e.color, rung.w * 0.8, 0.16)

  rrPath(ctx, x, y, rung.w, rung.h, M.RUNG_R)
  ctx.fillStyle = hexA(e.color, probing ? 0.24 : contents.length ? 0.15 : 0.09)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, probing ? 1 : contents.length ? 0.78 : 0.45)
  ctx.lineWidth = probing ? 3 : 2
  ctx.stroke()

  // countable slots. A slot is empty (outline) or holds one value.
  const isFull = contents.filter(Boolean).length >= rung.slots
  for (let i = 0; i < rung.slots; i++) {
    const r = L.slotRect(rung.pos, rung.w, rung.slots, i)
    const held = contents[i] ?? null
    rrPath(ctx, r.x, r.y, r.w, r.h, M.SLOT.r)
    ctx.fillStyle = held ? hexA(e.color, 0.2) : hexA(e.color, 0.1)
    ctx.fill()
    ctx.strokeStyle = held ? hexA(e.color, 0.7) : hexA(e.color, 0.34)
    ctx.lineWidth = 1.3
    ctx.stroke()
    if (held) {
      const center = { x: r.x + r.w / 2, y: r.y + r.h / 2 }
      // the displaced slot flashes as its occupant leaves — the FACT of
      // displacement. No cue indicates why this slot and not another.
      let a = 1
      if (bi === S.DISPLACE_BEAT && rungId === 'l1' && held === S.DISPLACE.incoming) {
        a = clamp((lin - S.DISPLACE.at) / 0.12, 0, 1)
      }
      drawValue(ctx, center, held, a)
    }
  }

  // "no free slot" — stated on the box at the moment it becomes true
  if (bi === S.DISPLACE_BEAT && rungId === 'l1' && isFull) {
    const a = lin < S.DISPLACE.at
      ? easeInOutCubic(clamp((lin - 0.16) / 0.2, 0, 1))
      : clamp(1 - (lin - S.DISPLACE.at) / 0.2, 0, 1)
    drawPill(
      ctx, L.probePos(rung), S.FULL_TEXT[s.lang as Lang],
      `800 ${M.F.probe}px ${M.FONT}`, M.PROBE.padX, M.PROBE.h,
      hexA('#fbbf24', 0.95), 'rgba(12,16,36,0.95)', '#fbbf24', a * appear,
    )
  }
  ctx.restore()

  // probe badge — the level ANSWERS; it is never shown searching
  if (probing || answered) {
    const pos = L.probePos(rung)
    const text = probing
      ? S.PROBE_ASK[s.lang as Lang]
      : probe!.found ? S.PROBE_YES[s.lang as Lang] : S.PROBE_NO[s.lang as Lang]
    const color = probing ? '#facc15' : probe!.found ? COL.exec : COL.wait
    const a = probing
      ? easeInOutCubic(clamp((lin - probe!.from) / 0.08, 0, 1))
      : clamp(1 - (lin - probe!.to) / 0.3, 0, 1)
    drawPill(
      ctx, pos, text, `800 ${M.F.probe}px ${M.FONT}`, M.PROBE.padX, M.PROBE.h,
      hexA(color, 0.95), 'rgba(12,16,36,0.95)', color, a * appear,
    )
  }

  // size bars — now explaining a limit the learner has already felt
  if (bi >= S.SIZE_BEAT) {
    const a = easeInOutCubic(clamp(bi === S.SIZE_BEAT ? (lin - 0.18) / 0.4 : 1, 0, 1))
    if (a > 0.01) {
      const bar = L.sizeBar(rung)
      ctx.save()
      ctx.globalAlpha = a * appear
      rrPath(ctx, bar.x, bar.y, bar.w, bar.h, M.SIZE_BAR.r)
      ctx.fillStyle = hexA(e.color, 0.55)
      ctx.fill()
      ctx.strokeStyle = hexA(e.color, 0.85)
      ctx.lineWidth = 1.2
      ctx.stroke()
      ctx.fillStyle = COL.dim
      ctx.font = `600 ${M.F.sizeTag}px ${M.FONT}`
      ctx.textAlign = 'center'
      ctx.textBaseline = 'top'
      ctx.fillText(S.SIZE_CAPTION[rungId][s.lang as Lang], rung.pos.x, bar.y + bar.h + M.BREATH)
      ctx.restore()
    }
  }

  const named = bi > S.LADDER_BEAT || lin >= S.NAME_AT
  ctx.save()
  ctx.globalAlpha = appear
  drawName(ctx, rung.pos, named ? e.name : '', e.color, active || probing, nameDy(rung.h / 2), M.F.cacheName)
  ctx.restore()
}

// ===========================================================================
// LADDER-STAGE — Scene B's labelless painter: rung links, the copy-back, the
// displaced value leaving, and the continuous execution strip.
// ===========================================================================
export const drawLadderStage: EntityRenderer = (ctx, s, _e, _active) => {
  const bi = s.beatIndex
  const lin = beatFrac(s)

  ctx.save()

  LINKS.forEach(([a, b], i) => {
    let appear = 1
    if (bi < S.LADDER_BEAT) appear = 0
    else if (bi === S.LADDER_BEAT) {
      const from = S.RUNG_REVEAL[LADDER_RUNGS[i + 1].id] ?? 0
      appear = easeInOutCubic(clamp((lin - from + 0.06) / 0.16, 0, 1))
    }
    if (appear <= 0.01) return
    const onIt =
      s.sparkScale > 0.05 &&
      s.sparkPos.x >= Math.min(a.x, b.x) - M.BREATH &&
      s.sparkPos.x <= Math.max(a.x, b.x) + M.BREATH
    const hot = onIt ? 1 : 0
    ctx.save()
    ctx.globalAlpha = appear
    ctx.lineCap = 'round'
    const color = i === LINKS.length - 1 ? COL.ram : COL.cache
    if (hot) {
      ctx.shadowColor = color
      ctx.shadowBlur = 16
    }
    ctx.strokeStyle = hexA(color, 0.22 + 0.62 * hot)
    ctx.lineWidth = M.BUS.width + (M.BUS.activeWidth - M.BUS.width) * hot
    if (hot) {
      ctx.setLineDash(M.BUS.dash)
      ctx.lineDashOffset = -s.t * 0.06
    }
    ctx.beginPath()
    ctx.moveTo(a.x, a.y)
    ctx.lineTo(b.x, b.y)
    ctx.stroke()
    ctx.setLineDash([])
    ctx.restore()
  })

  // copy rings as the value settles into each level on the way home
  if (bi === S.COPY_BEAT) {
    for (const drop of S.COPY_DROPS) {
      const rung = rungById(drop.level)
      const pop = clamp((lin - drop.at) / 0.1, 0, 1)
      if (pop <= 0.01 || pop >= 1) continue
      ctx.save()
      ctx.globalAlpha = 1 - pop
      ctx.strokeStyle = hexA('#facc15', 0.9)
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.arc(rung.pos.x, rung.pos.y, rung.w * 0.3 + rung.w * 0.35 * pop, 0, TAU)
      ctx.stroke()
      ctx.restore()
    }
  }

  // the displaced value drifts away and fades — the observable fact of loss.
  // It leaves downward, away from every path, so no direction implies a rule.
  if (bi === S.DISPLACE_BEAT) {
    const f = clamp((lin - S.DISPLACE.at) / 0.3, 0, 1)
    if (f > 0.01 && f < 1) {
      const l1 = rungById('l1')
      const slotIdx = 1
      const r = L.slotRect(l1.pos, l1.w, l1.slots, slotIdx)
      const from: Vec2 = { x: r.x + r.w / 2, y: r.y + r.h / 2 }
      // The victim leaves UPWARD, out through the top of the box: the name
      // label sits below the rung and the glyph must never cross it. Rising
      // also keeps the exit clear of every travel path, so no direction of
      // departure can be read as an ordering rule.
      const rise = l1.h / 2 + M.LABEL_GAP + M.VALUE.size
      const pos: Vec2 = { x: from.x, y: from.y - rise * easeInOutCubic(f) }
      drawValue(ctx, pos, S.DISPLACE.victim, 1 - f, 1 - 0.3 * f)
      ctx.save()
      ctx.globalAlpha = (1 - f) * 0.85
      ctx.fillStyle = hexA('#fecdd3', 0.9)
      ctx.font = `700 ${M.F.sizeTag}px ${M.FONT}`
      ctx.textAlign = 'left'
      ctx.textBaseline = 'middle'
      ctx.fillText(S.GONE_TEXT[s.lang as Lang], pos.x + M.VALUE.size, pos.y)
      ctx.restore()
    }
  }

  drawStripB(ctx, s, bi, lin)
  ctx.restore()
}

/** Scene B's strip: one continuous timeline. Red returning after green is the
 *  chapter's closing evidence that cache success is conditional. */
function drawStripB(
  ctx: CanvasRenderingContext2D,
  s: { t: number; lang: string },
  bi: number,
  lin: number,
) {
  if (bi < S.LADDER_BEAT) return
  const spec = M.STRIP_B as L.StripSpec
  const lang = s.lang as Lang

  ctx.save()
  rrPath(ctx, spec.x, spec.y, spec.w, spec.h, spec.r)
  ctx.fillStyle = COL.panel
  ctx.fill()
  ctx.strokeStyle = 'rgba(226,232,240,0.2)'
  ctx.lineWidth = 2
  ctx.stroke()

  const tag = L.stripTag(spec)
  ctx.fillStyle = COL.dim
  ctx.font = `700 ${M.F.stripTag}px ${M.FONT}`
  ctx.textAlign = 'left'
  ctx.textBaseline = 'middle'
  ctx.fillText(S.STRIP_B_CAPTION[lang], tag.x, tag.y)

  paintCells(ctx, spec, 0, S.RUN_B, S.cellsFilledB(bi, lin), s.t, 1)

  // verdict pills label the exact cells they describe, once those cells exist
  for (const v of S.VERDICTS) {
    const shown = bi > v.beat || (bi === v.beat && lin >= v.at)
    if (!shown) continue
    const a = bi === v.beat ? easeInOutCubic(clamp((lin - v.at) / 0.16, 0, 1)) : 1
    const color = v.kind === 'hit' ? COL.exec : COL.wait
    drawPill(
      ctx, L.verdictPos(spec, 0, v.from, v.to), v.label,
      `800 ${M.F.verdict}px ${M.FONT}`, M.VERDICT.padX, M.VERDICT.h,
      hexA(color, 0.95), 'rgba(12,16,36,0.95)', color, a,
    )
  }
  ctx.restore()
}

export const RENDERERS = {
  'proc-core': drawProcCore,
  'ram-bank': drawRamBank,
  'cache-box': drawCacheBox,
  'gap-stage': drawGapStage,
  'cache-level': drawCacheLevel,
  'ladder-stage': drawLadderStage,
}

export { CACHE_POS }
