// scenes/metrics.ts — Topic 01 Chapter 04 layout *primitives*: every bare
// number the geometry and the renderers use, named exactly once. PURE — no
// imports — so scene geometry and the derived layout system build on it
// without cycles.
//
// Doctrine (docs/constitution/VISUAL_LANGUAGE.md §2.2 Derivable Geometry, and
// docs/pipeline/02_PRODUCTION_LIFECYCLE.md Layout Derivation Law): an inline
// literal coordinate is a defect. Every drawn coordinate must be a named metric
// or a function of a container rect + measured text.
//
// CONTINUITY (CURRICULUM_GRAPH §2.3 + owner spec): the `entry` scene re-enters
// the Chapter-02/03 memory ladder verbatim — same axis, same rung order, same
// sizes, same gaps, same colours — so the learner re-enters the remembered
// world unchanged (Orientation Preservation §17). New to this chapter: the
// program list panel, the completion counter, and the instruction card.

// ---- global spacing scale -----------------------------------------------------
export const BREATH = 8 // min text↔edge / text↔text breathing (world units)
export const CLIP_INSET = 14 // min content inset from a scene bbox edge
export const LABEL_GAP = 12 // gap between a box edge and its name label
export const LABEL_TEXT_H = 20 // approx cap-height of a name label (for bbox math)

// ---- canvas font families (single source, same as Chapters 02/03) -------------
export const FONT = "'Quicksand', system-ui, sans-serif"
export const MONO = "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace"

// ---- type scale (world px) — one named size per role, never a literal --------
export const F = {
  partName: 19,
  panelTitle: 22,
  termPill: 21,
  question: 24,
  verdict: 20,
  counter: 17,
  chip: 16,
  sub: 14,
  small: 13,
  tiny: 11,
}

// ==============================================================================
// THE MACHINE CLOCK — one tick = one station hop = one beat of the machine
// ==============================================================================
/** Real time of one machine tick (ms). The whole floor's rhythm derives from
 *  this single constant (PEDAGOGICAL_SYSTEM §4.5: the counter, the cards and
 *  the narration all read the same TICK). */
export const TICK = 1600
/** How many stations the working floor has. */
export const STATIONS = 5
/** The tick at which the very first completion lands (row r0's journey end). */
export const FIRST_COMPLETE_TICK = 5

// ==============================================================================
// SCENE `entry` — the remembered Topic-01 world (mirrors Chapter 02/03 scene B)
// ==============================================================================
export const AXIS_Y = 372
export const LADDER_START_X = 120
export const CPU_BOX = { w: 196, h: 168, r: 18 }
export const RAM_BOX = { w: 280, h: 240, r: 16 }
export const RUNG_R = 14
export interface RungSpec {
  id: string
  w: number
  h: number
  gapBefore: number
  slots: number
}
export const RUNGS: RungSpec[] = [
  { id: 'cpu', w: CPU_BOX.w, h: CPU_BOX.h, gapBefore: 0, slots: 0 },
  { id: 'l1', w: 132, h: 92, gapBefore: 104, slots: 3 },
  { id: 'l2', w: 176, h: 116, gapBefore: 148, slots: 4 },
  { id: 'l3', w: 224, h: 142, gapBefore: 196, slots: 5 },
  { id: 'ram', w: RAM_BOX.w, h: RAM_BOX.h, gapBefore: 300, slots: 0 },
]
export const SLOT = { padX: 13, gap: 7, h: 30, r: 5 }
export const CPU_PINS = { count: 5, len: 11, w: 4, inset: 26 }
export const CPU_CORE = { half: 34, r: 8 }
export const RAM_GRID = { cols: 16, rows: 12, cell: 9, gap: 4 }
export const VALUE = { size: 15, ring: 13 }
export const SPARK = { r: 44, dockGap: 44 + BREATH }
export const BUS = { width: 5, activeWidth: 7, dash: [2, 16] }

// ---- the program list panel (HUD north of the CPU) -----------------------------
export const LIST_PANEL = { w: 224, r: 16, titleH: 36, padX: 16, padY: 12 }
export const LIST_ROW = { h: 24, gap: 2 }
/** Rows visible inside the list panel at once (derives LIST_PANEL.h below). */
export const LIST_ROWS_VISIBLE = 6
/** Total rows in the program (the "long list"). */
export const PROGRAM_ROWS = 50

// ---- the completion counter (the chapter's evidence board) ----------------------
export const COUNTER_PANEL = { w: 214, h: 92, r: 16, padX: 18 }
export const COUNTER_NUM = { size: 40 }

// ---- the die-scale instruction card + completion flash --------------------------
export const MINI_CARD = { w: 96, h: 48, r: 9 }
export const FLASH = { r: 64, ring: 3.5 }

// ==============================================================================
// SCENE `floor` — the working floor inside the CPU
// ==============================================================================
export const PANEL = { x: 340, y: 196, r: 22 }
export const STATION = { w: 176, h: 158, r: 18 }
export const STATION_GAP = 34
export const PANEL_PAD = { x: 28, top: 30, bottom: 24 }
/** The plain-language sub-label zone under each station's locked term. */
export const STATION_SUB = { h: 32, gap: 4 }
/** The station label band: locked term over plain sub (both inside the panel). */
export const STATION_LABEL_H = 20 + STATION_SUB.gap + STATION_SUB.h

export const ROW_INNER_W = STATIONS * STATION.w + (STATIONS - 1) * STATION_GAP
export const PANEL_W = 2 * PANEL_PAD.x + ROW_INNER_W
export const PANEL_H = PANEL_PAD.top + STATION.h + STATION_LABEL_H + PANEL_PAD.bottom

// ---- the instruction card that travels the floor --------------------------------
export const CARD = { w: 108, h: 52, r: 10 }
export const CARD_STRIP = { h: 7 } // op-colour strip on the card top
export const CARD_STAR = { r: 9, dy: -34 } // golden ★ above the watched card

// ---- the docks ------------------------------------------------------------------
export const LIST_FLOOR = { x: 56, y: 190, w: 216, r: 16, titleH: 36, padX: 14, padY: 10 }
export const LIST_FLOOR_ROWS_VISIBLE = 9
export const COUNTER_FLOOR = { x: PANEL.x + PANEL_W + 44, y: 108, w: 222, h: 96, r: 16, padX: 18 }
export const REG_DOCK = { w: 140, h: 80, r: 14, padX: 12 }
export const L1_DOCK = { w: 116, h: 64, r: 12, dy: 58 }
export const ORIENT = { h: 34, r: 17, padX: 16, gap: 14 }

// ---- lanes (distinct paths, Connection Identity §2.1) ---------------------------
export const LANE = { w: 4, arrow: 14 }
export const TRIP = { w: 4, dash: [3, 9] }

// ---- the completion ceremony -----------------------------------------------------
export const DONE_RING = { r: 60, ring: 3 }
export const CHIP = { r: 8 } // the result chip flying to the registers dock

// ---- the Pipeline term pill (the chapter's single term, after observation) ------
export const TERM = { h: 44, r: 22, padX: 22, gap: 18, maxW: 430 }

// ---- scene bounding boxes ---------------------------------------------------------
export const WORLD_H_PAD = 30 // horizontal air around the whole machine (horizon)
