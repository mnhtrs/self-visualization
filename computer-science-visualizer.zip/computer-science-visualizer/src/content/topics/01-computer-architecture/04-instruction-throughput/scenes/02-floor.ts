// scenes/02-floor.ts — the `floor` scene geometry: the working floor inside
// the CPU — the five stations, the docks (program list west, counter
// north-east, registers east, L1 below Memory), the orientation chip, and the
// protagonist’s continuous path. Every anchor derives from scenes/layout.ts
// (Layout Derivation Law).

import * as L from './layout'
import type { Vec2 } from '../../../../../chapter-loader/types'
import type { PartSpec } from '../types'

// ---- anchors ----------------------------------------------------------------
export const F = (): Vec2 => L.stationC(0)
export const D = (): Vec2 => L.stationC(1)
export const E = (): Vec2 => L.stationC(2)
export const M = (): Vec2 => L.stationC(3)
export const W = (): Vec2 => L.stationC(4)
export const LIST_HEAD: Vec2 = L.LIST_HEAD
export const REG_C: Vec2 = { x: L.REG.x + L.REG.w / 2, y: L.REG.y + L.REG.h / 2 }

// ---- entities ----------------------------------------------------------------
const procDock = L.procDockRect()
export const cpuDock: PartSpec = {
  id: 'cpu',
  kind: 'proc-dock',
  pos: { x: procDock.x + procDock.w / 2, y: procDock.y + procDock.h / 2 },
  color: '#fb923c',
  name: 'CPU',
  gloss: {
    en: 'The requester. It cannot see the floor from here — it only sends instructions in and receives completed work out.',
    vi: 'Bên gửi việc. Từ đây nó không nhìn thấy sàn — nó chỉ đưa lệnh vào và nhận kết quả đã xong trở ra.',
  },
}

export const floorStage: PartSpec = {
  id: 'floor',
  kind: 'floor-stage',
  pos: { x: L.PANEL.x + L.PANEL.w / 2, y: L.PANEL.y + 60 },
  color: '#22d3ee',
  name: 'working floor',
  gloss: {
    en: 'The floor inside the CPU — five stations, and every instruction passes through them in the same order.',
    vi: 'Sàn làm việc bên trong CPU — năm trạm, và mọi lệnh đều đi qua chúng theo cùng một thứ tự.',
  },
}

export const fetchDock: PartSpec = {
  id: 'fetch',
  kind: 'station-dock',
  pos: L.stationC(0),
  color: '#38bdf8',
  name: 'Fetch',
  gloss: {
    en: 'The station where an instruction enters the machine, straight from the program.',
    vi: 'Trạm nơi một lệnh bước vào cỗ máy, thẳng từ chương trình.',
  },
}

export const writeBackDock: PartSpec = {
  id: 'write-back',
  kind: 'station-dock',
  pos: L.stationC(4),
  color: '#4ade80',
  name: 'Write Back',
  gloss: {
    en: 'The last station — where a finished instruction leaves the floor.',
    vi: 'Trạm cuối — nơi một lệnh hoàn thành rời khỏi sàn.',
  },
}

export const listDock: PartSpec = {
  id: 'list',
  kind: 'program-list-floor',
  pos: { x: L.LIST.x + L.LIST.w / 2, y: L.LIST.y + 16 },
  color: '#e2e8f0',
  name: 'the program',
  gloss: {
    en: 'The program — the same long list. One instruction slides out of it into the machine at a time.',
    vi: 'Chương trình — vẫn danh sách dài ấy. Mỗi lần một lệnh trượt ra khỏi nó để vào cỗ máy.',
  },
}

export const counterDock: PartSpec = {
  id: 'counter',
  kind: 'completion-counter-floor',
  pos: { x: L.COUNTER.x + L.COUNTER.w / 2, y: L.COUNTER.y + 18 },
  color: '#4ade80',
  name: 'instructions completed',
  gloss: {
    en: 'The tally of finished instructions. Watch it — it has its own rhythm.',
    vi: 'Bộ đếm các lệnh đã hoàn thành. Hãy để ý nó — nó có nhịp riêng của mình.',
  },
}

export const regDock: PartSpec = {
  id: 'registers',
  kind: 'registers-dock',
  pos: REG_C,
  color: '#a78bfa',
  name: 'registers',
  gloss: {
    en: 'Where results land when an instruction finishes — the last stop of every completed instruction.',
    vi: 'Nơi kết quả hạ cánh khi một lệnh xong — điểm dừng cuối của mọi lệnh đã hoàn thành.',
  },
}

export const l1Dock: PartSpec = {
  id: 'l1',
  kind: 'l1-mini-dock',
  pos: { x: L.L1D.x + L.L1D.w / 2, y: L.L1D.y + L.L1D.h / 2 },
  color: '#22d3ee',
  name: 'L1 Cache',
  gloss: {
    en: 'The nearest cache level — a data request goes down here and comes back fast. You know this trip.',
    vi: 'Tầng cache gần nhất — một request dữ liệu đi xuống đây rồi quay về ngay. Bạn biết chuyến đi này rồi.',
  },
}

/** The labelless painter entity of the floor scene. */
export const floorStageEntity: PartSpec = floorStage

export const PATH_FLOOR: Vec2[] = L.PATH_FLOOR
export const BBOX_FLOOR = L.bboxFloor()
