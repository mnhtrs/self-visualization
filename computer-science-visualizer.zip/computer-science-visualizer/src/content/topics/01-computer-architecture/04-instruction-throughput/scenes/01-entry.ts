// scenes/01-entry.ts — the `entry` and `horizon` scene geometry: the whole
// Topic-01 world, assembled — CPU west, the remembered L1/L2/L3 ladder, RAM
// east, the program list above the CPU, the completion counter top-right.
// Everything DERIVES from scenes/metrics.ts + scenes/layout.ts primitives
// (Layout Derivation Law). The horizon reuses this exact world, running.

import * as L from './layout'
import * as M from './metrics'
import type { Vec2 } from '../../../../../chapter-loader/types'
import type { PartSpec } from '../types'

// ---- entities ----------------------------------------------------------------
export const cpu: PartSpec = {
  id: 'cpu',
  kind: 'proc-core',
  pos: L.CPU_RUNG.pos,
  color: '#fb923c',
  name: 'CPU',
  gloss: {
    en: 'The same processor we have known since the first chapter — the machine that turns instructions into completed work.',
    vi: 'Vẫn con CPU ta đã biết từ chương đầu tiên — cỗ máy biến các lệnh thành công việc đã hoàn thành.',
  },
}

const rungGloss = (en: string, vi: string) => ({ en, vi })

export const l1: PartSpec = {
  id: 'l1',
  kind: 'cache-rung',
  pos: L.L1_RUNG.pos,
  color: '#22d3ee',
  name: 'L1 Cache',
  gloss: rungGloss(
    'The nearest level — where the program’s instructions and its hottest data live closest to the CPU.',
    'Tầng gần nhất — nơi các lệnh của chương trình và dữ liệu nóng nhất sống gần CPU nhất.',
  ),
  extra: { rungId: 'l1' },
}

export const l2: PartSpec = {
  id: 'l2',
  kind: 'cache-rung',
  pos: L.L2_RUNG.pos,
  color: '#22d3ee',
  name: 'L2 Cache',
  gloss: rungGloss(
    'A step further out, a step larger — asked only when L1 comes up empty.',
    'Xa hơn một nấc, lớn hơn một nấc — chỉ bị hỏi khi L1 không có.',
  ),
  extra: { rungId: 'l2' },
}

export const l3: PartSpec = {
  id: 'l3',
  kind: 'cache-rung',
  pos: L.rungById('l3').pos,
  color: '#22d3ee',
  name: 'L3 Cache',
  gloss: rungGloss(
    'The last stop before RAM — largest and furthest of the three.',
    'Chặng cuối trước khi ra RAM — lớn nhất và xa nhất trong ba tầng.',
  ),
  extra: { rungId: 'l3' },
}

export const ram: PartSpec = {
  id: 'ram',
  kind: 'ram-bank',
  pos: L.RAM_RUNG.pos,
  color: '#a78bfa',
  name: 'RAM',
  gloss: rungGloss(
    'The far memory. Everything ultimately lives here — the caches only ever keep copies of a few things it lent out.',
    'Bộ nhớ xa. Mọi thứ cuối cùng đều nằm ở đây — cache chỉ giữ bản sao của vài thứ mượn từ nó.',
  ),
}

export const listPanel: PartSpec = {
  id: 'list',
  kind: 'program-list',
  pos: { x: L.listPanelRect().x + L.listPanelRect().w / 2, y: L.listPanelRect().y + 14 },
  color: '#e2e8f0',
  name: 'the program',
  gloss: {
    en: 'The program — every row is one instruction, waiting in order. The machine works through them one by one.',
    vi: 'Chương trình — mỗi dòng là một lệnh, xếp hàng theo thứ tự. Cỗ máy lần lượt làm từng lệnh.',
  },
}

export const counterPanel: PartSpec = {
  id: 'counter',
  kind: 'completion-counter',
  pos: { x: L.counterRect().x + L.counterRect().w / 2, y: L.counterRect().y + 18 },
  color: '#4ade80',
  name: 'instructions completed',
  gloss: {
    en: 'The tally of finished instructions — the machine’s evidence board.',
    vi: 'Bộ đếm các lệnh đã hoàn thành — bảng bằng chứng của cỗ máy.',
  },
}

/** Labelless painter: links, the fetch hops, the completion flashes, the
 *  horizon’s endless running state. */
export const entryStage: PartSpec = {
  id: 'entry-stage',
  kind: 'entry-stage',
  pos: { x: L.L1_RUNG.pos.x, y: M.AXIS_Y },
  color: '#22d3ee',
  name: '',
  gloss: { en: '', vi: '' },
}

/** The horizon’s labelless painter (same world, running forever). */
export const horizonStage: PartSpec = {
  id: 'horizon-stage',
  kind: 'horizon-stage',
  pos: { x: L.CPU_RUNG.pos.x, y: M.AXIS_Y },
  color: '#fb923c',
  name: '',
  gloss: { en: '', vi: '' },
}

export const PATH_ENTRY: Vec2[] = L.PATH_ENTRY
export const PATH_HORIZON: Vec2[] = L.PATH_HORIZON
export const BBOX_ENTRY = L.bboxEntry()
export const BBOX_HORIZON = L.bboxHorizon()
export const CPU_RECT = L.CPU_RECT
