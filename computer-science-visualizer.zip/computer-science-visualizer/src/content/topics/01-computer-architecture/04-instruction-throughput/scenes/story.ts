// scenes/story.ts — the single source of truth for every beat-driven fact:
// the program stream, the tick windows of every beat, the in-flight cards, the
// completions, the memory trips, the watched (golden) instruction, and all
// on-canvas captions. Everything is a pure function of (beatIndex, beatFrac),
// so scrubbing, pausing and stepping backwards stay deterministic
// (VISUAL_LANGUAGE §15).
//
// Quantity discipline (PEDAGOGICAL_SYSTEM §4.5): every number the narration
// speaks is DERIVED from the tables here — five stations (metrics STATIONS),
// five ticks per journey (the station count itself), one completion per tick
// (the TICK rhythm), the counter values (this file), the long list
// (PROGRAM_ROWS) — never typed twice.
//
// Affirmative-state discipline (§4.6): the floor being FULL is an affirmative
// predicate (floorFull), never the negation of "empty".
//
// THE MECHANICS (declared in 00_JOURNEY_DEFINITION.md §5): the stream issues
// exactly one instruction per tick, and every data request hits the nearest
// cache level — that is what makes the observed rhythm true and clean. Hazards,
// stalls, misses mid-flight, contention, processes/threads/cores are declared
// Deferred Internals and never depicted.

import * as M from './metrics'

// =============================================================================
// The program stream — 50 rows, the "long list"
// =============================================================================
export type Op = 'LOAD' | 'ADD' | 'STORE' | 'SUB' | 'CMP' | 'MOV'
export type ValueId = 'v1' | 'v2' | 'v3' | 'v4'

export interface InstrSpec {
  row: number // 1-based program row (its identity)
  op: Op
  /** The value glyph a LOAD brings home / a STORE carries out. */
  value?: ValueId
  /** The watched (golden) instruction. */
  marked?: boolean
}

export const OP_COLORS: Record<Op, string> = {
  LOAD: '#38bdf8',
  ADD: '#4ade80',
  STORE: '#f472b6',
  SUB: '#fbbf24',
  CMP: '#c084fc',
  MOV: '#94a3b8',
}

export const VALUES: Record<ValueId, { glyph: string; color: string }> = {
  v1: { glyph: '◆', color: '#facc15' },
  v2: { glyph: '▲', color: '#f472b6' },
  v3: { glyph: '■', color: '#4ade80' },
  v4: { glyph: '●', color: '#38bdf8' },
}

/** The program: rows 1–50. Rows 1–5 complete in the entry scene; row 6 is the
 *  first instruction to enter the floor (the watched one of the ramp); row 19
 *  is the watched instruction of the climax. */
const ROWS: [Op, ValueId?][] = [
  ['LOAD', 'v1'], ['ADD'], ['STORE', 'v2'], ['SUB'], ['CMP'],
  ['LOAD', 'v4'], ['ADD'], ['STORE', 'v1'], ['MOV'], ['SUB'],
  ['CMP'], ['LOAD', 'v2'], ['ADD'], ['STORE', 'v4'], ['MOV'],
  ['ADD'], ['CMP'], ['LOAD', 'v1'], ['ADD'], ['STORE', 'v2'],
  ['SUB'], ['CMP'], ['MOV'], ['LOAD', 'v4'], ['ADD'],
  ['STORE', 'v1'], ['SUB'], ['CMP'], ['MOV'], ['LOAD', 'v2'],
  ['ADD'], ['STORE', 'v4'], ['CMP'], ['SUB'], ['MOV'],
  ['LOAD', 'v1'], ['ADD'], ['STORE', 'v2'], ['CMP'], ['SUB'],
  ['MOV'], ['LOAD', 'v4'], ['ADD'], ['STORE', 'v1'], ['CMP'],
  ['SUB'], ['MOV'], ['LOAD', 'v2'], ['ADD'], ['STORE', 'v4'],
]

export const STREAM: InstrSpec[] = ROWS.map(([op, value], i) => ({
  row: i + 1,
  op,
  value,
  marked: i + 1 === 6 || i + 1 === 19,
}))

export const instrByRow = (row: number): InstrSpec =>
  STREAM[Math.max(0, Math.min(STREAM.length - 1, row - 1))]

/** The first row that enters the working floor (rows 1..r0-1 completed at die
 *  scale in the entry scene). */
export const FLOOR_FIRST_ROW = 6
/** The watched instruction of the climax. */
export const GOLDEN_ROW = 19

// =============================================================================
// The clock — global ticks
// =============================================================================
/** The FIRST global tick of each floor beat. */
export const TICKS_AT: Record<number, number> = {
  7: 0, // the floor reveal (no ticks yet)
  8: 1, // one-enters: ticks 1-2
  9: 3, // two-at-once: ticks 3-5
  10: 6, // filling: ticks 6-8
  11: 9, // the-rhythm: ticks 9-11
  12: 12, // watch-this-one: ticks 12-13
  13: 14, // climax: ticks 14-18
  14: 19, // glance-back: ticks 19-22
  15: 23, // the-name: ticks 23-26
  16: 27, // keep-running: ticks 27-30
}
/** How many ticks a floor beat spans. */
export const TICKS_IN: Record<number, number> = {
  8: 2,
  9: 3,
  10: 3,
  11: 3,
  12: 2,
  13: 5,
  14: 4,
  15: 4,
  16: 4,
}

/** The global tick at (beat, frac) for a floor beat. Clamped to the beat's
 *  last tick so the frac=1 instant never spills into a spurious next tick
 *  (the next beat's frac=0 continues from the exact same state — seamless). */
export function globalTick(beat: number, frac: number): number {
  const start = TICKS_AT[beat]
  const n = TICKS_IN[beat]
  if (start === undefined || n === undefined) return -1
  return Math.min(start + n - 1, start + Math.floor(frac * n))
}

/** Sub-tick fraction (0..1) for smooth card motion. */
export function subTick(beat: number, frac: number): number {
  const n = TICKS_IN[beat]
  if (n === undefined) return 0
  return Math.min(1, Math.max(0, frac * n - Math.floor(frac * n)))
}

/** The row that ENTERS Fetch at global tick t (row r0-1 + t). */
export const rowAtTick = (t: number): number => FLOOR_FIRST_ROW - 1 + t

/** Station index (0..4) of the row that entered at tick e, at tick t:
 *  F at e, D at e+1, …, W at e+4; completed after that. */
export function stationOf(entryTick: number, t: number): number | null {
  const s = t - entryTick
  if (s < 0 || s > M.STATIONS - 1) return null
  return s
}

/** How many instructions have COMPLETED by the end of global tick t. */
export function counterAt(t: number): number {
  if (t < M.FIRST_COMPLETE_TICK) return FLOOR_FIRST_ROW - 1
  return FLOOR_FIRST_ROW - 1 + (t - M.FIRST_COMPLETE_TICK + 1)
}

/** The completion tick of the row that entered at tick e. */
export const completeTickOf = (e: number): number => e + M.STATIONS - 1

/** The entry tick of the row that completes at tick t. */
export const entryTickOf = (t: number): number => t - M.STATIONS + 1

/** Affirmative predicate: is the floor FULL (all five stations occupied)? */
export function floorFull(t: number): boolean {
  // Row k is in flight during ticks [k-(r0-1), k-(r0-1)+4]; at tick t the rows
  // in flight are exactly t-(r0-1)+1 … t-(r0-1)+5 → all five stations occupied
  // iff t >= 5.
  return t >= M.FIRST_COMPLETE_TICK
}

/** The rows in flight at tick t, each with its station. */
export function inFlight(t: number): { row: number; station: number }[] {
  const out: { row: number; station: number }[] = []
  if (t < 1) return out
  for (let e = Math.max(1, t - M.STATIONS + 1); e <= t; e++) {
    const s = stationOf(e, t)
    if (s !== null) out.push({ row: rowAtTick(e), station: s })
  }
  return out
}

/** The watched row during each floor beat (the spark's card), if any. */
export function watchedRow(beat: number): number | null {
  if (beat === 8) return 6
  if (beat === 9) return 6
  if (beat === 12) return GOLDEN_ROW // waiting at the stream head
  if (beat === 13) return GOLDEN_ROW // crossing the floor
  return null
}

/** The watched card's exact position anchor index into PATH_FLOOR at (beat,
 *  frac): 0 = stream head, 1..5 = stations, 6 = registers. */
export function watchedAnchor(beat: number, frac: number): number {
  if (beat === 8) {
    const t = globalTick(beat, frac)
    const sub = subTick(beat, frac)
    if (t === 1) return sub < 0.45 ? 0 : 1
    return 2
  }
  if (beat === 9) {
    const t = globalTick(beat, frac)
    if (t === 3) return 3
    if (t === 4) return 4
    return 5
  }
  if (beat === 12) return 0
  if (beat === 13) {
    const t = globalTick(beat, frac)
    if (t === 14) return 1
    if (t === 15) return 2
    if (t === 16) return 3
    if (t === 17) return 4
    return 5 // tick 18: at Write Back, completing
  }
  return 0
}

// =============================================================================
// Per-tick events (derived, deterministic)
// =============================================================================
export interface CompletionEvent {
  tick: number
  row: number
}

/** Completions inside a floor beat: one per tick from tick 5 on. */
export function completionsIn(beat: number, frac: number): CompletionEvent[] {
  const start = TICKS_AT[beat]
  const n = TICKS_IN[beat]
  if (start === undefined || n === undefined) return []
  const until = start + Math.floor(frac * n)
  const out: CompletionEvent[] = []
  for (let t = Math.max(M.FIRST_COMPLETE_TICK, start); t <= until; t++) {
    out.push({ tick: t, row: rowAtTick(entryTickOf(t)) })
  }
  return out
}

export interface TripEvent {
  tick: number
  row: number
  op: 'LOAD' | 'STORE'
  value: ValueId
}

/** Memory trips inside a floor beat: the data glyph travels between the card
 *  at Memory and the L1 dock. LOAD rows carry no glyph until the trip lands. */
export function tripsIn(beat: number, frac: number): TripEvent[] {
  const start = TICKS_AT[beat]
  const n = TICKS_IN[beat]
  if (start === undefined || n === undefined) return []
  const until = start + Math.floor(frac * n)
  const out: TripEvent[] = []
  for (let t = Math.max(start, 1); t <= until; t++) {
    for (const f of inFlight(t)) {
      if (f.station !== 3) continue
      const ins = instrByRow(f.row)
      if (ins.op !== 'LOAD' && ins.op !== 'STORE') continue
      out.push({ tick: t, row: f.row, op: ins.op, value: ins.value ?? 'v1' })
    }
  }
  return out
}

// =============================================================================
// The entry scene — die-scale completions (rows 1..5, one per beat b1..b5)
// =============================================================================
export const DIE_BEATS: Record<number, number> = { 1: 1, 2: 2, 3: 3, 4: 4, 5: 5 }
export const DIE_COMPLETE_FRAC = 0.86

// =============================================================================
// The horizon — the machine running forever (s.t-driven loop)
// The accumulated duration of beats 0..16 is computed at runtime by the
// horizon renderer (sum of the beats array), never hard-typed.
// =============================================================================
/** The counter value the horizon continues from (counterAt(30) = 31). */
export const HORIZON_C0 = 31
/** The list pointer row the horizon starts from (rowAtTick(31) = 36). */
export const HORIZON_POINTER = 36

// ---- the horizon speed ramp: slow-motion viewing pace → real-speed feel ----
// The chapter watches the machine in slow motion (one tick = 1600 ms) so the
// eye can follow a single instruction. Once the model is fully established,
// the horizon lets the machine SPEED UP on screen — the tick shortens, the
// counter spins, the program list scrolls — so the learner finally FEELS the
// machine's rate. The canon is untouched: every tick still completes exactly
// one instruction; only the tick's real length changes.
export const H_TICK_SLOW = 1600 // ms per tick while we watch in slow motion
// The slow lead-in is deliberately short: just long enough to see the CPU reach
// L1 once (two slow ticks), then the machine snaps up to speed.
export const H_RAMP_START = 3200 // ms into the horizon: speed-up begins
export const H_RAMP_END = 5600 // ms into the horizon: max speed reached
export const H_TICK_FAST = 20 // ms per tick at max speed (50 ticks/s on screen)

/** The progress of the speed ramp (0 at H_RAMP_START, 1 at H_RAMP_END). */
function rampK(elapsed: number): number {
  return Math.min(1, Math.max(0, (elapsed - H_RAMP_START) / (H_RAMP_END - H_RAMP_START)))
}

/** Strong ease-out cubic: the tick collapses fast right after the lead-in, so
 *  the machine visibly *launches* rather than creeping up one number at a time. */
function easeOutCubic(k: number): number {
  return 1 - Math.pow(1 - k, 3)
}

/** The local tick length at `elapsed` ms into the horizon (non-linear ramp). */
export function horizonTickLen(elapsed: number): number {
  if (elapsed < H_RAMP_START) return H_TICK_SLOW
  if (elapsed >= H_RAMP_END) return H_TICK_FAST
  return H_TICK_SLOW - (H_TICK_SLOW - H_TICK_FAST) * easeOutCubic(rampK(elapsed))
}

/** The horizon's global tick count at `elapsed` ms (deterministic). The ramp is
 *  integrated numerically against the non-linear tick length so the counter and
 *  the fetch stream stay in lockstep with the visible acceleration. */
export function horizonTickAt(elapsed: number): number {
  if (elapsed <= 0) return 0
  const n1 = Math.floor(Math.min(elapsed, H_RAMP_START) / H_TICK_SLOW)
  if (elapsed <= H_RAMP_START) return n1
  const tEnd = Math.min(elapsed, H_RAMP_END)
  let ticks = n1
  const step = 4 // ms — cheap, exact enough for a smooth readout
  let tau = H_RAMP_START
  while (tau < tEnd) {
    const t1 = Math.min(tau + step, tEnd)
    const l0 = horizonTickLen(tau)
    const l1 = horizonTickLen(t1)
    ticks += (t1 - tau) / ((l0 + l1) / 2)
    tau = t1
  }
  const rampTicks = Math.floor(ticks)
  if (elapsed <= H_RAMP_END) return rampTicks
  return rampTicks + Math.floor((elapsed - H_RAMP_END) / H_TICK_FAST)
}

/** Which speed stage the horizon is in at `elapsed` ms. */
export function horizonStage(elapsed: number): 'slow' | 'ramp' | 'fast' {
  if (elapsed < H_RAMP_START) return 'slow'
  if (elapsed < H_RAMP_END) return 'ramp'
  return 'fast'
}

// =============================================================================
// Captions (bilingual, plain language)
// =============================================================================
export const CAP = {
  listTitle: { en: 'the program', vi: 'chương trình' },
  counter: { en: 'instructions completed', vi: 'lệnh đã hoàn thành' },
  counterStage: {
    slow: { en: 'slow motion', vi: 'quay chậm' },
    ramp: { en: 'speeding up…', vi: 'đang tăng tốc…' },
    fast: { en: 'still slow motion', vi: 'vẫn quay chậm' },
  },
  counterSub: { en: 'real speed ≈ 4 billion/s', vi: 'thật ≈ 4 tỷ lệnh/s' },
  orient: { en: 'inside the CPU', vi: 'bên trong CPU' },
  registers: { en: 'registers', vi: 'thanh ghi' },
  l1: { en: 'L1', vi: 'L1' },
  stationSubs: [
    { en: 'where the instruction enters', vi: 'nơi lệnh đi vào' },
    { en: 'the machine reads what it says', vi: 'máy đọc xem nó bảo gì' },
    { en: 'the calculation happens', vi: 'phép tính được thực hiện' },
    { en: 'data goes out, or comes back', vi: 'dữ liệu ra, hoặc quay về' },
    { en: 'the result is recorded', vi: 'kết quả được ghi lại' },
  ],
  done: { en: 'done', vi: 'xong' },
  me: { en: 'here', vi: 'có' },
}

export const TERM_PILL = {
  term: 'Pipeline',
  at: 0.5,
  sub: {
    en: 'every station busy, every tick',
    vi: 'mọi trạm luôn bận, mỗi nhịp một lệnh',
  },
}
