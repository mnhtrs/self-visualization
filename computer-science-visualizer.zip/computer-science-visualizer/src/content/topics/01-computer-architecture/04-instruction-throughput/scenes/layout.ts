// scenes/layout.ts — the derived *layout system* for Topic 01 Chapter 04.
// Every container interior the renderers draw into (the entry world's list and
// counter, the floor's stations, lanes, docks, cards, trips) is computed HERE
// from named metrics + container rects, so the renderers hold no eyeballed
// arithmetic (Layout Derivation Law).
//
// Imports metrics (pure) + nothing else; nothing imports this file back.

import * as M from './metrics'
import type { Vec2 } from '../../../../../chapter-loader/types'

// =============================================================================
// SCENE `entry` — the remembered world (same ladder primitives as Ch-02/03)
// =============================================================================
export interface Rung {
  id: string
  pos: Vec2
  w: number
  h: number
  west: number
  east: number
  slots: number
}

function buildRungs(): Rung[] {
  const out: Rung[] = []
  let cursor = M.LADDER_START_X
  for (const spec of M.RUNGS) {
    const west = cursor + spec.gapBefore
    const pos: Vec2 = { x: west + spec.w / 2, y: M.AXIS_Y }
    out.push({ id: spec.id, pos, w: spec.w, h: spec.h, west, east: west + spec.w, slots: spec.slots })
    cursor = west + spec.w
  }
  return out
}

export const RUNGS: Rung[] = buildRungs()
export const rungById = (id: string): Rung => RUNGS.find((r) => r.id === id) ?? RUNGS[0]
export const CPU_RUNG = rungById('cpu')
export const L1_RUNG = rungById('l1')
export const L2_RUNG = rungById('l2')
export const RAM_RUNG = rungById('ram')

/** The dock the spark hops to: a spark-radius clear of L1's west face. */
export const L1_DOCK: Vec2 = { x: L1_RUNG.west - M.SPARK.dockGap, y: M.AXIS_Y }

/** Link segments between consecutive rungs (each hop is its own path §2.1). */
export const LINKS: [Vec2, Vec2][] = RUNGS.slice(0, -1).map((r, i) => [
  { x: r.east, y: M.AXIS_Y },
  { x: RUNGS[i + 1].west, y: M.AXIS_Y },
])

/** The program list panel: centred above the CPU box (a HUD window into the
 *  program, whose bytes live in the memory hierarchy). Its height derives
 *  from the rows it must hold (PLATFORM_ENGINE §2.4). */
export const listPanelRect = () => {
  const h =
    M.LIST_PANEL.titleH
    + M.LIST_PANEL.padY
    + M.LIST_ROWS_VISIBLE * M.LIST_ROW.h
    + (M.LIST_ROWS_VISIBLE - 1) * M.LIST_ROW.gap
    + M.LIST_PANEL.padY
  return {
    x: CPU_RUNG.pos.x - M.LIST_PANEL.w / 2,
    y: CPU_RUNG.pos.y - CPU_RUNG.h / 2 - h - M.LABEL_GAP * 2,
    w: M.LIST_PANEL.w,
    h,
    r: M.LIST_PANEL.r,
  }
}

export const listRowY = (i: number): number => {
  const r = listPanelRect()
  return r.y + M.LIST_PANEL.titleH + M.LIST_PANEL.padY + i * (M.LIST_ROW.h + M.LIST_ROW.gap)
}

/** The completion counter: the evidence board, top-right over the RAM side. */
export const counterRect = () => ({
  x: RAM_RUNG.east - M.COUNTER_PANEL.w,
  y: M.AXIS_Y - M.RAM_BOX.h / 2 - M.COUNTER_PANEL.h - M.BREATH * 2,
  w: M.COUNTER_PANEL.w,
  h: M.COUNTER_PANEL.h,
  r: M.COUNTER_PANEL.r,
})

/** The protagonist's waypoints in the entry world. */
export const PATH_ENTRY: Vec2[] = [CPU_RUNG.pos, L1_DOCK, CPU_RUNG.pos]

/** The scene bbox — derived from content + clip inset. */
export const bboxEntry = () => {
  const lp = listPanelRect()
  const cp = counterRect()
  const minX = CPU_RUNG.west - M.CLIP_INSET
  const maxX = RAM_RUNG.east + M.CLIP_INSET
  const minY = Math.min(lp.y, cp.y) - M.CLIP_INSET
  const maxY = M.AXIS_Y + M.RAM_BOX.h / 2 + M.LABEL_GAP + M.LABEL_TEXT_H + M.CLIP_INSET
  return { minX, maxX, minY, maxY }
}

/** The hit zone: the CPU box (click to start, as in Ch-02/03). */
export const CPU_RECT = {
  x: CPU_RUNG.pos.x - CPU_RUNG.w / 2,
  y: CPU_RUNG.pos.y - CPU_RUNG.h / 2,
  w: CPU_RUNG.w,
  h: CPU_RUNG.h,
}

// =============================================================================
// SCENE `floor` — the working floor inside the CPU
// =============================================================================
export const PANEL = {
  x: M.PANEL.x,
  y: M.PANEL.y,
  w: M.PANEL_W,
  h: M.PANEL_H,
  r: M.PANEL.r,
}

/** Station box `i` (0..4 = Fetch, Decode, Execute, Memory, Write Back). */
export const stationRect = (i: number) => ({
  x: PANEL.x + M.PANEL_PAD.x + i * (M.STATION.w + M.STATION_GAP),
  y: PANEL.y + M.PANEL_PAD.top,
  w: M.STATION.w,
  h: M.STATION.h,
  r: M.STATION.r,
})

export const stationC = (i: number): Vec2 => {
  const r = stationRect(i)
  return { x: r.x + r.w / 2, y: r.y + r.h / 2 }
}

/** The vertical centre of the station row (lanes run along it). */
export const stationRowY = (): number => {
  const r0 = stationRect(0)
  return r0.y + r0.h / 2
}

/** The locked term baseline inside the label band of station `i`. */
export const stationTermY = (i: number): number => {
  const r = stationRect(i)
  return r.y + r.h + M.STATION_SUB.gap + M.STATION_LABEL_H / 2 - M.STATION_SUB.h / 2 - 2
}

/** The plain sub baseline of station `i`. */
export const stationSubY = (i: number): number => {
  const r = stationRect(i)
  return r.y + r.h + M.STATION_SUB.gap + M.STATION_LABEL_H / 2 + M.STATION_SUB.h / 2 - 4
}

/** Connector between station `i` and `i+1` (each lane is its own path §2.1). */
export const connector = (i: number): [Vec2, Vec2] => [
  { x: stationRect(i).x + stationRect(i).w, y: stationRowY() },
  { x: stationRect(i + 1).x, y: stationRowY() },
]

/** The instruction card centred on station `i`. */
export const cardAt = (i: number) => {
  const c = stationC(i)
  return { x: c.x - M.CARD.w / 2, y: c.y - M.CARD.h / 2, w: M.CARD.w, h: M.CARD.h, r: M.CARD.r }
}

// ---- the docks ----------------------------------------------------------------
/** The list dock's height derives from the rows it must hold (§2.4). */
export const LIST_H =
  M.LIST_FLOOR.titleH
  + M.LIST_FLOOR.padY
  + M.LIST_FLOOR_ROWS_VISIBLE * M.LIST_ROW.h
  + (M.LIST_FLOOR_ROWS_VISIBLE - 1) * M.LIST_ROW.gap
  + M.LIST_FLOOR.padY

/** The small CPU west of the list — the requester. Its position derives from
 *  the list dock (the machine's west side), never a literal. */
export const procDockRect = () => {
  const w = 92
  const h = 68
  return {
    x: LIST_POS.x + LIST_POS.w - w + 6,
    y: LIST_POS.y + LIST_H + 44 - h / 2,
    w,
    h,
    r: 12,
  }
}

export const LIST_POS = {
  x: M.LIST_FLOOR.x,
  y: M.LIST_FLOOR.y,
  w: M.LIST_FLOOR.w,
}

export const LIST = {
  x: LIST_POS.x,
  y: LIST_POS.y,
  w: LIST_POS.w,
  h: LIST_H,
  r: M.LIST_FLOOR.r,
}

export const listRowYF = (i: number): number =>
  LIST.y + M.LIST_FLOOR.titleH + M.LIST_FLOOR.padY + i * (M.LIST_ROW.h + M.LIST_ROW.gap)

/** The stream head: where the next instruction waits before sliding into Fetch. */
export const LIST_HEAD: Vec2 = { x: LIST.x + LIST.w + 64, y: stationRowY() }

/** The fetch lane: from the stream head to Fetch's west face. */
export const FETCH_LANE: [Vec2, Vec2] = [LIST_HEAD, { x: stationRect(0).x, y: stationRowY() }]

export const COUNTER = {
  x: M.COUNTER_FLOOR.x,
  y: M.COUNTER_FLOOR.y,
  w: M.COUNTER_FLOOR.w,
  h: M.COUNTER_FLOOR.h,
  r: M.COUNTER_FLOOR.r,
}

export const REG = {
  x: PANEL.x + PANEL.w + M.BREATH * 6,
  y: stationRowY() - M.REG_DOCK.h / 2,
  w: M.REG_DOCK.w,
  h: M.REG_DOCK.h,
  r: M.REG_DOCK.r,
}

/** The exit lane: Write Back's east face to the registers dock. */
export const EXIT_LANE: [Vec2, Vec2] = [
  { x: stationRect(M.STATIONS - 1).x + stationRect(M.STATIONS - 1).w, y: stationRowY() },
  { x: REG.x, y: stationRowY() },
]

/** The L1 dock under the Memory station (the data trip's destination). */
export const L1D = {
  x: stationC(3).x - M.L1_DOCK.w / 2,
  y: PANEL.y + PANEL.h + M.L1_DOCK.dy,
  w: M.L1_DOCK.w,
  h: M.L1_DOCK.h,
  r: M.L1_DOCK.r,
}

/** The data trip lane: Memory's bottom face down to L1 (distinct path §2.1). */
export const TRIP_LANE: [Vec2, Vec2] = [
  { x: stationC(3).x, y: stationRect(3).y + stationRect(3).h },
  { x: stationC(3).x, y: L1D.y },
]

/** The 'inside the CPU' orientation chip at the panel header's left edge. */
export const orientChip = (textW: number) => {
  const w = textW + 2 * M.ORIENT.padX
  return {
    x: PANEL.x + M.BREATH,
    y: PANEL.y - M.ORIENT.h - M.BREATH,
    w,
    h: M.ORIENT.h,
    r: M.ORIENT.r,
  }
}

/** The Pipeline term pill dock: south of the panel, below the L1 dock row —
 *  the pill (term + two sub lines) must stay inside the scene bbox. */
export const termDock = (): Vec2 => ({ x: PANEL.x + PANEL.w / 2, y: L1D.y + L1D.h + 74 })

/** The protagonist's waypoints through the floor. */
export const PATH_FLOOR: Vec2[] = [LIST_HEAD, stationC(0), stationC(1), stationC(2), stationC(3), stationC(4), REG]

/** The floor scene bbox — derived from content + clip inset. The south room
 *  covers the L1 dock, its label, and the Pipeline term pill with its sub. */
export const bboxFloor = () => {
  const minX = Math.min(LIST.x, PANEL.x) - M.CLIP_INSET
  const maxX = Math.max(COUNTER.x + COUNTER.w, REG.x + REG.w) + M.CLIP_INSET
  const minY = Math.min(COUNTER.y, PANEL.y - M.ORIENT.h - M.BREATH) - M.CLIP_INSET
  const maxY = L1D.y + L1D.h + 130 + M.CLIP_INSET
  return { minX, maxX, minY, maxY }
}

// =============================================================================
// SCENE `horizon` — the whole world again, running forever (entry framing)
// =============================================================================
/** The horizon's protagonist loop: core → L1 → core, at the chapter's own
 *  accelerating tick rate (runtime.loopPosition). */
export const PATH_HORIZON: Vec2[] = [CPU_RUNG.pos, L1_DOCK, CPU_RUNG.pos]
export const bboxHorizon = () => {
  const b = bboxEntry()
  return { ...b, minX: b.minX - M.WORLD_H_PAD, maxX: b.maxX + M.WORLD_H_PAD }
}
