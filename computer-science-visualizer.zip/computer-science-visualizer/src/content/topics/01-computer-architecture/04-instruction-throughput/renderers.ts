// content/topics/01-computer-architecture/04-instruction-throughput/renderers.ts
//
// Chapter renderer barrel. The painters themselves live in /renderers, split
// by scene family:
//   entry.ts  — the entry/horizon world (proc-core, cache-rung, ram-bank,
//               program-list, completion-counter, entry-stage, horizon-stage)
//   floor.ts  — the working floor (proc-dock, station-dock, program-list-floor,
//               completion-counter-floor, registers-dock, l1-mini-dock,
//               floor-stage)
//
// LAYOUT-SYSTEM DRIVEN: every coordinate in those files is a named metric
// (scenes/metrics.ts) or a value derived in scenes/layout.ts from a container
// rect + measured text (Layout Derivation Law). Every renderer is a pure
// function of (PresentationState, entity.extra): all beat-driven content
// derives from s.beatIndex / s.beatElapsed, so scrubbing, pausing and
// stepping backwards stay deterministic (VISUAL_LANGUAGE §15).
//
// SCOPE LOCK (owner directive + AGENT_BOOT forbidden list): nothing here draws
// hazards, stalls, dependency waits, misses mid-flight, contention, processes,
// threads, cores, coherence, superscalar/out-of-order, branch prediction, or
// any Throughput/Latency text. The chapter shows the FACT of instruction-level
// throughput — one instruction completing every tick while each still takes
// the same full journey — and nothing else.

import {
  drawProcCore, drawCacheRung, drawRamBank, drawProgramList, drawCompletionCounter,
  drawEntryStage, drawHorizonStage,
} from './renderers/entry'
import {
  drawProcDock, drawStationDock, drawProgramListFloor, drawCompletionCounterFloor,
  drawRegistersDock, drawL1MiniDock, drawFloorStage,
} from './renderers/floor'

export const RENDERERS = {
  'proc-core': drawProcCore,
  'cache-rung': drawCacheRung,
  'ram-bank': drawRamBank,
  'program-list': drawProgramList,
  'completion-counter': drawCompletionCounter,
  'entry-stage': drawEntryStage,
  'horizon-stage': drawHorizonStage,
  'proc-dock': drawProcDock,
  'station-dock': drawStationDock,
  'program-list-floor': drawProgramListFloor,
  'completion-counter-floor': drawCompletionCounterFloor,
  'registers-dock': drawRegistersDock,
  'l1-mini-dock': drawL1MiniDock,
  'floor-stage': drawFloorStage,
}
