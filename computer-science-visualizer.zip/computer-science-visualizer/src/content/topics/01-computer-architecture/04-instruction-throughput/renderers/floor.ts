// renderers/floor.ts — the working-floor painters: the five stations with
// their labels, the connector lanes, the travelling instruction cards, the
// memory trips down to the L1 dock, the completions at Write Back, the
// counter pops, the golden (watched) instruction, the program list window,
// the registers dock, and the chapter's single term pill.
//
// Everything here is a pure function of (beatIndex, beatFraction) read from
// scenes/story.ts — deterministic by construction (VISUAL_LANGUAGE §15).
// Process over diagram: nothing merely appears; cards travel, trip, complete
// and settle (owner spec). Auxiliary cards carry decayed visual weight; the
// watched instruction alone is golden (VISUAL_LANGUAGE §18).

import type { EntityRenderer } from '../../../../../rendering/types'
import type { Vec2, Lang } from '../../../../../chapter-loader/types'
import { rrPath, hexA } from '../../../../../rendering/primitives/canvas-utils'
import { glow } from '../../../../../rendering/primitives/glow'
import { drawName } from '../../../../../rendering/primitives/text'
import { TAU, clamp, easeInOutCubic, lerp } from '../../../../../shared/math'

import * as M from '../scenes/metrics'
import * as L from '../scenes/layout'
import * as S from '../scenes/story'
import {
  beatFrac, COL, drawValue, drawInstrCard, drawStar, label as textLabel,
} from './entry'

const T = (txt: { en: string; vi: string }, lang: string) =>
  (lang as Lang) === 'vi' ? txt.vi : txt.en

/** The global tick and sub-tick of the current floor beat. */
function tickOf(s: { beatIndex: number; beatElapsed: number }): { t: number; sub: number } {
  const frac = beatFrac(s)
  return { t: S.globalTick(s.beatIndex, frac), sub: S.subTick(s.beatIndex, frac) }
}

/** The card's centre: it glides from the previous station to its own during
 *  the first 20% of the tick window, then rests — the conveyor rhythm. */
function cardPos(station: number, sub: number): Vec2 {
  const cur = L.stationC(station)
  if (sub >= 0.2) return cur
  const prev = station === 0 ? L.LIST_HEAD : L.stationC(station - 1)
  const k = easeInOutCubic(clamp(sub / 0.2, 0, 1))
  return { x: lerp(prev.x, cur.x, k), y: lerp(prev.y, cur.y, k) }
}

function ramp(x: number, a: number, b: number): number {
  return clamp((x - a) / (b - a), 0, 1)
}

// ===========================================================================
// PROC-DOCK — the small CPU west of the floor
// ===========================================================================
export const drawProcDock: EntityRenderer = (ctx, _s, e, active) => {
  const r = L.procDockRect()
  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.8
  if (active) glow(ctx, e.pos, e.color, 90, 0.25)
  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fillStyle = hexA(e.color, 0.12)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 1 : 0.5)
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.fillStyle = hexA('#fff3c0', 0.85)
  ctx.font = `800 13px ${M.FONT}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText('CPU', e.pos.x, e.pos.y)
  ctx.restore()
  drawName(ctx, e.pos, e.name, e.color, active, r.h / 2 + M.LABEL_GAP, M.F.partName)
}

// ===========================================================================
// STATION-DOCK — gloss carriers for the fetch / write-back stations
// ===========================================================================
export const drawStationDock: EntityRenderer = (ctx, s, e, active) => {
  if (!active) return
  ctx.save()
  ctx.globalAlpha = 0.5 + 0.2 * Math.sin(s.t * 0.01)
  ctx.strokeStyle = hexA(e.color, 0.8)
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.arc(e.pos.x, e.pos.y, M.STATION.w / 2 + 4, 0, TAU)
  ctx.stroke()
  ctx.restore()
}

// ===========================================================================
// PROGRAM-LIST (floor) — the streaming window into the program
// ===========================================================================
export const drawProgramListFloor: EntityRenderer = (ctx, s, _e, active) => {
  const { t, sub } = tickOf(s)
  const ptr = S.rowAtTick(t) // the row sliding into Fetch this tick
  const doneCount = S.counterAt(t)
  const watched = S.watchedRow(s.beatIndex)
  const windowTop = ptr - 4
  const scroll = sub * (M.LIST_ROW.h + M.LIST_ROW.gap)

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.92
  ctx.fillStyle = COL.panel
  rrPath(ctx, L.LIST.x, L.LIST.y, L.LIST.w, L.LIST.h, L.LIST.r)
  ctx.fill()
  ctx.strokeStyle = hexA('#e2e8f0', 0.5)
  ctx.lineWidth = 1.5
  ctx.stroke()
  textLabel(ctx, T(S.CAP.listTitle, s.lang), { x: L.LIST.x + M.LIST_FLOOR.padX, y: L.LIST.y + M.LIST_FLOOR.titleH / 2 }, {
    size: 13, align: 'left', color: hexA('#e2e8f0', 0.85),
  })

  for (let i = 0; i < M.LIST_FLOOR_ROWS_VISIBLE; i++) {
    const row = windowTop + i
    if (row < 1 || row > M.PROGRAM_ROWS) continue
    const ins = S.instrByRow(row)
    const y = L.listRowYF(i) + M.LIST_ROW.h / 2 - scroll
    const done = row <= doneCount
    const fetching = row === ptr
    const nextUp = watched === row
    const opCol = S.OP_COLORS[ins.op]

    ctx.save()
    if (fetching) {
      ctx.fillStyle = hexA('#fbbf24', 0.16)
      rrPath(ctx, L.LIST.x + 8, y - M.LIST_ROW.h / 2, L.LIST.w - 16, M.LIST_ROW.h, 4)
      ctx.fill()
    } else if (nextUp) {
      ctx.fillStyle = hexA('#fbbf24', 0.08 + 0.05 * Math.sin(s.t * 0.008))
      rrPath(ctx, L.LIST.x + 8, y - M.LIST_ROW.h / 2, L.LIST.w - 16, M.LIST_ROW.h, 4)
      ctx.fill()
    }
    ctx.font = `700 11px ${M.MONO}`
    ctx.textAlign = 'left'
    ctx.textBaseline = 'middle'
    ctx.fillStyle = hexA('#94a3b8', done ? 0.45 : nextUp ? 1 : 0.85)
    ctx.fillText(`${row}`, L.LIST.x + M.LIST_FLOOR.padX, y)
    ctx.font = `700 12px ${M.FONT}`
    ctx.fillStyle = hexA(opCol, done ? 0.45 : 0.95)
    ctx.fillText(ins.op, L.LIST.x + M.LIST_FLOOR.padX + 32, y)
    if (ins.value) {
      drawValue(ctx, { x: L.LIST.x + M.LIST_FLOOR.padX + 78, y }, ins.value, done ? 0.45 : 0.95, 0.7)
    }
    if (nextUp) drawStar(ctx, { x: L.LIST.x + L.LIST.w - M.LIST_FLOOR.padX - 8, y }, 0.9, 0.5 + 0.5 * Math.sin(s.t * 0.008))
    if (done) {
      ctx.font = `700 12px ${M.FONT}`
      ctx.fillStyle = hexA('#4ade80', 0.85)
      ctx.textAlign = 'right'
      ctx.fillText('✓', L.LIST.x + L.LIST.w - M.LIST_FLOOR.padX, y)
    }
    ctx.restore()
  }
  ctx.restore()
}

// ===========================================================================
// COMPLETION-COUNTER (floor) — pops once per tick from the first completion on
// ===========================================================================
export const drawCompletionCounterFloor: EntityRenderer = (ctx, s, _e, active) => {
  const { t, sub } = tickOf(s)
  const value = S.counterAt(t)
  const pop = t >= M.FIRST_COMPLETE_TICK ? Math.max(0, 1 - sub / 0.3) : 0

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.92
  ctx.fillStyle = COL.panel
  rrPath(ctx, L.COUNTER.x, L.COUNTER.y, L.COUNTER.w, L.COUNTER.h, L.COUNTER.r)
  ctx.fill()
  ctx.strokeStyle = hexA('#4ade80', pop > 0 ? 1 : 0.65)
  ctx.lineWidth = pop > 0 ? 2.5 : 1.5
  ctx.stroke()
  textLabel(ctx, T(S.CAP.counter, s.lang), { x: L.COUNTER.x + L.COUNTER.w / 2, y: L.COUNTER.y + 18 }, {
    size: 12, color: hexA('#e2e8f0', 0.75),
  })
  const numScale = 1 + 0.24 * pop
  ctx.save()
  ctx.translate(L.COUNTER.x + L.COUNTER.w / 2, L.COUNTER.y + 52)
  ctx.scale(numScale, numScale)
  ctx.font = `800 ${M.COUNTER_NUM.size}px ${M.MONO}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = hexA('#4ade80', 0.95)
  ctx.fillText(String(value), 0, 0)
  ctx.restore()
  ctx.restore()
}

// ===========================================================================
// REGISTERS-DOCK — where completed results land
// ===========================================================================
export const drawRegistersDock: EntityRenderer = (ctx, s, e, active) => {
  const { t } = tickOf(s)
  const done = S.counterAt(t)
  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.85
  rrPath(ctx, L.REG.x, L.REG.y, L.REG.w, L.REG.h, L.REG.r)
  ctx.fillStyle = COL.panel
  ctx.fill()
  ctx.strokeStyle = hexA('#a78bfa', 0.7)
  ctx.lineWidth = 1.5
  ctx.stroke()
  textLabel(ctx, T(S.CAP.registers, s.lang), { x: L.REG.x + L.REG.w / 2, y: L.REG.y + 14 }, {
    size: 12, color: hexA('#e2e8f0', 0.8),
  })
  // the last few results as a small stack of dots
  const n = clamp(done - 5, 0, 8)
  for (let i = 0; i < n; i++) {
    const row = done - i
    const ins = S.instrByRow(row)
    const px = L.REG.x + 16 + (i % 4) * 26
    const py = L.REG.y + 34 + Math.floor(i / 4) * 20
    ctx.beginPath()
    ctx.arc(px, py, 4, 0, TAU)
    ctx.fillStyle = hexA(S.OP_COLORS[ins.op], 0.9)
    ctx.fill()
  }
  ctx.restore()
  drawName(ctx, e.pos, e.name, e.color, active, L.REG.h / 2 + M.LABEL_GAP, M.F.partName)
}

// ===========================================================================
// L1-MINI-DOCK — the nearest cache level; the data trips land here
// ===========================================================================
export const drawL1MiniDock: EntityRenderer = (ctx, s, e, active) => {
  const { t, sub } = tickOf(s)
  const trips = S.tripsIn(s.beatIndex, beatFrac(s))
  const cur = trips.find((tr) => tr.tick === t)
  const busy = !!cur

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.85
  if (busy) glow(ctx, { x: L.L1D.x + L.L1D.w / 2, y: L.L1D.y + L.L1D.h / 2 }, '#22d3ee', 80, 0.3)
  rrPath(ctx, L.L1D.x, L.L1D.y, L.L1D.w, L.L1D.h, L.L1D.r)
  ctx.fillStyle = hexA('#22d3ee', busy ? 0.2 : 0.08)
  ctx.fill()
  ctx.strokeStyle = hexA('#22d3ee', busy ? 1 : 0.75)
  ctx.lineWidth = busy ? 2.5 : 1.5
  ctx.stroke()
  textLabel(ctx, T(S.CAP.l1, s.lang), { x: L.L1D.x + L.L1D.w / 2, y: L.L1D.y + L.L1D.h / 2 }, {
    size: 13, color: hexA('#e2e8f0', 0.9),
  })

  // the glyph in transit on the trip lane
  if (cur) {
    const prog = ramp(sub, 0.15, 0.8)
    const cardC = cardPos(3, sub)
    const fromL1 = cur.op === 'LOAD'
    const pos: Vec2 = fromL1
      ? { x: lerp(L.L1D.x + L.L1D.w / 2, cardC.x, easeInOutCubic(prog)), y: lerp(L.L1D.y, cardC.y, easeInOutCubic(prog)) }
      : { x: lerp(cardC.x, L.L1D.x + L.L1D.w / 2, easeInOutCubic(prog)), y: lerp(cardC.y, L.L1D.y, easeInOutCubic(prog)) }
    drawValue(ctx, pos, cur.value, 0.95, 0.85)
  }
  ctx.restore()
  drawName(ctx, e.pos, e.name, e.color, active, L.L1D.h / 2 + M.LABEL_GAP, M.F.partName)
}

// ===========================================================================
// FLOOR-STAGE — the working floor itself
// ===========================================================================
export const drawFloorStage: EntityRenderer = (ctx, s, _e, _active) => {
  const frac = beatFrac(s)
  const { t, sub } = tickOf(s)
  const full = S.floorFull(t)
  const watched = S.watchedRow(s.beatIndex)
  const reveal = s.beatIndex === 7 // the floor materializes
  const isCity = s.beatIndex >= 10 // from filling on, the machine is alive

  // ---- the panel frame (its aliveness rises with the floor's fullness) ----
  ctx.save()
  ctx.fillStyle = 'rgba(10,14,32,0.82)'
  rrPath(ctx, L.PANEL.x, L.PANEL.y, L.PANEL.w, L.PANEL.h, L.PANEL.r)
  ctx.fill()
  ctx.strokeStyle = hexA('#22d3ee', 0.5 + 0.4 * (full ? 1 : 0.45))
  ctx.lineWidth = 2
  ctx.stroke()
  if (full && isCity) glow(ctx, { x: L.PANEL.x + L.PANEL.w / 2, y: L.PANEL.y + L.PANEL.h / 2 }, '#22d3ee', 240, 0.1)
  ctx.restore()

  // ---- the orientation chip: 'inside the CPU' ----
  const orientTxt = T(S.CAP.orient, s.lang)
  ctx.save()
  ctx.font = `700 12px ${M.FONT}`
  const chip = L.orientChip(ctx.measureText(orientTxt).width)
  ctx.globalAlpha = 0.9
  rrPath(ctx, chip.x, chip.y, chip.w, chip.h, chip.r)
  ctx.fillStyle = 'rgba(10,14,32,0.9)'
  ctx.fill()
  ctx.strokeStyle = hexA('#22d3ee', 0.7)
  ctx.lineWidth = 1.5
  ctx.stroke()
  ctx.fillStyle = hexA('#e2e8f0', 0.92)
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(orientTxt, chip.x + chip.w / 2, chip.y + chip.h / 2)
  ctx.restore()

  // ---- the five stations + connectors ----
  const stationAlpha = (i: number) =>
    reveal ? clamp((frac - (0.1 + i * 0.13)) / 0.4, 0, 1) : 1

  for (let i = 0; i < M.STATIONS; i++) {
    const r = L.stationRect(i)
    const a = stationAlpha(i)
    if (a <= 0.01) continue
    const pulse = sub < 0.25 ? clamp(1 - Math.max(0, sub - i * 0.03) / 0.25, 0, 1) : 0
    const isWatchedStation = watched !== null && S.watchedAnchor(s.beatIndex, frac) === i + 1
    ctx.save()
    ctx.globalAlpha = a
    rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
    ctx.fillStyle = hexA('#0f172a', 0.9)
    ctx.fill()
    ctx.strokeStyle = hexA('#22d3ee', 0.55 + 0.4 * pulse + (isWatchedStation ? 0.35 : 0))
    ctx.lineWidth = isWatchedStation ? 3 : 2
    ctx.stroke()
    // the station glyph: a small mark of what the station does
    ctx.fillStyle = hexA('#e2e8f0', 0.5 + 0.3 * pulse)
    ctx.font = `700 15px ${M.FONT}`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    const glyphs = ['↓', '?', '+', '⇄', '✓']
    ctx.fillText(glyphs[i], r.x + r.w - 22, r.y + 22)
    ctx.restore()
    // locked term + plain sub
    const term = ['Fetch', 'Decode', 'Execute', 'Memory', 'Write Back'][i]
    const termY = L.stationTermY(i)
    const subY = L.stationSubY(i)
    ctx.save()
    ctx.globalAlpha = a * 0.95
    ctx.font = `800 15px ${M.FONT}`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillStyle = hexA('#e2e8f0', 0.95)
    ctx.fillText(term, r.x + r.w / 2, termY)
    ctx.font = `600 12px ${M.FONT}`
    ctx.fillStyle = hexA('#94a3b8', 0.85)
    ctx.fillText(T(S.CAP.stationSubs[i], s.lang), r.x + r.w / 2, subY)
    ctx.restore()
  }

  // ---- the connectors: each lane is its own path (§2.1) ----
  const laneAlpha = (i: number) => {
    const pulse = sub < 0.3 ? clamp(1 - Math.max(0, sub - i * 0.05) / 0.3, 0, 1) : 0
    return 0.35 + 0.5 * pulse
  }
  ctx.save()
  for (let i = 0; i < M.STATIONS - 1; i++) {
    const [a, b] = L.connector(i)
    ctx.globalAlpha = laneAlpha(i) * stationAlpha(i + 1)
    ctx.strokeStyle = hexA('#22d3ee', 0.8)
    ctx.lineWidth = M.LANE.w
    ctx.beginPath()
    ctx.moveTo(a.x, a.y)
    ctx.lineTo(b.x, b.y)
    ctx.stroke()
    drawArrow(ctx, a, b)
  }
  // the fetch lane and the exit lane
  ctx.globalAlpha = laneAlpha(0)
  ctx.strokeStyle = hexA('#fb923c', 0.8)
  ctx.lineWidth = M.LANE.w
  const [fa, fb] = L.FETCH_LANE
  ctx.beginPath()
  ctx.moveTo(fa.x, fa.y)
  ctx.lineTo(fb.x, fb.y)
  ctx.stroke()
  drawArrow(ctx, fa, fb)
  const [ea, eb] = L.EXIT_LANE
  ctx.strokeStyle = hexA('#a78bfa', 0.8)
  ctx.beginPath()
  ctx.moveTo(ea.x, ea.y)
  ctx.lineTo(eb.x, eb.y)
  ctx.stroke()
  drawArrow(ctx, ea, eb)
  // the data trip lane (distinct path — dashed)
  const [ta, tb] = L.TRIP_LANE
  ctx.strokeStyle = hexA('#22d3ee', 0.6)
  ctx.lineWidth = M.TRIP.w
  ctx.setLineDash(M.TRIP.dash as [number, number])
  ctx.beginPath()
  ctx.moveTo(ta.x, ta.y)
  ctx.lineTo(tb.x, tb.y)
  ctx.stroke()
  ctx.setLineDash([])
  ctx.restore()

  // ---- the in-flight cards ----
  if (s.beatIndex >= 8) {
    for (const f of S.inFlight(t)) {
      const ins = S.instrByRow(f.row)
      const golden = watched === f.row
      const atM = f.station === 3
      const completing = f.station === M.STATIONS - 1
      const alpha = completing && sub > 0.85 ? 1 - (sub - 0.85) / 0.15 : golden ? 1 : 0.5
      const pos = cardPos(f.station, sub)

      // value glyph state on the card
      let showValue = false
      if (ins.value) {
        if (ins.op === 'STORE') showValue = f.station < 3 || (atM && sub < 0.15)
        if (ins.op === 'LOAD') showValue = f.station > 3 || (atM && sub >= 0.8)
      }

      ctx.save()
      if (golden) glow(ctx, pos, '#fbbf24', 70, 0.35)
      drawInstrCard(ctx, pos, f.row, {
        w: M.CARD.w,
        h: M.CARD.h,
        r: M.CARD.r,
        alpha,
        golden,
        showValue,
        value: ins.value,
      })
      if (golden) {
        const pulse = 0.5 + 0.5 * Math.sin(s.t * 0.012)
        drawStar(ctx, { x: pos.x, y: pos.y - M.CARD.h / 2 + M.CARD_STAR.dy }, 0.95, pulse)
      }
      ctx.restore()

      // ---- the completion ceremony at Write Back ----
      if (completing) {
        const flash = ramp(sub, 0.45, 0.8)
        if (flash > 0 && flash < 1) {
          ctx.save()
          ctx.globalAlpha = (1 - flash) * 0.9
          ctx.strokeStyle = '#fde68a'
          ctx.lineWidth = M.DONE_RING.ring
          ctx.beginPath()
          ctx.arc(pos.x, pos.y, M.DONE_RING.r * (0.5 + 0.5 * flash), 0, TAU)
          ctx.stroke()
          ctx.restore()
        }
        const chipK = ramp(sub, 0.5, 0.9)
        if (chipK > 0 && chipK < 1) {
          const chip: Vec2 = {
            x: lerp(pos.x, L.REG.x + L.REG.w / 2, easeInOutCubic(chipK)),
            y: lerp(pos.y, L.REG.y + L.REG.h / 2, easeInOutCubic(chipK)),
          }
          ctx.save()
          ctx.globalAlpha = 1 - chipK * 0.3
          ctx.beginPath()
          ctx.arc(chip.x, chip.y, M.CHIP.r, 0, TAU)
          ctx.fillStyle = S.OP_COLORS[ins.op]
          ctx.fill()
          ctx.restore()
        }
      }
    }
  }

  // ---- the watched card waiting at the stream head (b12) ----
  if (watched !== null && s.beatIndex === 12) {
    const pos = L.LIST_HEAD
    ctx.save()
    glow(ctx, pos, '#fbbf24', 70, 0.3 + 0.1 * Math.sin(s.t * 0.01))
    drawInstrCard(ctx, pos, watched, {
      w: M.CARD.w,
      h: M.CARD.h,
      r: M.CARD.r,
      alpha: 1,
      golden: true,
      showValue: false,
    })
    drawStar(ctx, { x: pos.x, y: pos.y - M.CARD.h / 2 + M.CARD_STAR.dy }, 0.95, 0.5 + 0.5 * Math.sin(s.t * 0.012))
    ctx.restore()
  }

  // ---- the chapter's single term pill: Pipeline (b15, after observation) ----
  if (s.beatIndex === 15) {
    const a = ramp(frac, S.TERM_PILL.at, S.TERM_PILL.at + 0.12)
    if (a > 0.01) {
      drawTermPill(ctx, L.termDock(), a, s.lang)
    }
  }
}

function drawArrow(ctx: CanvasRenderingContext2D, a: Vec2, b: Vec2) {
  const ang = Math.atan2(b.y - a.y, b.x - a.x)
  const tip = 8
  const spread = 0.5
  ctx.save()
  ctx.fillStyle = ctx.strokeStyle as string
  ctx.beginPath()
  ctx.moveTo(b.x, b.y)
  ctx.lineTo(b.x - tip * Math.cos(ang - spread), b.y - tip * Math.sin(ang - spread))
  ctx.lineTo(b.x - tip * Math.cos(ang + spread), b.y - tip * Math.sin(ang + spread))
  ctx.closePath()
  ctx.fill()
  ctx.restore()
}

/** The Pipeline term pill — the only term of the chapter, revealed after the
 *  behaviour was fully watched (NARRATIVE_FRAMING §13). */
function drawTermPill(ctx: CanvasRenderingContext2D, center: Vec2, alpha: number, lang: string) {
  if (alpha <= 0.01) return
  const sub = T(S.TERM_PILL.sub, lang)
  const maxTextW = M.TERM.maxW - 2 * M.TERM.padX
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.font = `800 ${M.F.termPill}px ${M.FONT}`
  const w1 = ctx.measureText(S.TERM_PILL.term).width
  ctx.font = `600 ${M.F.sub}px ${M.FONT}`
  let subTxt = sub
  if (ctx.measureText(subTxt).width > maxTextW) subTxt = subTxt.slice(0, Math.max(1, subTxt.length - 3)) + '…'
  const w2 = ctx.measureText(subTxt).width
  const w = Math.min(M.TERM.maxW, Math.max(w1, w2) + 2 * M.TERM.padX)
  const h = M.TERM.h + M.F.sub + 8
  rrPath(ctx, center.x - w / 2, center.y - h / 2, w, h, M.TERM.r)
  ctx.fillStyle = 'rgba(12,16,36,0.95)'
  ctx.fill()
  ctx.strokeStyle = hexA('#fbbf24', 0.9)
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = '#fbbf24'
  ctx.font = `800 ${M.F.termPill}px ${M.FONT}`
  ctx.fillText(S.TERM_PILL.term, center.x, center.y - M.F.sub / 2 - 4)
  ctx.fillStyle = hexA('#e2e8f0', 0.85)
  ctx.font = `600 ${M.F.sub}px ${M.FONT}`
  ctx.fillText(subTxt, center.x, center.y + M.F.sub / 2 + 6)
  ctx.restore()
}
