// renderers/entry.ts — the `entry` and `horizon` scene painters: the
// remembered Topic-01 world — the CPU, the ladder with its resident values,
// the program list, the completion counter, the fetch hops with their mini
// instruction cards, the completion flashes — and the horizon's endless
// running state. LAYOUT-SYSTEM DRIVEN: every coordinate derives from
// scenes/metrics.ts + scenes/layout.ts (Layout Derivation Law).
//
// Every painter is a pure function of (PresentationState, entity.extra): all
// beat-driven content derives from s.beatIndex / s.beatElapsed, so scrubbing,
// pausing and stepping backwards stay deterministic (VISUAL_LANGUAGE §15).
// The horizon beat is the one deliberate exception: it is the final loop, and
// its clock derives from s.t (the global clock), the same pattern the earlier
// chapters use for their looping protagonist.

import type { EntityRenderer } from '../../../../../rendering/types'
import type { Vec2, Lang } from '../../../../../chapter-loader/types'
import { rrPath, hexA } from '../../../../../rendering/primitives/canvas-utils'
import { glow } from '../../../../../rendering/primitives/glow'
import { drawName } from '../../../../../rendering/primitives/text'
import { TAU, clamp } from '../../../../../shared/math'
import { polylinePoint } from '../../../../../shared/geometry'

import { beats } from '../narration/beats'
import * as M from '../scenes/metrics'
import * as L from '../scenes/layout'
import * as S from '../scenes/story'
import { DIE_BEATS } from '../scenes/story'

// ---------------------------------------------------------------------------
// shared helpers (also used by the floor renderer)
// ---------------------------------------------------------------------------
export const DUR: Record<number, number> = Object.fromEntries(beats.map((b, i) => [i, b.duration]))
export const beatFrac = (s: { beatIndex: number; beatElapsed: number }, bi = s.beatIndex) =>
  clamp(s.beatElapsed / (DUR[bi] ?? 3000), 0, 1)

export const COL = {
  exec: '#4ade80',
  wait: '#fb7185',
  cpu: '#fb923c',
  cache: '#22d3ee',
  ram: '#a78bfa',
  dim: 'rgba(170,180,208,0.72)',
  panel: 'rgba(10,14,32,0.92)',
  chip: '#e2e8f0',
}

const T = (txt: { en: string; vi: string }, lang: string) =>
  (lang as Lang) === 'vi' ? txt.vi : txt.en

export function label(
  ctx: CanvasRenderingContext2D,
  text: string,
  at: Vec2,
  opts: { size?: number; color?: string; align?: CanvasTextAlign; alpha?: number; weight?: number } = {},
) {
  if ((opts.alpha ?? 1) <= 0.01) return
  ctx.save()
  ctx.globalAlpha = opts.alpha ?? 1
  ctx.font = `${opts.weight ?? 700} ${opts.size ?? M.F.sub}px ${M.FONT}`
  ctx.textAlign = opts.align ?? 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = opts.color ?? COL.dim
  ctx.fillText(text, at.x, at.y)
  ctx.restore()
}

export function drawPill(
  ctx: CanvasRenderingContext2D,
  center: Vec2,
  text: string,
  font: string,
  padX: number,
  h: number,
  stroke: string,
  fill: string,
  textColor: string,
  alpha = 1,
) {
  if (alpha <= 0.01) return
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.font = font
  const w = ctx.measureText(text).width + 2 * padX
  rrPath(ctx, center.x - w / 2, center.y - h / 2, w, h, h / 2)
  ctx.fillStyle = fill
  ctx.fill()
  ctx.strokeStyle = stroke
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.fillStyle = textColor
  ctx.font = font
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(text, center.x, center.y)
  ctx.restore()
}

/** The resident value glyphs — the same ◆ ▲ ■ ● language as Chapters 02/03. */
export function drawValue(
  ctx: CanvasRenderingContext2D,
  center: Vec2,
  valueId: S.ValueId,
  alpha: number,
  scale = 1,
) {
  if (alpha <= 0.01) return
  const v = S.VALUES[valueId]
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.fillStyle = v.color
  ctx.font = `${700 * scale} ${M.VALUE.size * scale}px ${M.FONT}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(v.glyph, center.x, center.y)
  ctx.restore()
}

/** The instruction card (die-scale mini card or floor card). */
export function drawInstrCard(
  ctx: CanvasRenderingContext2D,
  center: Vec2,
  row: number,
  opts: {
    w: number
    h: number
    r: number
    alpha?: number
    golden?: boolean
    showValue?: boolean
    value?: S.ValueId
    scale?: number
  },
) {
  if ((opts.alpha ?? 1) <= 0.01) return
  const ins = S.instrByRow(row)
  const opCol = S.OP_COLORS[ins.op]
  const w = opts.w
  const h = opts.h
  ctx.save()
  ctx.globalAlpha = opts.alpha ?? 1
  // body
  rrPath(ctx, center.x - w / 2, center.y - h / 2, w, h, opts.r)
  ctx.fillStyle = 'rgba(13,18,40,0.94)'
  ctx.fill()
  ctx.strokeStyle = opts.golden ? hexA('#fbbf24', 0.95) : hexA(opCol, 0.55)
  ctx.lineWidth = opts.golden ? 2.5 : 1.5
  ctx.stroke()
  // op-colour strip
  ctx.fillStyle = hexA(opCol, opts.golden ? 0.95 : 0.75)
  rrPath(ctx, center.x - w / 2 + 6, center.y - h / 2 + 6, w - 12, 6, 3)
  ctx.fill()
  // op text
  const fs = Math.max(11, Math.round(h * 0.34))
  ctx.font = `800 ${fs}px ${M.FONT}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = opts.golden ? '#fde68a' : hexA('#f1f5f9', 0.95)
  ctx.fillText(ins.op, center.x + (opts.showValue && opts.value ? 14 : 0), center.y + 5)
  // value glyph
  if (opts.showValue && opts.value) {
    drawValue(ctx, { x: center.x + w / 2 - 18, y: center.y + 5 }, opts.value, 1, 0.92)
  }
  // row index
  ctx.font = `700 10px ${M.FONT}`
  ctx.fillStyle = hexA('#94a3b8', 0.9)
  ctx.textAlign = 'left'
  ctx.fillText(String(row), center.x - w / 2 + 8, center.y - h / 2 + 12)
  ctx.restore()
}

/** The golden ★ that marks the watched instruction. */
export function drawStar(
  ctx: CanvasRenderingContext2D,
  at: Vec2,
  alpha: number,
  pulse: number,
) {
  if (alpha <= 0.01) return
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.font = `700 20px ${M.FONT}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = hexA('#fbbf24', 0.9 + 0.1 * pulse)
  ctx.fillText('★', at.x, at.y)
  ctx.restore()
}

// ===========================================================================
// PROC-CORE — the CPU of the entry/horizon scenes
// ===========================================================================
export const drawProcCore: EntityRenderer = (ctx, s, e, active) => {
  const box = M.CPU_BOX
  const x = e.pos.x - box.w / 2
  const y = e.pos.y - box.h / 2
  const inHorizon = s.scene === 'horizon'
  const working = s.phase !== 'waiting'
  const frac = beatFrac(s)

  // completion flash phase on die beats
  let flash = 0
  if (!inHorizon && DIE_BEATS[s.beatIndex] !== undefined) {
    flash = clamp((frac - S.DIE_COMPLETE_FRAC) / 0.14, 0, 1)
  }
  // horizon: one work cycle per tick — phase follows the accelerating tick
  // length (horizonPhase), so the core's glow, pulse and completion flash
  // visibly *launch* alongside the cache and the counter instead of staying
  // locked at the slow 1.6 s cadence.
  let hPhase = 0
  if (inHorizon) hPhase = horizonPhase(s)

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.72
  const glowA = inHorizon ? 0.5 + 0.2 * pulse01(hPhase, 0.55, 0.75) : working ? 0.4 + 0.12 * Math.sin(s.t * 0.01) : active ? 0.2 : 0.08
  if (glowA > 0.02) glow(ctx, e.pos, e.color, 130, glowA)

  ctx.fillStyle = hexA(e.color, working ? 0.6 : 0.3)
  for (let i = 0; i < M.CPU_PINS.count; i++) {
    const fx = x + M.CPU_PINS.inset + (i / (M.CPU_PINS.count - 1)) * (box.w - 2 * M.CPU_PINS.inset)
    ctx.fillRect(fx - M.CPU_PINS.w / 2, y - M.CPU_PINS.len, M.CPU_PINS.w, M.CPU_PINS.len)
    ctx.fillRect(fx - M.CPU_PINS.w / 2, y + box.h, M.CPU_PINS.w, M.CPU_PINS.len)
    const fy = y + M.CPU_PINS.inset + (i / (M.CPU_PINS.count - 1)) * (box.h - 2 * M.CPU_PINS.inset)
    ctx.fillRect(x - M.CPU_PINS.len, fy - M.CPU_PINS.w / 2, M.CPU_PINS.len, M.CPU_PINS.w)
    ctx.fillRect(x + box.w, fy - M.CPU_PINS.w / 2, M.CPU_PINS.len, M.CPU_PINS.w)
  }

  rrPath(ctx, x, y, box.w, box.h, box.r)
  ctx.fillStyle = hexA(e.color, working ? 0.2 : 0.09)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, working ? 0.95 : 0.42)
  ctx.lineWidth = 2.5
  ctx.stroke()

  const c = M.CPU_CORE
  rrPath(ctx, e.pos.x - c.half, e.pos.y - c.half, c.half * 2, c.half * 2, c.r)
  const workK = inHorizon ? pulse01(hPhase, 0.55, 0.75) : working ? 1 : 0
  if (workK > 0) {
    const g = ctx.createRadialGradient(e.pos.x, e.pos.y, 2, e.pos.x, e.pos.y, c.half)
    g.addColorStop(0, hexA('#fff3c0', 0.95 * workK))
    g.addColorStop(1, hexA(e.color, 0.22 * workK))
    ctx.fillStyle = g
  } else {
    ctx.fillStyle = 'rgba(28,34,62,0.9)'
  }
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, working ? 0.95 : 0.35)
  ctx.lineWidth = 2
  ctx.stroke()

  // completion flash ring (die beats + horizon tick)
  if (flash > 0 || (inHorizon && hPhase > 0.76 && hPhase < 1)) {
    const f = flash > 0 ? flash : pulse01(hPhase, 0.76, 1)
    ctx.save()
    ctx.globalAlpha = (1 - f) * 0.9
    ctx.strokeStyle = '#fde68a'
    ctx.lineWidth = M.FLASH.ring
    ctx.beginPath()
    ctx.arc(e.pos.x, e.pos.y, M.FLASH.r * (0.6 + 0.4 * f), 0, TAU)
    ctx.stroke()
    ctx.restore()
  }
  ctx.restore()

  drawName(ctx, e.pos, e.name, e.color, active || working, M.CPU_BOX.h / 2 + M.LABEL_GAP, M.F.partName)
}

/** Linear pulse of `x` within [a, b] (0 outside, 1 at b). */
function pulse01(x: number, a: number, b: number): number {
  if (x <= a) return 0
  if (x >= b) return 1
  return (x - a) / (b - a)
}

/** The horizon's start on the global clock = the sum of all previous beats. */
export function horizonStartT(): number {
  let t = 0
  for (let i = 0; i < beats.length - 1; i++) t += beats[i].duration
  return t
}

/** The horizon's local tick index (0, 1, 2, …) — the tick shortens over the
 *  speed ramp (story.ts horizonTickAt). */
export function horizonTick(s: { t: number; scene: string }): number {
  if (s.scene !== 'horizon') return 0
  const start = horizonStartT()
  return S.horizonTickAt(Math.max(0, s.t - start))
}

/** The horizon's phase within the current tick (0..1) — follows the same
 *  shortening tick length, so the machine's glow and hops accelerate. */
export function horizonPhase(s: { t: number; scene: string }): number {
  if (s.scene !== 'horizon') return 0
  const start = horizonStartT()
  const t0 = Math.max(0, s.t - start)
  const len = S.horizonTickLen(t0)
  return len > 0 ? (t0 / len) % 1 : 0
}

/** The horizon's speed stage at the current moment. */
export function horizonStage(s: { t: number; scene: string }): 'slow' | 'ramp' | 'fast' {
  if (s.scene !== 'horizon') return 'slow'
  return S.horizonStage(Math.max(0, s.t - horizonStartT()))
}

// ===========================================================================
// CACHE-RUNG — one rung of the remembered ladder, with its remembered values
// ===========================================================================
export const drawCacheRung: EntityRenderer = (ctx, s, e, active) => {
  const rid = (e.extra?.rungId as string) ?? 'l1'
  const rung = L.rungById(rid)
  const r = rung.pos
  const x = r.x - rung.w / 2
  const y = r.y - rung.h / 2
  const frac = beatFrac(s)

  // the fetch flash: L1 brightens while the spark is at its door
  const fetching =
    !(s.scene === 'horizon') && rid === 'l1' && DIE_BEATS[s.beatIndex] !== undefined
      ? frac > 0.3 && frac < 0.52
      : false
  const hFetch = s.scene === 'horizon' && rid === 'l1' ? horizonPhase(s) > 0.35 && horizonPhase(s) < 0.55 : false

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.8
  ctx.fillStyle = hexA(e.color, 0.1)
  rrPath(ctx, x, y, rung.w, rung.h, M.RUNG_R)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, fetching || hFetch ? 1 : 0.65)
  ctx.lineWidth = fetching || hFetch ? 3 : 2
  ctx.stroke()
  if (fetching || hFetch) glow(ctx, r, e.color, 90, 0.35)

  // remembered resident values (Chapter 02/03 closing state)
  const resident = rid === 'l1' ? ['v1', 'v2', 'v3'] : ['v1', 'v2']
  const slotW = (rung.w - 2 * M.SLOT.padX - (resident.length - 1) * M.SLOT.gap) / resident.length
  resident.forEach((vid, i) => {
    const sx = x + M.SLOT.padX + i * (slotW + M.SLOT.gap)
    const sy = y + (rung.h - M.SLOT.h) / 2
    ctx.fillStyle = 'rgba(15,23,42,0.85)'
    rrPath(ctx, sx, sy, slotW, M.SLOT.h, M.SLOT.r)
    ctx.fill()
    drawValue(ctx, { x: sx + slotW / 2, y: sy + M.SLOT.h / 2 }, vid as S.ValueId, 0.95, 0.8)
  })
  ctx.restore()

  drawName(ctx, r, e.name, e.color, active || fetching, rung.h / 2 + M.LABEL_GAP, M.F.partName)
}

// ===========================================================================
// RAM-BANK — the far memory
// ===========================================================================
export const drawRamBank: EntityRenderer = (ctx, _s, e, active) => {
  const r = L.RAM_RUNG
  const x = r.pos.x - r.w / 2
  const y = r.pos.y - r.h / 2
  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.8
  ctx.fillStyle = hexA(e.color, 0.08)
  rrPath(ctx, x, y, r.w, r.h, M.RAM_BOX.r)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, 0.6)
  ctx.lineWidth = 2
  ctx.stroke()
  const g = M.RAM_GRID
  const cellW = (r.w - 2 * M.SLOT.padX - (g.cols - 1) * g.gap) / g.cols
  const cellH = (r.h - 2 * M.SLOT.padX - (g.rows - 1) * g.gap) / g.rows
  for (let cy = 0; cy < g.rows; cy++) {
    for (let cx = 0; cx < g.cols; cx++) {
      const px = x + M.SLOT.padX + cx * (cellW + g.gap)
      const py = y + M.SLOT.padX + cy * (cellH + g.gap)
      ctx.fillStyle = hexA(e.color, 0.18)
      ctx.fillRect(px, py, cellW, cellH)
    }
  }
  ctx.restore()
  drawName(ctx, r.pos, e.name, e.color, active, r.h / 2 + M.LABEL_GAP, M.F.partName)
}

// ===========================================================================
// PROGRAM-LIST (entry) — the HUD window into the program
// ===========================================================================
export const drawProgramList: EntityRenderer = (ctx, s, _e, active) => {
  const r = L.listPanelRect()
  const frac = beatFrac(s)
  const inHorizon = s.scene === 'horizon'

  // which rows are visible: die beats → rows 1..6; horizon → the window
  // follows the pointer forever
  const horizonRows = (): number[] => {
    const ptr = S.HORIZON_POINTER + horizonTick(s)
    const out: number[] = []
    for (let i = 0; i < M.LIST_ROWS_VISIBLE; i++) out.push(ptr - 3 + i)
    return out
  }
  const rows = inHorizon ? horizonRows() : Array.from({ length: M.LIST_ROWS_VISIBLE }, (_, i) => i + 1)
  const currentRow = inHorizon ? S.HORIZON_POINTER + horizonTick(s) : DIE_BEATS[s.beatIndex] ?? 0

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.9
  ctx.fillStyle = COL.panel
  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fill()
  ctx.strokeStyle = hexA('#e2e8f0', 0.35)
  ctx.lineWidth = 1.5
  ctx.stroke()
  label(ctx, T(S.CAP.listTitle, s.lang), { x: r.x + M.LIST_PANEL.padX, y: r.y + M.LIST_PANEL.titleH / 2 }, {
    size: 13, align: 'left', color: hexA('#e2e8f0', 0.85),
  })

  rows.forEach((row, i) => {
    const y = L.listRowY(i) + M.LIST_ROW.h / 2
    const ins = S.instrByRow(row)
    const justDone =
      DIE_BEATS[s.beatIndex] !== undefined && !inHorizon && row === currentRow && frac > S.DIE_COMPLETE_FRAC
    const done = row < currentRow || justDone
    const fetching = row === currentRow && !done
    const opCol = S.OP_COLORS[ins.op]

    ctx.save()
    // row band
    if (fetching) {
      ctx.fillStyle = hexA('#fbbf24', 0.14)
      rrPath(ctx, r.x + 8, y - M.LIST_ROW.h / 2, r.w - 16, M.LIST_ROW.h, 4)
      ctx.fill()
    }
    // index
    ctx.font = `700 11px ${M.MONO}`
    ctx.textAlign = 'left'
    ctx.textBaseline = 'middle'
    ctx.fillStyle = hexA('#94a3b8', done ? 0.5 : 0.9)
    ctx.fillText(`${row}`, r.x + M.LIST_PANEL.padX, y)
    // op
    ctx.font = `700 12px ${M.FONT}`
    ctx.fillStyle = hexA(opCol, done ? 0.45 : 0.95)
    ctx.fillText(ins.op, r.x + M.LIST_PANEL.padX + 34, y)
    // value glyph
    if (ins.value) {
      drawValue(ctx, { x: r.x + M.LIST_PANEL.padX + 82, y }, ins.value, done ? 0.45 : 0.95, 0.75)
    }
    // done check
    if (done) {
      ctx.font = `700 12px ${M.FONT}`
      ctx.fillStyle = hexA('#4ade80', 0.9)
      ctx.textAlign = 'right'
      ctx.fillText('✓', r.x + r.w - M.LIST_PANEL.padX, y)
    }
    ctx.restore()
  })
  ctx.restore()
}

// ===========================================================================
// COMPLETION-COUNTER (entry) — the evidence board
// ===========================================================================
export const drawCompletionCounter: EntityRenderer = (ctx, s, _e, active) => {
  const r = L.counterRect()
  const frac = beatFrac(s)
  const inHorizon = s.scene === 'horizon'

  let value: number
  let pop = 0
  if (inHorizon) {
    value = S.HORIZON_C0 + horizonTick(s)
    const p = horizonPhase(s)
    pop = p > 0.76 ? pulse01(p, 0.76, 0.9) : 0
  } else if (s.beatIndex === 0) {
    value = 0
  } else {
    const row = DIE_BEATS[s.beatIndex] ?? 0
    value = row > 0 && frac > S.DIE_COMPLETE_FRAC ? row : Math.max(0, row - 1)
    pop = row > 0 ? pulse01(frac, S.DIE_COMPLETE_FRAC, S.DIE_COMPLETE_FRAC + 0.1) : 0
  }

  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.92
  ctx.fillStyle = COL.panel
  rrPath(ctx, r.x, r.y, r.w, r.h, r.r)
  ctx.fill()
  ctx.strokeStyle = hexA('#4ade80', 0.5)
  ctx.lineWidth = 1.5
  ctx.stroke()
  label(ctx, T(S.CAP.counter, s.lang), { x: r.x + r.w / 2, y: r.y + 18 }, { size: 12, color: hexA('#e2e8f0', 0.75) })

  const numScale = 1 + 0.22 * pop
  ctx.save()
  ctx.translate(r.x + r.w / 2, r.y + 52)
  ctx.scale(numScale, numScale)
  ctx.font = `800 ${M.COUNTER_NUM.size}px ${M.MONO}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = hexA('#4ade80', 0.95)
  ctx.fillText(String(value), 0, 0)
  ctx.restore()
  // the real-speed caption under the counter, following the speed ramp.
  // Two short lines, auto-shrunk so the text NEVER overflows the panel.
  if (inHorizon) {
    const stage = horizonStage(s)
    const line1 = T(S.CAP.counterStage[stage], s.lang)
    const line2 = T(S.CAP.counterSub, s.lang)
    const maxW = r.w - 2 * M.COUNTER_FLOOR.padX
    const fitLine = (txt: string, size: number) => {
      let s2 = size
      ctx.font = `600 ${s2}px ${M.FONT}`
      while (ctx.measureText(txt).width > maxW && s2 > 8) {
        s2--
        ctx.font = `600 ${s2}px ${M.FONT}`
      }
      return s2
    }
    const s1 = fitLine(line1, 11)
    const s2 = fitLine(line2, 11)
    label(ctx, line1, { x: r.x + r.w / 2, y: r.y + r.h - 24 }, { size: s1, color: hexA('#e2e8f0', 0.92) })
    label(ctx, line2, { x: r.x + r.w / 2, y: r.y + r.h - 10 }, { size: s2, color: hexA('#e2e8f0', 0.7) })
  }
  ctx.restore()
}

// ===========================================================================
// ENTRY-STAGE — the links, the fetch hops, the mini instruction cards
// ===========================================================================
export const drawEntryStage: EntityRenderer = (ctx, s, _e, _active) => {
  const frac = beatFrac(s)

  // ---- the links between the rungs (each hop is its own path §2.1) ----
  ctx.save()
  ctx.globalAlpha = 0.4
  ctx.strokeStyle = hexA('#94a3b8', 0.5)
  ctx.lineWidth = M.BUS.width
  ctx.setLineDash(M.BUS.dash as [number, number])
  for (const [a, b] of L.LINKS) {
    ctx.beginPath()
    ctx.moveTo(a.x, a.y)
    ctx.lineTo(b.x, b.y)
    ctx.stroke()
  }
  ctx.restore()

  // ---- the fetch hop's mini instruction card (die beats) ----
  const row = DIE_BEATS[s.beatIndex]
  if (row !== undefined && s.fading !== 'out') {
    const alpha = clamp((frac - 0.42) / 0.1, 0, 1) * clamp((0.92 - frac) / 0.1, 0, 1)
    if (alpha > 0.01) {
      const ins = S.instrByRow(row)
      drawInstrCard(ctx, s.sparkPos, row, {
        w: M.MINI_CARD.w,
        h: M.MINI_CARD.h,
        r: M.MINI_CARD.r,
        alpha,
        showValue: ins.op === 'LOAD',
        value: ins.value,
        scale: 0.8,
      })
    }
  }
}

// ===========================================================================
// HORIZON-STAGE — the machine running forever
// ===========================================================================
const HORIZON_CARD_PATH: Vec2[] = [L.CPU_RUNG.pos, L.L1_DOCK, L.CPU_RUNG.pos]

export const drawHorizonStage: EntityRenderer = (ctx, s, _e, _active) => {
  const tick = horizonTick(s)
  if (tick <= 0) return

  // the fetch stream: three tiny cards chase each other core → L1 → core,
  // one new card every 2/3 tick, so at speed the road visibly streams with
  // instructions (each tick still carries exactly one instruction — the
  // cards are the same instruction viewed at consecutive instants).
  const N = 3
  for (let i = 0; i < N; i++) {
    const origin = tick - i * (2 / 3)
    if (origin < 0) continue
    const u = (((origin % 2) + 2) % 2) / 2
    const pos = polylinePoint(HORIZON_CARD_PATH, u)
    const row = S.HORIZON_POINTER + Math.floor(origin)
    drawInstrCard(ctx, pos, row, {
      w: M.MINI_CARD.w * 0.8,
      h: M.MINI_CARD.h * 0.8,
      r: M.MINI_CARD.r,
      alpha: 0.8,
    })
  }
}
