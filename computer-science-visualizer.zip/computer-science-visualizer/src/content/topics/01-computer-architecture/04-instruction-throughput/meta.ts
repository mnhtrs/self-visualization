// content/topics/01-computer-architecture/04-instruction-throughput/meta.ts
// Topic 01 Chapter 04 — question-based title, per the curriculum graph and the
// owner's final-chapter directive.

import type { ChapterMeta } from '../../../../chapter-loader/types'
import thumb from './assets/thumbnail.jpg'

const meta: ChapterMeta = {
  id: 'topic-01-computer-architecture--ch-04-instruction-throughput',
  slug: 'how-cpu-runs-billions-per-second',
  order: 4,
  chapterOrder: 4,
  topicId: 'topic-01-computer-architecture',
  topicSlug: 'computer-architecture',
  topicOrder: 1,
  topicTitle: { en: 'Computer Architecture', vi: 'Kiến trúc Máy tính' },
  status: 'available',
  thumbnail: thumb,
  title: {
    en: 'How does a CPU run billions of instructions per second?',
    vi: 'CPU chạy hàng tỷ lệnh mỗi giây như thế nào?',
  },
  subtitle: {
    en: 'The final chapter of Topic 01. Follow one instruction inside the CPU and watch the working floor fill until every station is busy — one instruction completes every tick, while each one still takes the same full journey.',
    vi: 'Chương cuối của Topic 01. Đi theo một lệnh vào bên trong CPU và nhìn sàn làm việc dần kín — mỗi nhịp lại có một lệnh hoàn thành, trong khi từng lệnh vẫn mất trọn hành trình như cũ.',
  },
  accent: '#fb923c',
  loadStory: () => import('./index').then((m) => m.chapter),
}

export default meta
