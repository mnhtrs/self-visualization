// content/topics/01-computer-architecture/04-instruction-throughput/assemble.ts
// The full declarative assembly of Topic 01 Chapter 04 — everything except the
// meta import. Kept meta-free so the chapter can be built and verified outside
// Vite's asset pipeline (same pattern as Ch-02/Ch-03's assemble.ts).

import type {
  Chapter,
  ChapterMeta,
  EntityDescription,
  HitZone,
  SceneDescription,
  Vec2,
} from '../../../../chapter-loader/types'

import {
  cpu, l1, l2, l3, ram, listPanel, counterPanel, entryStage, horizonStage,
  PATH_ENTRY, PATH_HORIZON, BBOX_ENTRY, BBOX_HORIZON, CPU_RECT,
} from './scenes/01-entry'
import {
  cpuDock, floorStage, fetchDock, writeBackDock, listDock, counterDock,
  regDock, l1Dock, PATH_FLOOR, BBOX_FLOOR,
} from './scenes/02-floor'
import { beats } from './narration/beats'
import {
  chapterTitle, waitingLine, startButton, sceneTag, tipText, doneLabel,
} from './narration/labels'
import type { PartSpec } from './types'
import { RENDERERS } from './renderers'
import { horizonStartT } from './renderers/entry'
import { polylinePoint } from '../../../../shared/geometry'
import * as S from './scenes/story'
import type { Vec2 as LVec2 } from '../../../../chapter-loader/types'

// ---- helpers ----------------------------------------------------------------
const toEntity = (
  p: PartSpec,
  sceneId: string,
  extra?: Record<string, unknown>,
): EntityDescription => ({
  id: p.id,
  kind: p.kind ?? p.id,
  pos: p.pos,
  color: p.color,
  name: p.name,
  gloss: p.gloss,
  scene: sceneId,
  extra: { ...p.extra, ...extra },
  labelSize: p.labelSize,
})

// ---- scene 1: entry — the whole machine, quiet --------------------------------
const entryScene: SceneDescription = {
  id: 'entry',
  bbox: BBOX_ENTRY,
  cameraPad: 0.9,
  path: PATH_ENTRY,
  entities: [
    toEntity(entryStage, 'entry'),
    toEntity(cpu, 'entry'),
    toEntity(l1, 'entry'),
    toEntity(l2, 'entry'),
    toEntity(l3, 'entry'),
    toEntity(ram, 'entry'),
    toEntity(listPanel, 'entry'),
    toEntity(counterPanel, 'entry'),
  ],
}

// ---- scene 2: floor — the working floor inside the CPU -------------------------
const floorScene: SceneDescription = {
  id: 'floor',
  bbox: BBOX_FLOOR,
  cameraPad: 0.9,
  path: PATH_FLOOR,
  entities: [
    toEntity(floorStage, 'floor'),
    toEntity(listDock, 'floor'),
    toEntity(counterDock, 'floor'),
    toEntity(regDock, 'floor'),
    toEntity(l1Dock, 'floor'),
    toEntity(fetchDock, 'floor'),
    toEntity(writeBackDock, 'floor'),
    toEntity(cpuDock, 'floor'),
  ],
}

// ---- scene 3: horizon — the whole world, running forever ------------------------
const horizonScene: SceneDescription = {
  id: 'horizon',
  bbox: BBOX_HORIZON,
  cameraPad: 0.92,
  path: PATH_HORIZON,
  entities: [
    toEntity(horizonStage, 'horizon'),
    toEntity(cpu, 'horizon'),
    toEntity(l1, 'horizon'),
    toEntity(l2, 'horizon'),
    toEntity(l3, 'horizon'),
    toEntity(ram, 'horizon'),
    toEntity(listPanel, 'horizon'),
    toEntity(counterPanel, 'horizon'),
  ],
}

// ---- hit zone (the learner starts the machine by clicking the CPU) --------------
const hitZones: HitZone[] = [
  {
    id: 'cpu-box',
    hits: (w: Vec2) =>
      w.x >= CPU_RECT.x &&
      w.x <= CPU_RECT.x + CPU_RECT.w &&
      w.y >= CPU_RECT.y &&
      w.y <= CPU_RECT.y + CPU_RECT.h,
  },
]

// ---- the assembled Chapter --------------------------------------------------------
export function assembleChapter(m: ChapterMeta): Chapter {
  return {
    meta: m,
    scenes: [entryScene, floorScene, horizonScene],
    timeline: {
      beats,
      fadeDuration: 450,
    },
    hitZones,
    runtime: {
      // The protagonist holds at each scene's exit anchor during fade-out, so
      // it stays traceable across every seam (VISUAL_LANGUAGE §13).
      seamPosition: (scene: string): Vec2 | null => {
        if (scene === 'entry') return PATH_ENTRY[PATH_ENTRY.length - 1]
        if (scene === 'floor') return PATH_FLOOR[PATH_FLOOR.length - 1]
        if (scene === 'horizon') return PATH_HORIZON[PATH_HORIZON.length - 1]
        return null
      },
      // The horizon protagonist RUNS: core → L1 → core, one loop per two
      // ticks, at the chapter's own accelerating tick rate — so when the
      // machine speeds up, the golden spark visibly races (the trail
      // stretches into a light ribbon). Each tick still completes exactly
      // one instruction; the spark is the flowing work, not a faster
      // instruction (canon C-05 preserved).
      loopPosition: (t: number, scene: string): LVec2 | null => {
        if (scene !== 'horizon') return null
        const elapsed = Math.max(0, t - horizonStartT())
        const tick = S.horizonTickAt(elapsed)
        const len = S.horizonTickLen(elapsed)
        const phase = len > 0 ? (elapsed / len) % 1 : 0
        const u = (((tick + phase) % 2) + 2) % 2 / 2
        return polylinePoint(PATH_HORIZON, u)
      },
    },
    ui: {
      chapterTitle,
      waitingLine,
      startButton,
      sceneTag,
      tipText,
      doneLabel,
    },
    entityRenderers: RENDERERS,
  }
}
