// narration/labels.ts — UI strings of Topic 01 Chapter 04 (the Viewer reads
// these via chapter.ui; every key the generic Viewer may look for is provided).

import type { LocalizedText } from '../../../../../chapter-loader/types'

export const chapterTitle: LocalizedText = {
  en: 'How does a CPU run billions of instructions per second?',
  vi: 'CPU chạy hàng tỷ lệnh mỗi giây như thế nào?',
}

export const waitingLine: LocalizedText = {
  en: 'The whole machine is waiting — and so is the long program. Start it, and watch the CPU work.',
  vi: 'Cả cỗ máy đang chờ — và chương trình dài cũng vậy. Cho nó chạy đi, rồi nhìn CPU làm việc.',
}

export const startButton: LocalizedText = {
  en: 'Start the machine',
  vi: 'Khởi động cỗ máy',
}

export const sceneTag: LocalizedText = {
  en: 'Inside the CPU',
  vi: 'Bên trong CPU',
}

export const tipText: LocalizedText = {
  en: 'Click the CPU to begin. Use the < > buttons or the dots to step through.',
  vi: 'Bấm vào CPU để bắt đầu. Dùng nút < > hoặc các chấm để tua tới lui.',
}

export const doneLabel: LocalizedText = { en: 'Done', vi: 'Xong' }
