// narration/beats.ts — the storyboard of Topic 01 Chapter 04: 17 beats over 3
// scenes, answering exactly one question — how does a CPU run billions of
// instructions per second? — without ever answering it in words.
//
// Structure (mirrors 04_storyboard.json beat-for-beat):
//   ACT 0 (entry, b0–b6):  the whole machine, the remembered slow cadence —
//                          quiet, nothing unusual.
//   ACT 1 (floor, b7–b11): the working floor; one instruction crosses it; a
//                          second appears before the first has finished; the
//                          floor fills; one completes every tick — the lines
//                          name the instruction kinds and why the steps repeat,
//                          without ever stating the chapter's conclusion.
//   ACT 2 (floor, b12–b13): the watched instruction crosses the whole floor in
//                          five ticks while five instructions complete — THE
//                          CLIMAX. Silence. One realization, unspoken.
//   ACT 3 (floor, b14–b16): the look-back — the same journey every time; the
//                          one name (Pipeline); the machine keeps running.
//   ACT 4 (horizon, b17):   the whole world, running forever.
//
// Authoring rules honoured here:
//   • Knowledge Reveal Law (NARRATIVE_FRAMING §13): the only term of the
//     chapter — Pipeline — is spoken once (b15), after its behaviour was fully
//     watched. Station names appear once, as labels of what is already known
//     from Chapter 01 (fetch/decode/execute/write back; Memory is the one new
//     name, introduced by the trip it performs).
//   • The climax (b13) carries NO narration, NO term, NO conclusion — the
//     only fully silent beat; the realisation must be the learner's own.
//     (The entry/ramp beats carry brief plain-language explanation of the
//     instruction kinds and the repetition — never the conclusion.)
//   • Quantities spoken derive from scenes/story.ts (§4.5): five stations,
//     five ticks, one completion per tick, the counter values.
//   • Nothing from Chapters 01–03 is re-taught — the cycle is performed, the
//     memory trips are fast familiar blinks.
//   • Forbidden territory (owner directive + AGENT_BOOT): no hazards, stalls,
//     dependency stalls, misses mid-flight, contention, processes, threads,
//     cores, coherence, superscalar/out-of-order, and no Throughput / Latency
//     text anywhere. Enforced by the scope gate.
//   • Silence beats use a non-breaking space so the narration panel keeps its
//     height while showing nothing.

import type { BeatDescription } from '../../../../../chapter-loader/types'

const SILENT: { en: string; vi: string } = { en: '\u00A0', vi: '\u00A0' }

export const beats: BeatDescription[] = [
  // ===========================================================================
  // ACT 0 — the whole machine, quiet
  // ===========================================================================
  {
    id: 'the-machine',
    scene: 'entry',
    line: {
      en: 'Here is the whole machine, just as we know it: the CPU, the cache ladder, RAM. And a program — long, and waiting to run.',
      vi: 'Đây là cả cỗ máy, đúng như ta từng biết: CPU, bậc thang cache, RAM. Và một chương trình — dài, đang chờ được chạy.',
    },
    duration: 6800, active: 'cpu', rest: { at: 0 }, emerge: true,
  },
  {
    id: 'runs-as-always',
    scene: 'entry',
    line: {
      en: 'It runs, exactly as it always has: fetch, decode, execute, write back. One after another. The first step is a LOAD: the machine brings a value back from the nearest cache level — ◆, one of the values this program works with.',
      vi: 'Nó chạy, y như xưa nay: fetch, decode, execute, write back. Hết lệnh này đến lệnh khác. Bước đầu là một lệnh LOAD: máy mang một giá trị về từ tầng cache gần nhất — ◆, một trong những giá trị chương trình này đang dùng.',
    },
    duration: 7400, active: 'cpu', travel: { from: 0, to: 2 },
  },
  {
    id: 'one-then-the-next',
    scene: 'entry',
    line: {
      en: 'Now an ADD: the machine adds two numbers it already holds inside — no trip to memory. The same few kinds of steps repeat, because that repetition is what running a long program means.',
      vi: 'Giờ là lệnh ADD: máy cộng hai số đã có sẵn bên trong — không cần đi ra bộ nhớ. Mấy loại bước quen thuộc cứ lặp đi lặp lại, vì sự lặp lại đó chính là việc chạy một chương trình dài.',
    },
    duration: 7000, active: null, travel: { from: 0, to: 2 },
  },
  {
    id: 'nothing-unusual',
    scene: 'entry',
    line: {
      en: 'A STORE sends a value back out to the cache levels. One after another. Nothing unusual — every program is just a long list of simple steps, run in order.',
      vi: 'Lệnh STORE gửi một giá trị trả ra các tầng cache. Hết lệnh này đến lệnh khác. Chẳng có gì lạ — mọi chương trình chỉ là một danh sách dài những bước đơn giản, chạy theo thứ tự.',
    },
    duration: 7000, active: 'l1', travel: { from: 0, to: 2 },
  },
  {
    id: 'and-another',
    scene: 'entry',
    line: {
      en: 'SUB subtracts, CMP compares — more of the same kinds of steps. Same journey, different row, every time.',
      vi: 'SUB là trừ, CMP là so sánh — vẫn mấy loại bước như thế. Cùng một hành trình, khác dòng lệnh, lần nào cũng vậy.',
    },
    duration: 7000, active: null, travel: { from: 0, to: 2 },
  },
  {
    id: 'still-long',
    scene: 'entry',
    line: {
      en: 'Five done. And the list is still long — this is only the beginning. A real program needs billions of steps like these just to draw one screen. And we are watching in slow motion — far, far slower than real life: the real machine finishes around four billion instructions every second. In the time it takes you to blink, about a billion of them are done.',
      vi: 'Mới năm lệnh xong. Mà danh sách vẫn còn dài — đây mới chỉ là khởi đầu. Một chương trình thật cần hàng tỉ bước như thế này chỉ để vẽ ra một màn hình. Và chúng ta đang xem phim quay chậm — chậm hơn thực tế rất, rất nhiều: máy thật hoàn thành khoảng bốn tỉ lệnh mỗi giây. Trong một cái chớp mắt của bạn, đã có khoảng một tỉ lệnh xong.',
    },
    duration: 7000, active: 'list', travel: { from: 0, to: 2 },
  },
  {
    id: 'follow-it-in',
    scene: 'entry',
    line: {
      en: 'Follow the next instruction — inside the machine.',
      vi: 'Theo chân lệnh tiếp theo — vào bên trong cỗ máy.',
    },
    duration: 6400, active: 'cpu', travel: { from: 0, to: 2 },
  },

  // ===========================================================================
  // ACT 1 — the working floor: ramp → city
  // ===========================================================================
  {
    id: 'the-floor',
    scene: 'floor',
    line: {
      en: 'This is the working floor of the CPU. Five stations — every instruction visits them in the same order: Fetch, Decode, Execute, Memory, Write Back.',
      vi: 'Đây là sàn làm việc của CPU. Năm trạm — mọi lệnh đều ghé qua theo đúng thứ tự: Fetch, Decode, Execute, Memory, Write Back.',
    },
    duration: 7000, active: 'floor', rest: { at: 0 }, emerge: true,
  },
  {
    id: 'one-enters',
    scene: 'floor',
    line: {
      en: 'Row 6 enters — a LOAD. It will bring its value down and up from the cache levels. For now the floor is empty: four stations sit idle.',
      vi: 'Dòng 6 đi vào — một lệnh LOAD. Nó sẽ mang giá trị của nó xuống rồi lên từ các tầng cache. Còn lúc này sàn vẫn trống: bốn trạm đứng chờ.',
    },
    duration: 3200, active: null, travel: { from: 0, to: 2 },
  },
  {
    id: 'two-at-once',
    scene: 'floor',
    line: {
      en: 'A second instruction appears before the first has finished. The machine never waits for the floor to empty — each station hands its work onward, and the first station is free again.',
      vi: 'Lệnh thứ hai xuất hiện khi lệnh đầu chưa xong. Máy không bao giờ chờ sàn trống — mỗi trạm chuyển việc cho trạm kế tiếp, và trạm đầu lại rảnh.',
    },
    duration: 4800, active: null, travel: { from: 3, to: 5 },
  },
  {
    id: 'filling',
    scene: 'floor',
    line: {
      en: 'The first instruction of this floor completes — the counter moves to 6. Every station is now busy: the floor is full, and it stays full.',
      vi: 'Lệnh đầu tiên của sàn này hoàn thành — bộ đếm nhảy lên 6. Giờ mọi trạm đều bận: sàn đã đầy, và nó cứ đầy như vậy.',
    },
    duration: 4800, active: null, rest: { at: 0 },
  },
  {
    id: 'the-rhythm',
    scene: 'floor',
    line: {
      en: 'One instruction in, one instruction out — every tick. The steps keep repeating because the program still has rows left: each repetition is one more row finished. This is what running a long program looks like — slowed down billions of times.',
      vi: 'Mỗi nhịp: một lệnh vào, một lệnh ra. Các bước cứ lặp lại vì chương trình vẫn còn dòng: mỗi lần lặp là thêm một dòng đã xong. Chạy một chương trình dài trông như thế này — khi đã quay chậm lại hàng tỉ lần.',
    },
    duration: 4800, active: null, rest: { at: 0 },
  },

  // ===========================================================================
  // ACT 2 — the watched instruction; THE CLIMAX
  // ===========================================================================
  {
    id: 'watch-this-one',
    scene: 'floor',
    line: {
      en: 'Watch the next one — row 19, an ADD. It will cross the whole floor, one station per tick, just like every instruction before it.',
      vi: 'Hãy nhìn lệnh tiếp theo — dòng 19, một lệnh ADD. Nó sẽ băng qua cả sàn, mỗi nhịp một trạm, y như mọi lệnh trước nó.',
    },
    duration: 3200, active: 'fetch', rest: { at: 0 },
  },
  {
    id: 'climax',
    scene: 'floor',
    line: SILENT,
    duration: 8000, active: null, travel: { from: 0, to: 6 },
  },

  // ===========================================================================
  // ACT 3 — the look-back
  // ===========================================================================
  {
    id: 'glance-back',
    scene: 'floor',
    line: {
      en: 'The same five stations. The same journey — from the very first instruction on this floor to this one.',
      vi: 'Vẫn năm trạm. Vẫn hành trình ấy — từ lệnh đầu tiên bước vào sàn này cho tới lệnh vừa rồi.',
    },
    duration: 6400, active: 'counter', rest: { at: 6 },
  },
  {
    id: 'the-name',
    scene: 'floor',
    line: {
      en: 'The way this floor works — every station at work, every tick — has a name: a Pipeline.',
      vi: 'Cách cái sàn này làm việc — trạm nào cũng bận, nhịp nào cũng chạy — có một cái tên: Pipeline.',
    },
    duration: 6400, active: 'floor', rest: { at: 6 },
  },
  {
    id: 'keep-running',
    scene: 'floor',
    line: {
      en: 'It will keep running like this for as long as the program lasts. Step back — look at the whole machine.',
      vi: 'Nó sẽ chạy như thế này chừng nào chương trình còn. Lùi ra nào — ngắm cả cỗ máy.',
    },
    duration: 6400, active: 'floor', rest: { at: 6 },
  },

  // ===========================================================================
  // ACT 4 — the whole machine, running forever
  // ===========================================================================
  {
    id: 'forever',
    scene: 'horizon',
    line: {
      en: 'The whole machine is at work. Every tick, one more instruction done — and the list is still long. So far we have been watching in slow motion: here, one tick lasts about one and a half seconds. Now watch it speed up — the tick shortens, and shortens again. Every tick still completes exactly one instruction; the machine simply never stops. At real speed that is around four billion completions every second — about a billion in a single blink.',
      vi: 'Cả cỗ máy đang làm việc. Mỗi nhịp, thêm một lệnh hoàn thành — mà danh sách vẫn còn dài. Nãy giờ chúng ta vẫn đang xem phim quay chậm: ở đây, một nhịp kéo dài khoảng một giây rưỡi. Giờ hãy nhìn nó tăng tốc — nhịp ngắn lại, rồi ngắn nữa. Mỗi nhịp vẫn hoàn thành đúng một lệnh; cỗ máy chỉ đơn giản là không bao giờ dừng. Ở tốc độ thật, đó là khoảng bốn tỉ lệnh hoàn thành mỗi giây — khoảng một tỉ trong một cái chớp mắt.',
    },
    duration: 20000, active: 'cpu', rest: { at: 0 }, effect: 'loop',
  },
]
