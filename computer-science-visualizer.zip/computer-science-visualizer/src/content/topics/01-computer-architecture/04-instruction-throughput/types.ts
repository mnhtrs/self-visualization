// content/topics/01-computer-architecture/04-instruction-throughput/types.ts
// Chapter-local types. The generic interfaces live in chapter-loader/types.

import type { LocalizedText, Vec2 } from '../../../../chapter-loader/types'

/** Legacy alias so narration/geometry code reads like the earlier chapters. */
export type L = LocalizedText

/** The three scenes of the journey. */
export type Scene = 'entry' | 'floor' | 'horizon'

export interface Rect {
  x: number
  y: number
  w: number
  h: number
}

/** A part as the chapter describes it (mirrors the PartSpec of Ch-01/02/03). */
export interface PartSpec {
  id: string
  kind?: string
  pos: Vec2
  color: string
  name: string
  gloss: LocalizedText
  labelSize?: number
  extra?: Record<string, unknown>
}
