// content/chapter-03-across-the-internet/meta.ts — FROZEN thumbnail, question-based

import type { ChapterMeta } from '../../../../chapter-loader/types'
import thumb from './assets/thumbnail.jpg'

const meta: ChapterMeta = {
  id: 'topic-03-networking--ch-06-end-to-end-data-flow',
  slug: 'end-to-end-data-flow',
  order: 6,
  chapterOrder: 6,
  topicId: 'topic-03-networking',
  topicSlug: 'networking',
  topicOrder: 3,
  topicTitle: { en: 'Networking', vi: 'Mạng Máy tính' },
  status: 'available',
  thumbnail: thumb,
  title: {
    en: 'What is the full end-to-end journey of a web request?',
    vi: 'Hành trình đầu-cuối đầy đủ của một web request là gì?',
  },
  subtitle: {
    en: "Follow the page's bytes across the Internet.",
    vi: 'Theo những byte của trang web vượt qua Internet.',
  },
  accent: '#a78bfa',
  loadStory: () => import('./index').then((m) => m.chapter),
}
export default meta
