// app/routes.ts
// Route shapes: Home + Viewer with Topic/Chapter hierarchy.
// Supports both new hierarchical hashes (#/topicSlug/chapterSlug) and legacy flat hashes (#/chapterId)

export type Route =
  | { name: 'home' }
  | { name: 'viewer'; chapterId: string; topicSlug?: string; chapterSlug?: string }

function decode(s: string): string {
  try { return decodeURIComponent(s) } catch { return s }
}

/** Parse window.location.hash into a Route. Unknown/empty → home. */
export function parseHash(hash: string): Route {
  if (!hash) return { name: 'home' }
  // Remove leading '#'
  let h = hash.startsWith('#') ? hash.slice(1) : hash
  // Remove leading '/'
  if (h.startsWith('/')) h = h.slice(1)
  if (!h || h === '/') return { name: 'home' }

  // Split by '/' and filter empty
  const parts = h.split('/').map(decode).filter(Boolean)
  if (parts.length === 0) return { name: 'home' }

  if (parts.length === 1) {
    // Legacy: #/chapter-id or #/chapter-slug or synthetic id
    return { name: 'viewer', chapterId: parts[0] }
  }

  if (parts.length >= 2) {
    const topicSlug = parts[0]
    const chapterSlug = parts[1]
    // chapterId is composite for lookup, but we also keep split parts
    const chapterId = `${topicSlug}/${chapterSlug}`
    return { name: 'viewer', chapterId, topicSlug, chapterSlug }
  }

  return { name: 'home' }
}

/** Build hash URL for a chapter */
export function buildChapterHash(topicSlug: string, chapterSlug: string): string {
  return `#/${encodeURIComponent(topicSlug)}/${encodeURIComponent(chapterSlug)}`
}

/** Build legacy hash (fallback) */
export function buildLegacyHash(chapterId: string): string {
  return `#/${encodeURIComponent(chapterId)}`
}
