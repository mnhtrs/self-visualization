// app/App.tsx
// Application shell with Topic→Chapter hierarchy.
// Handles both hierarchical (#/topic/chapter) and legacy (#/chapterId) routes.

import { useEffect } from 'react'
import { useHashRoute } from './useHashRoute'
import { isAvailable, getChapter } from '../chapter-loader/registry'
import { buildChapterHash } from './routes'
import Home from '../home/Home'
import Viewer from '../viewer/Viewer'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faHouse } from '@fortawesome/free-solid-svg-icons'

export default function App() {
  const { route, navigate } = useHashRoute()

  // Esc → leave the viewer and return home.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') navigate('#/')
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [navigate])

  const inViewer = route.name === 'viewer' && isAvailable(route.chapterId)

  if (inViewer) {
    const r = route as { name: 'viewer'; chapterId: string; topicSlug?: string; chapterSlug?: string }
    // Resolve canonical id via registry (to get topic/chapter normalization)
    const resolved = getChapter(r.chapterId)
    const id = resolved ? resolved.id : r.chapterId
    const homeBtn = (
      <button
        className="viewer-back"
        onClick={() => navigate('#/')}
        title="Back to home (Esc)"
        aria-label="Back to home"
      >
        <FontAwesomeIcon icon={faHouse} /> <span>Home</span>
      </button>
    )
    return <Viewer key={id} chapterId={id} controlsLeft={homeBtn} />
  }

  // Unknown or coming-soon chapter id → fall back to home.
  return (
    <Home
      onOpen={(topicSlug, chapterSlug) => navigate(buildChapterHash(topicSlug, chapterSlug))}
      onOpenLegacy={(id) => navigate('#/' + id)}
    />
  )
}
