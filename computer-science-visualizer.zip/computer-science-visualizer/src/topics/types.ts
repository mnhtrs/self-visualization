// topics/types.ts — Topic hierarchy types for CESVI restructure

import type { LocalizedText } from '../chapter-loader/types'

export interface TopicChapterDef {
  order: number // 1..N reset per topic
  slug: string // url-safe, e.g. 'program-execution'
  id: string // canonical chapter id, e.g. 'program-execution' or full unique
  title: LocalizedText
  subtitle?: LocalizedText
}

export interface TopicDef {
  id: string // e.g. 'topic-01-computer-architecture'
  slug: string // e.g. 'computer-architecture'
  order: number // 1..15
  title: LocalizedText
  subtitle: LocalizedText
  accent: string // hex color
  centralQuestion?: LocalizedText
  chapters: TopicChapterDef[]
}

export interface TopicMeta {
  id: string
  slug: string
  order: number
  title: LocalizedText
  subtitle: LocalizedText
  accent: string
  centralQuestion?: LocalizedText
}
