// topics/definitions.ts — REVISED CURRICULUM AUDIT (49 chapters, question-based)
// Freeze: 3 existing chapters (program-execution, resource-loading, end-to-end-data-flow) keep their thumbnails untouched.
// All other chapters are coming-soon with unique thumbnail specs (to be generated).

import type { TopicDef } from './types'

const en = (s: string) => ({ en: s, vi: s })

export const TOPICS: TopicDef[] = [
  {
    id: 'topic-01-computer-architecture',
    slug: 'computer-architecture',
    order: 1,
    title: { en: 'Computer Architecture', vi: 'Kiến trúc Máy tính' },
    subtitle: { en: 'How hardware executes computation', vi: 'Phần cứng thực thi tính toán như thế nào' },
    accent: '#fb923c',
    centralQuestion: en('How does hardware execute computation?'),
    chapters: [
      // CURRICULUM v1.2.0 (owner directive, Topic 01 Ch-02 redesign): the old
      // Ch-02 "How does a CPU execute a single instruction?" was RETIRED — the
      // Basic Instruction Cycle is already established inside Ch-01, so a second
      // chapter on it would repeat rather than transform a mental model.
      // Ch-02 is now the memory-latency chapter; the remaining chapters shift up.
      //
      // CURRICULUM v1.3.0 (owner directive, official production spec): the
      // reserved Ch-03 "Instruction-level throughput" moves to slot 04. Slot 03
      // now opens Chapter 02's deferred black box: how a cache level decides
      // hit or miss (Cache Line, Set, the three mappings, Tag/Index/Offset,
      // Lookup, Replacement with FIFO/LRU).
      { order: 1, slug: 'program-execution', id: 'program-execution', title: { en: 'How does a program actually start running?', vi: 'Chương trình thực sự bắt đầu chạy như thế nào?' } },
      { order: 2, slug: 'how-cpu-avoids-waiting-for-memory', id: 'how-cpu-avoids-waiting-for-memory', title: { en: 'How does the CPU avoid waiting for memory?', vi: 'CPU tránh chờ bộ nhớ như thế nào?' } },
      { order: 3, slug: 'how-cache-decides-hit-or-miss', id: 'how-cache-decides-hit-or-miss', title: { en: 'How does a CPU cache decide hit or miss?', vi: 'Cache quyết định Hit hay Miss như thế nào?' } },
      { order: 4, slug: 'how-cpu-runs-billions-per-second', id: 'how-cpu-runs-billions-per-second', title: { en: 'How does a CPU run billions of instructions per second?', vi: 'CPU chạy hàng tỷ lệnh mỗi giây như thế nào?' } },
    ],
  },
  {
    // CURRICULUM v0.4.0 (owner directive 2026-08-15):
    // Topic 02 redesigned from 6 chapters to 5 canonical chapters.
    // Legacy CH02 (Inside a Process) + Legacy CH03 (Running a Process) merged into
    // New CH02: Process Execution: Pause, Switch, Resume (slug: process-execution).
    //
    // Each chapter = one mental model transformation (CESVI pedagogical law).
    // Canonical authority: docs/curriculum/CURRICULUM_GUARDIAN_T02_DRAFT.md
    // Causal backbone: Program → Process → Process Execution (Pause/Switch/Resume) →
    //   CPU Scheduling → Threads → Multithreading → (Topic 06)
    id: 'topic-02-operating-systems',
    slug: 'operating-systems',
    order: 2,
    title: { en: 'Processes & Threads', vi: 'Tiến trình & Luồng' },
    subtitle: {
      en: 'How the OS creates, runs, and manages execution',
      vi: 'OS tạo, chạy và quản lý thực thi như thế nào',
    },
    accent: '#f472b6',
    centralQuestion: en(
      'How does the OS turn programs into managed execution, and how does that execution evolve from processes to threads?'
    ),
    chapters: [
      // CH01 — Process: From Program to Managed Execution
      // Mental model: A Program is not a Process. A Process is a managed execution instance.
      // Central question: What does the OS actually create when you launch a program?
      {
        order: 1,
        slug: 'process-from-program-to-execution',
        id: 'process-from-program-to-execution',
        title: {
          en: 'Process: From Program to Managed Execution',
          vi: 'Process: Từ chương trình đến thực thi được OS quản lý',
        },
      },
      // CH02 — Process Execution: Pause, Switch, Resume
      // Mental model: A Process has an execution environment and execution context; state changes
      // in response to events; execution pauses, switches CPU to another Process, and resumes.
      // Central question: How can the OS manage a Process as it runs, stops, and resumes?
      {
        order: 2,
        slug: 'process-execution',
        id: 'process-execution',
        title: {
          en: 'Process Execution: Pause, Switch, Resume',
          vi: 'Process Execution: Tạm dừng, chuyển đổi và tiếp tục thực thi',
        },
      },
      // CH03 — CPU Scheduling: Who Runs Next?
      // Mental model: CPU time is limited; the OS allocates it via a scheduling policy.
      // Central question: How does the OS decide which Process gets the CPU next?
      {
        order: 3,
        slug: 'cpu-scheduling',
        id: 'cpu-scheduling',
        title: {
          en: 'CPU Scheduling: Who Runs Next?',
          vi: 'CPU Scheduling: Ai được chạy tiếp?',
        },
      },
      // CH04 — Thread: Multiple Paths Inside One Process
      // Mental model: A Process provides the shared environment; Threads are independent paths inside it.
      // Central question: Why does a Process need Threads to do many things at once?
      {
        order: 4,
        slug: 'threads',
        id: 'threads',
        title: {
          en: 'Thread: Multiple Paths Inside One Process',
          vi: 'Thread: Nhiều đường thực thi bên trong một Process',
        },
      },
      // CH05 — Multithreading: Many Threads, One Shared World
      // Mental model: Multiple paths sharing mutable state create concurrency problems.
      // Central question: What happens when many Threads share the same data?
      // Boundary: stops at "need for synchronization" — Topic 06 owns the solution.
      {
        order: 5,
        slug: 'multithreading',
        id: 'multithreading',
        title: {
          en: 'Multithreading: Many Threads, One Shared World',
          vi: 'Multithreading: Nhiều Thread trong cùng một thế giới dữ liệu',
        },
      },
    ],
  },
  {
    id: 'topic-03-networking',
    slug: 'networking',
    order: 3,
    title: { en: 'Networking', vi: 'Mạng Máy tính' },
    subtitle: { en: 'How data travels between computers', vi: 'Dữ liệu đi giữa các máy tính như thế nào' },
    accent: '#a78bfa',
    centralQuestion: en('How does data travel from one computer to another over network?'),
    chapters: [
      { order: 1, slug: 'what-leaves-your-computer', id: 'what-leaves-your-computer', title: { en: 'What actually leaves your computer when you send data?', vi: 'Điều gì thực sự rời khỏi máy tính của bạn khi bạn gửi dữ liệu?' } },
      { order: 2, slug: 'how-packet-finds-way', id: 'how-packet-finds-way', title: { en: 'How does a packet find its way across the world?', vi: 'Gói tin tìm đường đi khắp thế giới như thế nào?' } },
      { order: 3, slug: 'how-internet-knows-server', id: 'how-internet-knows-server', title: { en: 'How does the Internet know which server you want?', vi: 'Internet biết bạn muốn máy chủ nào như thế nào?' } },
      { order: 4, slug: 'how-data-arrives-reliably', id: 'how-data-arrives-reliably', title: { en: 'How does data arrive reliably despite an unreliable network?', vi: 'Dữ liệu đến một cách đáng tin cậy mặc dù mạng không đáng tin cậy như thế nào?' } },
      { order: 5, slug: 'how-internet-keeps-private', id: 'how-internet-keeps-private', title: { en: 'How does the Internet keep your data private?', vi: 'Internet giữ dữ liệu của bạn riêng tư như thế nào?' } },
      { order: 6, slug: 'end-to-end-data-flow', id: 'end-to-end-data-flow', title: { en: 'What is the full end-to-end journey of a web request?', vi: 'Hành trình đầu-cuối đầy đủ của một web request là gì?' } },
    ],
  },
  {
    id: 'topic-04-web-browser',
    slug: 'web-browser',
    order: 4,
    title: { en: 'Web Browser', vi: 'Trình duyệt Web' },
    subtitle: { en: 'How browser turns resources into web pages', vi: 'Trình duyệt biến tài nguyên thành trang web như thế nào' },
    accent: '#22d3ee',
    centralQuestion: en('How does browser turn resources into visible websites?'),
    chapters: [
      { order: 1, slug: 'what-happens-after-enter', id: 'what-happens-after-enter', title: { en: 'What happens after you press Enter in the address bar?', vi: 'Điều gì xảy ra sau khi bạn nhấn Enter trên thanh địa chỉ?' } },
      { order: 2, slug: 'resource-loading', id: 'resource-loading', title: { en: 'How does a website reach my screen?', vi: 'Một trang web đến màn hình của bạn như thế nào?' } },
      { order: 3, slug: 'how-html-becomes-pixels', id: 'how-html-becomes-pixels', title: { en: 'How does HTML become pixels you can see?', vi: 'HTML trở thành pixels mà bạn có thể thấy như thế nào?' } },
      { order: 4, slug: 'how-browser-stays-safe-fast', id: 'how-browser-stays-safe-fast', title: { en: 'How does the browser keep you safe while staying fast?', vi: 'Trình duyệt giữ bạn an toàn trong khi vẫn nhanh như thế nào?' } },
    ],
  },
  {
    id: 'topic-05-memory-systems',
    slug: 'memory-systems',
    order: 5,
    title: { en: 'Memory Systems', vi: 'Hệ thống Bộ nhớ' },
    subtitle: { en: 'How programs see and use memory', vi: 'Chương trình nhìn và dùng bộ nhớ như thế nào' },
    accent: '#4ade80',
    centralQuestion: en('How do programs see and use memory?'),
    chapters: [
      { order: 1, slug: 'what-variable-looks-like', id: 'what-variable-looks-like', title: { en: 'What does a variable actually look like in memory?', vi: 'Biến thực sự trông như thế nào trong bộ nhớ?' } },
      { order: 2, slug: 'how-program-manages-memory', id: 'how-program-manages-memory', title: { en: 'How does a program manage memory while it runs?', vi: 'Chương trình quản lý bộ nhớ khi đang chạy như thế nào?' } },
      { order: 3, slug: 'how-every-process-thinks-all-memory', id: 'how-every-process-thinks-all-memory', title: { en: 'How can every process think it has all the memory?', vi: 'Làm sao mọi tiến trình đều nghĩ nó có toàn bộ bộ nhớ?' } },
      { order: 4, slug: 'what-happens-to-forgotten-memory', id: 'what-happens-to-forgotten-memory', title: { en: 'What happens to memory you forget to free?', vi: 'Điều gì xảy ra với bộ nhớ bạn quên giải phóng?' } },
    ],
  },
  {
    id: 'topic-06-concurrency-parallelism',
    slug: 'concurrency-parallelism',
    order: 6,
    title: { en: 'Concurrency & Parallelism', vi: 'Đồng thời & Song song' },
    subtitle: { en: 'How multiple flows progress correctly', vi: 'Nhiều luồng cùng tiến triển đúng đắn như thế nào' },
    accent: '#facc15',
    centralQuestion: en('How can multiple execution flows progress concurrently while ensuring correctness?'),
    chapters: [
      { order: 1, slug: 'difference-concurrency-parallelism', id: 'difference-concurrency-parallelism', title: { en: 'What’s the difference between concurrency and parallelism?', vi: 'Khác biệt giữa đồng thời và song song là gì?' } },
      { order: 2, slug: 'why-sharing-memory-breaks', id: 'why-sharing-memory-breaks', title: { en: 'Why does sharing memory break programs?', vi: 'Tại sao chia sẻ bộ nhớ làm hỏng chương trình?' } },
      { order: 3, slug: 'how-to-protect-shared-data', id: 'how-to-protect-shared-data', title: { en: 'How do you protect shared data from corruption?', vi: 'Bạn bảo vệ dữ liệu chia sẻ khỏi hỏng như thế nào?' } },
      { order: 4, slug: 'why-parallel-code-gets-stuck', id: 'why-parallel-code-gets-stuck', title: { en: 'Why does parallel code get stuck or slow?', vi: 'Tại sao code song song bị kẹt hoặc chậm?' } },
    ],
  },
  {
    id: 'topic-07-compilers-language-implementation',
    slug: 'compilers-language-implementation',
    order: 7,
    title: { en: 'Compilers & Language Implementation', vi: 'Trình biên dịch & Cài đặt Ngôn ngữ' },
    subtitle: { en: 'How source becomes executable', vi: 'Source code trở thành thứ thực thi được như thế nào' },
    accent: '#60a5fa',
    centralQuestion: en('How is source code turned into something computers can execute?'),
    chapters: [
      { order: 1, slug: 'how-source-becomes-understood', id: 'how-source-becomes-understood', title: { en: 'How does source code become something the machine understands?', vi: 'Source code trở thành thứ máy hiểu như thế nào?' } },
      { order: 2, slug: 'how-compiler-makes-fast', id: 'how-compiler-makes-fast', title: { en: 'How does the compiler make your code fast and runnable?', vi: 'Trình biên dịch làm code của bạn nhanh và chạy được như thế nào?' } },
      { order: 3, slug: 'how-code-runs-without-compiling', id: 'how-code-runs-without-compiling', title: { en: 'How can code run without being compiled ahead of time?', vi: 'Code chạy mà không cần biên dịch trước như thế nào?' } },
    ],
  },
  {
    id: 'topic-08-storage-file-systems',
    slug: 'storage-file-systems',
    order: 8,
    title: { en: 'Storage & File Systems', vi: 'Lưu trữ & Hệ thống Tệp' },
    subtitle: { en: 'How storage becomes files and directories', vi: 'Storage trở thành file và thư mục như thế nào' },
    accent: '#f87171',
    centralQuestion: en('How does system turn huge storage into files?'),
    chapters: [
      { order: 1, slug: 'how-disk-becomes-files', id: 'how-disk-becomes-files', title: { en: 'How does a disk full of blocks become files you can see?', vi: 'Đĩa đầy blocks trở thành files bạn thấy như thế nào?' } },
      { order: 2, slug: 'how-system-avoids-losing-data', id: 'how-system-avoids-losing-data', title: { en: 'How does the system avoid losing data when power fails?', vi: 'Hệ thống tránh mất dữ liệu khi mất điện như thế nào?' } },
      { order: 3, slug: 'why-ssd-different-from-hdd', id: 'why-ssd-different-from-hdd', title: { en: 'Why is an SSD so different from an HDD?', vi: 'Tại sao SSD khác HDD nhiều như vậy?' } },
    ],
  },
  {
    id: 'topic-09-databases',
    slug: 'databases',
    order: 9,
    title: { en: 'Databases', vi: 'Cơ sở Dữ liệu' },
    subtitle: { en: 'How DB stores, searches and maintains correctness', vi: 'DB lưu, tìm và duy trì đúng đắn dữ liệu như thế nào' },
    accent: '#34d399',
    centralQuestion: en('How does database store, search and maintain correctness?'),
    chapters: [
      { order: 1, slug: 'how-database-stores-finds', id: 'how-database-stores-finds', title: { en: 'How does a database store and find data on disk?', vi: 'Database lưu và tìm dữ liệu trên đĩa như thế nào?' } },
      { order: 2, slug: 'what-happens-when-you-run-sql', id: 'what-happens-when-you-run-sql', title: { en: 'What happens when you run a SQL query?', vi: 'Điều gì xảy ra khi bạn chạy một truy vấn SQL?' } },
      { order: 3, slug: 'how-database-stays-correct', id: 'how-database-stays-correct', title: { en: 'How does a database stay correct with many writers?', vi: 'Database giữ đúng đắn với nhiều người ghi như thế nào?' } },
    ],
  },
  {
    id: 'topic-10-distributed-systems',
    slug: 'distributed-systems',
    order: 10,
    title: { en: 'Distributed Systems', vi: 'Hệ Phân tán' },
    subtitle: { en: 'How many computers form a reliable system', vi: 'Nhiều máy tính tạo một hệ đáng tin cậy như thế nào' },
    accent: '#c084fc',
    centralQuestion: en('How can many computers form a reliable system?'),
    chapters: [
      { order: 1, slug: 'how-computers-communicate-when-late-lost', id: 'how-computers-communicate-when-late-lost', title: { en: 'How do computers communicate when messages can be late or lost?', vi: 'Máy tính giao tiếp khi tin nhắn có thể trễ hoặc mất như thế nào?' } },
      { order: 2, slug: 'how-data-survives-machine-fails', id: 'how-data-survives-machine-fails', title: { en: 'How can data survive when machines fail?', vi: 'Dữ liệu sống sót khi máy hỏng như thế nào?' } },
      { order: 3, slug: 'how-many-machines-agree', id: 'how-many-machines-agree', title: { en: 'How do many machines agree on one decision?', vi: 'Nhiều máy đồng ý một quyết định như thế nào?' } },
    ],
  },
  {
    id: 'topic-11-security',
    slug: 'security',
    order: 11,
    title: { en: 'Security', vi: 'Bảo mật' },
    subtitle: { en: 'How systems protect resources', vi: 'Hệ thống bảo vệ tài nguyên như thế nào' },
    accent: '#fb7185',
    centralQuestion: en('How does system protect resources?'),
    chapters: [
      { order: 1, slug: 'how-system-decides-who-you-are', id: 'how-system-decides-who-you-are', title: { en: 'How does the system decide who you are and what you can do?', vi: 'Hệ thống quyết định bạn là ai và làm gì như thế nào?' } },
      { order: 2, slug: 'how-data-kept-secret', id: 'how-data-kept-secret', title: { en: 'How is data kept secret even if someone sees it?', vi: 'Dữ liệu giữ bí mật ngay khi ai đó thấy nó như thế nào?' } },
      { order: 3, slug: 'how-system-keeps-programs-from-harming', id: 'how-system-keeps-programs-from-harming', title: { en: 'How does the system keep programs from harming each other?', vi: 'Hệ thống giữ các chương trình không làm hại nhau như thế nào?' } },
    ],
  },
  {
    id: 'topic-12-computer-graphics',
    slug: 'computer-graphics',
    order: 12,
    title: { en: 'Computer Graphics', vi: 'Đồ họa Máy tính' },
    subtitle: { en: 'How computers turn geometry into pixels', vi: 'Máy tính biến hình học thành pixel như thế nào' },
    accent: '#38bdf8',
    centralQuestion: en('How does computer turn geometry and data into pixels?'),
    chapters: [
      { order: 1, slug: 'how-numbers-become-3d-picture', id: 'how-numbers-become-3d-picture', title: { en: 'How do numbers become a picture of a 3D world?', vi: 'Số trở thành ảnh của thế giới 3D như thế nào?' } },
      { order: 2, slug: 'how-gpu-turns-geometry-into-pixels', id: 'how-gpu-turns-geometry-into-pixels', title: { en: 'How does the GPU turn geometry into millions of pixels?', vi: 'GPU biến hình học thành hàng triệu pixels như thế nào?' } },
    ],
  },
  {
    id: 'topic-13-embedded-systems',
    slug: 'embedded-systems',
    order: 13,
    title: { en: 'Embedded Systems', vi: 'Hệ Nhúng' },
    subtitle: { en: 'How small computers interact with physical world', vi: 'Máy tính nhỏ tương tác thế giới vật lý như thế nào' },
    accent: '#a3e635',
    centralQuestion: en('How does a small computer interact directly with hardware?'),
    chapters: [
      { order: 1, slug: 'how-tiny-computer-interacts-real-world', id: 'how-tiny-computer-interacts-real-world', title: { en: 'How does a tiny computer interact with the real world?', vi: 'Máy tính tí hon tương tác thế giới thực như thế nào?' } },
      { order: 2, slug: 'how-embedded-devices-talk-deadlines', id: 'how-embedded-devices-talk-deadlines', title: { en: 'How do embedded devices talk and meet deadlines?', vi: 'Thiết bị nhúng nói chuyện và đáp ứng deadline như thế nào?' } },
    ],
  },
  {
    id: 'topic-14-iot-cyber-physical',
    slug: 'iot-cyber-physical',
    order: 14,
    title: { en: 'IoT & Cyber-Physical Systems', vi: 'IoT & Hệ Cyber-Physical' },
    subtitle: { en: 'How systems sense physical world and act over network', vi: 'Hệ thống cảm nhận thế giới vật lý và hành động qua mạng như thế nào' },
    accent: '#2dd4bf',
    centralQuestion: en('How can a system sense physical world and act over network?'),
    chapters: [
      { order: 1, slug: 'how-sensor-data-becomes-useful', id: 'how-sensor-data-becomes-useful', title: { en: 'How does sensor data become useful information in the cloud?', vi: 'Dữ liệu cảm biến trở thành thông tin hữu ích trên cloud như thế nào?' } },
      { order: 2, slug: 'what-happens-when-physical-fails', id: 'what-happens-when-physical-fails', title: { en: 'What happens when the physical world or network fails?', vi: 'Điều gì xảy ra khi thế giới vật lý hoặc mạng hỏng?' } },
    ],
  },
  {
    id: 'topic-15-ai-systems',
    slug: 'ai-systems',
    order: 15,
    title: { en: 'AI Systems & Computational Intelligence', vi: 'Hệ thống AI & Trí tuệ Tính toán' },
    subtitle: { en: 'AI as systems engineering, not just models', vi: 'AI như kỹ thuật hệ thống, không chỉ mô hình' },
    accent: '#fbbf24',
    centralQuestion: en('How do AI systems scale computation and serve intelligence?'),
    chapters: [
      { order: 1, slug: 'what-happens-when-ai-learns', id: 'what-happens-when-ai-learns', title: { en: 'What really happens when an AI model learns from data?', vi: 'Điều gì thực sự xảy ra khi mô hình AI học từ dữ liệu?' } },
      { order: 2, slug: 'how-ai-turns-prompt-into-answer', id: 'how-ai-turns-prompt-into-answer', title: { en: 'How does an AI model turn your prompt into an answer?', vi: 'Mô hình AI biến prompt của bạn thành câu trả lời như thế nào?' } },
      { order: 3, slug: 'how-run-ai-reliably-for-millions', id: 'how-run-ai-reliably-for-millions', title: { en: 'How do you run AI reliably for millions of users?', vi: 'Bạn chạy AI đáng tin cậy cho hàng triệu người dùng như thế nào?' } },
    ],
  },
]
