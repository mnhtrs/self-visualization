// topics/registry.ts — Topic registry and helper lookups
import { TOPICS } from './definitions'
import type { TopicDef } from './types'

export const topics: TopicDef[] = TOPICS.slice().sort((a, b) => a.order - b.order)

export function getTopicBySlug(slug: string): TopicDef | undefined {
  return topics.find(t => t.slug === slug || t.id === slug)
}

export function getTopicById(id: string): TopicDef | undefined {
  return topics.find(t => t.id === id)
}

export function getTopicForChapterSlug(chapterSlug: string): TopicDef | undefined {
  // naive: find which topic contains chapter slug
  return topics.find(t => t.chapters.some(c => c.slug === chapterSlug || c.id === chapterSlug))
}

export function getChapterDef(topicSlug: string, chapterSlug: string) {
  const topic = getTopicBySlug(topicSlug)
  if (!topic) return undefined
  return topic.chapters.find(c => c.slug === chapterSlug || c.id === chapterSlug)
}
