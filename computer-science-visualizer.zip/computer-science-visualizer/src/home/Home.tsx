// home/Home.tsx
// Topic-based homepage — shows Topic hierarchy with Chapter reset 01 per Topic

import { useState } from 'react'
import { getTopics } from '../chapter-loader/registry'
import type { ChapterMeta, Lang } from '../chapter-loader/types'
import SocialButtons, { FACEBOOK_URL, DISCORD_URL } from '../components/SocialButtons'
import './home.css'

interface Props {
  onOpen: (topicSlug: string, chapterSlug: string) => void
  onOpenLegacy?: (chapterId: string) => void
}

export default function Home({ onOpen }: Props) {
  const topics = getTopics()
  const [lang, setLang] = useState<Lang>('en')
  const year = new Date().getFullYear()
  const t = lang === 'vi'
  const scrollTo = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })

  return (
    <div className="home">
      {/* ===== HEADER ===== */}
      <header className="home-header">
        <div className="header-inner">
          <div className="logo-wrap">
            <img className="logo-mark" src="/favicon.svg" alt="CeSVi" />
            <div className="logo">CeSVi</div>
          </div>
          <div className="header-right">
            <div className="header-nav">
              <button className="header-link" onClick={() => scrollTo('journeys')}>{t ? 'Khám phá' : 'Explore'}</button>
              <button className="header-link" onClick={() => scrollTo('about')}>{t ? 'Giới thiệu' : 'About'}</button>
            </div>
            {(['en', 'vi'] as Lang[]).map((l) => (
              <button key={l} className={`lang-pill ${lang === l ? 'on' : ''}`} onClick={() => setLang(l)}>
                {l.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* ===== MAIN ===== */}
      <main className="home-main">
        <div className="hero">
          <h1 className="brand">
            {t ? 'Học Khoa học Máy tính bằng hình ảnh' : 'Learn Computer Science visually'}
          </h1>
          <p className="tagline">
            {t ? '15 Topics • 203 cơ chế • Mỗi Chapter là một visualization hành trình' : '15 Topics • 203 mechanisms • Each Chapter is a visual journey'}
          </p>
        </div>

        <div className="topics" id="journeys">
          {topics.map((topic) => {
            const availableCount = topic.chapters.filter((c: any) => c.status === 'available').length
            const totalCount = topic.chapters.length
            return (
              <section key={topic.id} className="topic-section" style={{ ['--accent' as string]: topic.accent }}>
                <div className="topic-header">
                  <div className="topic-meta">
                    <div className="topic-num">Topic {String(topic.order).padStart(2, '0')}</div>
                    <h2 className="topic-title">{topic.title[lang]}</h2>
                    <p className="topic-sub">{topic.subtitle[lang]}</p>
                  </div>
                  <div className="topic-stats">
                    <span className="topic-count">{availableCount}/{totalCount} {t ? 'sẵn sàng' : 'available'}</span>
                  </div>
                </div>
                <div className="grid">
                  {topic.chapters.map((c: ChapterMeta) => {
                    const available = c.status === 'available'
                    return (
                      <button
                        key={c.id}
                        className={`card ${available ? 'available' : 'soon'}`}
                        onClick={available ? () => onOpen(c.topicSlug, c.slug) : undefined}
                        disabled={!available}
                        style={{ ['--accent' as string]: c.accent }}
                      >
                        <div className="thumb">
                          {c.thumbnail ? <img src={c.thumbnail} alt="" /> : <div className="thumb-empty" />}
                          {!available && (
                            <div className="badge-soon">{t ? 'Sắp ra mắt' : 'Coming Soon'}</div>
                          )}
                        </div>
                        <div className="card-body">
                          <div className="card-num-row">
                            <span className="card-topic-label" title={topic.title[lang]}>
                              T{String(topic.order).padStart(2, '0')}
                            </span>
                            <span className="card-num">Ch {String(c.chapterOrder).padStart(2, '0')}</span>
                          </div>
                          <div className="card-title">{c.title[lang]}</div>
                          <div className="card-sub">{c.subtitle[lang] || (t ? `Thuộc ${topic.title[lang]}` : `Part of ${topic.title[lang]}`)}</div>
                        </div>
                      </button>
                    )
                  })}
                </div>
              </section>
            )
          })}
        </div>
      </main>

      {/* ===== FOOTER ===== */}
      <footer className="home-footer">
        <div className="footer-inner">
          <div className="footer-top">
            <div className="footer-brand-col" id="about">
              <div className="footer-logo">
                <img className="logo-mark footer-logo-icon" src="/favicon.svg" alt="CeSVi" />
                <span className="footer-logo-text">CeSVi</span>
              </div>
              <p className="footer-desc">
                {t
                  ? 'CeSVi là nền tảng hình ảnh hóa Khoa học Máy tính. Mỗi Topic là một miền kiến thức, mỗi Chapter là một cơ chế có thể trực quan hóa.'
                  : 'CeSVi is a Computer Science visualization platform. Every Topic is a knowledge domain, every Chapter is a visualizable mechanism.'}
              </p>
            </div>

            <div className="footer-links-col">
              <div className="footer-col">
                <div className="footer-col-title">{t ? 'Cộng đồng' : 'Community'}</div>
                <a href={FACEBOOK_URL} target="_blank" rel="noopener noreferrer">Facebook</a>
                <a href={DISCORD_URL} target="_blank" rel="noopener noreferrer">Discord</a>
              </div>
              <div className="footer-col">
                <div className="footer-col-title">{t ? 'Cấu trúc' : 'Structure'}</div>
                <div className="footer-stat">{topics.length} Topics</div>
                <div className="footer-stat">{topics.reduce((a, t) => a + t.chapters.length, 0)} Chapters</div>
                <div className="footer-stat">{topics.reduce((a, t) => a + t.chapters.filter((c: any) => c.status === 'available').length, 0)} Available</div>
              </div>
            </div>
          </div>

          <div className="footer-bottom">
            <span className="footer-copy">
              © {year} CeSVi. {t ? 'Mọi quyền được bảo lưu.' : 'All rights reserved.'}
            </span>
            <div className="footer-social">
              <SocialButtons />
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
