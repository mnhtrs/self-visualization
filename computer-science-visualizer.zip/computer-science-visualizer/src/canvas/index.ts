// canvas/index.ts — public barrel for bounded canvas navigation abstraction

export * from './types'
export { BoundedCameraController, CAMERA_DEFAULTS } from './BoundedCameraController'

// Aliases required by spec naming examples
export { BoundedCameraController as CameraController } from './BoundedCameraController'
export { BoundedCameraController as PanZoomController } from './BoundedCameraController'
export { BoundedCameraController as BoundedCanvas } from './BoundedCameraController'

export type ViewportBoundsAlias = import('./types').ViewportBounds
export type WorldBoundsAlias = import('./types').WorldBounds
