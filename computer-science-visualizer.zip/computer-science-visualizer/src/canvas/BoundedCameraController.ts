// canvas/BoundedCameraController.ts
// Reusable bounded pan/zoom controller for all chapters.
// Implements the acceptance criteria from CESVI spec sections 5-12.
//
// Core invariants:
// - World bounds = scene bbox (per chapter scene, variable)
// - Viewport bounds = stage size W,H
// - Visualization must always have at least margin visible (bounded pan)
// - Zoom clamped to [MIN_ZOOM, MAX_ZOOM] relative to fit
// - Pan bounds recomputed on zoom/viewport/world change and on resize
// - Fit-to-View recomputes base fit and resets user pan/zoom
// - No hard-coded viewport-specific numbers, only ratios

import { clamp } from '../shared/math'
import { fit as fitUtil } from '../shared/geometry'
import type { ViewportBounds, WorldBounds, PanBounds, CameraState } from './types'
import type { BBox } from '../shared/types'

export const CAMERA_DEFAULTS = {
  MIN_ZOOM: 0.35, // allow zoom out more but still finite
  MAX_ZOOM: 5,
  WHEEL_FACTOR: 0.0015,
  CLICK_DRAG_PX: 4,
  // Minimum visible: 32% of viewport must show world content at extremes
  // This satisfies spec: "Minimum visible area should remain approximately 25–35%"
  MARGIN_RATIO: 0.32,
  MIN_VISIBLE_PX: 120,
} as const

export class BoundedCameraController {
  private viewport: ViewportBounds = { width: 0, height: 0 }
  private world: WorldBounds = { minX: 0, maxX: 1000, minY: 0, maxY: 1000 }
  private pad: number = 0.9

  private _baseZoom: number = 1
  private _baseOx: number = 0
  private _baseOy: number = 0

  private _panX: number = 0
  private _panY: number = 0
  private _zoom: number = 1 // user relative zoom

  constructor(world?: WorldBounds, viewport?: ViewportBounds, pad?: number) {
    if (world) this.world = world
    if (viewport) this.viewport = viewport
    if (pad !== undefined) this.pad = pad
    this.recalcBaseFit()
  }

  // -------------------------------------------------------------------------
  // Public getters (composed values)
  // -------------------------------------------------------------------------
  get baseZoom() { return this._baseZoom }
  get baseOx() { return this._baseOx }
  get baseOy() { return this._baseOy }
  get panX() { return this._panX }
  get panY() { return this._panY }
  get zoom() { return this._zoom }
  get zoomTotal() { return this._baseZoom * this._zoom }
  get offX() { return this._baseOx + this._panX }
  get offY() { return this._baseOy + this._panY }

  getState(): CameraState {
    return {
      baseZoom: this._baseZoom,
      baseOx: this._baseOx,
      baseOy: this._baseOy,
      panX: this._panX,
      panY: this._panY,
      zoom: this._zoom,
      zoomTotal: this.zoomTotal,
      offX: this.offX,
      offY: this.offY,
    }
  }

  // -------------------------------------------------------------------------
  // Viewport / World updates
  // -------------------------------------------------------------------------
  setViewport(width: number, height: number) {
    this.viewport = { width, height }
    this.recalcBaseFit()
    this.clampPan()
  }

  setWorldBounds(bbox: BBox, pad?: number) {
    if (pad !== undefined) this.pad = pad
    this.world = {
      minX: bbox.minX,
      maxX: bbox.maxX,
      minY: bbox.minY,
      maxY: bbox.maxY,
    }
    this.recalcBaseFit()
    this.clampPan()
  }

  // Accepts generic WorldBounds as well
  setWorldBoundsRaw(world: WorldBounds, pad?: number) {
    if (pad !== undefined) this.pad = pad
    this.world = { ...world }
    this.recalcBaseFit()
    this.clampPan()
  }

  // -------------------------------------------------------------------------
  // Fit calculation
  // -------------------------------------------------------------------------
  private recalcBaseFit() {
    const { width: W, height: H } = this.viewport
    if (W <= 0 || H <= 0) return // not initialized yet
    const bbox = {
      minX: this.world.minX,
      maxX: this.world.maxX,
      minY: this.world.minY,
      maxY: this.world.maxY,
    }
    // Prevent zero-size bbox
    const bw = bbox.maxX - bbox.minX
    const bh = bbox.maxY - bbox.minY
    if (bw <= 0 || bh <= 0) {
      this._baseZoom = 1
      this._baseOx = W / 2
      this._baseOy = H / 2
      return
    }
    const f = fitUtil(bbox, W, H, this.pad)
    this._baseZoom = f.zoom
    this._baseOx = f.ox
    this._baseOy = f.oy
  }

  // -------------------------------------------------------------------------
  // Pan bounds computation — bounded navigation core
  // Viewport shows world interval:
  //   wx0 = -offX / zoomTotal
  //   wx1 = (W - offX) / zoomTotal
  // Similarly Y. We require at least margin visible:
  //   screenX0 = minX*z + offX
  //   screenX1 = maxX*z + offX
  //   overlap with [0,W] >= marginX
  // This yields:
  //   offX ∈ [ marginX - maxX*z , W - marginX - minX*z ]
  // Same for Y.
  // -------------------------------------------------------------------------
  computePanBounds(): PanBounds {
    const { width: W, height: H } = this.viewport
    const z = this.zoomTotal
    const { minX, maxX, minY, maxY } = this.world

    const marginX = Math.max(W * CAMERA_DEFAULTS.MARGIN_RATIO, CAMERA_DEFAULTS.MIN_VISIBLE_PX)
    const marginY = Math.max(H * CAMERA_DEFAULTS.MARGIN_RATIO, CAMERA_DEFAULTS.MIN_VISIBLE_PX)

    // Base bounds ensuring at least marginX/Y overlap
    let minOffX = marginX - maxX * z
    let maxOffX = W - marginX - minX * z
    let minOffY = marginY - maxY * z
    let maxOffY = H - marginY - minY * z

    // If interval invalid (possible when ratio >=0.5 but we use 0.08, so safe), fallback to center
    if (minOffX > maxOffX) {
      const center = (minOffX + maxOffX) / 2
      minOffX = center
      maxOffX = center
    }
    if (minOffY > maxOffY) {
      const center = (minOffY + maxOffY) / 2
      minOffY = center
      maxOffY = center
    }

    return { minOffX, maxOffX, minOffY, maxOffY }
  }

  clampPan() {
    const bounds = this.computePanBounds()
    // offX = baseOx + panX → panX = offX - baseOx
    // So clamp offX then convert back to pan
    const targetOffX = clamp(this.offX, bounds.minOffX, bounds.maxOffX)
    const targetOffY = clamp(this.offY, bounds.minOffY, bounds.maxOffY)
    this._panX = targetOffX - this._baseOx
    this._panY = targetOffY - this._baseOy
  }

  // -------------------------------------------------------------------------
  // Zoom handling — cursor-anchored, with pan clamping after
  // -------------------------------------------------------------------------
  clampZoom(z: number): number {
    return clamp(z, CAMERA_DEFAULTS.MIN_ZOOM, CAMERA_DEFAULTS.MAX_ZOOM)
  }

  /** Set zoom anchored at screen point (mx,my). Returns new zoom after clamp. */
  setZoomAt(newZoom: number, anchorScreenX: number, anchorScreenY: number): number {
    const clamped = this.clampZoom(newZoom)
    const oldTotal = this.zoomTotal
    // World coord under anchor before zoom
    const wx = (anchorScreenX - this.offX) / oldTotal
    const wy = (anchorScreenY - this.offY) / oldTotal

    this._zoom = clamped
    const newTotal = this.zoomTotal
    const newOffX = anchorScreenX - wx * newTotal
    const newOffY = anchorScreenY - wy * newTotal

    this._panX = newOffX - this._baseOx
    this._panY = newOffY - this._baseOy

    this.clampPan()
    return this._zoom
  }

  /** Wheel handler: deltaY in pixels, anchor mx,my */
  applyWheel(deltaY: number, anchorScreenX: number, anchorScreenY: number): number {
    const factor = Math.exp(-deltaY * CAMERA_DEFAULTS.WHEEL_FACTOR)
    const newZoom = this.clampZoom(this._zoom * factor)
    return this.setZoomAt(newZoom, anchorScreenX, anchorScreenY)
  }

  /** Pan by screen delta (drag) */
  panBy(dx: number, dy: number) {
    this._panX += dx
    this._panY += dy
    this.clampPan()
  }

  setPan(panX: number, panY: number) {
    this._panX = panX
    this._panY = panY
    this.clampPan()
  }

  // -------------------------------------------------------------------------
  // Fit / Reset
  // -------------------------------------------------------------------------
  resetView() {
    this._panX = 0
    this._panY = 0
    this._zoom = 1
    this.clampPan()
  }

  fitToView() {
    this.recalcBaseFit()
    this.resetView()
  }

  /** Full recompute after external change (viewport resize etc.) */
  recomputeAfterResize() {
    this.recalcBaseFit()
    this.clampPan()
  }

  // -------------------------------------------------------------------------
  // Coordinate transforms
  // -------------------------------------------------------------------------
  screenToWorld(screenX: number, screenY: number): { x: number; y: number } {
    const z = this.zoomTotal
    return {
      x: (screenX - this.offX) / z,
      y: (screenY - this.offY) / z,
    }
  }

  worldToScreen(worldX: number, worldY: number): { x: number; y: number } {
    const z = this.zoomTotal
    return {
      x: worldX * z + this.offX,
      y: worldY * z + this.offY,
    }
  }

  // -------------------------------------------------------------------------
  // Validation helpers
  // -------------------------------------------------------------------------
  isPanValid(): boolean {
    const b = this.computePanBounds()
    return this.offX >= b.minOffX && this.offX <= b.maxOffX && this.offY >= b.minOffY && this.offY <= b.maxOffY
  }

  isZoomValid(): boolean {
    return this._zoom >= CAMERA_DEFAULTS.MIN_ZOOM && this._zoom <= CAMERA_DEFAULTS.MAX_ZOOM
  }

  /** Whether visualization is at risk of being lost (off-screen) */
  isVisualizationVisible(): boolean {
    return this.isPanValid()
  }
}
