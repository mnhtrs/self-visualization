// canvas/types.ts — Bounded canvas navigation types

export interface ViewportBounds {
  width: number
  height: number
}

export interface WorldBounds {
  minX: number
  maxX: number
  minY: number
  maxY: number
}

export interface PanBounds {
  minOffX: number
  maxOffX: number
  minOffY: number
  maxOffY: number
}

export interface CameraState {
  baseZoom: number
  baseOx: number
  baseOy: number
  panX: number
  panY: number
  zoom: number
  zoomTotal: number
  offX: number
  offY: number
}
