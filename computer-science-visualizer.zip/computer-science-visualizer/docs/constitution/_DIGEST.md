---
type: "digest"
guiding_question: "What are the essential constitutional rules extracted from PHILOSOPHY, VISUAL_LANGUAGE, and NARRATIVE_FRAMING for chapter production?"
sources: ["PHILOSOPHY.md 2.0.0", "VISUAL_LANGUAGE.md 3.0.0", "NARRATIVE_FRAMING.md 3.0.0"]
authority: "This file is a compression layer only. If any rule here conflicts with a source document, the source document wins unconditionally."
---

# Constitution Digest — Operational Rules for Chapter Production

Read source documents for rationale or disambiguation. This digest retains only rules that directly constrain production decisions.

---

## From PHILOSOPHY.md — Cognitive Laws

**No Unlearning (§3):** Everything taught must remain true in every downstream chapter. Never teach a model that must later be discarded.

**Black Box Rule (§5.3):** A hidden mechanism must be classified as either a *Deferred Internal* (revealed later, explicitly scheduled) or a *Terminal Boundary* (permanently out of scope). No false analogy may substitute for either. Declare the classification explicitly in `00_JOURNEY_DEFINITION.md §5`.

**Single State Mutation (§5.1):** Each beat introduces exactly one new independent state variable. Multi-variable mutations must be decomposed and verified individually first.

**Atomic Chunking (§5.2):** Only after each sub-step is individually verified may they be combined into a single atomic operation in subsequent beats.

**State-Predictive Verification (§5.4):** Learner verification must require predicting or manually mutating exact system state. Passive reading and multiple choice are prohibited.

**Target Audience (§7):** Every chapter must be simultaneously effortless for absolute beginners AND structurally sound for IT students answering technical interview questions. Both conditions are mandatory.

---

## From VISUAL_LANGUAGE.md — Visual Production Laws

**Derivable Geometry (§2.2):** Every drawn coordinate must be expressible as a named layout primitive or a function of a container rectangle. Inline literal coordinates are defects.

**Connection Identity (§2.1):** Distinct physical or logical paths must be rendered as distinct visual lines. Merging two distinct paths into one drawn line is forbidden.

**Protagonist Continuity (§13):** Exactly one persistent visual protagonist per chapter. It must be traceable at every second of the timeline across every scene.

**Transition Causality (§14):** A scene transition must be caused by an observable state change. Narration alone cannot justify a transition.

**Visual Determinism (§15):** The visual state at any timeline step must be completely deterministic. Skip, pause, and rewind must reproduce identical results.

**UI Attentional Priority (§16):** HUD elements, data tables, and logs must yield visual priority to the active mechanism at all times.

**Primary Protagonist in Parallelism (§18):** When concurrent flows are shown, one protagonist is highlighted; auxiliary flows are rendered with significantly decayed visual weight.

**Causal Animation Dominance (§19):** Visual animation is the engine of state change ($T_0 \text{ moves} \rightarrow T_1 \text{ observed} \rightarrow T_2 \text{ labeled}$). Animation shall never serve as passive illustration for spoken text.

**Visual Stall & Friction Rendering (§20):** Stalls, memory waits, and path contention must be rendered through direct physical cues (core darkening, paused sparks, glowing friction paths). Stalls shall never be communicated solely by static text badges or narration declarations.

---

## From NARRATIVE_FRAMING.md — Narration Laws

**Observation Before Explanation (§3):** The visual state change happens before or simultaneously with the narration line explaining it. Narration organises what was already seen; it never replaces observation.

**Question Before Answer (§4):** Every explanation answers a previously established uncertainty. No information is introduced without a clear educational purpose.

**Knowledge Reveal Law (§13):** A technical term may be introduced only after the learner has observed the phenomenon that makes the term necessary. Terminology never precedes the experience.

**Plain Language and Technical Lock (§15):** Core component names are locked to their English origins. All surrounding explanation must be written in natural, clear native language accessible to absolute beginners.

**Curiosity Bottleneck Genesis (§16):** Every scene must be birthed by a bottleneck or question raised in the preceding scene. Scenes may never be created simply because a concept is important in textbooks.

**Experiential Climax Law (§17):** A chapter climax must be an unassisted visual observation of the system operating at scale. Text summaries, static diagrams, voiceover lectures, and on-canvas definitions are strictly forbidden as climaxes. Exactly one climax per chapter.

**Reality Before Story (§2):** Facts, mechanisms, and causal relationships always take precedence over narrative convenience.
