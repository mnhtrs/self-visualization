---
guiding_question: "Which Chapter 01 decisions are permanently locked, which are defaults, and which are overridable for future Topic 02 chapters?"
primary_consumer: "Content Authors, Curriculum Architects, AI Agents"
authority_level: "Authoritative Decision Registry"
depends_on:
  - "docs/topics/topic-02/00_TOPIC_02_PRODUCTION_BASELINE.md"
referenced_by:
  - "docs/topics/topic-02/02_CHAPTER_DELTA_AUDIT_TEMPLATE.md"
  - "docs/topics/topic-02/04_TOPIC_02_CHAPTER_CONTRACT.md"
---

# Topic 02 Inherited & Locked Decisions Registry

**Topic ID:** `topic-02-operating-systems`  
**Status:** Authoritative Decision Registry  
**Version:** 1.0.0  

---

## 1. Classification Framework

Every decision from Chapter 01 is classified into one of three statuses:

1. **LOCKED:** Immutable curriculum law for Topic 02. Future chapters CANNOT modify or contradict these decisions under any circumstances without formal curriculum amendment.
2. **DEFAULT:** Authoritative production default. Future chapters inherit these rules by default. They MAY be overridden ONLY if the chapter contract provides an explicit pedagogical justification.
3. **CH01-SPECIFIC:** Subject-specific decision or implementation artifact from Chapter 01. Future chapters do NOT inherit these and MUST define their own subject-appropriate equivalents.

---

## 2. Locked Decisions Registry

| Decision ID | Decision Summary | Status | Rationale & Protection |
| :--- | :--- | :--- | :--- |
| **LOK-01** | **Program $\neq$ Process** | `LOCKED` | Core Topic 02 mental model. A Program is a static stored artifact; a Process is an active OS-managed execution instance. |
| **LOK-02** | **Persistent Source Program** | `LOCKED` | Launching a Program does not alter or destroy the stored artifact. The Program remains on storage during launch and after Process termination. |
| **LOK-03** | **OS Mediation Layer** | `LOCKED` | The OS is the system software entity that creates, manages, and terminates Processes. The OS is not the CPU, RAM, or a generic app. |
| **LOK-04** | **Process Identity (PID)** | `LOCKED` | Every Process instance has a unique PID assigned by the OS. The PID identifies the instance, not the Program. |
| **LOK-05** | **One Program $\to$ Multiple Processes** | `LOCKED` | Re-launching a Program creates separate, independent Process instances with distinct PIDs. |
| **LOK-06** | **Process $\neq$ Application Window** | `LOCKED` | A Process is an execution environment, not a desktop GUI window. Window management concepts must not leak into Process identity. |
| **LOK-07** | **Machine $\neq$ OS** | `LOCKED` | Physical execution hardware (CPU/RAM/IO) belongs to the Machine context and must not be rendered inside the OS software band. |
| **LOK-08** | **Deterministic Beat/Frac Engine** | `LOCKED` | All rendering and animations MUST be computed deterministically from `(beatIndex, beatFrac)` with zero unseeded random state. |

---

## 3. Default Production Rules Registry

| Decision ID | Default Rule | Status | Override Condition |
| :--- | :--- | :--- | :--- |
| **DEF-01** | **Spatial Axis Alignment** (West=Storage, Middle=OS, East=Machine) | `DEFAULT` | May be adapted if a chapter's mental model (e.g., Thread interleaving or Ready Queue) requires a vertical or matrix layout. |
| **DEF-02** | **Entity Hierarchy** ($\text{Entity} > \text{Identity} > \text{Provenance}$) | `DEFAULT` | May be modified if a chapter introduces a secondary sub-entity (e.g., Thread inside Process) requiring a 4-tier hierarchy. |
| **DEF-03** | **Borderless OS Tint** (Soft background fill, no nested panels) | `DEFAULT` | May be modified if teaching explicit kernel vs. user-space boundary in a later memory chapter. |
| **DEF-04** | **De-Windowed Process Container** (Rounded rect, no header divider) | `DEFAULT` | May be modified only if teaching GUI event queues where window handles are the explicit topic. |
| **DEF-05** | **Causality via Motion** (Requests move, entities bloom) | `DEFAULT` | Static arrows permitted only when teaching static memory structures or fixed pointers. |
| **DEF-06** | **Simultaneous Coexistence Animation** ($t_A \cap t_B \neq \emptyset$) | `DEFAULT` | Inherited whenever teaching non-destructive entity creation or $A \neq B$. |
| **DEF-07** | **Independence Ack (`INDEP_ACK`)** | `DEFAULT` | Inherited whenever creating a new instance while an existing instance is active. |
| **DEF-08** | **Survivor Ack (`SURVIVOR_ACK`)** | `DEFAULT` | Inherited whenever one instance terminates while others remain active. |

---

## 4. CH01-Specific Decisions (DO NOT INHERIT)

The following choices are CH01 implementation details. Future chapters MUST NOT blindly copy them:

* **Exemplar Program ("Photos"):** CH01 used "Photos" as a concrete non-executable media app. Future chapters choose exemplars relevant to their topic (e.g., CH03 may use CPU-bound vs I/O-bound exemplars).
* **Exact Container Coordinates & Dimensions:** Pixels like `width: 232px` or `x: 120px` were CH01 layout parameters. Future chapters derive layout from container metrics.
* **Exact Beat Count (18 Beats / 3 Scenes):** Beat counts depend strictly on the chapter's story spine.
* **Exact Pulse Durations:** Animation fractions like `0.10–0.42` were tuned for CH01's timing. Future chapters tune timing to their narrative pace.

---

## 5. Decision Override Protocol

If a future chapter author or agent needs to override a `DEFAULT` decision:

1. State the Decision ID being overridden in the Chapter Contract (`04_TOPIC_02_CHAPTER_CONTRACT.md`).
2. Provide the explicit pedagogical justification (e.g., "CH03 Ready Queue requires a vertical queue layout instead of West-to-East axis to show queue ordering").
3. Verify that the override does NOT violate any `LOCKED` decisions.
4. Record the override in the chapter's Delta Audit (`02_CHAPTER_DELTA_AUDIT_TEMPLATE.md`).
