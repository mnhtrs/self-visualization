---
guiding_question: "What is the mandatory 13-field pre-implementation contract required before any Topic 02 chapter implementation begins?"
primary_consumer: "Content Authors, Curriculum Architects, AI Agents"
authority_level: "Authoritative Chapter Contract Specification"
depends_on:
  - "docs/topics/topic-02/00_TOPIC_02_PRODUCTION_BASELINE.md"
  - "docs/topics/topic-02/01_INHERITED_AND_LOCKED_DECISIONS.md"
referenced_by:
  - "docs/topics/topic-02/03_TOPIC_02_FAST_PRODUCTION_WORKFLOW.md"
---

# Topic 02 Chapter Pre-Implementation Contract Template

**Mandatory Rule:** No Topic 02 chapter implementation (CH02–CH05) may begin without completing and approving this contract. The contract locks the pedagogical scope, mental-model transformation, and visual requirements before a single line of code is written.

---

# Chapter Pre-Implementation Contract: [Chapter Title]

**Chapter ID:** `topic-02-ch-0[X]-[slug]`  
**Order:** [X]  
**Author / Agent:**  
**Date:**  

---

### 1. Chapter Identity & Slug
* **Slug:** `[chapter-slug]`
* **Title (EN):** 
* **Title (VI):** 

### 2. Central Question
> *What explicit, intuitive question does this chapter answer for the learner?*

### 3. Previous Mental Model (Upstream Exit State)
*What mental model does the learner hold entering this chapter from previous chapters?*

### 4. Target Mental Model (Downstream Exit State)
*What transformed mental model will the learner hold after completing this chapter?*

### 5. False Model Blocked
*What explicit false mental model does this chapter actively block or disassemble?*

### 6. Central Discovery
*What central phenomenon or tension does the learner observe before encountering formal terms?*

### 7. Prerequisite Assumptions
*List the exact facts inherited from previous chapters that this chapter assumes known:*
- [ ] Inherited Fact 1:
- [ ] Inherited Fact 2:

### 8. Inherited Concepts & Visual Grammar
*List the Topic 02 baseline elements inherited without change:*
- [ ] Visual Grammar: (e.g., De-windowed Process, Soft OS band)
- [ ] Animation Semantics: (e.g., Materialization bloom, Coexistence pulse)

### 9. New Concepts Introduced
*List the new concepts introduced in this chapter:*
1. 
2. 

### 10. Forbidden Concepts & Scope Boundaries
*List downstream concepts that MUST NOT appear or leak into this chapter:*
- [ ] Forbidden Concept 1: (e.g., Scheduling algorithms in CH02)
- [ ] Forbidden Concept 2:

### 11. New Visual Grammar Requirements
*Specify any new visual primitives or grammar required (or "None — inherited grammar sufficient"):*

### 12. New Animation Grammar Requirements
*Specify any new causal animation sequences required:*

### 13. Terminology Reveal Plan
*Map the exact beats where technical terms are unlocked after observation:*
* **Beat [N]:** Phenomenon observed
* **Beat [N+1]:** Tension / Question posed
* **Beat [N+2]:** Discovery made
* **Beat [N+3]:** Term Unlocked: `[Technical Term]`

### 14. Silent Climax & Bridge to Next Chapter
* **Silent Climax:** *What single visual sequence proves the core transformation with narration muted?*
* **Open Bridge Question:** *What open question does this chapter leave to motivate the next chapter?*

---

## Sign-off & Approval
* **Status:** APPROVED FOR IMPLEMENTATION
* **Approver:**
* **Date:**
