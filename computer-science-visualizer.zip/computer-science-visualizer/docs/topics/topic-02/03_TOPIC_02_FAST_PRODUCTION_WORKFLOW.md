---
guiding_question: "What is the 10-phase fast chapter production workflow that enables rapid, high-quality production of CH02–CH05 without infinite audit loops?"
primary_consumer: "Content Authors, Curriculum Architects, AI Agents"
authority_level: "Authoritative Production Workflow"
depends_on:
  - "docs/topics/topic-02/00_TOPIC_02_PRODUCTION_BASELINE.md"
  - "docs/topics/topic-02/01_INHERITED_AND_LOCKED_DECISIONS.md"
  - "docs/topics/topic-02/02_CHAPTER_DELTA_AUDIT_TEMPLATE.md"
  - "docs/topics/topic-02/04_TOPIC_02_CHAPTER_CONTRACT.md"
---

# Topic 02 Fast Chapter Production Workflow

**Purpose:** This document specifies the 10-phase production pipeline for Topic 02 chapters (CH02–CH05). It eliminates repetitive micro-refinements and audit loops by establishing strict materiality rules, iteration budgets, and explicit freeze criteria.

---

## 1. The 10-Phase Fast Production Pipeline

```
[PHASE 1: INHERIT] ──→ [PHASE 2: DEFINE] ──→ [PHASE 3: DELTA AUDIT] ──→ [PHASE 4: STORY]
                                                                              │
[PHASE 8: VERIFY] ←── [PHASE 7: MATERIALITY] ←── [PHASE 6: RENDER] ←── [PHASE 5: IMPLEMENT]
        │
        ├──→ [PHASE 9: HUMAN VISUAL PASS] ──→ [PHASE 10: FREEZE]
```

---

### PHASE 1 — INHERIT
* **Action:** Read [`00_TOPIC_02_PRODUCTION_BASELINE.md`](00_TOPIC_02_PRODUCTION_BASELINE.md) and [`01_INHERITED_AND_LOCKED_DECISIONS.md`](01_INHERITED_AND_LOCKED_DECISIONS.md).
* **Output:** Mental check of established ground truth. Do NOT re-plan inherited concepts.

### PHASE 2 — DEFINE
* **Action:** Fill out the [`04_TOPIC_02_CHAPTER_CONTRACT.md`](04_TOPIC_02_CHAPTER_CONTRACT.md).
* **Output:** Locked Central Question, Target Mental Model, Scope Boundaries, and Prerequisite Assumptions.

### PHASE 3 — DELTA AUDIT
* **Action:** Execute [`02_CHAPTER_DELTA_AUDIT_TEMPLATE.md`](02_CHAPTER_DELTA_AUDIT_TEMPLATE.md) for NEW material only.
* **Output:** List of new misconceptions, new visual grammar requirements, and scope guards.

### PHASE 4 — STORY
* **Action:** Write the beat spine, discovery sequence, terminology reveal beats, silent climax, and bridge to the next chapter.
* **Output:** `01_CHAPTER_PRODUCTION_[BLUEPRINT].md` for the chapter.

### PHASE 5 — IMPLEMENT
* **Action:** Implement chapter content using existing Topic 02 renderer architecture, visual primitives, and deterministic engine.
* **Output:** Working chapter implementation in `src/content/topics/02-operating-systems/`.

### PHASE 6 — RENDER EARLY
* **Action:** Render key representative beats (Beat 00, First Discovery, Terminology Reveal, Silent Climax, Bridge) at actual viewer dimensions (e.g., 1400×850).
* **Output:** Rendered frames or contact sheet for inspection.

### PHASE 7 — MATERIALITY CHECK
* **Action:** Classify all findings strictly into P0, P1, P2, P3:
  * **P0 (Critical False Model):** Must fix.
  * **P1 (Major Causal Weakness):** Must fix.
  * **P2 (Pedagogical Weakness):** Fix IF material in ONE pass.
  * **P3 (Cosmetic / Polish):** Document and IGNORE. Do NOT spend production time fixing P3.
* **Output:** Remediation plan for P0/P1/P2 only. Zero changes for P3.

### PHASE 8 — VERIFY
* **Action:** Run automated verification suite (`npm run build`, `npm run smoke`).
* **Output:** All inherited and chapter-specific gates PASS with zero errors.

### PHASE 9 — HUMAN VISUAL PASS
* **Action:** Inspect generated contact sheet to confirm visual readability and choreography.
* **Output:** Confirmation that visual storytelling is clear with narration muted.

### PHASE 10 — FREEZE
* **Action:** If P0=0, P1=0, P2=0 and the central mental-model transformation is visually proven: **FREEZE THE CHAPTER**.
* **Output:** Register release in `PROJECT_STATE.md` and `CHANGELOG.md`.

---

## 2. Iteration Budget & Micro-Tweak Prevention Rules

To prevent endless iteration loops, every future Topic 02 chapter operates under a strict **Iteration Budget**:

* **Maximum 1 Delta Audit**
* **Maximum 1 Implementation Pass**
* **Maximum 1 Remediation Pass** (only if P0/P1/P2 exist)
* **Maximum 1 Final Verification**

### Explicit STOP Rule
> If a chapter is conceptually correct, its central mental-model transformation is visually proven, and there are ZERO P0/P1/P2 issues:
> **YOU MUST STOP.**
> Do NOT perform micro-polish passes. Do NOT manufacture new P3 visual issues. Do NOT run additional audit rounds. **FREEZE IMMEDIATELY.**
