---
guiding_question: "How do future Topic 02 chapters perform a fast, lightweight Delta Audit focused strictly on new material instead of repeating full-re-audits?"
primary_consumer: "Content Authors, Curriculum Architects, AI Agents"
authority_level: "Authoritative Audit Template"
depends_on:
  - "docs/topics/topic-02/00_TOPIC_02_PRODUCTION_BASELINE.md"
  - "docs/topics/topic-02/01_INHERITED_AND_LOCKED_DECISIONS.md"
referenced_by:
  - "docs/topics/topic-02/03_TOPIC_02_FAST_PRODUCTION_WORKFLOW.md"
---

# Topic 02 Chapter Delta Audit Template

**Usage Rule:** Future Topic 02 chapters (CH02–CH05) MUST use this template during Phase 3 (Delta Audit). Do NOT perform a full ground-up audit of already-locked Topic 02 facts. Focus strictly on the **DELTA** (what is new in this chapter).

---

# Chapter [X] — Delta Audit: [Chapter Title]

**Chapter ID:** `topic-02-ch-0[X]-[slug]`  
**Author / Agent:**  
**Date:**  

---

## 1. Inherited Baseline
*List what this chapter inherits unchanged from Topic 02 baseline and previous chapters:*
- [ ] Inherited mental model: (e.g., Program $\neq$ Process, PID ownership)
- [ ] Inherited visual grammar: (e.g., De-windowed Process, Soft OS band, Machine bay)
- [ ] Inherited animation patterns: (e.g., Materialization bloom, Coexistence pulse)

## 2. New Mental-Model Transformation
*State the single mental-model transformation introduced by this chapter:*
* **Current Learner Model:**  
* **Target Learner Model:**  
* **Central Question Answered:**  

## 3. New Entities Introduced
*List any new entities introduced in this chapter (or "None — inherited entities sufficient"):*
- Entity Name: 
  - Visual Representation:
  - Parent / Container:

## 4. New Causal Relationships Introduced
*List the new causal mechanisms demonstrated in this chapter:*
- Trigger: $\longrightarrow$ Action: $\longrightarrow$ Effect:

## 5. New Misconception Inventory
*ONLY list misconceptions introduced specifically by the NEW material in this chapter. Do NOT repeat locked CH01 misconceptions unless this chapter specifically risks re-triggering them.*
1. **Misconception 1:**  
   * *Protection / Reusable Rule:*  
2. **Misconception 2:**  
   * *Protection / Reusable Rule:*  

## 6. New Visual Grammar Required
*Specify any visual grammar genuinely new to this chapter. If inherited grammar is sufficient, state "None — inherited grammar is sufficient."*
- [ ] New Visual Grammar:

## 7. New Animation Semantics Required
*Specify new causal animation sequences required by this chapter:*
- [ ] Sequence: $\text{CAUSE} \to \text{ACTION} \to \text{EFFECT} \to \text{NEW STABLE STATE}$

## 8. Scope & Leakage Risks
*Identify downstream concepts that could accidentally leak into this chapter:*
- [ ] Risk concept: (e.g., Scheduling in CH02)
- [ ] Guard mechanism: (e.g., Scope gate assertion)

## 9. Geometry & Spatial Risks
*Identify potential false spatial interpretations in this chapter:*
- [ ] Spatial Risk:  
- [ ] Correction:  

## 10. Verification Additions
*List only NEW chapter-specific test gates required:*
- [ ] New Scope Gate Rule:  
- [ ] New Layout Proof Assertion:  

## 11. Decision & Materiality Verdict

### Materiality Classification
- **P0 (Critical False Model):** [Count]
- **P1 (Major Causal Weakness):** [Count]
- **P2 (Pedagogical Weakness):** [Count]
- **P3 (Cosmetic / Polish):** [Count - DO NOT BLOCK FREEZE FOR P3]

### Verdict (Select One)
* **[ ] GO:** Zero P0/P1/P2 issues. Proceed to story/implementation or freeze.
* **[ ] MODIFY (Single Pass):** P0/P1/P2 issues identified. Fix coherently in ONE pass.
* **[ ] STOP:** Central mental model transformation unproven. Redesign Chapter Contract.
