---
guiding_question: "What is the authoritative inheritance baseline, visual grammar, animation semantics, and scope boundary matrix for all Topic 02 chapters?"
primary_consumer: "Content Authors, Curriculum Architects, AI Agents"
authority_level: "Authoritative Topic 02 Production Baseline"
depends_on:
  - "docs/curriculum/CURRICULUM_CONSTITUTION.md"
  - "docs/curriculum/CURRICULUM_GRAPH.md"
  - "docs/curriculum/CURRICULUM_GUARDIAN_T02_DRAFT.md"
  - "docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md"
referenced_by:
  - "docs/topics/topic-02/01_INHERITED_AND_LOCKED_DECISIONS.md"
  - "docs/topics/topic-02/02_CHAPTER_DELTA_AUDIT_TEMPLATE.md"
  - "docs/topics/topic-02/03_TOPIC_02_FAST_PRODUCTION_WORKFLOW.md"
  - "docs/topics/topic-02/04_TOPIC_02_CHAPTER_CONTRACT.md"
---

# Topic 02 Production Baseline & Inheritance Specification

**Topic ID:** `topic-02-operating-systems`  
**Status:** Authoritative Production Baseline  
**Version:** 1.0.0  
**Authority:** Topic-level operational specification extending [`CURRICULUM_GUARDIAN_T02_DRAFT.md`](../../curriculum/CURRICULUM_GUARDIAN_T02_DRAFT.md) and [`CURRICULUM_GRAPH.md`](../../curriculum/CURRICULUM_GRAPH.md). Encodes frozen Chapter 01 production lessons into reusable multi-chapter baseline rules.

---

## 1. Governance & Deference Header

1. **Supreme Curriculum Law:** [`CURRICULUM_CONSTITUTION.md`](../../curriculum/CURRICULUM_CONSTITUTION.md) (Canons C-01…C-10).
2. **Topic Guardian Baseline:** [`CURRICULUM_GUARDIAN_T02_DRAFT.md`](../../curriculum/CURRICULUM_GUARDIAN_T02_DRAFT.md) (5-chapter canonical structure & boundaries).
3. **Operational Deference Rule:** This baseline provides the authoritative inheritance defaults for Topic 02 (CH02–CH05). It eliminates repetitive full-re-audits by establishing what future chapters inherit by default.
4. **Non-Negotiable Baseline Rule:** Chapter 01 (`topic-02-ch-01-process-from-program-to-execution`) is **FROZEN**. Future chapters inherit its validated principles and visual/animation semantics without reopening CH01 source code or artwork.

---

## 2. Hard-Won Lessons from CH01 Production

The following 20 core principles were established during CH01 production and MUST be inherited across Topic 02 to prevent expensive iteration loops:

1. **Lock Mental Model First:** Never begin renderer implementation before the mental model transformation and scope boundaries are locked.
2. **Pedagogical Visualization ≠ UI Design:** Technically valid UI components (cards, progress bars, title bars) often introduce false mental models. Visualization must be semantically intentional.
3. **De-Windowing Rule:** Avoid desktop window affordances (header dividers, close buttons, window frames) when visualising a `Process`. A Process is an OS-managed execution instance, not an application window.
4. **De-Carding Rule:** Avoid nested dashboard borders or module boxes inside system layers (`OS`). Nested panels read as dashboard cards rather than a unified software layer.
5. **Anti-Progress-Bar Rule:** Avoid horizontal filled tracks inside Process entity representations that suggest task progress or activity unless state progress is the explicit concept being taught.
6. **Machine vs. OS Boundary:** Never nest physical hardware resources (CPU, RAM, I/O) inside the `OS` representation. OS is system software; physical resources belong to the Machine execution context.
7. **Causality via Motion, Not Static Glyphs:** Avoid static directional chevrons or arrows on intake/creation ports. Static arrows read as network/data-flow pipelines or hardware sockets. Causality MUST be carried by animated motion (request movement, creation bloom).
8. **Simultaneous Coexistence Proof:** When teaching $A \neq B$ (e.g., Program $\neq$ Process), show $A$ and $B$ simultaneously salient. Sequential appearance wrongly implies transformation ($A \to B$).
9. **Visual Independence Demonstration:** When a second instance $B$ is created, the existing instance $A$ must emit a restrained acknowledgment pulse (`INDEP_ACK`) to visually prove it remains untouched.
10. **Entity Hierarchy Law:** The entity being identified must be visually more primary than its identifier ($Entity > Identity > Provenance$).
11. **Subordinate Provenance:** Provenance markers (e.g., source program name) must remain visually subordinate to Process identity so ontology does not collapse.
12. **Persistent Source Artifact:** The Program must remain visually stable on its recessed storage platform while Process instances materialize.
13. **Semantic Geometry over Aesthetic Layout:** Position must carry meaning (e.g., West=Storage, Middle=OS, East=Machine). Do not optimize spatial layout purely for alignment or symmetry.
14. **Materiality Rule (P0–P3):** Classify all findings into P0 (false model/broken), P1 (major causal weakness), P2 (pedagogical weakness), P3 (polish). Fix P0/P1/P2 in ONE pass. Ignore/document P3.
15. **Stop Rule:** Once P0/P1/P2 are zero and the mental model transformation is visually proven, STOP. Do not run infinite micro-tweak audits.
16. **Muted Narration Recovery:** Load-bearing causal facts MUST be visually recoverable with narration muted. Narration carries abstract motivation and intuition.
17. **Discovery before Terminology:** Introduce the observed phenomenon and tension BEFORE revealing formal technical terms (Phenomenon $\to$ Tension $\to$ Question $\to$ Discovery $\to$ Terminology $\to$ Formalization).
18. **Deterministic Rendering:** All animations must compute strictly from deterministic `(beatIndex, beatFrac)`. Zero unseeded random state, zero time-dependent offsets.
19. **Automated Verification Infrastructure:** Reuse existing scope gates, layout proofs, double-render deterministic tests, and smoke tests instead of rewriting test runners.
20. **Delta Audit Workflow:** Future chapters only audit what is NEW (`INHERIT \to DEFINE \to DELTA AUDIT \to STORY \to IMPLEMENT \to RENDER \to MATERIALITY CHECK \to VERIFY \to FREEZE`).

---

## 3. Topic 02 Mental-Model Continuity

### 3.1 Inherited Foundation (Established by CH01)
Future Topic 02 chapters (CH02–CH05) assume the learner holds the following established facts:

* **Program $\neq$ Process:**
  * **Program:** Static, stored artifact sitting in persistent storage. Remains unchanged when launched and after Process termination.
  * **Process:** Dynamic execution instance created and managed by the OS. Has identity, resources, and lifetime.
* **Process Identity (PID):**
  * Spatially attached to exactly one Process instance.
  * Identifies the specific Process instance, NOT the Program.
* **OS Role:**
  * System software layer mediating between stored programs, execution instances, and hardware resources.
  * Creates, manages, and terminates Processes. Is NOT the physical CPU/RAM.
* **One Program $\to$ Multiple Processes:**
  * Launching a Program multiple times produces separate, independent Process instances with distinct PIDs.

### 3.2 Conceptual Continuity Contract Across Topic 02

```
[CH01: Process Identity & Lifetime]
       ↓ (inherits Program ≠ Process, PID, OS mediation)
[CH02: Process Execution: Pause, Switch, Resume]
       ↓ (inherits Address Space, Context, States, Context Switch & Resume)
[CH03: CPU Scheduling: Who Runs Next?]
       ↓ (inherits Ready Queue, Time Slices, Preemption)
[CH04: Thread: Multiple Paths Inside One Process]
       ↓ (inherits Process Environment vs Thread Context)
[CH05: Multithreading: Shared State & Race Conditions]
       ↓ (handoff to Topic 06 Concurrency & Parallelism)
```

---

## 4. Visual Continuity Contract

### 4.1 Semantic Grammar Defaults

| Entity / Layer | Visual Grammar Default | Semantic Meaning | Must NOT be rendered as |
| :--- | :--- | :--- | :--- |
| **PROGRAM / ARTIFACT** | Recessed storage platform tile, muted dark fill, persistent position (West). | Stored static artifact in storage. | Active execution window, floating card, dynamic entity. |
| **PROCESS** | Distinct rounded entity container, center bloom materialization, independent bounds. | Active managed execution instance. | Desktop application window, title-bar window, progress bar. |
| **PID / IDENTITY** | Compact ID badge spatially attached to Process header region. | Unique instance identifier. | Floating global label, louder than Process caption, attached to Program. |
| **OS / SYSTEM LAYER** | Horizontal system software band (Middle), borderless action core, intake/creation ports. | System software mediating execution. | Physical machine box, nested dashboard panel, generic app card. |
| **MACHINE CONTEXT** | Squarer physical bay (East, radius 8px) with mini hardware glyphs (CPU chip, RAM stick, I/O port). | Physical execution hardware. | Nested sub-panel inside OS, floating generic icons. |
| **STORAGE CONTEXT** | Recessed platform bay containing Program tiles. | Non-volatile storage location. | Execution space, active RAM region. |

### 4.2 Entity Visual Hierarchy Rule

$$\text{Entity (Process: 15px)} > \text{Identity (PID: 14px)} > \text{Provenance (Source Program: 11px)}$$

* **Rule:** The thing being identified (Process) MUST be visually primary over its identity marker (PID), which in turn MUST be primary over its source provenance (Program name).
* **Reference Font Sizes (CH01 Reference):** `cellCaption` = 15px, `chipText` = 14px, `sourceCue` = 11px.
* **Scope:** Inherited across all Topic 02 chapters.

---

## 5. Anti-Misconception Visual Contract

Future Topic 02 chapters MUST enforce the following visual protections against competing false models:

| Competing False Model | Blocked Visual Grammar | Required Reusable Protection |
| :--- | :--- | :--- |
| **"Program becomes Process"** | Sequential $A \to B$ animation where $A$ disappears. | Simultaneous visibility: Program remains + look-back pulse. |
| **"Process is an Application Window"** | Horizontal header dividers, close buttons, window borders. | Borderless/dividerless entity container with spacing grouping. |
| **"OS is a Dashboard / App Card"** | Nested panel borders, card outlines inside OS. | Soft borderless core tint for OS action tracks. |
| **"OS contains Physical CPU/RAM"** | Placing CPU/RAM icons inside the OS container. | Separate Machine bay (East) distinct from OS band (Middle). |
| **"Causality is a Data Pipeline"** | Static directional chevrons/arrows on intake ports. | Motion-driven requests and materialization pulses. |
| **"Second launch restarts first Process"** | Shaking or resetting existing Process $A$ when $B$ is born. | Restrained acknowledgment pulse (`INDEP_ACK`) on $A$. |
| **"Termination deletes Program"** | Program tile fading when Process terminates. | Program tile remains unchanged while Process cell dissolves (`SURVIVOR_ACK`). |

---

## 6. Animation Continuity Contract

### 6.1 Core Animation Law
$$\text{CAUSE} \longrightarrow \text{ACTION} \longrightarrow \text{EFFECT} \longrightarrow \text{NEW STABLE STATE}$$

Every load-bearing state change MUST be animated through this sequence. Static jump-cuts or pure appear/disappear effects are forbidden for causal state changes.

### 6.2 Reusable Animation Choreography Patterns

1. **Materialization Bloom:** Entity forms continuously from a radial center bloom / outline path sweep, proving "creation into existence".
2. **Simultaneous Coexistence Pulse:** Program and Process light up with overlapping animation windows ($t_{Program} \cap t_{Process} \neq \emptyset$), followed by a "look-back" pulse on Program ("still here, unchanged").
3. **Independence Acknowledgment (`INDEP_ACK`):** Existing Process $A$ emits a soft, single glow pulse while Process $B$ materializes, visually confirming $A$ is undisturbed.
4. **Survivor Acknowledgment (`SURVIVOR_ACK`):** When Process $A$ terminates, surviving Processes ($B, C$) emit a brief acknowledgment pulse, confirming local termination.
5. **Causal Request Travel:** Request pulses travel along causal pathways from source to destination to carry action visually.

---

## 7. Geometry-as-Pedagogy Contract

Spatial arrangement carries semantic meaning. Default Topic 02 spatial axis:

$$\text{Storage / Stored Program (West)} \xrightarrow{\quad\text{Launch Request}\quad} \text{OS Software Layer (Middle)} \xrightarrow{\quad\text{Managed Entity / Execution}\quad} \text{Machine Context (East)}$$

* **West (Storage):** Stored artifacts, inert data, inactive programs.
* **Middle (OS Layer):** System software mediation, creation, state management, scheduling.
* **East (Execution / Machine):** Active execution entities (Processes/Threads), CPU/RAM physical context.

*Note:* Future chapters may adapt pixel coordinates or container metrics, but MUST preserve the semantic left-to-right progression unless an explicit pedagogical override is justified.

---

## 8. Terminology Reveal Contract

Preserve the discovery-first sequence:

$$\text{PHENOMENON} \longrightarrow \text{TENSION} \longrightarrow \text{QUESTION} \longrightarrow \text{DISCOVERY} \longrightarrow \text{TERMINOLOGY} \longrightarrow \text{FORMALIZATION}$$

* **Rule:** Never introduce a technical term (e.g., *Address Space*, *Context Switch*, *Ready Queue*, *Thread*) before the learner has observed the underlying physical/system tension.
* **Terminology Ownership:** Terms are unlocked at specific beats defined in the Chapter Contract and MUST NOT leak into earlier beats or chapters.

---

## 9. Muted-Narration Contract

* **Visually Recoverable (Muted Requirement):**
  * Object creation, destruction, identity association.
  * Causal triggers, state transitions, entity relationships.
  * Coexistence and independence proofs.
* **Narration-Carried (Abstract Intuition):**
  * Conceptual motivation ("Why system software is necessary for shared hardware").
  * Real-world analogies and high-level architectural context.

---

## 10. Scope Boundary Inheritance Matrix

| Chapter | Core Concept Owned | Inherited Foundation | Permitted Concepts | Forbidden Leakage (Must NOT Appear) |
| :--- | :--- | :--- | :--- | :--- |
| **CH01** | Process Identity & Lifetime | T01 Instruction Execution | Program $\neq$ Process, PID, OS launch, multiple instances | Address Space, States (Ready/Running/Waiting), Context Switch, Scheduling, Threads |
| **CH02** | Process Execution (Pause, Switch, Resume) | CH01 Process Identity | Code/Data/Heap/Stack, Resources/Handles, Execution Context (PC/Registers), States, Events, Context Preservation, Context Switch, Resume | Ready Queue ordering algorithms (FCFS/RR), Time Slice policy, Scheduler decision algorithms, Threads |
| **CH03** | CPU Scheduling Policies | CH02 Process Execution | Ready Queue, Scheduler, Time Slice, Preemption, FCFS/Round Robin | Thread scheduling, Multicore scheduling, Mutex/Locks, Race conditions |
| **CH04** | Thread Concept & Execution Paths | CH03 CPU Scheduling | Process vs Thread, Shared Address Space, Thread Stack/PC | Race conditions, Mutex/Locks, Semaphores, Deadlocks, Memory ordering |
| **CH05** | Multithreading & Race Conditions | CH04 Threads | Concurrency, Interleaving, Shared Mutable State, Race Condition | Mutex implementation details, Semaphore mechanics, Atomic hardware instructions (Topic 06) |

---

## 11. Cross-Chapter Inheritance Matrix

| Knowledge Element | CH01 | CH02 | CH03 | CH04 | CH05 |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Program $\neq$ Process** | ESTABLISH | INHERIT | INHERIT | INHERIT | INHERIT |
| **Process Identity (PID)** | ESTABLISH | INHERIT | INHERIT | INHERIT | INHERIT |
| **OS Mediation Layer** | ESTABLISH | INHERIT | INHERIT | INHERIT | INHERIT |
| **Address Space (Code/Data/Heap/Stack)** | — | ESTABLISH | INHERIT | INHERIT | INHERIT |
| **Execution Context (PC / Registers / Stack Pointer)** | — | ESTABLISH | INHERIT | INHERIT | INHERIT |
| **Process States (Running / Ready / Waiting / Terminated)** | — | ESTABLISH | INHERIT | INHERIT | INHERIT |
| **Context Switch & Resume** | — | ESTABLISH | INHERIT | INHERIT | INHERIT |
| **Ready Queue & Scheduler** | — | — | ESTABLISH | INHERIT | INHERIT |
| **Scheduling Policies (FCFS/RR/Time Slice)** | — | — | ESTABLISH | INHERIT | INHERIT |
| **Thread (Execution Path inside Process)** | — | — | — | ESTABLISH | INHERIT |
| **Shared Address Space vs Thread Context** | — | — | — | ESTABLISH | INHERIT |
| **Shared Mutable State & Race Conditions** | — | — | — | — | ESTABLISH |
