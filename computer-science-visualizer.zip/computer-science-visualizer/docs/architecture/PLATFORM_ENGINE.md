---
guiding_question: "How are the executable engine, viewer shell, rendering pipelines, and state management technical contracts structured?"
primary_consumer: "Software Engineers, Platform Developers, AI Agents"
depends_on:
  - "docs/protocols/GOVERNANCE_AND_AMENDMENTS.md"
  - "docs/constitution/VISUAL_LANGUAGE.md"
referenced_by:
  - "docs/README_FOR_AI.md"
  - "docs/architecture/CANVAS_NAVIGATION.md"
---

# Cesvi Platform Engine Architecture

**Status:** Frozen  
**Version:** 1.1.0  
**Authority:** Technical platform architecture specification for the executable engine, viewer shell, and renderer.

---

## 1. System Overview

The Cesvi executable engine powers interactive 2D/3D visualizations. It consists of three decoupled layers:

$$\text{Viewer Shell (UI Chrome)} \rightarrow \text{Orchestrator Engine} \rightarrow \text{Canvas Renderer}$$

---

## 2. Platform Architecture Contracts

### 2.1 Chapter Independence & Dynamic Loading
- Chapters are code-split chunks located in `src/content/chapters/<chapter-id>/`.
- The engine loads chapters lazily via `registry.loadStory()`.
- Adding a new chapter requires zero changes outside its own `src/content/` folder.

### 2.2 Shared Engine State
- The timeline and scene states are strictly deterministic functions of elapsed time `t` and active beat `b`.
- State transitions are pure and idempotent: `render(beat, elapsed, t, camera)`.

### 2.3 Visual Tokens Integration
- Visual styles, colors, and typography inherit from [DESIGN_TOKENS.json](DESIGN_TOKENS.json).

### 2.4 Derived Container Extent
- A container's **size** — not only its position — shall be derived from the content it must hold plus named padding (e.g. `panelH = 2*padY + tagH + rows*rowH + (rows-1)*rowGap + BREATH`).
- This extends the Layout Derivation Law (`docs/pipeline/02_PRODUCTION_LIFECYCLE.md`) from coordinates to extents: a hand-typed width or height silently violates its own breathing minimums as soon as content is added.
- **Provenance:** `docs/chapters/topic-01-ch-02-cpu-memory-wait/08_PHASE_X_REPORT.md` (L3, defect D6, proof row B7).

### 2.5 Evidence Board Persistence
- A panel that accumulates evidence over a scene (timeline strips, comparison meters, counters, trackers) shall be drawn in its **empty state** from the moment the learner enters the scene that will fill it.
- Empty slots are structure; filled slots are state (`docs/constitution/VISUAL_LANGUAGE.md` §4). Showing the empty structure tells the learner how much is about to be accounted for and prevents a dead band in the layout.
- **Provenance:** `docs/chapters/topic-01-ch-02-cpu-memory-wait/08_PHASE_X_REPORT.md` (L4, defect D5).
