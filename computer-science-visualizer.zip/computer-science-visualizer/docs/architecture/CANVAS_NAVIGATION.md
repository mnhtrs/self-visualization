---
guiding_question: "How do camera controls, pan/zoom bounds, and spatial multi-level navigation behave?"
primary_consumer: "Canvas Engineers, Platform Developers, AI Agents"
depends_on:
  - "docs/architecture/PLATFORM_ENGINE.md"
  - "docs/constitution/VISUAL_LANGUAGE.md"
referenced_by:
  - "docs/README_FOR_AI.md"
---

# Architecture Specification — Global Canvas Navigation

**Status:** FROZEN · **Version:** 1.1.0  
**Layer:** `architecture/`  
**Kind:** Normative viewer/runtime contract  

---

## 1. Overview
Canvas navigation is a **mandatory capability** of the CESVI viewer shell. Every chapter MUST support the same viewport navigation model. Navigation is a viewport capability and is independent of the storyboard and educational logic.

---

## 2. Navigation Model & Matrix Composition

The viewer renders each scene through a camera transform over a world coordinate space. The composed transform is derived as:

$$T_{\text{composed}} = T_{\text{user}} \circ T_{\text{fit}}$$

- **Pan:** Dragging empty canvas pans the camera. Objects remain fixed in world coordinates.
- **Zoom:** Wheel/trackpad pinch zooms centered on cursor position, clamped to $[Z_{\min}, Z_{\max}]$.
- **Reset:** Double-clicking empty canvas or pressing Reset restores auto-fit view.

---

## 3. Single Source of Transform Invariant

The composed camera transform (`zoomTotal`, `offX`, `offY`) MUST be computed exactly once per frame by the engine. Both the renderer and all screen-to-world hit tests MUST consume this single composed transform.
