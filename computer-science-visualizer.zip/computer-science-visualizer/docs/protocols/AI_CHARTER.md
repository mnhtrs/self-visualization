---
guiding_question: "What are the operating laws, truth obligations, and authority bounds for AI agents operating in this repository?"
primary_consumer: "AI Agents, System Maintainers"
depends_on:
  - "docs/constitution/PHILOSOPHY.md"
referenced_by:
  - "docs/README_FOR_AI.md"
---

# Cesvi AI Charter & Operating Law

**Status:** Active  
**Version:** 2.0.0  
**Authority:** Governs all AI agent interactions, autonomy bounds, and quality obligations across the repository.

---

## 1. Universal Operating Principles

1. **Truth Supremacy:** AI agents shall never fabricate technical mechanisms, invent unverified API contracts, or mask runtime errors.
2. **Authority Hierarchy:** Constitutional laws override pipeline preferences; pipeline rules override source code precedent.
3. **No Unlearning:** AI agents must ensure foundational models hold true across all chapters without introducing oversimplifications that require future unlearning.
4. **Task-Routed Decision Making:** AI agents must identify the active governing document for every non-trivial decision before modifying code or documentation.

---

## 2. Autonomy Boundaries & Verification Rules

* **Code Edits:** Every code modification must be justified by empirical evidence (logs, stack traces, or failing tests) and verified via `npm run build` and `npm run smoke`.
* **Documentation Amendments:** Frozen documents may be amended ONLY through the formal Amendment Process (`docs/protocols/GOVERNANCE_AND_AMENDMENTS.md`).
* **Task Completion:** A task is complete only when all criteria in the active governing chain are satisfied and `docs/protocols/DOCUMENTATION_EVOLUTION.md` has run.
