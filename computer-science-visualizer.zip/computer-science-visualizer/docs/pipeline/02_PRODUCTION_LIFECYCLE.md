---
guiding_question: "What is the step-by-step production lifecycle for building, testing, freezing, and evolving a chapter?"
primary_consumer: "Content Authors, Implementation Engineers, AI Agents"
depends_on:
  - "docs/protocols/GOVERNANCE_AND_AMENDMENTS.md"
  - "docs/pipeline/01_COGNITIVE_STAGES.md"
  - "docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md"
referenced_by:
  - "docs/README_FOR_AI.md"
  - "docs/pipeline/03_QA_VERIFICATION.md"
---

# Cesvi Chapter Production Lifecycle

**Status:** Active  
**Version:** 2.1.0  
**Authority:** Defines the 9 production phases from drafting code to freezing and Phase X repository evolution. All phases MUST conform to [`CHAPTER_PRODUCTION_STANDARD.md`](CHAPTER_PRODUCTION_STANDARD.md).

---

## 1. Production Phase Overview

Every chapter follows a strict 9-Phase lifecycle plus post-freeze Repository Evolution (Phase X):

1. **Phase 1: Journey Definition & Learner State** — Finalize Step 0 (Learner State Reconstruction), scope, central question, and target mental model (`CHAPTER_PRODUCTION_STANDARD.md` §2).
2. **Phase 2: Pipeline Design & Scene Arc** — Define 4-Act Discovery Arc, curiosity bottlenecks, and single experiential climax (`CHAPTER_PRODUCTION_STANDARD.md` §3 & §4).
3. **Phase 3: Pipeline Validation** — Verify CS technical truth against first principles.
4. **Phase 4: Story Architecture** — Map scenes into code structures (`src/content/chapters/<id>/`).
5. **Phase 5: Scene Design & Layout Derivation** — Derive all geometry using named primitives (Layout Derivation Law).
6. **Phase 6: Narration & Animation Sync** — Sync narration with causal animation dominance ($T_0 \rightarrow T_1 \rightarrow T_2$).
7. **Phase 7: Self Review & QA Check** — Audit against `03_QA_VERIFICATION.md`.
8. **Phase 8: Audit & Release Freeze** — Execute `npm run build` and `npm run smoke`, then lock artifacts as `FROZEN`.
9. **Phase 9: Production Closure** — Register chapter in `PROJECT_STATE.md`.
10. **Phase X: Repository Evolution** — Run `DOCUMENTATION_EVOLUTION.md` to generalize reusable production lessons back into repository docs.

---

## 2. Mandatory Rules During Production

* **Layout Derivation Law:** Coordinates must be derived from named primitives or container functions. Inline coordinate literals are prohibited.
* **Connection Identity:** Distinct physical/logical paths must be drawn as distinct visual lines.
* **Phase-Local Constraint Activation:** Before working on any phase, reopen its governing document section.
* **Checkpoint Obligation:** A phase is NOT complete until the Checkpoint Protocol below is executed in full.

---

## 3. Checkpoint Protocol (Mandatory after Every Phase)

A production phase is considered complete only when ALL of the following succeed, in order:

1. ✓ **Artifacts generated** — all required outputs for this phase exist on disk.
2. ✓ **Validation completed** — schema validation or gate script passes (where applicable).
3. ✓ **`AGENT_MEMORY.md` updated** — reflect the just-completed phase, finalized decisions, and next task.
4. ✓ **`AGENT_BOOT.md` updated** — `active_phase`, `checkpoint_id`, `next_action`, and `next_file` reflect the new state.

Treat this as a transactional commit. If the session is interrupted after step 1 but before step 4, the incomplete checkpoint is detected on resume by cross-checking `AGENT_BOOT.checkpoint_id` against the last completed entry in `AGENT_MEMORY.md`.

---

## 4. Execution Flow

```
Session Start
     ↓
Read AGENT_BOOT.md
     ↓
Read AGENT_MEMORY.md (link from working_memory field)
     ↓
Read required governing docs for active_phase
     ↓
Execute production phase
     ↓
Generate artifacts
     ↓
Validate (schema / gate scripts)
     ↓
Update AGENT_MEMORY.md
     ↓
Update AGENT_BOOT.md
     ↓
Begin next phase
```

---

## 5. Failure Recovery Protocol

If execution stops unexpectedly:

```
Read AGENT_BOOT.md
     ↓
Read AGENT_MEMORY.md
     ↓
Verify existing artifacts (check artifact list in AGENT_MEMORY)
     ↓
If AGENT_BOOT.checkpoint_id matches last completed phase in AGENT_MEMORY
  → Resume active_phase from checkpoint
Else (checkpoint interrupted midway)
  → Re-execute current phase from the beginning
     ↓
Never restart a completed phase unless its validation gate fails
```
