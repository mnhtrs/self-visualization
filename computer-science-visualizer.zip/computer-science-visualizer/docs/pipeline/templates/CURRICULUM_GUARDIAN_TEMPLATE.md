---
guiding_question: "What is the standard template format for drafting Topic-level Curriculum Guardian specifications?"
primary_consumer: "Curriculum Architects, Authors, AI Agents"
authority_level: "Procedural / Derived Production Aid"
depends_on:
  - "docs/curriculum/CURRICULUM_CONSTITUTION.md"
  - "docs/curriculum/CURRICULUM_GRAPH.md"
  - "docs/protocols/GOVERNANCE_AND_AMENDMENTS.md"
referenced_by:
  - "docs/curriculum/CURRICULUM_GRAPH.md"
---

# Curriculum Guardian Specification Template: Topic [ID] — [Title]

**Topic ID:** [e.g., Topic 02 — Browser Rendering]  
**Status:** [Draft Spec | Frozen Guardian]  
**Version:** 1.0.0  
**Authority:** Topic-level curriculum contract extending [`CURRICULUM_CONSTITUTION.md`](../../curriculum/CURRICULUM_CONSTITUTION.md) and [`CURRICULUM_GRAPH.md`](../../curriculum/CURRICULUM_GRAPH.md). This specification defines topic boundaries and cannot override supreme curriculum canons.

---

## 1. Governance & Authority Deference

* **Supreme Curriculum Law:** [`CURRICULUM_CONSTITUTION.md`](../../curriculum/CURRICULUM_CONSTITUTION.md) (Canons C-01…C-10)
* **Macro Curriculum Graph:** [`CURRICULUM_GRAPH.md`](../../curriculum/CURRICULUM_GRAPH.md) §2 & §3
* **Amendment Protocol:** [`GOVERNANCE_AND_AMENDMENTS.md`](../../protocols/GOVERNANCE_AND_AMENDMENTS.md)

---

## 2. Topic Mission & Central Transformation

* **Topic Mission Statement:** [State the overarching educational goal of this topic in 1–2 sentences]
* **Upstream Entry Assumption:** [State what prior knowledge from upstream topics is assumed as true]
* **Downstream Handoff Payload:** [State what exit payload this topic hands off to downstream topics]

---

## 3. Step 0 Learner State Reconstruction Baseline

Define the standard Step 0 baseline for chapters within this topic (`CHAPTER_PRODUCTION_STANDARD.md` §2):

1. **Active Mental Models:** [List active mental models carried over]
2. **Resident Visual Metaphors & Assets:** [List entities, colors, component shapes]
3. **Misconception Inventory & Educational Debt Status:** [List active misconceptions and Debt Facet status]
4. **Cognitive Replay Triggers:** [List upstream prior mechanisms reactivated on scene entry]

---

## 4. Topic Conceptual Boundaries

Declare the strict conceptual ownership matrix for this topic:

* **Owned Concepts (T[ID] Primary Authority):** [Concepts this topic explicitly introduces and transforms]
* **Assumed Concepts (Upstream Carry-Over):** [Concepts assumed known from prior topics]
* **Deferred Concepts (Internal Details Saved for Later):** [Internal mechanisms deferred to future chapters]
* **Explicitly Excluded Concepts (Forbidden Overlap):** [Concepts strictly prohibited within this topic]
* **Terminal Boundary:** [The exact physical/logical stopping point where this topic ends]

---

## 5. Terminology Ownership & Canonical Vocabulary

List official technical terms owned by this topic and forbidden false analogies:

| Owned Term | Mechanical Meaning | Forbidden Analogy / Misleading Term |
| :--- | :--- | :--- |
| `[Term Name]` | [Exact technical definition] | [Forbidden false analogy] |

---

## 6. Chapter Breakdown & Allocation Matrix

Declare the intra-topic sequence of chapters:

| Chapter ID | Chapter Title | Target Mental-Model Transformation | Prerequisite |
| :--- | :--- | :--- | :--- |
| `T[ID]/Ch-01` | [Title] | [Before model → After model] | [Prereq ID] |
| `T[ID]/Ch-02` | [Title] | [Before model → After model] | `T[ID]/Ch-01` |

---

## 7. Curriculum Guardian Five-Point Verification

Every chapter in this topic must satisfy the Guardian test:

1. [ ] **Single Transformation:** Does the chapter complete exactly one mental-model transformation?
2. [ ] **Boundary Compliance:** Does the chapter stay within declared owned concepts without leaking into excluded domains?
3. [ ] **Protagonist Traceability:** Is the designated visual protagonist continuously traceable?
4. [ ] **Experiential Climax:** Does the climax occur through pure visual observation?
5. [ ] **No Unlearning:** Does the chapter teach zero false mechanisms?
