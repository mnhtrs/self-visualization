---
guiding_question: "What is the standard template format for drafting new constitution documents?"
primary_consumer: "Maintainers, Authors"
depends_on:
  - "docs/protocols/GOVERNANCE_AND_AMENDMENTS.md"
referenced_by:
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
---

# Constitution Document Template: [Title]

**Title:** [Title]  
**Purpose:** [Single sentence defining the constitutional responsibility of this document.]  
**Status:** Draft  
**Version:** 0.0.0  
**Dependencies:** [List upstream constitution documents, e.g., `PHILOSOPHY.md`]  
**Downstream Documents:** [List what this document governs, e.g., Curriculum, Journeys, Runtime Architecture]  
**Review Gates:** [List required reviewer roles]  

---

## 1. [Law Name]
[One-sentence statement of the immutable law.]
* **1.1. [Sub-rule name]:** [Precise, deterministic rule statement.]
* **1.2. [Sub-rule name]:** [Precise, deterministic rule statement.]

## 2. [Law Name]
[One-sentence statement of the immutable law.]
* **2.1. [Sub-rule name]:** [Precise, deterministic rule statement.]
