---
guiding_question: "What is the standard template format for conducting Phase 7 Quality Audits against 03_QA_VERIFICATION.md?"
primary_consumer: "QA Auditors, Implementation Engineers, AI Agents"
authority_level: "Procedural / Derived Production Aid"
depends_on:
  - "docs/pipeline/03_QA_VERIFICATION.md"
  - "docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md"
  - "docs/pedagogy/PEDAGOGICAL_SYSTEM.md"
referenced_by:
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
---

# QA Verification Audit Template: [Chapter ID / Title]

**Chapter ID:** [e.g., topic-01-ch-04-instruction-throughput]  
**Phase:** Phase 7 — Self Review & QA Check  
**Audit Date:** [YYYY-MM-DD]  
**Auditor:** [Author / QA Agent]  
**Authority:** Procedural audit template instantiating [`03_QA_VERIFICATION.md`](../03_QA_VERIFICATION.md) v2.1.0. This document cannot modify existing quality gate definitions or introduce un-ratified gates.

---

## Deference & Verification Baseline

* **Authoritative QA Baseline:** [`03_QA_VERIFICATION.md`](../03_QA_VERIFICATION.md) v2.1.0
* **Governing Production Standard:** [`CHAPTER_PRODUCTION_STANDARD.md`](../CHAPTER_PRODUCTION_STANDARD.md) v1.0.0
* **Pedagogical System Baseline:** [`PEDAGOGICAL_SYSTEM.md`](../../pedagogy/PEDAGOGICAL_SYSTEM.md) v1.3.0

---

## Gate 1: Pedagogical & Scope Alignment

* [ ] **1.1 Target Mental Model:** Declares exactly one central question and target mental-model transformation.
  * *Evidence:* [Cite central question from `00_JOURNEY_DEFINITION.md`]
* [ ] **1.2 No Unlearning:** Introduces zero false analogies or temporary hand-waving explanations.
  * *Evidence:* [Confirm mechanism accuracy]
* [ ] **1.3 Black Box Boundary:** Opaque components are explicitly classified as Deferred Internal or Terminal Boundary.
  * *Evidence:* [List declared boundary classifications]
* [ ] **1.4 Learner State Alignment:** Step 0 audit completed; entry state aligns with upstream prerequisite carry-over payloads and reactivates cognitive replay triggers (`CHAPTER_PRODUCTION_STANDARD.md` §2).
  * *Evidence:* [Reference `01_delta.json` learner state reconstruction]

---

## Gate 2: Storytelling & Narration

* [ ] **2.1 Observation Before Terminology:** Technical terms appear only after the visual referent has been observed (`PEDAGOGICAL_SYSTEM.md` §4.1).
  * *Evidence:* [Identify timeline beats where term is introduced after visual observation]
* [ ] **2.2 Bilingual Naturalness:** Narration in both English and Vietnamese is written in human spoken register (no textbook jargon dumps).
  * *Evidence:* [Review narration strings in storyboard]
* [ ] **2.3 Single Focus:** Each beat mutates exactly one independent concept or state variable (`PEDAGOGICAL_SYSTEM.md` §4.3).
  * *Evidence:* [Verify timeline beat mutations]
* [ ] **2.4 Experiential Climax:** Climax is reached through unassisted visual observation of system operation at scale (zero text recaps, voiceover lectures, or static diagrams; `CHAPTER_PRODUCTION_STANDARD.md` §4).
  * *Evidence:* [Specify Climax Beat ID and confirm zero narration text during operation]

---

## Gate 3: Visual & Layout Integrity

* [ ] **3.1 Layout Derivation Law:** All visual coordinates are derived from named primitives or container functions (no hardcoded coordinate literals; `VISUAL_LANGUAGE.md` §2.2).
  * *Evidence:* [Reference `06_LAYOUT_PROOF.md`]
* [ ] **3.2 Connection Identity:** Distinct physical/logical paths are rendered as distinct visual lines.
  * *Evidence:* [Confirm path separation]
* [ ] **3.3 Protagonist Traceability:** The visual protagonist remains continuously traceable across all scenes (`VISUAL_LANGUAGE.md` §13).
  * *Evidence:* [Specify protagonist entity color and path]
* [ ] **3.4 Animation Causal Dominance:** Animation moves visually before narration labels ($T_0 \rightarrow T_1 \rightarrow T_2$); stalls are physically rendered (`CHAPTER_PRODUCTION_STANDARD.md` §5).
  * *Evidence:* [Confirm animation timestamp precedes narration text trigger]

---

## Gate 4: Execution & Automated Test Pass

* [ ] **4.1 Build Check:** `npm run build` completes with zero errors or bundle warnings.
  * *Evidence Result:* [PASS | FAIL]
* [ ] **4.2 Smoke Suite Check:** `npm run smoke` passes for integrity, playthroughs, and deterministic snapshots.
  * *Evidence Result:* [PASS | FAIL] (Record total checks passed, e.g., 482 checks)
* [ ] **4.3 Phase X Evolution Protocol:** `docs/protocols/DOCUMENTATION_EVOLUTION.md` is scheduled post-freeze.
  * *Evidence:* [Confirmed scheduled for Phase X]

---

## Final QA Audit Verdict

* **Overall Status:** [APPROVED FOR FREEZE | REVISION REQUIRED]
* **Notes / Open Action Items:** [Summary of required fixes if any]
