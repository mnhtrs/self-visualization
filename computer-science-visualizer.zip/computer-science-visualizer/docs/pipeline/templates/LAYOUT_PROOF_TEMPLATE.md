---
guiding_question: "What is the standard template format for documenting Phase 5 Layout Derivation Law compliance and geometric proofs?"
primary_consumer: "Rendering Engineers, Content Authors, AI Agents"
authority_level: "Procedural / Derived Production Aid"
depends_on:
  - "docs/constitution/VISUAL_LANGUAGE.md"
  - "docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md"
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
referenced_by:
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
---

# Layout Proof Template: [Chapter ID / Title]

**Chapter ID:** [e.g., topic-01-ch-04-instruction-throughput]  
**Phase:** Phase 5 — Scene Design & Layout Derivation  
**Status:** [Draft | Verified]  
**Authority:** Procedural aid deriving from [`VISUAL_LANGUAGE.md`](../../constitution/VISUAL_LANGUAGE.md) §2.2 (*Derivable Geometry*). This document operationalizes layout compliance and cannot override constitutional visual laws.

---

## 1. Governance & Deference Header

* **Canonical Source:** [`VISUAL_LANGUAGE.md`](../../constitution/VISUAL_LANGUAGE.md) §2.2 & [`CHAPTER_PRODUCTION_STANDARD.md`](../CHAPTER_PRODUCTION_STANDARD.md) §4.0
* **Viewport Assumptions:** [e.g., 1920 × 1080 canvas, 16:9 aspect ratio]
* **Enforced Layout Rule:** Layout Derivation Law — all visual coordinates must derive from named primitives or container functions. Inline coordinate literals are strictly prohibited.

---

## 2. Container & Named Dock Definitions

Declare all container bounds and named layout docks used across scenes:

| Dock / Region ID | Purpose | Bounding Box Derivation Formula | Spatial Role |
| :--- | :--- | :--- | :--- |
| `DOCK_HEADER` | Global chapter navigation HUD | `y: 0, height: NAV_BAR_HEIGHT` | Fixed HUD |
| `DOCK_MAIN` | Central interactive visual stage | `y: NAV_BAR_HEIGHT, height: STAGE_HEIGHT` | Primary Focus |
| `DOCK_CPU` | CPU core visual boundary | `x: PADDING_LEFT, width: CPU_WIDTH` | Hardware Container |
| `DOCK_MEMORY` | Cache/RAM ladder visual boundary | `x: DOCK_CPU.right + GAP_X, width: MEM_WIDTH` | Memory Ladder |

---

## 3. Named Layout Primitives

Declare all named constants and spatial scales:

```ts
// Named Layout Geometry Primitives
export const PADDING_LEFT = 40;
export const GAP_X = 64;
export const CPU_WIDTH = 320;
export const MEM_WIDTH = 480;
export const ROW_HEIGHT = 48;
```

---

## 4. Scene Coordinate Derivations

For each scene, document the affirmative coordinate derivations:

### Scene [ID / Title]
* **Target Elements:** [e.g., Protagonist Spark, L1 Cache Dock, RAM Array]
* **Derivation Table:**

| Element / Component | Coordinate Field | Derivation Formula / Reference |
| :--- | :--- | :--- |
| `ProtagonistSpark` | `x(t)` | `DOCK_CPU.centerX + t * (DOCK_MEMORY.left - DOCK_CPU.centerX)` |
| `ProtagonistSpark` | `y(t)` | `DOCK_CPU.centerY` |
| `L1_Set_Box[i]` | `y` | `DOCK_MEMORY.top + i * (ROW_HEIGHT + GAP_Y)` |

---

## 5. Disjointness & Containment Verification

Verify spatial stability and absence of overlap:

* [ ] **Disjointness Assertion:** Distinct Docks do not overlap (`DOCK_CPU.right + GAP_X <= DOCK_MEMORY.left`).
* [ ] **Containment Assertion:** All child components fit within parent Docks without overflow.
* [ ] **Connection Identity:** Physical/logical paths are rendered as distinct visual lines terminating at component boundaries ([`VISUAL_LANGUAGE.md`](../../constitution/VISUAL_LANGUAGE.md) §2.1).

---

## 6. Verification Result

* **Layout Gate Status:** [PASS | FAIL]
* **Automated Layout Proof Command:** `npm run layout-proof` (if available for chapter)
* **Auditor / Agent Signature:** [Name / Date]
