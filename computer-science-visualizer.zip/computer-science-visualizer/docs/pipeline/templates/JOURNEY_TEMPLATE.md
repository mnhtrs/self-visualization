---
guiding_question: "What is the standard template format for drafting new chapter journey definitions?"
primary_consumer: "Content Authors, Story Authors"
depends_on:
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
referenced_by:
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
---

# Journey Template: [Title]

**Chapter ID:** [e.g., chapter-05-os-scheduler]  
**Status:** [Draft | Tech Review | Ed Review | Anim Review | Approved | Released]  

---

## 0. Phase-Local Activation Record
* **Governing documents reopened for this phase:** [List exact docs/sections reopened immediately before authoring this artifact.]
* **Active Constraint List:**
    1. [Constraint copied/summarized from governing docs]
    2. [Constraint copied/summarized from governing docs]
    3. [Constraint copied/summarized from governing docs]
* **Decision provenance:** [State whether docs determined them or they required design inference.]

---

## 1. Target Mental-Model Transformation
* **Before:** [State the learner's incomplete mental model before the chapter.]
* **After:** [State the accurate mental model the learner should hold after the chapter.]
* **Transformation:** [State the single transformation this chapter completes.]

---

## 2. Central Educational Question
[State the exact, singular learner-facing question that frames the target mental-model transformation.]

---

## 3. Narrative Threading & Continuity Contract
* **Upstream Endpoint State:** [Describe system state at the end of previous chapter.]
* **Contextual Carry-Over:** [Define visual assets and variables carried over.]
* **Downstream Launchpad:** [Define physical handoff to the next chapter.]
