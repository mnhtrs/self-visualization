---
guiding_question: "What is the single canonical operational standard for transforming learner state into discovery stories, causal animations, experiential climaxes, and verifiable chapters?"
primary_consumer: "Content Authors, Story Designers, Animation Engineers, QA Auditors, AI Agents"
depends_on:
  - "docs/constitution/PHILOSOPHY.md"
  - "docs/constitution/VISUAL_LANGUAGE.md"
  - "docs/constitution/NARRATIVE_FRAMING.md"
  - "docs/pedagogy/PEDAGOGICAL_SYSTEM.md"
  - "docs/curriculum/CURRICULUM_GRAPH.md"
referenced_by:
  - "docs/README_FOR_AI.md"
  - "docs/pipeline/01_COGNITIVE_STAGES.md"
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
  - "docs/pipeline/03_QA_VERIFICATION.md"
---

# CESVI Chapter Production Standard

**Status:** Active — Operational Production Baseline  
**Version:** 1.0.0  
**Authority:** Single authoritative operational standard governing chapter production, learner state reconstruction, scene arc design, experiential climaxes, causal animation physics, and review alignment across the CESVI ecosystem.

---

## 1. Purpose & Scope

This document translates constitutional philosophy and pedagogical principles into a unified, operational production standard. It eliminates linear textbook storytelling, illustrative (passive) animations, weak dramatic tension, and informational climaxes.

Every future CESVI chapter must satisfy all 5 sections of this standard during production Phases 1 through 8.

---

## 2. Section 1: Learner State Reconstruction Protocol (Step 0)

Before designing any scene, beat, or code, every chapter production MUST begin by reconstructing the learner's exact cognitive starting state.

### 2.1 The Learner State Audit
Authors and AI agents must audit and document the following four dimensions of learner state:

1. **Active Mental Models:** What does the learner currently believe about how the system works? (Derived from the exit state of upstream prerequisite chapters in `docs/curriculum/CURRICULUM_GRAPH.md`).
2. **Resident Visual Metaphors & Assets:** What visual entities, colors, component shapes, and glyphs are already established in working memory? (e.g., Golden Spark `#fb923c`, CPU `#fb923c`, Cache `#22d3ee`, RAM `#a78bfa`).
3. **Misconception Inventory & Educational Debt Status:** What false intuitions or naive assumptions still exist? Which official educational debt facets (e.g. Debt D0) remain un-cleared?
4. **Cognitive Replay Triggers:** Which specific mental model or visual element from a prior chapter must be reactivated in the opening scene to serve as the cognitive foundation or point of friction?

### 2.2 Integration with Stage 1 (`delta.json`)
The output of Step 0 must be codified into the `learner_state_reconstruction` block of `delta.json` before proceeding to topology design.

---

## 3. Section 2: Story & Scene Architecture

### 3.1 The 4-Act Discovery Arc
Every CESVI chapter must be structured as a 4-Act discovery journey:

* **Act 1: Naive Expectation & Friction (Entry State)**
  * The learner enters holding their current mental model.
  * The system is subjected to a scenario where the naive expectation fails, creating observable friction (stall, bottleneck, corruption, or overflow).
* **Act 2: Curiosity Bottleneck & Isolation**
  * The friction is isolated into a single, unanswered question.
  * The learner feels: *"Why does the system slow down/fail here? What is missing?"*
* **Act 3: Mechanical Invention & Experimentation**
  * The internal mechanism is revealed step-by-step to resolve the exact bottleneck.
  * Each beat introduces exactly one causal state mutation.
* **Act 4: Experiential Climax & Quiet Integration**
  * The complete mechanism operates at full scale.
  * The learner observes the system running continuously and effortlessly, experiencing the mental-model transformation without narration commentary.

### 3.2 Curiosity-Driven Scene Genesis
* **Rule:** A scene may NEVER be created simply because a concept is "important" or part of a textbook curriculum.
* **Genesis Requirement:** Every scene must be birthed by a bottleneck, curiosity question, or physical constraint raised in the immediately preceding scene.
* **Scene Hierarchy:**
  * **Course:** Sequence of mental-model transformations.
  * **Chapter:** Exactly ONE target mental-model transformation.
  * **Scene:** Resolves exactly ONE necessary sub-question or bottleneck.
  * **Beat:** Mutates exactly ONE independent state variable.

---

## 4. Section 3: Experiential Climax Architecture

### 4.1 Definition of Experiential Climax
A Climax in CESVI is the peak moment of learning where the target mental model is validated through pure, unassisted visual observation of the system operating at scale.

### 4.2 Immutable Climax Laws
1. **Visual Observation Only:** The climax MUST be reached by watching the system operate visually.
2. **Prohibition of Informational Summary:** A climax shall NEVER consist of a text summary, static diagram, bullet-point recap, voiceover speech, or on-canvas definitions.
3. **Single Climax Rule:** A chapter contains EXACTLY ONE climax. Secondary climaxes are strictly forbidden.
4. **Quiet Integration Phase:** Following the climax, narration must remain quiet, allowing the learner to observe the working system and form their own downstream curiosity questions.

---

## 5. Section 4: Causal Animation & Motion Physics

### 5.1 Causal Animation Dominance Protocol
Visual animation is the engine of causality in CESVI. Narration follows observation; animation NEVER "illustrates" spoken text.

$$\text{Animation Moves } (T_0) \rightarrow \text{Phenomenon Observed } (T_1) \rightarrow \text{Narration Labels } (T_2)$$

1. **Frame $T_0$ (Causal Trigger):** An entity moves, a buffer fills, or a core darkens.
2. **Frame $T_1$ (Observation):** The learner observes the physical consequence (e.g. stall, flow, completion).
3. **Frame $T_2$ (Naming):** Concise narration appears to apply plain technical terms to the event already observed.

### 5.2 Visual Stall & Friction Cues
System stalls, waits, or contention must be visually self-evident:
* **Core Darkening:** A core waiting for memory turns visually dark/inactive.
* **Paused Spark:** The protagonist spark halts at the boundary.
* **Friction Glow:** Paths under contention pulse or show queue accumulation.
* **Prohibition:** Stalls must NEVER be communicated solely by narration text like *"The CPU is now waiting for RAM."*

### 5.3 Camera & Spatial Framing
* **Orientation Preservation:** Layouts must maintain spatial stability. Camera pans or zooms must preserve the learner's sense of orientation.
* **Protagonist Priority in Parallelism:** When concurrent flows occur, exactly ONE Primary Protagonist is visually highlighted (`#fb923c`). Auxiliary flows carry decayed visual weight to prevent cognitive overload (`VISUAL_LANGUAGE.md` §18).

---

## 6. Section 5: Review & Quality Verification Alignment

Before Phase 8 freeze, every chapter must be audited against `docs/pipeline/03_QA_VERIFICATION.md` to confirm full compliance with this standard:

* **Gate 1.4 (Learner State Alignment):** Step 0 audit completed; entry state matches upstream carry-over payload.
* **Gate 2.4 (Experiential Climax):** Single climax reached by visual observation; zero text recaps or static diagrams.
* **Gate 3.4 (Animation Causal Dominance):** Animation moves before narration labels; stalls are visually rendered.
