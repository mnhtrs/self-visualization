---
guiding_question: "Has a chapter satisfied all mandatory quality gates required for release and freeze?"
primary_consumer: "QA Auditors, Implementation Engineers, AI Agents"
depends_on:
  - "docs/pedagogy/PEDAGOGICAL_SYSTEM.md"
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
referenced_by:
  - "docs/README_FOR_AI.md"
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
---

# Cesvi Chapter QA Verification Gates

**Status:** Active  
**Version:** 2.1.0  
**Authority:** Mandatory quality gates that every chapter must pass before being frozen.

---

## Quality Gates Matrix

### Gate 1: Pedagogical & Scope Alignment
- [ ] **1.1 Target Mental Model:** Declares exactly one central question and target mental-model transformation.
- [ ] **1.2 No Unlearning:** Introduces zero false analogies or temporary hand-waving explanations.
- [ ] **1.3 Black Box Boundary:** Opaque components are explicitly classified as Deferred Internal or Terminal Boundary.
- [ ] **1.4 Learner State Alignment:** Step 0 audit completed; entry state aligns with upstream prerequisite carry-over payloads and reactivates cognitive replay triggers (`CHAPTER_PRODUCTION_STANDARD.md` §2).

### Gate 2: Storytelling & Narration
- [ ] **2.1 Observation Before Terminology:** Technical terms appear only after the visual referent has been observed.
- [ ] **2.2 Bilingual Naturalness:** Narration in both English and Vietnamese is written in human spoken register (no textbook jargon).
- [ ] **2.3 Single Focus:** Each beat mutates exactly one independent concept or state variable.
- [ ] **2.4 Experiential Climax:** Climax is reached through unassisted visual observation of system operation at scale (zero text recaps, voiceover lectures, or static diagrams; `CHAPTER_PRODUCTION_STANDARD.md` §4).

### Gate 3: Visual & Layout Integrity
- [ ] **3.1 Layout Derivation Law:** All visual coordinates are derived from named primitives or container functions (no hardcoded coordinate literals).
- [ ] **3.2 Connection Identity:** Distinct physical/logical paths are rendered as distinct visual lines.
- [ ] **3.3 Protagonist Traceability:** The visual protagonist remains continuously traceable across all scenes.
- [ ] **3.4 Animation Causal Dominance:** Animation moves visually before narration labels ($T_0 \rightarrow T_1 \rightarrow T_2$); stalls are physically rendered (`CHAPTER_PRODUCTION_STANDARD.md` §5).

### Gate 4: Execution & Automated Test Pass
- [ ] **4.1 Build Check:** `npm run build` completes with zero errors or bundle warnings.
- [ ] **4.2 Smoke Suite Check:** `npm run smoke` passes for integrity, playthroughs, and deterministic snapshots.
- [ ] **4.3 Phase X Evolution:** `docs/protocols/DOCUMENTATION_EVOLUTION.md` is executed post-freeze and its report emitted.
