---
guiding_question: "How does an author transform CS domain truth into a 5-stage cognitive artifact chain (`delta` → `topology` → `trace` → `storyboard` → `blueprint`)?"
primary_consumer: "Content Engineers, Story Authors, AI Agents"
depends_on:
  - "docs/pedagogy/PEDAGOGICAL_SYSTEM.md"
  - "docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md"
  - "schemas/chapter/delta.schema.json"
  - "schemas/chapter/topology.schema.json"
  - "schemas/chapter/trace.schema.json"
  - "schemas/chapter/storyboard.schema.json"
  - "schemas/chapter/journey_blueprint.schema.json"
referenced_by:
  - "docs/README_FOR_AI.md"
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
---

# Cesvi 5-Stage Cognitive Planning Protocol

**Status:** Active  
**Version:** 2.1.0  
**Authority:** Defines the pre-production thinking pass executed by authors and AI agents before chapter coding begins.

---

## 1. Protocol Purpose & Stage Sequence

The Cognitive Planning Protocol forces structured cognitive decisions — about learner state reconstruction, misconceptions, minimal topology, protagonist paths, storyboards, and final blueprints — into machine-verifiable JSON artifacts before writing code. All stages MUST conform to [`docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md`](CHAPTER_PRODUCTION_STANDARD.md).

```
Stage 1 (delta.json) → Stage 2 (topology.json) → Stage 3 (trace.json) 
→ Stage 4 (storyboard.json) → Stage 5 (journey_blueprint.json) 
→ 02_PRODUCTION_LIFECYCLE.md (Phase 1)
```

No stage may begin until the preceding artifact passes its machine schema validation.

---

## 2. Stage Breakdown & Artifact Requirements

### Stage 1: Truth Delta & Learner State (`delta.json`)
- **Purpose:** Execute Step 0 (Learner State Reconstruction per `CHAPTER_PRODUCTION_STANDARD.md` §2), audit active mental models & cognitive replay triggers, and identify the naive misconception and target mental model.
- **Schema:** `schemas/chapter/delta.schema.json`

### Stage 2: Minimal Topology (`topology.json`)
- **Purpose:** Identify the minimum number of system nodes (2–6 nodes) and connection paths required to show the mechanism.
- **Schema:** `schemas/chapter/topology.schema.json`

### Stage 3: Protagonist Trace (`trace.json`)
- **Purpose:** Trace the continuous path of the visual protagonist through the system topology across all scenes.
- **Schema:** `schemas/chapter/trace.schema.json`

### Stage 4: Storyboard (`storyboard.json`)
- **Purpose:** Structure scenes into the 4-Act Discovery Arc with curiosity bottlenecks, single experiential climax, and bilingual narration (EN/VI) per `CHAPTER_PRODUCTION_STANDARD.md` §3 & §4.
- **Schema:** `schemas/chapter/storyboard.schema.json`

### Stage 5: Journey Blueprint (`journey_blueprint.json`)
- **Purpose:** Assemble the complete pre-production blueprint uniting scenes, beats, layout targets, and causal animation timing ($T_0 \rightarrow T_1 \rightarrow T_2$).
- **Schema:** `schemas/chapter/journey_blueprint.schema.json`
