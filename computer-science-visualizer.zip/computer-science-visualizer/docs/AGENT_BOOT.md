---
boot_version: "1.0.0"
guiding_question: "What is the current operational state, active chapter, active phase, and next action for an AI agent in Cesvi?"
constitution_revision: "PHILOSOPHY 2.0.0 · VISUAL_LANGUAGE 3.0.0 · NARRATIVE_FRAMING 3.0.0 · PEDAGOGY 1.3.0 · ARCHITECTURE 1.1.0"

active_chapter: "topic-02-operating-systems--ch-02-process-execution"
active_phase: 9
checkpoint_id: "t02ch02-inc1-gates-green"
next_action: "Owner review of Topic 02 Chapter 02 increment 1 (Inside a Process — production, gates green: smoke 438 · scope 3783 · layout 146). On approval: freeze per the Topic 02 fast workflow Phase 10. (T01/Ch-04 owner review also still pending.)"
next_file: "docs/chapters/topic-02-ch-02-process-execution/02_CHAPTER_PRODUCTION_[BLUEPRINT].md"
working_memory: "docs/chapters/topic-02-ch-02-process-execution/AGENT_MEMORY.md"
---

## Forbidden Actions

- Do NOT reopen Ch-02, Ch-03 or the Ch-04 design without explicit owner directive.
- Do NOT modify frozen artifacts outside the Amendment Process (`docs/protocols/GOVERNANCE_AND_AMENDMENTS.md`).
- Do NOT teach write-through/write-back, MESI, TLB, prefetch, dirty-bit, multi-core, hazards, stalls, contention, processes, threads, or schedulers in any T01 chapter.
- Do NOT add a second climax, on-canvas questions, Throughput/Latency text, or concluding narration to T01/Ch-04 (owner directive).
- Do NOT write history or rationale into this file — history belongs in `CHANGELOG.md`.

## Repository Snapshot (full detail → `docs/state/PROJECT_STATE.md`)

- Build: PASS · Smoke: PASS (438 + 3783 + 146 checks, T02/CH02 inc.1) · Status: Green
- Ch-03 FROZEN 2026-07-28 · Ch-02 FROZEN · T02/CH01 FROZEN 2026-08-14
- T01/Ch-04 (instruction-level throughput): production complete, gates green — awaiting owner review before freeze
- T02/CH02 increment 1 (Inside a Process: Memory, Resources & Execution Context): production complete, gates green — awaiting owner review. The States/Switch/Resume story is a LATER increment of the same chapter (do not implement without owner directive).

## Recovery Protocol

If resuming after interruption: read this file → read `working_memory` → verify existing artifacts → resume `active_phase`. Never restart a completed phase unless its validation gate fails.
