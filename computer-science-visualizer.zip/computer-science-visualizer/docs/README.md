---
guiding_question: "How is the Cesvi documentation system organized for human contributors?"
primary_consumer: "Human Contributors, Maintainers"
depends_on:
  - "docs/constitution/PHILOSOPHY.md"
referenced_by:
  - "Repository Root"
---

# Cesvi Documentation & Knowledge Base

**What is Cesvi?**  
Cesvi is a long-term interactive educational platform that teaches Computer Science, Information Technology, Operating Systems, Networks, Databases, AI, and Mathematics through scientifically correct, interactive visualization.

---

## Repository Documentation Structure

The documentation system is organized into strict domains by responsibility and mutability:

- **`docs/protocols/`** — AI operating law, truth obligations, and governance procedures (`AI_CHARTER.md`, `GOVERNANCE_AND_AMENDMENTS.md`, `DOCUMENTATION_EVOLUTION.md`).
- **`docs/constitution/`** — Immutable educational, visual, and narrative laws (`PHILOSOPHY.md`, `VISUAL_LANGUAGE.md`, `NARRATIVE_FRAMING.md`).
- **`docs/pedagogy/`** — Operational pedagogy framework & conflict resolution (`PEDAGOGICAL_SYSTEM.md`).
- **`docs/pipeline/`** — Chapter authoring lifecycle, 5 cognitive stages, QA verification gates, and scaffolds (`01_COGNITIVE_STAGES.md`, `02_PRODUCTION_LIFECYCLE.md`, `03_QA_VERIFICATION.md`, `templates/`).
- **`docs/architecture/`** — Technical platform engine and viewer specs (`PLATFORM_ENGINE.md`, `CANVAS_NAVIGATION.md`, `DESIGN_TOKENS.json`).
- **`docs/curriculum/`** — Supreme curriculum law (`CURRICULUM_CONSTITUTION.md` — frozen, scale-invariant contract: canons, single debt, extension doctrine, boundaries, audit protocol), macro curriculum sequence & inter-chapter continuity (`CURRICULUM_GRAPH.md`), and the Topic 01 validation record (`CURRICULUM_GUARDIAN_T01_FINAL.md`).
- **`docs/state/`** — Operational project state gate (`PROJECT_STATE.md`) and archived historical log (`CHANGELOG.md`).
- **`schemas/chapter/`** — Machine-executable JSON Schemas for chapter cognitive artifacts.

---

## Where to Start

- **AI Agents:** Read [docs/README_FOR_AI.md](README_FOR_AI.md) for deterministic task routing.
- **Human Contributors:** Start with [docs/constitution/PHILOSOPHY.md](constitution/PHILOSOPHY.md).
