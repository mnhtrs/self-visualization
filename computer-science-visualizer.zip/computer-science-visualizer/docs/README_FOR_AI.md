---
guiding_question: "How does an AI agent deterministically route any task to its single governing document?"
primary_consumer: "AI Agents"
depends_on:
  - "docs/protocols/AI_CHARTER.md"
  - "docs/state/PROJECT_STATE.md"
referenced_by:
  - "docs/README.md"
---

# AI Bootloader — Task-Routed Decision Architecture

This document is the mandatory entry point for every AI agent operating in the Cesvi repository.

Cesvi documentation is a **decision-routing system**, not a static knowledge dump. Do not try to read the entire repository. Identify your task category, resolve its governing document chain, and activate ONLY the documents required for that task.

---

## STEP 0 — Boot (Execute Before Anything Else)

**Read [`docs/AGENT_BOOT.md`](AGENT_BOOT.md) first.** Always. Without exception.

This file contains your current execution state: active chapter, active phase, next action, checkpoint ID, and link to the chapter working memory. It is 40 lines. Reading it takes under 30 seconds.

**If resuming after interruption:** Read `AGENT_BOOT.md` → Read the `working_memory` file linked there → Verify existing artifacts → Resume `active_phase`. Never restart a completed phase unless its validation gate fails.

---

## 1. Universal Boot Chain — Always Read First

Read these documents before classifying or executing any task:

1. [docs/protocols/AI_CHARTER.md](protocols/AI_CHARTER.md) — AI operating law, truth obligations, authority hierarchy.
2. [docs/protocols/DOCUMENTATION_EVOLUTION.md](protocols/DOCUMENTATION_EVOLUTION.md) — Phase X repository evolution requirement.
3. [docs/state/PROJECT_STATE.md](state/PROJECT_STATE.md) — Current repository status, active phase, baselines, forbidden actions.

---

## 1. Authority Hierarchy

When two active documents conflict, apply this strict hierarchy:

1. [docs/state/PROJECT_STATE.md](state/PROJECT_STATE.md) (Temporal state gate)
2. [docs/protocols/AI_CHARTER.md](protocols/AI_CHARTER.md) & [docs/protocols/GOVERNANCE_AND_AMENDMENTS.md](protocols/GOVERNANCE_AND_AMENDMENTS.md) (Governance law)
3. [docs/constitution/PHILOSOPHY.md](constitution/PHILOSOPHY.md), `VISUAL_LANGUAGE.md`, `NARRATIVE_FRAMING.md` (Constitutional law)
4. [docs/pedagogy/PEDAGOGICAL_SYSTEM.md](pedagogy/PEDAGOGICAL_SYSTEM.md) (Operational pedagogy)
5. [docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md](pipeline/CHAPTER_PRODUCTION_STANDARD.md) (Operational production standard)
6. [docs/architecture/PLATFORM_ENGINE.md](architecture/PLATFORM_ENGINE.md) & `CANVAS_NAVIGATION.md` (Technical specs)
7. [docs/pipeline/01_COGNITIVE_STAGES.md](pipeline/01_COGNITIVE_STAGES.md), `02_PRODUCTION_LIFECYCLE.md`, `03_QA_VERIFICATION.md` (Pipeline & QA)
8. Source code, tests, and build output (Evidence of current implementation only)

---

## 2. Task Category → Active Governing Chain

### A. Chapter Production
Active chain:
1. STEP 0 — [`docs/AGENT_BOOT.md`](AGENT_BOOT.md) + `working_memory` link
2. Universal Boot Chain
3. [docs/curriculum/CURRICULUM_CONSTITUTION.md](curriculum/CURRICULUM_CONSTITUTION.md) (supreme curriculum contract — canons, debt, boundaries, audit protocol) + [docs/curriculum/CURRICULUM_GRAPH.md](curriculum/CURRICULUM_GRAPH.md)
4. **[docs/constitution/_DIGEST.md](constitution/_DIGEST.md)** ← Read this first; open full source docs only if a rule needs disambiguation
5. **[docs/pedagogy/_DIGEST.md](pedagogy/_DIGEST.md)** ← Same: digest first, full `PEDAGOGICAL_SYSTEM.md` on demand
6. **[docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md](pipeline/CHAPTER_PRODUCTION_STANDARD.md)** ← Canonical production standard (Learner State Reconstruction, Story Arc, Climax, Causal Animation Physics)
7. [docs/pipeline/01_COGNITIVE_STAGES.md](pipeline/01_COGNITIVE_STAGES.md)
8. [docs/pipeline/02_PRODUCTION_LIFECYCLE.md](pipeline/02_PRODUCTION_LIFECYCLE.md)
9. [docs/pipeline/03_QA_VERIFICATION.md](pipeline/03_QA_VERIFICATION.md)

### B. Repository Evolution / Documentation Change
Active chain:
1. Universal Boot Chain
2. [docs/protocols/GOVERNANCE_AND_AMENDMENTS.md](protocols/GOVERNANCE_AND_AMENDMENTS.md)
3. [docs/protocols/DOCUMENTATION_EVOLUTION.md](protocols/DOCUMENTATION_EVOLUTION.md)
4. The target document(s) being modified

### C. Architecture Work & Runtime Fixes
Active chain:
1. Universal Boot Chain
2. [docs/architecture/PLATFORM_ENGINE.md](architecture/PLATFORM_ENGINE.md)
3. [docs/architecture/CANVAS_NAVIGATION.md](architecture/CANVAS_NAVIGATION.md)
4. Affected source files as implementation evidence

### D. Chapter QA Audit
Active chain:
1. Universal Boot Chain
2. [docs/pipeline/03_QA_VERIFICATION.md](pipeline/03_QA_VERIFICATION.md)
3. [docs/pedagogy/PEDAGOGICAL_SYSTEM.md](pedagogy/PEDAGOGICAL_SYSTEM.md)
4. Affected chapter source files as implementation evidence
