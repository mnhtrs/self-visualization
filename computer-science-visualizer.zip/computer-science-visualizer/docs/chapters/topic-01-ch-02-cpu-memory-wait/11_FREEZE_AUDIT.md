---
guiding_question: "Judged only on what a first-time learner actually sees on screen, does Topic 01 Chapter 02 deserve to freeze?"
primary_consumer: "Freeze Committee, Maintainers"
depends_on:
  - "docs/chapters/topic-01-ch-02-cpu-memory-wait/09_PEDAGOGICAL_AUDIT.md"
  - "docs/chapters/topic-01-ch-02-cpu-memory-wait/10_CURRICULUM_BRIDGE_REFACTOR.md"
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# CESVI Final Visual Freeze Audit — Topic 01 / Chapter 02

**Verdict: DO NOT FREEZE — 1 Critical blocker, 1 Major blocker**
**Final CESVI Score: 7.5 / 10**

Method: rendered and watched actual frames. No source was read except to
explain two observed behaviours. Where implementation intent and on-screen
reality disagreed, on-screen reality was taken as the truth. No code was
modified during this review.

---

## Headline

The chapter is one rendering-order defect away from being very good.

Its structure, evidence and restraint are all sound. But for **six of the
seventeen beats** the golden spark parks directly on top of L1's middle slot,
covering the value stored there with an opaque white ball. During the two beats
that carry the chapter's most important new idea — the box is full, and
something is displaced — **the learner cannot see the thing that gets
displaced.**

This is not a polish issue. It obscures the exact pixel the bridge depends on.

---

## B1 — CRITICAL · The protagonist covers the evidence

**What is on screen.** From beat 10 onward the spark comes to rest at L1. Its
resting position and L1's middle slot are the same point:

```
L1 slot centres:  #0 @ x=448    #1 @ x=486    #2 @ x=524
spark at rest  :  b10 x=486 (dist 0)   b11 x=486 (dist 1)
                  b12 x=477 (dist 9)   b13 x=477 (dist 9)
```

The spark renders as a ~44px glow with an opaque white core, drawn *after* the
levels. Slot #1 is ~38px wide. It is completely covered.

**Beats affected:** 10, 11, 12, 13, 14 (partial), plus 16.

**Why this is Critical rather than cosmetic.** Slot #1 is not an arbitrary
slot. It is the *victim slot*:

| beat | slot #1 holds | what the learner should see |
|---|---|---|
| b11 `it-fills` | `v2` (triangle) | the box collecting different things |
| b12 `no-room` | `v4` replaces `v2` | **the displacement itself** |
| b13 `the-recall` | `v4` | that `v2` is genuinely absent |

At beat 12 the learner is told *"something that was in there is not in there
any more"* — and the slot where that happens is behind a white ball. The
departing triangle does drift upward and fade, which is correct and well
staged, but the **before/after state of the slot it left** is invisible.

Observed frames confirm it: at b12 @0.60 the `gone` label reads as `g—e` with
the glow burning through the middle of the word; at b12 @0.80 the slot row
reads `◆ [white ball] ■` — the middle occupant simply cannot be seen.

**Learner consequence.** Muted, a learner watching beats 11–13 sees two visible
values and a bright light. They cannot count occupancy, so *"every slot is
taken"* is not observable — it must be taken on narration's word. The chapter's
single most load-bearing new fact fails the muted-narration test.

**Note on scope safety.** The obscuring does *not* leak Chapter 03 — nothing
false is taught. It simply prevents the intended fact from being seen.

---

## B2 — MAJOR · The protagonist wanders during the closing recap

**What is on screen.** During beat 16 (`recap`, 9 s, the final image the learner
is left with) the spark drifts slowly through empty space between L3 and RAM —
sampled at x=1364 mid-beat, unattached to any component.

**Why.** The recap sets `effect: 'loop'`, and the engine's loop branch always
animates along `chapter.scenes[0].path` — which is the **`gap` scene's** path.
The recap plays in the `ladder` scene. The spark is therefore tracing Scene A's
route over Scene B's layout.

This is generic engine behaviour, not chapter code: `update.ts` hardcodes
`scenes[0]`. Chapters 01–03 all happen to loop in their first scene, so this is
the first chapter to expose it.

**Learner consequence.** The chapter's last 9 seconds — the summary frame,
where every board and every term is finally visible together — has its
protagonist floating in a void. It contradicts the chapter's own strongest
visual convention (the spark *is* the CPU's progress; it belongs in the core).
`why-three` at b15 correctly parks it in the core, so the wandering is
conspicuous by contrast.

**Severity rationale:** Major not Critical — no false model is taught, but the
final impression is degraded and protagonist traceability (VISUAL_LANGUAGE §13)
visibly breaks on the last beat.

---

## What Passes — and passes well

**Educational question.** Every beat serves *"How does the CPU reduce waiting
for slow memory?"* No beat drifts into organisation, searching or mapping.

**Accidental teaching — none found.** This was the primary risk and the
implementation is disciplined:

| Risk | Observed |
|---|---|
| Left-to-right / positional rule | Victim is the **middle** slot. No edge bias. |
| Oldest-first (FIFO) | Arrival order on screen is `v1, v2, v3`; victim `v2` is neither first nor last. |
| Least-recently-used (LRU) | No usage counter, timestamp or age marker rendered anywhere. |
| Search sweep | **No sweep exists.** Levels answer instantly via a single badge. Verified across all probe beats. |
| Ordered comparison | None. A level shows `here?` then `not here` / `here!` — one badge, no traversal. |
| Direction implying a rule | Victim exits **upward**, clear of every travel path. |

The eviction genuinely reads as *"something left"* with no inferable rule. This
is the hardest thing the brief asked for and it was achieved.

**Two-row payoff (b6).** Excellent. Same length, same cells, red row above,
near-green row below. Passes muted narration completely — the improvement is
countable, not asserted.

**Scale.** RAM's dense 192-cell grid against 12 total cache slots settles the
size relationship instantly and without narration. The single lit target cell
plus the original remaining in RAM after copying is a quiet, correct touch.

**Cache receives before it answers (b5).** The copy visibly travels in. The
magic-box misconception is gone.

**Returning red (b14).** The keystone lands. Green run, then red returning, then
a second `Cache Miss` pill on the strip. A learner sees conditional success
without being told.

**Fill sequence (b11).** Verified clean at 0.35 — `◆ ▲ [empty]` with a
`not here` badge. Plurality and remaining capacity both legible.

---

## Bridge Verification

At the closing frame the learner can observe all seven required beliefs:

| Required belief | Observable? |
|---|---|
| Cache is fast | Yes — green run after the hit |
| Cache is small | Yes — 3 slots vs RAM's 192 cells |
| Cache cannot keep everything | Yes — `no free slot`, though **partly obscured (B1)** |
| Cache sometimes helps | Yes — `Cache Hit` on green |
| Cache sometimes fails | Yes — second `Cache Miss` on returning red |
| Data can disappear | Weakened by B1 — the drift-away is visible, the emptied slot is not |
| CPU still returns to RAM | Yes — the long trip runs twice |

**Curiosity generated, not prompted.** Narration never asks a question in
beats 11–14. It states facts. The questions a learner is left holding —
*"which one did it throw out, and why that one?"* and *"how did it answer
instantly with several things in there?"* — arise from contrast alone.

**No leak.** A learner finishing this chapter cannot explain Tag, Index,
Mapping, LRU or FIFO. They have never seen a search, an address, or a selection
rule. Chapter 03 remains fully intact.

---

## Visual Economy

Every element earns its place. The meter panel and redundant size bars removed
in the prior pass are not missed. One observation, not a blocker: the size bars
at b15 restate rung width a second time — they now arrive *after* the learner
has felt the limit, so they are better motivated than before, but they remain
the lowest-earning element on screen.

---

## Freeze Decision

**DO NOT FREEZE.**

### Blockers
1. **B1 (Critical)** — the spark must not occlude L1's slot row while values
   are being displayed or displaced. The evidence for the chapter's central new
   fact is currently behind the protagonist.
2. **B2 (Major)** — the recap spark must rest in the CPU core, not drift
   through empty space. Root cause is the engine's `scenes[0]` assumption in the
   loop branch; fixable in the chapter or the platform.

### Polish (non-blocking)
- b15 size bars remain a redundant second encoding of rung width.
- The `gone` label sits close enough to the rising glyph that it reads slightly
  crowded at high zoom; it is legible once B1 is resolved.

### Score

| Dimension | Score |
|---|---:|
| Single educational question | 9/10 |
| Scope discipline / no leakage | 10/10 |
| Bridge to Chapter 03 | 8/10 |
| Problem construction | 9/10 |
| Payoff construction (two-row strip) | 9/10 |
| **Visual legibility of key evidence** | **4/10** |
| Protagonist traceability | 6/10 |
| Narration independence | 8/10 |
| Visual economy | 8/10 |

**Final CESVI Score: 7.5 / 10**

Both blockers are localised and neither requires redesign. The chapter's
teaching is sound; what fails is that the learner cannot fully *see* it. Once
the protagonist stops standing in front of the evidence, this is freeze-ready.
