---
chapter_id: "topic-01-computer-architecture--ch-02-cpu-memory-wait"
guiding_question: "What working memory and execution state was recorded during Topic 01 Chapter 02 production?"
chapter_version: "1.0.0"
status: "FROZEN"
frozen_date: "2026-07-28"
all_phases_completed: true
checkpoint_id: "ch02-freeze-v1.0.0"
---

# AGENT MEMORY — T01/Ch-02 CPU Memory Wait

> **⚠ FROZEN — Do not modify this chapter without an explicit owner directive.**
> Reopen only for: factual error, implementation bug, architecture violation, or mandatory platform migration.

---

## Phase Completion Record

| Phase | Name | Status |
|---|---|---|
| 1 | Journey Definition | ✅ DONE |
| 2 | Pipeline Design | ✅ DONE |
| 3 | Pipeline Validation | ✅ DONE |
| 4 | Story Architecture | ✅ DONE |
| 5 | Scene Design & Layout Derivation | ✅ DONE |
| 6 | Narration & Voice | ✅ DONE |
| 7 | Self Review & QA Check | ✅ DONE |
| 8 | Audit & Release Freeze | ✅ DONE |
| 9 | Production Closure | ✅ DONE |
| X | Documentation Evolution | ✅ DONE |

---

## Mental Model Transformation

- **Before:** "Memory is instant; slowness means the CPU isn't fast enough."
- **After:** "CPU is dramatically faster than RAM; cache exists as a close fast layer so the CPU checks it first and reaches RAM only when it must."
- **Central Question:** How does the CPU avoid waiting for memory?

---

## Finalized Decisions (immutable)

- **Protagonist:** Golden execution spark (`cpu.color: #fb923c`) — the CPU's forward progress.
- **Colors:** `cpu: #fb923c`, `ram: #a78bfa`; cache layer introduced with same palette.
- **Antagonist:** Memory latency expressed as physical distance on a single horizontal axis.
- **Layout:** All coordinates derived from named layout primitives (Layout Derivation Law).
- **Scope:** Chapter shows cache answering "here / not here" only — the *how* is Deferred Internal.

---

## Scope Boundary (Deferred Internal → Ch-03)

Not taught, not hinted:
> How a cache level determines whether it holds a requested value, and what it discards to make room.

Absent by design: address decomposition, tag, index, offset, cache line, mapping, associativity, replacement policy, write-through/back, dirty bit, prefetch. No hardware capacities or nanosecond figures.

---

## Artifacts

- [x] `00_JOURNEY_DEFINITION.md` — v1.0.0, Released
- [x] `01_delta.json` — schema-validated
- [x] `02_topology.json` — schema-validated
- [x] `03_trace.json` — schema-validated
- [x] `04_storyboard.json` — schema-validated
- [x] `05_journey_blueprint.json` — schema-validated
- [x] `06_LAYOUT_PROOF.md` — layout verified
- [x] `07_QA_AUDIT.md` — all gates PASS
- [x] `08_PHASE_X_REPORT.md` — 4 lessons generalized
- [x] `09_PEDAGOGICAL_AUDIT.md`
- [x] `10_CURRICULUM_BRIDGE_REFACTOR.md`
- [x] `11_FREEZE_AUDIT.md`

Gate scripts: `scripts/smoke-topic01-ch02.ts`, `scripts/scope-gate-topic01-ch02.ts`, `scripts/layout-proof-topic01-ch02.ts` — **absent from tree** (debt #5 in PROJECT_STATE). Numbers on record in `07_QA_AUDIT.md`.

---

## Phase X Lessons Generalized (→ permanent doctrine)

- **L1 — Single Source for Quantities:** Narration quantities must derive from the same data the renderer draws → `PEDAGOGICAL_SYSTEM §4.5`
- **L2 — Affirmative State Derivation:** Problem badges must derive from affirmative predicates, not `!state` negations → `PEDAGOGICAL_SYSTEM §4.6`
- **L3 — Derived Container Extent:** Container size must derive from its content + named padding → `PLATFORM_ENGINE §2.4`
- **L4 — Evidence Board Persistence:** Accumulative panels draw their empty state from scene entry → `PLATFORM_ENGINE §2.5`

---

## Downstream Launchpad (Ch-03 entry state)

The learner exits holding: *"The CPU checks the nearest level first; a level either has the value or it does not."* The camera must enter the cache interior — not start a new lesson.

Carry-over payload: protagonist spark, `cpu #fb923c`, `cache #22d3ee`, `ram #a78bfa`, value glyphs `◆ ▲ ■` resident in L1/L2/L3, ladder axis + rung sizes unchanged.
