---
guiding_question: "What reusable production lessons did Topic 01 Chapter 02 generalize back into repository documentation?"
primary_consumer: "Maintainers, AI Agents"
depends_on:
  - "docs/protocols/DOCUMENTATION_EVOLUTION.md"
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# Phase X — Documentation Evolution Report

**Chapter:** `topic-01-computer-architecture--ch-02-cpu-memory-wait` v1.0.0
**Protocol:** `docs/protocols/DOCUMENTATION_EVOLUTION.md` §2

---

## 1. Lesson Identification

Four recurring patterns emerged that are **not** specific to caching:

* **L1 — Narration and rendered data can silently disagree.** Defect D1: a beat
  said "four blocks" while the board drew six. Both were "correct" in isolation;
  only reading them together exposed the contradiction. Any chapter whose
  narration quotes a count that a renderer also draws carries this risk.
* **L2 — Negation is the wrong way to derive a state badge.** Defect D2: deriving
  "stalled" as `!working` made the CPU look stalled during beats that were merely
  explaining. Absence of activity is not evidence of a problem state.
* **L3 — A panel height typed as a literal drifts from its contents.** Defect D6:
  a hand-typed panel height silently violated the breathing minimum once rows
  were added. Container sizes must be derived from what they contain.
* **L4 — Evidence boards must exist before they hold evidence.** Defect D5: a
  measurement panel that appears only when its first bar is drawn creates a dead
  band and hides from the learner that a comparison is coming.

## 2. Pre-Amendment Lookup Gate

Checked before proposing anything (§2.2):

* `VISUAL_LANGUAGE.md` §2.2 mandates derivable geometry but says nothing about
  **container sizes being derived from contents** (L3) — not contradicted, not
  covered.
* `VISUAL_LANGUAGE.md` §4 separates structure from state, which **implies** L4
  but had no operational rule stating that a structure must be drawn before its
  state exists.
* `PEDAGOGICAL_SYSTEM.md` §4 has no rule covering L1 or L2.
* No existing document is contradicted by any proposed addition.

## 3. Generalization (domain-agnostic form)

| # | Chapter-specific lesson | Generalized rule |
|---|---|---|
| L1 | "Six blocks" must match `SLOTS` | **Single Source for Quantities.** If narration states a quantity that a renderer also draws, both must read the same declared data. A quantity may not be typed independently in prose and in code. |
| L2 | `stalled` ≠ `!working` | **Affirmative State Derivation.** A visual state that makes an accusation about the system (stalled, failed, congested, dropped) must be derived from an affirmative predicate in the story data, never as the negation of another state. |
| L3 | `METER.h` derived from its rows | **Derived Container Extent.** A container's size is derived from the content it must hold plus named padding. This extends the Layout Derivation Law from positions to extents. |
| L4 | Empty tracks from beat 8 | **Evidence Board Persistence.** A panel that accumulates evidence must be drawn in its empty state from the moment the learner enters the scene that will fill it. |

## 4. Binding Forward Pointers — Amendments Applied

Per `GOVERNANCE_AND_AMENDMENTS.md` §4, these are **Minor** additions (new
operational rules, no principle changed, no downstream artifact invalidated):

* `docs/pedagogy/PEDAGOGICAL_SYSTEM.md` → **v1.3.0**
  * New §4.5 *Single Source for Quantities* (L1).
  * New §4.6 *Affirmative State Derivation* (L2).
  * New §5 review gate: *Quantity Agreement Gate*.
* `docs/architecture/PLATFORM_ENGINE.md` → **v1.1.0**
  * New §2.4 *Derived Container Extent* (L3).
  * New §2.5 *Evidence Board Persistence* (L4).

Both amended documents now carry binding pointers back to this report.

## 5. Tooling Contributed to the Platform

This chapter closed a repo-wide gap rather than only its own: `npm run smoke`
was previously registered nowhere (`PROJECT_STATE` §4 recorded it as `N/A`). The
script now exists and runs three reusable gate patterns:

| Script | Reusable pattern |
|---|---|
| `scripts/smoke-topic01-ch02.ts` | Headless playthrough on a stub canvas: beat/path integrity, non-finite coordinate detection, an N×M scrub matrix stepped backwards, determinism sampling. |
| `scripts/scope-gate-topic01-ch02.ts` | Scans only learner-facing strings for out-of-scope terminology, and asserts the **first beat** at which each term may be spoken — making `NARRATIVE_FRAMING` §13 executable instead of reviewable. |
| `scripts/layout-proof-topic01-ch02.ts` | Emits the layout proof table and exits non-zero on any clearance regression. |

**Recommendation for a future platform pass:** generalize these three into
`scripts/` helpers parameterized by chapter id, so every chapter inherits them.
Logged as a suggestion only — not executed here, since `PROJECT_STATE` §3 limits
this task to chapter-level work.

## 6. Debt Register Update

* **Resolved:** `PROJECT_STATE` §4 "Smoke Suite: N/A (not registered)" — now
  registered and passing.
* **Unchanged:** Chapter 01 layout audit debt; State-Predictive Verification
  runtime debt (`PHILOSOPHY` §5.4) remains platform-wide and unimplemented — this
  chapter, like its predecessors, is observational and does not gate progression
  on learner prediction.
