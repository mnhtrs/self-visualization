---
guiding_question: "Has Topic 01 Chapter 02 satisfied every mandatory quality gate required for release and freeze?"
primary_consumer: "QA Auditors, Maintainers, AI Agents"
depends_on:
  - "docs/pipeline/03_QA_VERIFICATION.md"
  - "docs/pedagogy/PEDAGOGICAL_SYSTEM.md"
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# QA Verification Audit — Topic 01 / Chapter 02

**Chapter:** `topic-01-computer-architecture--ch-02-cpu-memory-wait`
**Result:** PASS · **Version:** 1.0.0

Gates are quoted from `docs/pipeline/03_QA_VERIFICATION.md`. Every claim below is
backed by an executable check (`npm run smoke`) or a named artifact — not by
assertion.

---

## Gate 1 — Pedagogical & Scope Alignment

- [x] **1.1 Target Mental Model.** Exactly one central question ("How does the
  CPU avoid waiting for memory?") and one transformation, declared in
  `00_JOURNEY_DEFINITION.md` §1 and `01_delta.json`.
- [x] **1.2 No Unlearning.** No analogy is used at all: the chapter shows the
  literal components on a literal distance axis. Everything stated — cache holds
  *copies*, levels are checked in order, closer is smaller and quicker — remains
  true when internals are taught next.
- [x] **1.3 Black Box Boundary.** One Deferred Internal is declared in
  `00_JOURNEY_DEFINITION.md` §5: *how a level determines whether it holds a
  value, and what it discards to make room.* Levels answer only "here" / "not
  here"; no mechanism for that answer is implied or hinted.
- [x] **Scope boundary enforced executably.**
  `scripts/scope-gate-topic01-ch02.ts` scans **102** learner-facing strings for
  all 12 forbidden terms (tag, index, offset, cache line, mapping,
  associativity, replacement policy, write-through, write-back, dirty bit,
  prefetch, eviction) plus capacities and nanosecond figures. **0 hits.**
- [x] **No repetition of Chapter 01.** The same gate rejects re-explanation of
  program loading, SSD → RAM, the instruction cycle, the program counter and the
  GPU. **0 hits.** SSD and GPU do not appear on canvas at all — they take no part
  in this conflict (`PEDAGOGICAL_SYSTEM` §2.2, visual economy).

## Gate 2 — Storytelling & Narration

- [x] **2.1 Observation Before Terminology.** Verified by assertion, not review.
  The gate script asserts the first spoken occurrence of every term:

  | Term | First spoken | What the learner has already watched |
  |---|---|---|
  | Cache | beat 7 | the short out-and-back trip, in that same beat |
  | L1 / L2 / L3 | beat 9 | the three rungs revealed in beat 8 |
  | Cache Miss | beat 12 | the full level walk + long haul (beats 10–11) |
  | Cache Hit | beat 13 | L1 answering immediately, in that beat |

  On canvas the same law holds independently: the near box is drawn
  **unlabelled** in beat 6 and receives its name only in beat 7; the level name
  labels render only from beat 9; each verdict pill fades in partway through its
  own beat, after its trip has completed.
- [x] **2.2 Bilingual Naturalness.** All 16 beats carry EN + VI in spoken
  register ("Count them." / "Đếm thử đi."). Smoke asserts no beat is missing
  either language. Component names stay locked to English per
  `NARRATIVE_FRAMING` §15.
- [x] **2.3 Single Focus.** One mutation per beat. The two atomic chunks — the
  three-level walk (b10) and the copy-back (b12) — are sequenced internally by
  `PROBE_BEATS` / `COPY_DROPS` windows so their sub-steps are observed one at a
  time (`PHILOSOPHY` §5.2 Atomic Cognitive Chunking).

## Gate 3 — Visual & Layout Integrity

- [x] **3.1 Layout Derivation Law.** `06_LAYOUT_PROOF.md` — **23 clearances, 0
  failures**, all computed from named primitives. A grep for coordinate literals
  outside `metrics.ts` returns none. Pill widths come from `measureText`, so they
  fit in both EN and VI.
- [x] **3.2 Connection Identity.** Each hop is its own drawn segment. Before the
  cache exists the road is a single link; afterwards the same space reads as two
  distinct links, and the far link (L3 → RAM) is painted in RAM's colour to mark
  it as a different kind of trip before any words say so.
- [x] **3.3 Protagonist Traceability.** One protagonist across all 16 beats: the
  golden spark, which *is* the CPU's forward progress — when it leaves the core
  to fetch a value, the core goes visibly dark, so the stall is watched rather
  than narrated. Seam positions are pinned in `assemble.ts` (`gap` → cache box,
  `ladder` → CPU rung). Smoke asserts a finite spark position on **5,113**
  forward frames and across an **80-point scrub matrix** stepped backwards.

## Gate 4 — Execution & Automated Test Pass

- [x] **4.1 Build Check.** `npm run build` — zero errors, zero warnings.
- [x] **4.2 Smoke Suite Check.** `npm run smoke` — now a **registered script**
  (repo-wide status was `N/A — smoke script not registered` before this
  chapter). It runs three gates: playthrough + determinism, scope boundary, and
  the layout proof. All pass.
- [x] **4.3 Phase X Evolution.** Executed — see `08_PHASE_X_REPORT.md`.

---

## Defects Found During Production & Resolved

Found by rendering real frames headlessly and by the proof table. None were
visible from reading the source alone.

| # | Defect | Resolution |
|---|---|---|
| D1 | Narration said "Four blocks of work" while the strip counted **6**. A learner counting along would have caught the chapter contradicting itself. | Line corrected to "Six blocks of work, fifteen of standing still", matching the `SLOTS` array exactly. |
| D2 | The stall badge appeared on beats that were merely *explaining* (e.g. "why three levels?"), accusing the core of stalling during exposition. | Added explicit `cpuStalled` / `coreStalledLadder` predicates — "stalled" is now asserted by the story data, never inferred as "not working". |
| D3 | CPU work-tick dots were drawn on top of the core square. | `CPU_TICK.rowY` derived as `CPU_CORE.half + BREATH + r`, making the collision impossible by construction. |
| D4 | Meter captions were drawn over the bars, obscuring the length comparison that *is* the chapter's central evidence. | Captions moved into their own derived column (`METER.labelCol`) to the left of the bar track. |
| D5 | Scene B had a dead band — the meter panel did not exist until beat 12. | Empty tracks are drawn from beat 8: structure first, state later (`VISUAL_LANGUAGE` §4). |
| D6 | `METER.h` was a hand-typed `132`, leaving the second row only 6 px against the floor (min `BREATH` = 8). Caught by proof row B7. | Panel height derived from the content it must contain. |

---

## Success Criterion Check

> A complete beginner should finish able to answer *"Why doesn't the CPU read
> directly from RAM every single time?"* in their own words.

The chapter never states the answer as a definition. It is available to the
learner as three things they counted or measured themselves: the strip (6
working vs 15 waiting blocks), the two meter bars (a long red trip vs a short
green one on the same ruler), and the ladder (each box further out and larger).
The closing beat restates only what those three boards already showed.
