---
guiding_question: "What single mental-model transformation does Topic 01 Chapter 02 complete, and within what boundaries?"
primary_consumer: "Content Authors, QA Auditors, AI Agents"
depends_on:
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
  - "docs/curriculum/CURRICULUM_GRAPH.md"
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# Journey Definition — Topic 01 / Chapter 02

**Chapter ID:** `topic-01-computer-architecture--ch-02-cpu-memory-wait`
**Slug:** `how-cpu-avoids-waiting-for-memory`
**Status:** Released
**Version:** 1.0.0

---

## 0. Phase-Local Activation Record

* **Governing documents reopened for this phase:**
  `AI_CHARTER.md`, `DOCUMENTATION_EVOLUTION.md`, `PROJECT_STATE.md`,
  `CURRICULUM_GRAPH.md`, `PHILOSOPHY.md`, `VISUAL_LANGUAGE.md`,
  `NARRATIVE_FRAMING.md`, `PEDAGOGICAL_SYSTEM.md`, `01_COGNITIVE_STAGES.md`,
  `02_PRODUCTION_LIFECYCLE.md`, `03_QA_VERIFICATION.md`.
* **Active Constraint List:**
  1. One chapter completes exactly ONE mental-model transformation (`PEDAGOGICAL_SYSTEM` §3).
  2. Terminology may appear only after the phenomenon that motivates it (`NARRATIVE_FRAMING` §13).
  3. Every drawn coordinate must be derived from a named primitive (`VISUAL_LANGUAGE` §2.2).
  4. Distinct logical paths must be drawn as distinct lines (`VISUAL_LANGUAGE` §2.1).
  5. One persistent visual protagonist, continuously traceable (`VISUAL_LANGUAGE` §13).
  6. Deferred Internals must be declared, never explained by false analogy (`PHILOSOPHY` §5.3).
  7. No unlearning: everything taught must stay true in the next chapter (`PHILOSOPHY` §3).
* **Decision provenance:** Constraints 1–7 are determined by the documents.
  The problem-driven beat order (problem → felt cost → idea → naming) is an owner
  directive for this chapter, consistent with §3/§4 of `NARRATIVE_FRAMING`.

---

## 1. Target Mental-Model Transformation

* **Before:** The CPU reads what it needs straight from RAM and RAM answers at
  once; slowness means "the CPU isn't fast enough". Cache, if the word is known
  at all, is imagined as extra memory that makes the machine hold more.
* **After:** The CPU is dramatically faster than RAM, so every RAM trip leaves it
  with nothing to execute — and that waiting, not the CPU's speed, dominates the
  time. Cache is a small fast layer holding *copies* of values that also live in
  RAM, placed close to the CPU so repeated requests skip the trip. The CPU
  therefore always checks cache first and reaches RAM only when it must.
* **Transformation:** *"Memory is instant"* → *"Memory is far, and cache exists to
  shorten the distance."*

---

## 2. Central Educational Question

**How does the CPU avoid waiting for memory?**

Every scene, beat and drawn element in this chapter answers that one question.

---

## 3. Narrative Threading & Continuity Contract

* **Upstream Endpoint State (Ch-01 exit):** The program sits in RAM and the CPU
  has run it instruction by instruction through the Basic Instruction Cycle.
* **Contextual Carry-Over:** `protagonist_entity`: the golden execution spark;
  `cpu.color`: `#fb923c`; `ram.color`: `#a78bfa`; both components keep their
  Chapter 01 identity and are re-entered, never re-explained.
* **Explicitly NOT repeated:** program loading, SSD → RAM transfer, CPU overview,
  GPU overview, the Basic Instruction Cycle. The GPU and SSD do not appear at all
  — they take no part in this conflict (`PEDAGOGICAL_SYSTEM` §2.2, visual economy).
* **Downstream Launchpad:** The learner ends holding "the CPU checks the nearest
  level first, and a level either has the value or it does not." *How* a level
  answers that question is untouched and is the next chapter's subject.

---

## 4. Protagonist & Conflict

* **Protagonist:** the CPU — carried on screen by the golden spark, which *is* the
  CPU's forward progress. When the spark leaves the core to fetch a value, the
  core goes visibly dark: the stall is not narrated, it is watched.
* **Antagonist:** memory latency — expressed as physical distance on a single
  horizontal axis that both scenes share.
* **Conflict:** the CPU wants to continue executing; RAM cannot answer fast enough.

---

## 5. Strict Scope Boundary

Declared **Deferred Internal** (`PHILOSOPHY` §5.3) — visible as behaviour, with
mechanism deliberately withheld for the next chapter:

> *How a cache level determines whether it holds a requested value, and what it
> discards to make room.*

The chapter shows a level answering "here" or "not here" and never suggests a
mechanism for that answer, so nothing taught here must later be unlearned.

Absent by design — **no** address decomposition, tag, index, offset, cache line,
mapping, associativity, replacement policy, write-through, write-back, dirty bit,
or prefetch. Also excluded: hardware capacities and nanosecond figures — size and
distance are conveyed only in relative visual terms.

---

## 6. Success Criterion

A complete beginner can answer, in their own words:

> *"Why doesn't the CPU read directly from RAM every single time?"*

and independently conclude that cache is not extra memory, but a fast temporary
layer that exists so the CPU spends less time waiting.
