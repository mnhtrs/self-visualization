---
guiding_question: "Does Topic 01 Chapter 02 leave the learner holding the mental models Chapter 03 silently assumes — and asking the questions Chapter 03 answers?"
primary_consumer: "Curriculum Review Board, Chapter Authors, Maintainers"
depends_on:
  - "docs/curriculum/CURRICULUM_GRAPH.md"
  - "docs/constitution/PHILOSOPHY.md"
  - "docs/chapters/topic-01-ch-02-cpu-memory-wait/09_PEDAGOGICAL_AUDIT.md"
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# CESVI Curriculum Review Board — Ch-02 → Ch-03 Bridge Refactor

**Chapter:** `topic-01-computer-architecture--ch-02-cpu-memory-wait` v1.0.0
**Downstream:** Ch-03 (cache internals: line, address, tag, index, offset, set,
mapping, associativity, replacement, FIFO, LRU)

**Bridge Readiness (current): 3 / 10 — Chapter 02 is not yet a prerequisite for
Chapter 03. It is a prerequisite for a chapter that does not exist.**

---

## Executive Finding

Chapter 02 teaches that cache **works**. Chapter 03 exists because cache is
**constrained**. Nothing in Chapter 02 shows a constraint.

The root cause is a single verifiable fact:

```
renderers.ts:495   const isValue = holdsValue && i === 0
```

**Exactly one value exists in the entire chapter.** It is fetched once, copied
into three boxes, and requested again. Every cache level is drawn with 3–5 slots
and never holds more than one.

Everything Chapter 03 teaches is a consequence of scarcity — of a small box that
cannot hold everything, must choose what to discard, and must locate one entry
among many. A learner leaving Chapter 02 has watched a box with **four empty
slots** answer a question. Their honest conclusion is not *"how does it choose?"*
but *"there is plenty of room."*

Chapter 03 would open by solving problems the learner has never seen.

A second, compounding defect: `RUNGS` gives RAM `w: 244` against L3's `w: 216`.
On screen **RAM is 13% larger than L3.** The chapter's own size language —
established explicitly by the b14 size bars — tells the learner that cache and
RAM are roughly the same size. The single most important quantitative fact
underpinning all of Chapter 03 is not merely absent; it is contradicted.

---

## 1. Missing Prerequisites

Every item Chapter 03 silently assumes. Status verified against source.

| # | Prerequisite Ch-03 assumes | Ch-02 status | Ch-03 concepts it gates |
|---|---|---|---|
| **P1** | Cache is **dramatically smaller** than RAM | **Contradicted.** RAM 244 vs L3 216. Size bars compare caches only to each other, never to RAM | Replacement, capacity, why sets exist |
| **P2** | Cache **fills up** | **Absent.** One value, four spare slots, always | FIFO, LRU, Replacement |
| **P3** | When full, something already inside **must leave** | **Absent.** Unthinkable in current chapter | Replacement — the entire concept |
| **P4** | Which entry is discarded **has consequences** | **Absent.** Nothing is ever discarded | Why FIFO ≠ LRU; why policy is a real decision |
| **P5** | Cache holds **many distinct** values, not "the data" | **Absent.** One anonymous glowing slot | Tag, Index, Set — all presuppose plurality |
| **P6** | A value lives at a **particular place** in RAM | **Weak.** The spark travels to RAM-in-general; no specific cell is targeted | Memory Address |
| **P7** | Answering "is it here?" among many entries is **not obviously free** | **Absent.** One entry, instant verdict, no tension | Index, Tag, Mapping, Associativity |
| **P8** | Cache holds **copies**; RAM keeps the original | **Stated, not shown.** Narration says "copy"; the Scene-A box is drawn empty while answering (Audit C2) | Write policy, coherence, why a tag identifies a *copy* |
| **P9** | Cache helps **only sometimes** — a hit is not guaranteed | **Actively mistaught.** After b13 every access is fast forever | Hit rate, why policy quality matters |
| P10 | Data moves in **chunks**, not single values | Absent | Cache Line, Offset |

**P9 is not only a bridge failure — it is a No-Unlearning violation.**
`PHILOSOPHY` §3 forbids models that must later be discarded. Chapter 02 currently
ends on *"fetch once, fast forever."* Chapter 03 would have to demolish that
before it could build anything. This must be fixed irrespective of Chapter 03.

**Deliberately excluded: P10.** Chunked transfer cannot be shown without the
learner reasoning about *why* neighbours arrive together — which is spatial
locality, i.e. the justification for Cache Line. Ch-03 opens more strongly if
the learner meets the line as a genuine surprise. **Recommend leaving P10 to
Ch-03.** Prefer omission (§10, Minimal Teaching).

---

## 2. Scene Audit

### Scene A — `gap` (b0–b7)

1. **Mental model built:** the CPU is fast, RAM is far, waiting dominates, a
   near box shortens the trip.
2. **Sufficient for Ch-03?** **As motivation, yes. As substrate, no.** It
   establishes *why cache exists* — Ch-03's premise — but nothing about what
   cache *is made of*.
3. **If Ch-03 started here:** "Cache is a magic near-box." The learner has no
   notion that it contains multiple identifiable things. Tag and Index would be
   solutions to an unfelt problem.
4. **Removable inside Ch-02?** Partially. Scene A must stay lean — it owns the
   problem. The only prerequisite work it should carry is **P8** (the box visibly
   receives a copy), which is already a Critical blocker (Audit C2) for
   independent reasons. Everything else belongs to Scene B.

### Scene B — `ladder` (b8–b15)

1. **Mental model built:** the gap is a ladder of levels; a miss walks out to
   RAM and copies back; a repeat hit is nearly free; smaller = quicker.
2. **Sufficient for Ch-03?** **No.** It is a complete account of a cache that
   never fills, never chooses, and never fails twice.
3. **If Ch-03 started here, the learner's confusions:**
   - *"Why would anything ever be thrown out? The boxes are mostly empty."*
   - *"Why does the cache need to identify which value it holds? It holds the value."*
   - *"Why is finding it a problem? It just knows."*
   - *"Why would a cache ever miss after the program has warmed up?"*
   Chapter 03's first four topics land on all four confusions simultaneously.
4. **Removable inside Ch-02?** **Yes — and cheaply.** Every one of P1–P9 is a
   consequence of letting the program keep running for a few seconds longer than
   it currently does. No new mechanism, no new terminology, no new instrument.

---

## 3. Exact Timeline Modifications

Current: 16 beats / 79.8 s. Proposed: **17 beats / 81.6 s (+2.3%).**

New material is funded by compressions already recommended in `09_PEDAGOGICAL_AUDIT.md`.
This is a **reallocation, not an expansion.**

### Budget

| Change | Δ ms |
|---|---:|
| Merge b3 into b4 (redundant single-step demo) | −2 800 |
| Merge b8 + b9 (structure tour + naming) | −4 200 |
| Compress b10 + b11 (re-proving a settled premise) | −3 400 |
| Shorten b14 (lowest-earning beat, second-longest) | −2 600 |
| Split b12 mechanism from terminology (Audit M3) | +400 |
| **NEW-1** the cache fills | +5 000 |
| **NEW-2** no room left | +5 200 |
| **NEW-3** the cost of what was lost | +4 200 |
| **Net** | **+1 800** |

---

### MOD-1 · Scene A · b6 — the box receives a copy

- **Location:** beat 6 `the-idea`, Scene A.
- **Change:** as the box materialises, a copy of the value travels from RAM into
  one slot. One slot fills. Nothing else changes.
- **Reason:** P8. The narration *already says* "what if **a copy** of them were
  kept in a small box right here" — the visual currently shows an empty
  container answering correctly. This is Audit **C2**, blocking on its own merit;
  it is also the first prerequisite brick.
- **Learner takeaway:** "The box gets things from RAM and keeps them. RAM still
  has them too."
- **Ch-03 gate opened:** the notion of a *copy with an origin* — without which
  a tag identifies nothing.

### MOD-2 · Scene B · b8 (merged) — RAM is not the same size as the caches

- **Location:** the merged ladder-reveal beat.
- **Change:** two things. (a) `RUNGS` — RAM's rendered capacity must dwarf the
  cache rungs. Preferred implementation is **not** a wider box (that breaks the
  ladder layout and orientation) but a **dense multi-row cell grid** inside the
  existing RAM box against the cache rungs' 3–5 countable slots. (b) The b14
  size bars must be re-scoped so they never imply RAM belongs to the same size
  family.
- **Reason:** P1. Currently the chapter's own visual language states that RAM
  and L3 are comparably sized.
- **Learner takeaway:** "The near boxes hold a handful of things. RAM holds an
  enormous number."
- **Ch-03 gate opened:** everything. Scarcity is the premise of Ch-03.

### MOD-3 · Scene B · b10 (compressed) — the request targets a *particular* cell

- **Location:** the compressed walk/haul beat.
- **Change:** when the request reaches RAM, **one specific cell** lights and
  releases the value, rather than RAM-in-general glowing.
- **Reason:** P6. Costs zero seconds — it is a change of emphasis, not duration.
- **Learner takeaway:** "The value isn't just 'in RAM' — it's at one particular
  spot, and the CPU went to that spot."
- **Ch-03 gate opened:** Memory Address becomes the name for something already
  observed, not a new abstraction.

### MOD-4 · Scene B · split b12 — the copy-back owns its own beat

- **Location:** b12 `copy-back` splits into `copy-back` + the Miss reveal moving
  to open the hit beat.
- **Reason:** Audit **M3**. The causal core of the chapter (values are *copied
  in on the way home*) currently shares a beat with a terminology reveal. For
  the bridge this matters doubly: the copy-in mechanic is **how the cache gets
  its contents**, which is the precondition for it ever becoming full.
- **Learner takeaway:** "Things end up in the boxes because they passed through."
- **Ch-03 gate opened:** P2 becomes thinkable — contents accumulate.

### MOD-5 · Scene B · **NEW-1** — the cache fills *(insert after the hit)*

- **Location:** immediately after b13 `the-hit`. **Not an appendix** — it is the
  program simply continuing to run.
- **Change:** the program asks for two or three *different* values. Each is a
  miss, each takes the long trip, each is copied back. The learner watches L1's
  slots occupy one after another, with visibly **distinct** tiles (different
  glyph/colour — **no addresses, no labels, no numbering**).
- **Reason:** P5, P2, P7, and it repairs P9.
- **Learner takeaway:** "The box is collecting different things. It's getting
  full. And it still answers instantly even with several things in it."
- **Ch-03 gate opened:** plurality (Tag/Index/Set presuppose it) and the quiet
  tension behind Index/Mapping — *many entries, instant answer, no visible
  search*. **Critically: no search mechanism is depicted.** The question arises
  from contrast, not from watching an algorithm — so Ch-03 has nothing to undo.

### MOD-6 · Scene B · **NEW-2** — no room left *(insert)*

- **Location:** directly after NEW-1.
- **Change:** one more value is fetched. Every slot in the nearest box is
  occupied. The new value settles in, and one entry that was there is gone.
- **Reason:** P3 — the load-bearing prerequisite of Chapter 03.
- **Narration (draft, EN):** *"One more. But look at the nearest box — every
  slot is taken. The new value still has to go somewhere, so something that was
  in there is not in there any more."*
  **(VI):** *"Thêm một giá trị nữa. Nhưng nhìn cái hộp gần nhất xem — chỗ nào
  cũng đã có rồi. Giá trị mới vẫn phải nằm đâu đó, nên một thứ đang ở trong đó
  giờ không còn ở đó nữa."*
- **Learner takeaway:** "It can't keep everything. Getting something new means
  losing something old."
- **Constraint — how the eviction must be staged.** The **fact** of displacement
  is shown; the **selection** is not explained and must not be inferable. No
  ordering cue may be emphasised — the departing entry must not read as the
  oldest (→ FIFO), the least-touched (→ LRU), or the leftmost (→ a positional
  rule). Narration states the fact and moves on. It **never asks "which one?"** —
  per the brief, the question must form in the learner, not on screen.

### MOD-7 · Scene B · **NEW-3** — the cost of what was lost *(insert)*

- **Location:** directly after NEW-2. **This is the bridge's keystone.**
- **Change:** the program asks again for the value that was displaced. The
  nearest box does not have it. The long trip runs again — and on the strip, a
  run of red blocks reappears after a stretch of green.
- **Reason:** P4 and P9 together. This is the only beat that makes the
  *replacement decision* matter rather than merely exist.
- **Narration (draft, EN):** *"And now the program wants that first value back.
  It isn't there any more. The long trip runs again — and the waiting comes
  back with it."*
  **(VI):** *"Và giờ chương trình lại cần đúng giá trị đầu tiên đó. Nó không còn
  ở đó nữa. Chuyến đi dài lại chạy lại — và cái sự chờ đợi cũng quay lại theo."*
- **Learner takeaway:** "Cache doesn't always help. Whether it helps depends on
  whether the right thing happens to still be in there."
- **Ch-03 gate opened:** the learner now owns, unprompted, *"then which thing it
  throws away really matters — how does it pick?"* That is FIFO/LRU/Replacement,
  wanted before it is named.
- **Dependency:** this beat's evidence requires Audit **M1** (one instrument —
  the strip carried into Scene B). On the meter, "waiting came back" is a third
  bar. On the strip, it is red returning after green: a single glance.

### MOD-8 · Scene B · b15 — recap absorbs the limit

- **Location:** final beat. **No new beat, no epilogue.**
- **Change:** the closing line already states the correct model
  (*"cache is not extra memory — it is a fast layer…"*). Extend by one clause
  acknowledging the boundary the learner has now watched: it holds only a little,
  so it cannot hold everything it has seen.
- **Reason:** the recap must summarise what was observed. After MOD-5→7 the
  current text would understate the chapter.
- **Learner takeaway:** the exit model is *"a small fast layer of copies that
  usually helps"* — which is true, and needs no unlearning.

---

## 4. Scene Insertion / Removal Plan

**Scenes inserted: 0. Scenes removed: 0.**

All new material lands as **beats inside Scene B**, on the existing ladder, with
the existing instrument and the existing protagonist. This is deliberate:

- A new scene would demand a new bbox, a new seam and fresh orientation cost.
- The pressure story is only legible *on the ladder*, because the whole point is
  that a full L1 forces the long trip the ladder already taught.
- `VISUAL_LANGUAGE` §17 (orientation) and §7 (attentional economy) both favour
  extending a scene the learner has already parsed.

| Action | Target | Net beats |
|---|---|---:|
| Merge | b3 → b4 | −1 |
| Merge | b8 + b9 | −1 |
| Merge | b10 + b11 | −1 |
| Split | b12 (mechanism / term) | +1 |
| **Insert** | NEW-1 the cache fills | +1 |
| **Insert** | NEW-2 no room left | +1 |
| **Insert** | NEW-3 the cost of what was lost | +1 |
| | **16 → 17** | **+1** |

**Removed outright:** the b14 size bars (redundant second encoding of rung
width, Audit m2) and the Scene-B meter panel (Audit M1). The refactor **deletes
one entire visual language** while adding three beats.

---

## 5. Narrative Justification

The three inserted beats are not an educational appendix. They are **the program
continuing to run.**

Chapter 02's story is: a processor tries to keep working; distance keeps
stopping it; a near box shortens the distance. The current chapter stops the
clock the instant the box succeeds once — the equivalent of ending a story on
the first small victory.

What a program actually does next is ask for other things. That is not new
subject matter; it is the same protagonist, the same objective, the same
antagonist, one honest step further:

> Distance stops the CPU → a near box helps → **but the near box is small, so it
> cannot help with everything** → so *what it chooses to keep* is now the thing
> that decides whether the CPU waits.

That last clause is Chapter 03's entire agenda, and the learner arrives at it by
watching the same spark on the same ladder. No seam, no gear change.

The protagonist is unchanged (the spark = forward progress; red returns to the
strip exactly when the core goes dark again). The antagonist is unchanged —
distance — now revealed to be *conditionally* defeated rather than defeated.
Nothing is introduced that the story did not require.

---

## 6. Pedagogical Impact

| Prerequisite | Before | After | Delivered by |
|---|---|---|---|
| P1 cache ≪ RAM | Contradicted | Established | MOD-2 |
| P2 cache fills | Absent | Watched | MOD-5 |
| P3 something must leave | Absent | Watched | MOD-6 |
| P4 the choice matters | Absent | **Felt as cost** | MOD-7 |
| P5 many distinct values | Absent | Established | MOD-5 |
| P6 values have a location | Weak | Established | MOD-3 |
| P7 lookup is not obviously free | Absent | Tension created | MOD-5 |
| P8 copies, not originals | Stated only | Shown | MOD-1 |
| P9 cache helps *sometimes* | **Mistaught** | Corrected | MOD-7 |
| P10 chunked transfer | Absent | **Deliberately left to Ch-03** | — |

**9 of 10 prerequisites established. 3 new beats. Net +1.8 s. One visual
language deleted.**

Secondary gain: the chapter stops teaching a falsehood (P9) that Chapter 03
would otherwise have had to demolish in its opening minutes.

---

## 7. Regression Analysis

**Does this weaken Chapter 02's educational question?**
No — it completes it. The question is *"How does the CPU reduce waiting for slow
memory?"* The honest answer is *"by keeping copies close, which works when the
needed value is still there."* The current chapter answers only the first half
and implies the reduction is total. MOD-5→7 do not introduce a second question;
they finish the first one. A chapter that shows only a mechanism's successes has
not explained the mechanism.

**Does it weaken pacing?**
No. Runtime moves 79.8 s → 81.6 s (+2.3%), funded by compressions the
pedagogical audit already required. Structurally pacing **improves**: the audit
found 44% of runtime on the problem versus 18% on the resolution. After the
refactor the second half carries consequence instead of re-proving a settled
premise (MOD-3 removes 3.4 s of exactly that).

**Does it raise cognitive load?**
Net **lower**, on three counts:
- One instrument instead of two (M1) removes a cross-scene memory comparison.
- No new terminology. Zero. The three new beats name nothing.
- Each new beat carries exactly one mutation: *fills* → *displaces* → *costs*.

The one genuine increase — several distinct tiles instead of one — is *inference
material*, not memory load. Nothing must be memorised; the slots are visible and
countable at all times.

**Does it weaken visual economy?**
No — it improves it. Deleted: the meter panel (whole visual language) and the
b14 size bars. Added: no new component types. The new beats reuse the existing
cache-slot rendering with more than one slot occupied.

**Does it risk teaching Chapter 03's material?** — the forbidden fix.
Checked term by term:

| Ch-03 concept | Risk | Control |
|---|---|---|
| Replacement | Learner sees displacement happen | Only the **fact**; selection never explained. Learner ends with a question, not a rule |
| FIFO / LRU | Learner infers a rule from the victim | **Binding staging constraint in MOD-6**: no ordering cue emphasised — not oldest, not least-used, not leftmost |
| Tag | Learner sees entries identified | Tiles are *distinguishable*, never *labelled*. No addresses, no names, no numbering |
| Index / Mapping / Set | Learner infers placement or search rules | **No search is ever depicted.** Answers stay instant. The question arises from *contrast* (many entries, instant answer), so there is no mechanism to unlearn |
| Fully Associative | Depicting a sweep would teach this | **Explicitly rejected** during design — an earlier candidate (slots lighting in sequence during a probe) was discarded for exactly this reason |
| Cache Line / Offset | Chunked transfer | **P10 deliberately excluded.** Single values only |
| Memory Address | One cell lighting in RAM | Shows *a value has a place*. No numbering, no decomposition |
| Hit / Miss | Already taught in Ch-02 | Unchanged; MOD-7 strengthens Miss by making it recur |

**No modification lets the learner partially understand any Chapter 03
mechanism.** Each opens a question and closes no answer.

---

## 8. Educational Test — Zero-Knowledge Learner

Learner: no CS background. Simulated at the **end of the refactored chapter**.

**Believes:** *"The thinking part is quick, but the things it needs sit far away
in a huge store. There are little boxes next to it that keep copies of things it
recently used, so it doesn't have to make the long trip every time. The little
boxes only hold a few things. When a new thing comes in and they're full,
something that was in there goes. And if the processor then wants that thing
again, it's back to the long trip."*

**Unprompted questions at the closing frame:**

1. *"The little box was full and something had to go — but how does it pick
   which one? It threw out the exact thing I needed next."* → **Replacement,
   FIFO, LRU**
2. *"There were four or five different things in there and it still answered
   straight away. How does it know which one it's holding without looking
   through them?"* → **Tag, Index, Set, Mapping**
3. *"Sometimes the box saves the trip and sometimes it doesn't. What decides
   that?"* → **Hit rate, associativity, policy**
4. *"It went to one exact spot in the big store. How does it know which spot?"*
   → **Memory Address**

**Verification against the brief.** Each question is a restatement of something
*watched*, never something *said*. Narration states facts only — "every slot is
taken", "it isn't there any more" — and never poses a question. Question 1 is
the learner's reaction to MOD-7's cost, not to any line of narration.

The learner understands **why each problem exists** and has **no idea how any of
them is solved.** That is the required exit state.

---

## 9. Final Readiness Assessment

| | Score |
|---|---:|
| Bridge readiness — current | **3 / 10** |
| Bridge readiness — after refactor | **9 / 10** |

Withheld point: P10 (chunked transfer) is left unbuilt by deliberate choice, so
Cache Line will arrive in Chapter 03 without a prepared foothold. The board
judges this correct — spatial locality is Chapter 03's strongest opening surprise
and pre-empting it would spend the reveal for no gain.

**Is Chapter 02 a complete and natural bridge into Chapter 03 after this
refactor? — Yes.**

The refactored chapter ends where Chapter 03 must begin: with a small box that
demonstrably cannot hold everything, visibly discards things, and has just cost
the processor real time by discarding the wrong one. Chapter 03's first sentence
now answers a question the learner is already holding.

**Blocking dependencies.** This plan assumes the Critical items from
`09_PEDAGOGICAL_AUDIT.md`, which are load-bearing here and not merely adjacent:

- **C2** (copy visible in the cache) **is** prerequisite P8 — MOD-1.
- **M1** (single instrument) is what makes MOD-7 legible in one glance; on the
  meter the keystone beat loses most of its force.
- **C1** (payoff measured on the strip) establishes the green run that MOD-7's
  returning red is measured against. **Without C1, MOD-7 has no baseline to
  contradict and the keystone beat does not land.**

**Recommended execution order:** C2 → C1 → M1 → MOD-2/3/4 → MOD-5/6/7 → MOD-8.

**Freeze recommendation: DO NOT FREEZE** until the above lands. Chapter 02 is
currently a good standalone chapter and a poor prerequisite; three beats and one
deletion make it both.
