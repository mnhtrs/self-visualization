---
guiding_question: "Does every scene, beat, narration and animation in Topic 01 Chapter 02 serve one educational question — and does the learner's mental model actually improve?"
primary_consumer: "Review Board, Maintainers, Chapter Authors"
depends_on:
  - "docs/constitution/NARRATIVE_FRAMING.md"
  - "docs/pedagogy/PEDAGOGICAL_SYSTEM.md"
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# CESVI Pedagogical Review Board — Topic 01 / Chapter 02

**Chapter:** `topic-01-computer-architecture--ch-02-cpu-memory-wait` v1.0.0
**Verdict:** **DO NOT FREEZE** — 2 Critical blockers
**Overall CESVI Score:** **6.5 / 10**

This audit judges educational quality only. Implementation correctness, build
health and layout compliance are already green (`07_QA_AUDIT.md`) and are **not**
credited here. A chapter can pass every mechanical gate and still fail to teach.

---

## Executive Finding

The chapter builds an excellent instrument and then refuses to use it at the
moment that matters.

Phase 1–2 spends **25.8 s (32% of the chapter)** teaching the learner to read one
board: green = working, red = waiting, `6 working / 15 waiting`. That board is
the chapter's entire epistemic contract — *"don't take my word for it, count."*

Then Phase 3 — the payoff, where cache is revealed — writes **zero** cells to
that board. Verified:

```
beat 6 (the-idea   ) cells 21->21  added=0
beat 7 (short-trip ) cells 21->21  added=0
```

While the narration says *"The processor barely stopped,"* the board still reads
**6 working / 15 waiting**. The chapter makes its central claim and its own
instrument does not corroborate it.

Everything else in this report is secondary to that.

---

## 1. Educational Question

**One question? Yes.** "How does the CPU avoid waiting for memory?" is stated
once, never competes with a second question, and the scope gate proves no
out-of-scope terminology leaks in (102 strings, 0 hits).

**Does every scene advance it? Mostly.** No scene becomes a lesson about another
topic. There is no cache-internals drift, no bus lesson, no GPU cameo. On the
narrow definition of scope drift, the chapter is **clean**.

But there is a subtler drift: **budget drift**.

| Story function | Time | Share |
|---|---:|---:|
| Establishing the problem (Phase 1–2) | 25.8 s | 32% |
| Re-establishing the problem in Scene B (Phase 5, b10–b11) | 9.6 s | 12% |
| **Total spent on "the CPU waits"** | **35.4 s** | **44%** |
| Demonstrating the fix (Phase 3 + Phase 6) | 14.2 s | 18% |

The chapter is titled *"How does the CPU avoid waiting"* but spends **2.5× more
time on the waiting than on the avoiding.** The antagonist has better screen
time than the resolution.

---

## 2. Narrative Focus

| Element | Status | Notes |
|---|---|---|
| Protagonist | **Strong** | The spark *is* the CPU's progress. When it leaves, the core goes dark. Best decision in the chapter — the stall is watched, not narrated. |
| Antagonist | **Strong** | Latency rendered as literal distance on a fixed axis. Never anthropomorphised; RAM is explicitly "not being lazy." |
| Objective | **Clear** | Keep executing. |
| Conflict | **Clear** | Established by b2, felt by b4. |
| **Payoff** | **WEAK — see C1** | The resolution is asserted by narration and shown as a shorter *journey*, but never measured as a shorter *cost* on the instrument the learner was trained on. |

**Where it becomes unclear:** beat 7, at ~55% elapsed. The learner sees the spark
travel a short distance to a box and return. They are told this means less
waiting. The board below — the thing they were explicitly told to trust over the
narrator's word — is frozen and still says the CPU wasted 15 blocks.

---

## 3. Scene Audit

### Scene A — `gap` (beats 0–7, 34.6 s)

| Question | Answer |
|---|---|
| What question does it answer? | "Why is the CPU waiting at all, and how much does it cost?" |
| Only that? | Beats 0–5, yes — tightly. Beats 6–7 attempt the *answer* and belong to a different question. |
| Unnecessary concepts? | No. |
| Delays too long? | **Yes, mildly.** 25.8 s of problem before the first hint of relief. |
| Can it be simplified? | **Yes.** b3 ("one-step") is largely redundant with b4, which re-shows the same cycle at higher volume. |

### Scene B — `ladder` (beats 8–15, 45.2 s)

| Question | Answer |
|---|---|
| What question does it answer? | "What is actually in the space between CPU and RAM, and what changes on a repeat request?" |
| Only that? | **No.** b10–b11 re-run the Phase 1 problem in full (walk → nobody has it → long haul → stall). |
| Unnecessary concepts? | b14 ("why three levels") answers a question the learner has not necessarily asked. |
| Delays too long? | The first *positive* outcome in this scene arrives at b13 — 26 s into the scene. |
| Can it be simplified? | **Yes** — see M3. |

---

## 4. Beat Audit

Ideas per beat. **Bold** = more than one important concept.

| # | id | New concept | Visual evidence | Muted-narration test | Ideas |
|---|---|---|---|---|---|
| 0 | running | work has a rhythm | core lit, cells fill green | Pass | 1 |
| 1 | needs-value | a request must travel | spark leaves, core darkens | Pass | 1 |
| 2 | the-wait | distance costs idle time | dwell at RAM, red cells pile | **Strong pass** | 1 |
| 3 | one-step | return buys only one step | one green cell | Pass | 1 |
| 4 | again-and-again | the pattern dominates | 11 cells, 10 red | Pass | 1 |
| 5 | read-the-board | the cost is countable | ratio bar resolves | Pass | 1 |
| 6 | the-idea | keep a copy nearby | box fades in — **but empty** | **Fail — see C2** | 1 |
| 7 | short-trip | a near answer is cheap | short trip; **board frozen** | **Fail — see C1** | 2 |
| 8 | the-ladder | the gap has structure | rungs reveal, sizes differ | Pass | 2 |
| 9 | closer-quicker | closer=quicker, further=bigger + names | name labels | Partial | 2 |
| 10 | the-walk | levels are checked in order | probe badges in sequence | **Strong pass** | 1 |
| 11 | long-haul | a miss costs the full trip | dwell at RAM, meter row 0 | Pass | 1 |
| 12 | copy-back | **the value is copied on the way home** + term | copy rings drop | Pass | **2** |
| 13 | the-hit | a repeat is nearly free | short trip, short bar | **Strong pass** | 2 |
| 14 | why-three | small=fast tradeoff | size bars | Weak | 1 |
| 15 | recap | — | full board | Pass | 0 |

**Split recommended — b12.** It carries the chapter's single most important
*mechanism* (the value is **copied** into each level, which is the entire reason
the next request is fast) in the same beat as a terminology reveal
("Cache Miss"). The mechanism deserves its own beat; the term can ride the next.

---

## 5. Progressive Disclosure

Required: experience → observation → pattern → explanation → terminology → details.

**Terminology timing is exemplary and machine-enforced** (Cache b7, L1/L2/L3 b9,
Miss b12, Hit b13 — each after its referent). Credit where due: the gate script
asserts this rather than claiming it.

**But there is one genuine ordering violation, and it is the deepest problem in
the chapter.**

The name "Cache" arrives at b7 attached to a box that has **never been shown to
contain anything**. Verified: `LEVELS_FILLED_AT_BEAT` only has keys for beats
8–15; in Scene A the box is drawn with empty slots throughout.

So the actual learner sequence is:

```
experience (empty box answers instantly)  ← this is MAGIC, not observation
        ↓
terminology ("this is called Cache")
        ↓
… 5 beats later …
explanation (b12: oh — things get COPIED into it)
```

Terminology is correctly placed relative to *behaviour* but **precedes the
mechanism that makes the behaviour possible.** The learner names a miracle, then
retro-fits an explanation onto it five beats later. That is the exact shape
`NARRATIVE_FRAMING` §13 exists to prevent.

---

## 6. Cognitive Load

**Learners must remember instead of infer — two places:**

1. **Across the scene seam.** The strip (Scene A) is abandoned and replaced by
   the meter (Scene B). Both measure wasted time; neither shares a visual
   language with the other. The learner must hold "6 vs 15 blocks" in memory to
   compare it with a bar chart that uses different units, different colours-in-
   context, and a different axis. **Two instruments for one variable.**
2. **b7 → b12.** The learner must remember an unexplained instant answer for
   ~24 s until the copy mechanic finally justifies it.

**Animation before understanding:** b6 fades in a box before the learner knows
what it is for — this is *correct* and well-handled (the question pill in b5
motivates it first). No issue.

---

## 7. Visual Evidence (muted-narration test)

Applied to every beat. **13 of 16 pass.** Failures:

- **b7 (Critical).** Muted, the learner sees: a spark goes a short way and comes
  back; a static board that says the CPU wasted 15 blocks. Reasonable silent
  inference: *"a new box appeared; nothing measurable changed."* The intended
  idea is carried **entirely by narration** — which makes this animation
  decorative at the exact moment it needed to be evidential.
- **b6 (Major).** Muted, an empty box appears. Nothing indicates it holds copies.
  The narration says *"a copy of them were kept"* — the visual shows an empty
  container. **Narration and visual actively disagree.**
- **b14 (Minor).** Size bars are drawn at the same width as their boxes, so they
  restate what the box outlines already said. Muted, it adds nothing new.

---

## 8. Spotlight Audit

Moments attention leaves the central question:

| Where | Drift | Severity |
|---|---|---|
| b8–b9 | Two beats (9.4 s) establishing ladder structure and naming levels. Structural tour, not question-advancing. | Minor |
| b10–b11 | 9.6 s re-proving "the CPU stalls" — already proven in Phase 1. | Major |
| b14 | 6.4 s justifying a design tradeoff. Answers *"why is it built this way"*, not *"how does the CPU avoid waiting."* Legitimate curriculum content, but it is the **weakest-earning 8% of runtime**. | Minor |

**Bringing focus back:** merge b8+b9; compress b10–b11; make b14 the shortest
beat in the chapter rather than the second longest.

---

## 9. Aha Moment

**Current state: the chapter has two half-strength ahas and therefore no single
memorable one.**

- **b7** should be the aha ("oh — it doesn't have to go far"). Undercut by C1:
  no measurement.
- **b13** should be the aha ("oh — the second time is free"). Undercut by
  landing on the *meter*, an instrument introduced only 5 beats earlier, rather
  than on the strip the learner spent 26 s internalising.

The realisation is split across two moments on two instruments. A learner
finishing this chapter remembers *facts* (there are three levels; hit and miss
are words) more strongly than the one *shift*.

### The aha this chapter should be built around

> **The same stretch of time. The same board. Run it again with the box —
> and the red almost disappears.**

One instrument, two runs, one glance. That is the chapter in a single image, and
it is currently not on screen at any point.

---

## 10. Minimal Teaching Principle

Removable without reducing understanding:

| Candidate | Verdict |
|---|---|
| b3 ("one-step") | **Merge into b4.** It shows one green cell; b4 shows the same pattern three times. |
| b8 + b9 | **Merge.** One beat can reveal the rungs and name them. |
| b14 size bars | **Remove the bars, keep the beat's narration.** The rung widths already encode size; the bars are a redundant second encoding. |
| **The entire meter panel (Scene B)** | **Remove — replace with the strip.** See M2. This deletes a whole visual language from the chapter. |
| CPU work-tick dots | **Keep.** Redundant with the strip, but they keep the cost legible while the eye is on the chip. |

---

# Issues

### C1 — The payoff is never measured on the chapter's own instrument
**Severity: CRITICAL**

**Problem.** Phase 3 writes 0 cells to the strip. During b7 the board reads
`6 working / 15 waiting` while narration claims the processor barely stopped.

**Why it hurts learning.** The chapter's contract with the learner is *"count it
yourself."* At the decisive moment it withdraws that contract and asks for
trust instead. A learner who does what the chapter trained them to do — look at
the board — sees **no improvement**. This does not merely weaken the payoff; it
mildly discredits the instrument retroactively.

**Recommended change.** In b7, draw a **second row on the same strip**: same
length, same cells, same colours — the same stretch of time re-run with the box
in place. It fills mostly green (≈3 wait cells instead of 15). No new visual
language, no new concept, one new row.

**Expected benefit.** Converts the chapter's central claim from an assertion
into something the learner counts. Creates the missing single aha.

---

### C2 — Cache answers correctly while visibly empty
**Severity: CRITICAL**

**Problem.** In Scene A the cache box is rendered with empty slots for its whole
life. It is asked for a value and instantly supplies one it was never shown to
receive. The copy mechanic that would justify this does not appear until b12.

**Why it hurts learning.** This teaches, for five beats, exactly the
misconception the chapter exists to destroy. `01_delta.json` declares the target
model as *"cache is not extra memory... everything in it is a copy of something
that also lives in RAM."* The animation instead shows a magic box that simply
knows things. Worse, the learner is asked to accept the **name** "Cache" for that
magic (see §5). The b12 correction arrives after the wrong model has had 24 s to
set.

**Recommended change.** Minimal and already licensed by the existing script —
b6's narration *already says* "what if **a copy** of them were kept in a small
box right here." Make the visual honour the words: during b6, show a copy of the
value travelling from RAM into the box (or simply appearing in a slot as the box
materialises). One slot fills. Nothing else changes.

**Expected benefit.** The learner meets cache as *a place copies are kept* — the
correct model — from first contact. Removes an unlearning step and repairs the
terminology ordering violation at no cost in runtime.

---

### M1 — Two instruments measure one variable
**Severity: MAJOR**

**Problem.** The strip (Scene A) and the meter (Scene B) both quantify wasted
time, in different visual languages. The strip is abandoned at the seam.

**Why it hurts learning.** Doubles instrument-learning cost and forces
cross-scene memory comparison instead of direct visual inference. It also splits
the aha (§9).

**Recommended change.** **Delete the meter.** Carry the two-row strip from C1
into Scene B and let the miss trip fill row 1 and the hit trip fill row 2. One
instrument, whole chapter. This *removes* code and a visual language.

**Expected benefit.** Single mental instrument; the b13 hit lands on a board the
learner has trusted since 8 s in; satisfies §10 by deletion.

---

### M2 — Scene B re-runs the problem at full length
**Severity: MAJOR**

**Problem.** b10–b11 (9.6 s) re-establish "the CPU stalls waiting for RAM."

**Why it hurts learning.** The learner already accepted this at b2. Re-proving a
settled premise spends the learner's attention on confirmation rather than
transformation, and delays the scene's first positive outcome to 26 s.

**Recommended change.** Compress b10–b11 to a single beat. Keep the *sequential
probe* (that is genuinely new and is one of the chapter's best animations) and
cut the RAM dwell short — the cost of a RAM trip needs no re-proof.

**Expected benefit.** ~4 s returned; moves the hit (the scene's real content)
earlier; keeps the miss as setup rather than repeat.

---

### M3 — b12 carries mechanism and terminology together
**Severity: MAJOR**

**Problem.** The copy-back — the causal core of the whole chapter — shares a beat
with the "Cache Miss" reveal.

**Why it hurts learning.** Violates one-beat-one-mutation
(`PEDAGOGICAL_SYSTEM` §4.3) at the beat that can least afford divided attention.

**Recommended change.** Give the copy-back its own beat; let "Cache Miss" open
b13 as the label for what was just watched, immediately before "Cache Hit"
contrasts with it. The two terms then arrive **adjacent**, which strengthens both.

**Expected benefit.** The chapter's key mechanism gets undivided attention; the
hit/miss contrast becomes a single crisp comparison.

---

### m1 — Problem/solution runtime imbalance
**Severity: MINOR** · 44% of runtime on waiting vs 18% on avoiding.
**Change:** absorb the savings from M2, b3-merge and b8/b9-merge into the payoff.

### m2 — b14 is the second-longest beat and the lowest-earning
**Severity: MINOR** · **Change:** shorten to ~4 s; drop the redundant size bars.

### m3 — b5's question is posed and immediately answered
**Severity: MINOR** · "Does it have to go that far every time?" is the natural
prediction gate. Platform-wide State-Predictive Verification is deferred debt, so
this is not actionable now — but log b5 as the designated gate for when it lands.

---

# Zero-Knowledge Learner Simulation

Learner: no CS background. Knows a computer has parts. Nothing else.

### Scene A, beats 0–5 — the problem

- **Believes before:** "The computer is fast. Fast means everything inside is
  fast."
- **Misconception corrected:** *Fast processor ≠ fast everything.* Parts have
  different speeds, and distance between them costs real time.
- **New model formed:** "The thinking part is quick, but the stuff it needs is
  far away, and it just stands there while it waits."
- **Can they infer it unaided?** **Yes.** Core visibly darkens; red blocks pile
  up; they count 6 vs 15 themselves. **Strongest passage in the chapter.**

### Scene A, beats 6–7 — the idea

- **Believes before:** "Waiting is unavoidable — that's just how far it is."
- **Misconception intended to be corrected:** *You don't have to make the trip
  every time.*
- **What the learner actually infers:** "A small box appeared near the chip and
  it answers fast. …Why does it have the answer? Where did that come from?"
- **New model formed:** ⚠️ **"There is a magic box that knows things."**
- **Does the scene fail?** **YES.** Two ways: the box supplies a value it was
  never given (C2), and the board that quantifies everything shows no change
  (C1). The learner's model improves in *shape* (something near = good) but is
  **causally hollow** — and they were handed the word "Cache" for it.

### Scene B, beats 8–9 — the ladder

- **Believes before:** "There's a magic box between the chip and the memory."
- **Corrected:** *It isn't one box, it's a series, ordered by distance.*
- **New model:** "There are three boxes; nearer ones are smaller, further ones
  are bigger."
- **Infer unaided?** **Yes.** Size and distance are read directly off the
  geometry — the proof table guarantees each rung is larger and further. Clean.

### Scene B, beats 10–12 — the miss

- **Believes before:** "The boxes have the answers."
- **Corrected:** *Not always — the first time, nobody has it.* And crucially:
  *that's how things get into the boxes at all.*
- **New model:** "It asks each box in turn; if none has it, it goes all the way
  out — and on the way back it leaves a copy in each box."
- **Infer unaided?** **Mostly yes.** The probe sequence is excellent silent
  storytelling. The copy rings are legible but compete with the "Cache Miss"
  reveal (M3). **This is where C2's damage is repaired — 5 beats late.**

### Scene B, beat 13 — the hit

- **Believes before:** "Copies are in the boxes now."
- **Corrected:** *So the second time costs almost nothing.*
- **New model:** "Ask again → the nearest box has it → done. No long trip."
- **Infer unaided?** **Yes**, and the two bars make the contrast unmistakable.
  **Second-strongest passage.** Weakened only by landing on the newer instrument
  rather than the trusted one (M1).

### Scene B, beats 14–15 — sizes and recap

- **Believes before:** "Why not one big box, then?"
- **Corrected:** *Big and fast pull against each other.*
- **New model:** "Small = quick, big = slow, so they keep several."
- **Infer unaided?** **Weakly.** The size bars restate the boxes. The tradeoff is
  a *claim* the learner accepts on authority — it is the one place in the chapter
  where nothing is demonstrated. Acceptable (it is a design rationale, not a
  mechanism) but it should not be the second-longest beat.

### Exit state

Asked *"Why doesn't the CPU read directly from RAM every single time?"* the
simulated learner answers:

> *"Because RAM is far away and the processor just sits there waiting. So it
> keeps copies of stuff it used in little boxes right next to it, and checks
> those first."*

**That is a pass.** The target model is reached — but it is reached at **b12–b13**,
not at b7 where the chapter intends it, and the learner carries a magic-box
detour to get there.

---

# Verdict

## Overall CESVI Score: 6.5 / 10

| Dimension | Score | Note |
|---|---:|---|
| Single educational question | 9/10 | Genuinely disciplined; scope gate is exemplary |
| Protagonist / conflict | 9/10 | Spark-as-progress is the chapter's best idea |
| Problem construction | 9/10 | Countable, honest, self-verifying |
| **Payoff construction** | **3/10** | Unmeasured; carried by narration |
| **Causal completeness** | **4/10** | Cache works before it can work |
| Progressive disclosure | 6/10 | Term timing enforced, but names a mechanism-less box |
| Cognitive economy | 6/10 | Two instruments; problem re-run |
| Single aha | 4/10 | Split across two half-ahas |
| Visual evidence | 7/10 | 13/16 pass muted test; the 3 failures are the payoff beats |
| Craft & compliance | 9/10 | Not credited toward learning, noted for completeness |

The chapter is **well-built and under-taught**. Its problem half is close to
model CESVI work. Its solution half asserts what its problem half proved.

## Freeze Recommendation: **DO NOT FREEZE**

## Blockers before freeze

1. **C1** — measure the payoff on the strip (second row, b7). *Blocking.*
2. **C2** — put a copy in the cache before it answers (b6). *Blocking.*
3. **M1** — delete the meter; carry the strip into Scene B. *Blocking* — it is
   the mechanism by which C1's fix pays off in Scene B, and it removes rather
   than adds.
4. **M3** — split copy-back from the "Cache Miss" reveal. *Blocking.*
5. M2, m1, m2 — recommended in the same pass; not individually blocking.

## Note on the shape of these fixes

Every blocking recommendation **removes or reallocates**; none adds a concept.
Net effect if all are applied: one fewer visual language, one fewer misconception
to unlearn, roughly unchanged runtime, and one unmistakable aha where there are
currently two weak ones.
