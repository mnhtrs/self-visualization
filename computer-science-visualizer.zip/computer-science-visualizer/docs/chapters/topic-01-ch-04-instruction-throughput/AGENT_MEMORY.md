---
type: "chapter working memory"
guiding_question: "What working memory and execution state was recorded during Topic 01 Chapter 04 production?"
chapter: "topic-01-computer-architecture--ch-04-instruction-throughput"
slug: "how-cpu-runs-billions-per-second"
status: "production — gates green, ready for freeze review"
---

# AGENT_MEMORY — Topic 01 / Chapter 04

## Session Record

- **Phase 1 (Journey Definition):** DONE — `00_JOURNEY_DEFINITION.md`.
  One mental-model transformation: *"the CPU runs each instruction faster"*
  → *"every instruction still takes the same full five-station journey, but
  the CPU finishes one every tick because it never lets a station sit idle"*.
  Deferred Internals declared (hazards, stalls, misses mid-flight,
  contention, processes/threads/cores, coherence, superscalar/OoO — Topics
  02+). Owner constraints locked: exactly ONE climax, no Throughput /
  Latency text, no on-canvas questions, no concluding narration.
- **Phases 2–5 (Cognitive Planning):** DONE — `01_delta.json`,
  `02_topology.json`, `03_trace.json`, `04_storyboard.json`,
  `05_journey_blueprint.json` (schema-valid, storyboard = 18 beats).
- **Phases 4–7 (Implementation):** DONE —
  `src/content/topics/01-computer-architecture/04-instruction-throughput/`
  (metrics, layout, story, scenes, narration, renderers, assemble, meta,
  thumbnail). Full bilingual narration; silent beats use a non-breaking
  space.
- **Phase 7 (Self Review & QA):** DONE — gates authored and green:
  smoke (344), scope (48), layout proof (90); build PASS; headless
  Chromium playthrough verified all key moments with zero page errors.
- **Owner-directed Explanation Pass (2026-08-01):** value-glyph explanation
  (◆ ▲ ■ ● = data values) added at their first appearance in Topic 01
  (T01/Ch-02: beats `needs-value`, `the-ladder` — explanation only, nothing
  else touched). T01/Ch-04 now names the instruction kinds
  (LOAD/ADD/STORE/SUB/CMP) and the repetition reason in plain language
  (beats b1–b4, b8–b12); the climax (b13) remains the only silent beat.
  Storyboards re-synced (both chapters); gates re-green.
- **Slow-motion & real-speed pass (same day):** b5/b11/b17 name the
  observation speed (slow motion, ≈ 4 billion instructions per real second,
  ~1 billion per blink); horizon counter gained the caption
  "≈ 4 billion / real second" (EN/VI). Explanation-only; timeline/ticks/
  visuals/layout untouched; gates re-green (345 / 48 / 90).
- **Speed-ramp pass (same day, third round):** the horizon now accelerates
  visibly (slow → ramp → 25 ticks/s): counter spins, list scrolls, fetch
  trip races, CPU pulses at tick rate; caption tracks the stage; narration
  explains every tick still = one instruction (canon intact). Deterministic
  piecewise functions (horizonTickAt / horizonTickLen / horizonStage).
  Not a second climax — b13 remains the single realization; this is a
  speed illustration. Gates re-green (348 / 48 / 90).
- **Horizon protagonist fix (same day):** the golden spark now RUNS
  core → L1 → core at the accelerating tick rate via the new
  backward-compatible engine hook `runtime.loopPosition`; three
  instruction cards chase each other along the road. The epilogue moves
  in both stages; at speed the spark races with a light-ribbon trail.
  Canon intact (one instruction per tick; C-05); not a second climax.
  Gates re-green (348 / 48 / 90).

## Finalized Design Decisions

1. **The clock:** one tick = 1600 ms; the floor issues one instruction per
   tick; five stations; the first completion lands at tick 5. Beat
   durations are exact multiples of TICK so the tick grid aligns with
   renderer fractions.
2. **The golden (watched) instruction:** row 6 (the floor's first, marked)
   and row 19 (the climax, marked). It is the chapter's single protagonist
   (spark rides it); every other card renders at decayed weight.
3. **The climax (b13):** ticks 14–18, silent. The golden instruction
   crosses the whole floor in exactly five ticks while five instructions
   complete — its own completion is the fifth pop of the rhythm.
4. **The die scene (entry):** 5 completions at the remembered slow cadence
   (counter 0→5) — the "nothing unusual" phase. The floor's counter
   continues from 5.
5. **Scenes:** `entry` (whole world) → `floor` (the interior; reveal,
   ramp, city, climax, look-back, the one term) → `horizon` (the whole
   world running forever; single looping beat so the "Inside the CPU" tag
   never misfires).
6. **Terms:** station names spoken once at the floor reveal; "Pipeline"
   named once in b15 via the chapter's single term pill. No other terms.
7. **Gates:** `scripts/smoke-topic01-ch04.ts` (344), `scripts/scope-gate-topic01-ch04.ts` (48),
   `scripts/layout-proof-topic01-ch04.ts` (90); `package.json` smoke now
   runs all three.

## Next Actions

1. Owner review of the chapter and docs.
2. On approval: freeze (Phase 8) — mark docs/state/PROJECT_STATE.md and
   archive the release record in docs/state/CHANGELOG.md.
3. Phase X: generalize the three gates by chapter id (existing platform
   debt, logged in PROJECT_STATE §2).
