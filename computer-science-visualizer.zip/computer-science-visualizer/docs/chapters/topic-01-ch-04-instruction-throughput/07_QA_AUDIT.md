---
guiding_question: "Has Topic 01 Chapter 04 satisfied the mandatory quality gates for production, and how was it verified in a real browser?"
primary_consumer: "QA Auditors, Maintainers"
depends_on:
  - "docs/pipeline/03_QA_VERIFICATION.md"
  - "docs/pedagogy/PEDAGOGICAL_SYSTEM.md"
  - "docs/chapters/topic-01-ch-04-instruction-throughput/00_JOURNEY_DEFINITION.md"
---

# QA Audit — Topic 01 / Chapter 04

**Date:** 2026-08-01 · **Status:** PASS (production-ready, pre-freeze)

## 1 · Gate Results (executable)

| Gate | Script | Checks | Result |
| :--- | :--- | :--- | :--- |
| Build | `npm run build` | — | PASS (0 errors / 0 warnings) |
| Smoke | `scripts/smoke-topic01-ch04.ts` | 344 | PASS |
| Scope | `scripts/scope-gate-topic01-ch04.ts` | 48 | PASS |
| Layout proof | `scripts/layout-proof-topic01-ch04.ts` | 90 | PASS |
| **Total** | `npm run smoke` | **482** | **PASS** |

## 2 · Smoke Coverage (344 checks)

- **Playthrough integrity:** 18 beats × bilingual lines, scene membership,
  travel/rest bounds, active-entity existence, per-scene bbox/path/entities.
- **Story-table consistency (§4.5):** tick windows contiguous 1–30; the
  stream has 50 rows; marked rows 6 & 19; the golden instruction enters
  tick 14, completes tick 18, counter = 19 = the 5th pop of the climax
  window (rows 15→19 complete in order); counter continuity 5 → 31 →
  horizon; never more than 5 cards in flight; `floorFull` affirmative.
- **Determinism (§15):** full story grid sampled twice — byte-identical
  logs; bilingual captions; beat durations = ticks × TICK.
- **Storyboard ↔ narration sync:** `04_storyboard.json` mirrors
  `narration/beats.ts` beat-for-beat (ids + EN/VI lines).
- **Climax contract:** beat 13 is silent, exactly 5 ticks, covers ticks
  14–18, one completion per tick, ending with the golden instruction's own
  completion.

## 3 · Scope Coverage (48 checks)

- **Forbidden absent** (owner directive + AGENT_BOOT): Throughput, Latency,
  hazard, stall, bubble, superscalar, out-of-order, MESI/coherence, TLB,
  prefetch, write-through/write-back, dirty bit, multi-core, thread,
  process, scheduler, virtual memory, branch prediction, speculation,
  parallelism, dependency, contention, IPC — none appear in any
  learner-visible text (comments are stripped before scanning; the
  boundary list lives only in docs).
- **Pipeline is named once**, in b15, after the behaviour was fully
  observed (Knowledge Reveal §13) — the scope gate proves it never appears
  in any earlier beat.
- **No question/verdict pill machinery** — the owner forbids on-canvas
  questions and definitions; the only pill in the chapter is the single
  term pill.
- **Required present:** the five station names, the Pipeline term, TICK,
  STATIONS=5, the counter captions (EN/VI), the orientation chip (EN/VI),
  the watched-instruction machinery, `counterAt`, `inFlight`.

## 4 · Pedagogical Audit (against 00_JOURNEY_DEFINITION.md)

| Law | Verdict |
| :--- | :--- |
| One mental-model transformation | ✓ "the CPU runs each instruction faster" → "every instruction takes the same full journey, but one finishes every tick — the CPU stopped being empty" |
| Observation before explanation | ✓ the ramp, the overlap, the fill and the rhythm are all silent beats (b8–b11); the climax (b13) is silent; the single term lands in b15 |
| No unlearning | ✓ the Chapter-01 model holds at the macro level (completions are sequential); the die view shows completions, the floor reveals the interior — no contradiction |
| Protagonist continuity (§13) | ✓ the golden instruction (row 6, then row 19) is traceable at every second: die scale (spark), floor ramp (golden at F→D→E→M→W), head of the stream (b12), climax crossing (b13) |
| Auxiliary decay (§18) | ✓ auxiliary cards render at alpha 0.5, the watched card at 1.0 with a golden ring and ★ |
| Affirmative state (§4.6) | ✓ `floorFull` is an affirmative predicate; no problem-state badges exist |
| Deferred Internals (§5.3) | ✓ declared in 00_JOURNEY_DEFINITION §5 (hazards, stalls, misses mid-flight, contention, processes/threads/cores, coherence, superscalar/OoO — reserved for Topics 02+) |
| Single source of quantities (§4.5) | ✓ proven by the smoke gate |
| Transition causality (§14) | ✓ die→floor: the spark follows the instruction inside; floor→horizon: the machine keeps running and the camera steps back |

## 5 · Browser Verification (headless Chromium, 1400×850)

A live playthrough (18 beats, ~2 minutes) was driven in headless Chromium
with zero page errors. Pixel-level probes of the canvas confirmed:

- **Entry:** CPU, ladder with resident values, program list, counter
  0→5; the L1 fetch flash and the riding mini instruction card during b1.
- **Floor:** the five stations materialise; the golden instruction enters
  Fetch alone; a second card appears before the first finished; the floor
  fills; the counter pops once per tick from the first completion on.
- **Climax:** the golden card crosses F → D → M → W → exit, one station
  per tick, while the counter's green digit region grows and pops — the
  watched instruction's completion is the fifth pop of the window.
- **The-name:** the Pipeline term pill renders south of the floor.
- **Horizon:** the whole world runs forever — CPU pulsing, counter
  climbing, list streaming.
- **Vietnamese mode:** narration, captions and the orientation chip render
  correctly in VI.

## 6 · Residual Notes

- **Owner-directed Explanation Pass (2026-08-01):** the entry/ramp beats now
  carry brief plain-language lines naming the instruction kinds
  (LOAD/ADD/STORE/SUB/CMP) and the repetition reason, and the value glyphs
  are named at their first appearance in Topic 01 (T01/Ch-02, explanation
  only). The climax (b13) remains the chapter's only fully silent beat — the
  realisation stays the learner's own. Storyboards re-synced; gates re-green
  (344 / 48 / 90).
- **Slow-motion & real-speed pass (same day):** the chapter now names the
  observation speed explicitly — b5 (a real program needs billions of steps
  to draw one screen; we watch in slow motion; ≈ 4 billion instructions per
  second, ~1 billion per blink), b11 (rhythm = slowed down billions of
  times), b17 (real-speed figure in the closing line), and the horizon
  counter shows "≈ 4 billion / real second" (EN/VI). This closes the
  learner's "why does it look slow?" gap without touching the timeline.
  Gates re-green (345 / 48 / 90).
- **Speed-ramp pass (same day, third round):** the horizon epilogue now
  visibly accelerates — slow-motion pace → ramp → max speed (25 ticks/s on
  screen) — so the learner finally *feels* the machine's rate: the counter
  spins, the list scrolls, the fetch trip races, the CPU pulses at tick
  rate. Canon preserved (every tick still completes exactly one
  instruction; only the tick length changes — deterministic piecewise
  functions in story.ts). Not a second climax: the single realization
  remains b13; this is a speed illustration. Browser-verified: 0 pixel
  change per 400 ms in the slow stage vs 1.4–2.6k pixel change per 400 ms
  at speed. Gates re-green (348 / 48 / 90).
- **Horizon protagonist fix (same day):** the golden spark now RUNS
  core → L1 → core at the chapter's accelerating tick rate (new
  backward-compatible engine hook `runtime.loopPosition`), and three
  instruction cards chase each other along the road — the epilogue moves
  in BOTH stages (≈4.3k pixels/400 ms slow; previously 0), and at speed
  the spark visibly races with a light-ribbon trail while the counter
  spins and the list scrolls. Canon intact (one instruction per tick;
  C-05 preserved); not a second climax (the realization remains b13).
  Browser-verified; gates re-green (348 / 48 / 90).
- Determinism across user scrubbing is exact for all beat-driven state;
  the final horizon beat is the documented exception (its clock derives
  from `s.t`, the same pattern the earlier chapters use for looping
  protagonists).
