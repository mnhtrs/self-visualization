---
guiding_question: "Does every drawn rectangle of Topic 01 Chapter 04 derive from named metrics or container functions, and does every dock sit inside its scene bbox without collisions?"
primary_consumer: "QA Auditors, Layout Engineers"
depends_on:
  - "docs/pipeline/03_QA_VERIFICATION.md"
  - "src/content/topics/01-computer-architecture/04-instruction-throughput/scenes/metrics.ts"
  - "src/content/topics/01-computer-architecture/04-instruction-throughput/scenes/layout.ts"
---

# Layout Proof — Topic 01 / Chapter 04

**Executable gate:** `scripts/layout-proof-topic01-ch04.ts` — **90 checks, all PASS** (2026-08-01).

## 1 · Derivation Doctrine

Every drawn rectangle in the chapter derives from `scenes/metrics.ts`
(named primitives, the single home of bare numbers) or from
`scenes/layout.ts` (functions of container rects + measured text). No
inline coordinate literals exist outside `metrics.ts` — enforced by the
gate's source audit (§5 below).

## 2 · The Derived Layout System (summary table)

| Structure | Derivation chain |
| :--- | :--- |
| Entry list panel | `listPanelRect()` ← `LIST_PANEL` metrics + `LIST_ROWS_VISIBLE × LIST_ROW` (extent derives from content, PLATFORM_ENGINE §2.4) |
| Entry counter | `counterRect()` ← `COUNTER_PANEL` + RAM rung face |
| Floor panel | `PANEL` ← `STATION × STATIONS + STATION_GAP + PANEL_PAD` |
| Stations | `stationRect(i)` ← `PANEL + PANEL_PAD + i × (STATION + GAP)` |
| Cards | `cardAt(i)` ← `stationC(i) − CARD/2` (a card always fits its station — proven) |
| Connectors / lanes | `connector(i)`, `FETCH_LANE`, `EXIT_LANE`, `TRIP_LANE` ← station faces + `stationRowY()` |
| List dock | `LIST` ← `LIST_POS + LIST_H` (extent derives from `LIST_FLOOR_ROWS_VISIBLE`) |
| Counter dock | `COUNTER` ← `COUNTER_FLOOR` anchored to `PANEL.east` |
| Registers dock | `REG` ← `PANEL.east + BREATH × 6`, centred on the station row |
| L1 dock | `L1D` ← `stationC(3) − L1_DOCK/2`, below `PANEL.bottom + dy` |
| Proc dock | `procDockRect()` ← `LIST_POS + LIST_H` (never a literal) |
| Term pill dock | `termDock()` ← south of the L1 dock row (proven clear of L1D) |
| Scene bboxes | `bboxEntry/bboxFloor/bboxHorizon` ← content extents + `CLIP_INSET` |

## 3 · Containment & Disjointness (executable)

- Every rect finite (NaN/Infinity audit).
- All stations inside the panel; panel inside the floor bbox; every dock
  inside its scene bbox; rungs inside the entry bbox.
- Horizon bbox ⊇ entry bbox (same world, wider air).
- All five docks pairwise disjoint; all five stations pairwise disjoint;
  term pill dock south of the L1 dock.
- Connectors lie exactly on the station row.

## 4 · Source Audit

The gate strips comments and scans `layout.ts`, `story.ts`, both scene
files and both renderer files for bare coordinate object literals
(`{x: <number>, y: <number>}`) — **0 found**. `metrics.ts` is the single
allowed home of bare numbers.

## 5 · Single Source of Quantities

- `STATIONS = 5` — the number the narration speaks ("five stations").
- `TICK = 1600` — every floor beat duration is an exact multiple
  (`durations = ticksInBeat × TICK`), keeping the tick grid aligned with
  the renderer's fractions (proven per beat).
- The counter, the cards and the narration all read the same `story.ts`
  tables (PEDAGOGICAL_SYSTEM §4.5).
