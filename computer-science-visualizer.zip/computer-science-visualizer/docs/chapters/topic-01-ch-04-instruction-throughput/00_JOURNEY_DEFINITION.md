---
guiding_question: "What single mental-model transformation does Topic 01 Chapter 04 complete, and within what boundaries?"
primary_consumer: "Content Authors, QA Auditors, AI Agents"
depends_on:
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
  - "docs/curriculum/CURRICULUM_GRAPH.md"
  - "docs/chapters/topic-01-ch-03-cache-hit-or-miss/00_JOURNEY_DEFINITION.md"
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# Journey Definition — Topic 01 / Chapter 04

**Chapter ID:** `topic-01-computer-architecture--ch-04-instruction-throughput`
**Slug:** `how-cpu-runs-billions-per-second`
**Status:** Production
**Version:** 1.0.0

---

## 0. Phase-Local Activation Record

* **Governing documents reopened for this phase:**
  `AI_CHARTER.md`, `DOCUMENTATION_EVOLUTION.md`, `PROJECT_STATE.md`,
  `AGENT_BOOT.md`, `CURRICULUM_GRAPH.md`, `PHILOSOPHY.md`,
  `VISUAL_LANGUAGE.md`, `NARRATIVE_FRAMING.md`, `PEDAGOGICAL_SYSTEM.md`,
  `01_COGNITIVE_STAGES.md`, `02_PRODUCTION_LIFECYCLE.md`,
  `03_QA_VERIFICATION.md`.
* **Owner directive (verbatim brief, Topic 01 Chapter 04):** this is the FINAL
  chapter of Topic 01. It is NOT a chapter that explains the Pipeline — the
  pipeline is only the vehicle. The chapter must make the learner discover,
  with zero explanation, that *the CPU does not run faster — it simply never
  lets its working floor sit empty, so one instruction completes every tick
  while every instruction still takes the same full journey*. One single
  climax, reached by pure observation; afterwards a quiet look-back; and the
  chapter must end with the learner's OWN questions blooming (scheduling,
  threads, processes, OS, synchronization, coherence, multi-core) — none of
  them written on screen.
* **Active Constraint List:**
  1. One chapter completes exactly ONE mental-model transformation (`PEDAGOGICAL_SYSTEM` §3).
  2. Terminology may appear only after the phenomenon that motivates it (`NARRATIVE_FRAMING` §13).
  3. Every drawn coordinate must be derived from a named primitive (`VISUAL_LANGUAGE` §2.2).
  4. Distinct logical paths must be drawn as distinct lines (`VISUAL_LANGUAGE` §2.1).
  5. One persistent visual protagonist, continuously traceable (`VISUAL_LANGUAGE` §13).
  6. Deferred Internals must be declared, never explained by false analogy (`PHILOSOPHY` §5.3).
  7. No unlearning: everything taught must stay true in the next chapter (`PHILOSOPHY` §3).
  8. Quantities spoken in narration derive from the same data the renderer draws (`PEDAGOGICAL_SYSTEM` §4.5).
  9. Problem states derive from affirmative predicates (`PEDAGOGICAL_SYSTEM` §4.6).
  10. Container extents derive from their content (`PLATFORM_ENGINE` §2.4); evidence boards draw their empty state from scene entry (§2.5).
  11. When concurrent flows are shown, one protagonist is highlighted; auxiliary flows carry decayed visual weight (`VISUAL_LANGUAGE` §18).
  12. The chapter contains EXACTLY ONE climax: the moment the learner sees one
      instruction complete every tick while the watched instruction still takes
      its full five-station journey. No second climax. No on-canvas question
      marks, no definitions, no Throughput/Latency text, no concluding narration.

---

## 1. Target Mental-Model Transformation

* **Before:** The CPU works on one instruction at a time — the Chapter-01 model:
  an instruction completes, then the next one begins. Therefore "billions per
  second" can only mean that each instruction is astronomically fast; speed is
  imagined as the property of a single instruction.
* **After:** Every instruction still spends exactly the same time inside the
  machine — the full journey through all five stations of the working floor.
  The machine simply starts the next instruction the moment the first station
  frees, so the floor is never empty: once it is full, one instruction
  completes EVERY tick, and the counter climbs once per tick. The CPU did not
  get faster. It stopped being empty.
* **Transformation:** *"The CPU runs each instruction faster"* → *"Every
  instruction takes the same full journey — but the CPU finishes one every
  tick, because it never lets a station sit idle."*

## 2. Central Educational Question

**How does a CPU run billions of instructions per second?**

Every scene, beat and drawn element in this chapter serves that question —
without ever answering it in words.

## 3. Narrative Threading & Continuity Contract

* **Upstream Endpoint State (T01/Ch-03 exit):** the learner holds the complete
  cache lookup chain and the cost contrast hit ≈ instant vs miss = a RAM round
  trip. The memory ladder (CPU → L1 → L2 → L3 → RAM) is a familiar world;
  values ◆ ▲ ■ ● still live in the levels; the golden spark is the execution
  protagonist; colours are `cpu #fb923c`, `cache #22d3ee`, `ram #a78bfa`.
* **Contextual Carry-Over:** the ladder, its axis, rung order and resident
  values; the request-card visual language (op/glyph cards); the golden spark;
  the completion counter idea. The chapter opens on the whole assembled Topic-01
  world and the camera then follows ONE instruction INTO the CPU — the machine
  interior is new territory, but every part inside is made of known pieces
  (Fetch/Decode/Execute/Write Back from Chapter 01; the memory trip from
  Chapters 02–03).
* **Explicitly NOT repeated:** the Basic Instruction Cycle is not re-taught —
  it is performed and referenced by name (station labels and one orientation
  line). Owner-directed explanation pass (2026-08-01): the instruction kinds
  (LOAD/ADD/STORE/SUB/CMP) are named in one plain sentence each as they first
  execute, and the repetition reason is stated — brief naming, never a
  re-teach of the cycle's mechanics. The climax remains the only fully silent
  beat. Second owner-directed round (2026-08-01): the observation speed is
  named explicitly — slow motion (billions of times slower), real speed
  ≈ 4 billion instructions/second, a real program needing billions of steps
  to draw one screen, and an on-canvas real-speed caption on the horizon
  counter. Explanation-only; timeline and mechanics untouched. Third
  owner-directed round (2026-08-01): the horizon epilogue visibly
  accelerates (slow-motion pace → ramp → max speed, 25 ticks/s on screen)
  so the learner FEELS the machine's rate; the canon is preserved — every
  tick still completes exactly one instruction, only the tick length
  changes (deterministic piecewise functions in story.ts). This is a speed
  illustration, not a second climax: the single realization remains b13.
  Fourth owner-directed round (2026-08-01): the horizon protagonist (the
  golden spark) now RUNS core → L1 → core at the accelerating tick rate
  (backward-compatible engine hook `runtime.loopPosition`), with three
  instruction cards chasing each other along the road — the epilogue moves
  in both stages and at speed the spark races with a light-ribbon trail,
  so the machine's rate is FELT. Canon preserved: every tick still
  completes exactly one instruction; the spark is the flowing work, not a
  faster instruction (C-05). The speed gap, why cache exists, hit/miss mechanics
  are not re-argued — the memory trips appear as fast familiar blinks. The
  Chapter-03 lookup internals (index/tag/offset) never reappear; data simply
  comes home.
* **Downstream Launchpad (the whole point of the chapter):** the learner leaves
  with the machine's behaviour burned in — many instructions alive at once,
  one finishing every tick, a stream that never ends, a single shared ALU that
  every instruction must pass through, a single cache ladder every data trip
  uses. From that visual memory the questions arise by themselves: who decides
  which instruction goes first when the stream forks? what happens when two
  want the same station at the same time? what happens when the data is NOT in
  the cache mid-flight? what happens when several programs share this floor?
  how would a second floor make it even faster? These are the entry states of
  Topics 02+ (OS, scheduling, concurrency, synchronization, cache coherence,
  multi-core, parallelism). None appear as text.

## 4. Protagonist & Conflict

* **Protagonist:** ONE golden instruction — the instruction the camera follows.
  It first appears as the die-scale execution spark (the instruction the CPU is
  working on), then as the golden card that enters the working floor alone
  (row 6), and finally as the golden card whose full journey is measured during
  the climax (row 19). Every other instruction is an auxiliary flow with
  significantly decayed visual weight (`VISUAL_LANGUAGE` §18).
* **Antagonist:** emptiness. The empty stations of the working floor. The
  chapter's arc is the floor going from empty to full — the machine waking up.
* **Conflict:** the same instruction takes the same time as it always did; the
  machine that finishes more in that same time is not a faster machine — it is
  a busier one. The learner watches the contradiction resolve visually.

## 5. Strict Scope Boundary

Declared **Deferred Internals** (`PHILOSOPHY` §5.3) — never depicted, never
hinted, reserved for downstream topics (owner directive + `AGENT_BOOT`
forbidden list):

> *What happens when a later instruction needs a result that is not ready yet
> (dependencies / stalls); what happens when a data request misses the cache
> mid-flight (pipeline drain); what happens when two instructions want the same
> station at the same moment (structural conflicts); how several programs,
> processes or threads share this floor and who decides the order (OS,
> scheduling); why a second identical floor (another core) would finish even
> more per tick (multi-core, parallelism); how several floors keep their copies
> of the ladder consistent (cache coherence); superscalar / out-of-order /
> branch prediction / speculation.*

In this chapter the stream issues exactly one instruction per tick, every data
request is a cache hit (a small hot program), and the rhythm is perfect — that
is what makes the observed behaviour true and clean. The chapter shows THE
FACT of instruction-level throughput; it never explains a hazard, a stall, a
miss mid-pipeline, a thread, a process, a core, or a scheduler.

Also excluded: nanosecond/gigahertz figures, Throughput and Latency as terms
(owner directive), any bit-level or wiring detail, and any text that draws the
chapter's conclusion for the learner.

## 6. Scenes, Objectives & Act Map

| # | Scene | Objective (what the learner can do after this scene) |
|---|---|---|
| 1 | `entry` | Re-enter the whole Topic-01 world; watch the CPU complete instructions one after another at the remembered slow pace — nothing unusual. |
| 2 | `floor` | Enter the CPU's working floor; watch one instruction cross all five stations; watch a second instruction appear before the first has finished; watch the floor fill until every station is busy; watch one instruction complete every tick; watch the golden instruction take exactly the same five-station journey while five others finish — the realization; look back at the same machine; hear its one name: Pipeline. |
| 3 | `horizon` | Step back to the whole machine; watch it keep running forever — every tick one more done, the program still long; be left with the questions. |

## 7. Success Criterion

A complete beginner can, after ONE viewing, answer in their own words:

> *"Why does the CPU finish so many instructions per second?"*

with: *"Each instruction still takes the same full journey — but the machine
keeps every station busy, so one finishes every tick."* — and then begins, on
their own, to ask what happens when the machine is full, when two instructions
disagree, when more programs come, and why one floor might not be enough.

## 8. Learning Checkpoints

Interactive State-Predictive Verification is platform-wide deferred debt
(`PROJECT_STATE` §2); checkpoints therefore take the chapter's canonical
non-interactive form — created-question pauses and consolidation holds:

1. **CP1 (end `entry`):** the remembered slow cadence — one completion every
   several seconds. The question "how can this ever be billions?" forms in the
   learner's head before the floor is entered.
2. **CP2 (`floor`, beat `two-at-once`):** the second instruction appears while
   the first is still inside; the line names the machine's non-waiting
   behaviour in plain language, and the learner connects it to the repetition
   they are watching.
3. **CP3 (`floor`, beat `the-rhythm`):** the counter pops every tick and the
   line explains why the steps keep repeating (the program still has rows
   left) — cadence and repetition reason are both plain-language, never the
   chapter's conclusion.
4. **CP4 (`floor`, beat `climax`):** the golden instruction's five-tick journey
   is measured against five completions in the same window — the "À…" moment.
   The beat is silent and unbroken.
5. **CP5 (`horizon`):** the machine runs forever; the learner is left alone
   with the running world and their own questions.
