---
guiding_question: "What reusable production lessons did Topic 01 Chapter 03 generalize back into repository documentation?"
primary_consumer: "Maintainers, AI Agents"
depends_on:
  - "docs/protocols/DOCUMENTATION_EVOLUTION.md"
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# Phase X — Documentation Evolution Report

**Chapter:** `topic-01-computer-architecture--ch-03-cache-hit-or-miss` v1.0.0
**Protocol:** `docs/protocols/DOCUMENTATION_EVOLUTION.md` §2

---

## 1 · Lesson Identification

Five recurring patterns emerged that are **not** specific to caching:

* **L1 — Pills crowd unless they have derived homes.** Eleven distinct
  crowding/collision defects appeared in this chapter's first renderer pass
  (chips vs orientation chip, counter vs question, terms over rows/panels,
  verdict over rows, checkpoint chain overflow, ribbon pills over rows, second
  term stacking). All shared one root cause: *pills positioned by inline
  arithmetic near their referent*. Any chapter adding verdict/term/question
  pills will re-hit this.

* **L2 — Handoffs need exported windows.** The crowding that couldn't be solved
  spatially (two pills sharing a band) was solved temporally — but only after
  the timing constants moved from render-inline literals to exported story
  constants (`QUESTION_WINDOWS`, `COUNTER_EXIT`, `CARD_FOLD`). Inline timing
  literals are unprovable by gates.

* **L3 — Container content can escape its own wall.** The RAM block floated
  12 px below its panel because its Y was a metric instead of a derivation
  from the grid it represents. *Derived beats named* even inside one
  container's own geometry.

* **L4 — Bbox forgetting dock content.** Scene bboxes covered the panel but
  not the wrapped pill docks that hang off it; camera-side zoom-out "fixed"
  nothing because bboxes drive the fit. Bbox math must derive from the
  geometry of *everything* drawn in the scene, including pill wrap growth.

* **L5 — Docs can drift from the narration source in one character.** The
  storyboard JSON drifted from `beats.ts` by two typographic apostrophes —
  invisible to prose review, caught only by a sync gate's exact comparison.

## 2 · Generalization Decisions

Applied **inside this chapter** (immediately reusable by later chapters):

1. **Dock-based pill layout** — `scenes/layout.ts` exports `dockNorth`,
   `dockSouth`, `termDock`, `verdictDock`, `mastheadDock` with valign
   semantics (`top`/`bottom`/`center`), and the layout proof asserts
   containment + pairwise disjointness on the worst-case (wrapped) rects.
2. **Handoff windows as story constants** — `QUESTION_WINDOWS`,
   `COUNTER_EXIT`, `CARD_FOLD` exported; gates assert ordering
   (exit-start == question-start; fold-complete ≤ question-start).
3. **RAM block derived from its grid** — `RAM_BLOCK_ROWS` metric +
   `ramBlockRect()` derivation; the block is contained by construction.
4. **Bbox pill-growth derivation** — `NORTH_PAD`/`SOUTH_PAD` derive from
   `TERM_H_MAX = TERM.h + 2·(F.sub+6)` instead of ad-hoc margins.
5. **Storyboard↔narration sync gate** — smoke §5 compares the 26-beat
   storyboard JSON to `beats.ts` exactly (id + EN + VI).

Recommended for a **platform pass** (not done here — non-blocking debt #4
already logs gate generalization): parameterize the three gate scripts by
chapter id; elevate the L2 window pattern into `PLATFORM_ENGINE.md` as a
§-level pattern if a second chapter adopts it.

## 3 · Repository Hygiene Findings

* **Missing Ch-02 gate scripts (blocking-grade for §4 reproducibility,
  recorded as non-blocking debt #5):** `package.json` at Ch-03 production start
  referenced `scripts/smoke-topic01-ch02.ts`, `scripts/scope-gate-topic01-ch02.ts`
  and `scripts/layout-proof-topic01-ch02.ts`, yet the `scripts/` directory did
  not exist in the tree — PROJECT_STATE §4's quoted Ch-02 smoke numbers
  cannot be re-executed as found. Ch-03 ships its complete gate set;
  `npm run smoke` now runs it. The Ch-02 set should be reconstructed from its
  documented reports (`docs/chapters/topic-01-ch-02-cpu-memory-wait/06–08`).
* No other inconsistencies found in the governing chain during this production
  (constitution, pedagogy, pipeline, architecture docs mutually consistent as
  consumed).

## 4 · Constitution Amendments

**None required.** All production questions resolved within existing doctrine:
NARRATIVE_FRAMING §13 (term-after-behaviour), PEDAGOGICAL_SYSTEM §4.5/§4.6
(quantity/affirmative derivation), VISUAL_LANGUAGE §2.1/§2.2/§13/§15
(connections, derivation, traceability, determinism), PLATFORM_ENGINE §2.4/§2.5
(container extents, evidence boards). The chapter needed zero doctrine
exceptions.

## 5 · Residual Debt Registered

See `PROJECT_STATE.md` §2 — #4 (gate generalization, existing) and **#5
(missing Ch-02 gate scripts, new)**. No other debt introduced: the chapter
ships its full gate set, docs 00–11, schemas-conformant JSON artifacts
(01–05 validated against `schemas/chapter/*.schema.json`).
