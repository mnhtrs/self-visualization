---
guiding_question: "Does every scene, beat, narration and animation in Topic 01 Chapter 03 serve one educational question — and does the learner's mental model actually improve?"
primary_consumer: "Review Board, Maintainers, Chapter Authors"
depends_on:
  - "docs/constitution/NARRATIVE_FRAMING.md"
  - "docs/pedagogy/PEDAGOGICAL_SYSTEM.md"
  - "docs/chapters/topic-01-ch-03-cache-hit-or-miss/10_SPEC_DELIVERABLES.md"
referenced_by:
  - "docs/chapters/topic-01-ch-03-cache-hit-or-miss/11_FREEZE_AUDIT.md"
  - "docs/state/PROJECT_STATE.md"
---

# CESVI Pedagogical Review Board — Topic 01 / Chapter 03

**Chapter:** `topic-01-computer-architecture--ch-03-cache-hit-or-miss` v1.0.0
**Verdict:** **FREEZE** — 0 critical blockers, 0 major blockers, 3 minor observations (waivers recorded §6)
**Overall CESVI Score:** **9.0 / 10**

This audit judges educational quality only. Build health, scope enforcement and
layout compliance are already green (`07_QA_AUDIT.md`, 996 executable checks)
and are credited only where they carry pedagogical weight.

---

## Executive Finding

The chapter teaches *mechanism*, not vocabulary. Its single strongest move is
that **the three mappings are never defined** — they are *derived in front of
the learner* by request streams on a visible tally, and named only after the
outcome is already understood (Direct 4/0/4 → 2-way 4/2/2 → fully-associative
8/4/4 with a 16-compare fan-out). The second strongest move is the address:
split *by jobs, not by bits* — the Index is introduced as "the piece you have
watched routing requests since the lines grouped", making Act 4 a *re-naming of
behaviour already seen*, exactly as NARRATIVE_FRAMING §13 demands.

The pre-freeze visual review found and removed eleven crowding/collision
defects (chips vs orientation chip, counter vs question, term pills over rows
and panels, verdict pills over rows, checkpoint chain overflow, ribbon pills
over rows, RAM block outside its panel). All eleven are now gate-proven
non-regressions — the audit's crowding criterion is executable, not aspirational.

---

## 1 · One question, one transformation (PEDAGOGICAL_SYSTEM §3)

The chapter asks one question — *how does a cache decide hit or miss?* — and
the central question audit passes: every scene's objective (00 §6) answers a
sub-question of it, and the Act-7 replay reconstructs the full chain as the
answer. Nothing in the chapter serves a second master: the tally, the counter,
the streams all measure *answering cost*, the dimension the decision optimises.

## 2 · Observation before terminology (NARRATIVE_FRAMING §13)

Term landing order, enforced by the scope gate at exact beat indices:

| Beat | Behaviour watched first | Term landed |
|---|---|---|
| b2 | rows revealed + described as compartments | `Cache Line` |
| b6 | two same-stripe cards land in one group, twice | `Set` |
| b9 | 4 misses / 4 requests on single-line sets | `Direct Mapping` |
| b11 | same stream, two lines, 2 hits | `Set Associative Mapping` |
| b12 | load anywhere + 16-compare fan-out | `Fully Associative Mapping` |
| b13 | the card's three zones seam and separate | `Memory Address` |
| b14–b16 | routing / comparison / word pick, one at a time | `Index` → `Tag` → `Word Offset` (+ `Cache Lookup` closing the arc) |
| b15 | tag match resolves | `Cache Hit` (as the verdict) |
| b17 | two `not me` outcomes | `Cache Miss` |
| b18 | caravan (tag + 4 words) travels RAM → set | `Cache Line Loading` |
| b20 | full set, no free line | `Replacement` |
| b21–b22 | earliest-arrival victim, then staled victim | `FIFO` → `LRU` |

**No term is spoken before its referent has moved on screen; no beat adds more
than one new concept** (gate §2/§3). The final replay contains only previously
introduced vocabulary (gate §3.4).

## 3 · Problem → need → animation → understanding → terminology

The spec's required order holds at every scale:

- **Act 1:** problem is *felt* (14 counted checks) before the question pill
  asks "where should the cache look first?" (b5) — and the counter hands over
  its screen corner to the question instead of crowding it (handoff, gate-proven).
- **Act 2:** the design question "how many lines should a set hold?" (b7)
  precedes its three experimental answers; each name lands *after* its tally.
- **Act 6:** "no free line — which one should leave?" hangs for two beats
  before FIFO demonstrates one answer; LRU is then a *contrast on a rewind*,
  the sharpest possible demonstration that replacement is a *rule choice*, not
  a situation outcome.

## 4 · No unlearning; black-box honesty (PHILOSOPHY §3, §5.3)

- Everything taught stays true downstream: hit/miss semantics, line-granularity
  loads, set routing, tag identity, offset selection, victim-by-rule. Chapter
  04's cost model (hit ≈ instant, miss = RAM round trip) builds directly on it.
- The mapping story ends with "real caches settle in the middle" — no
  overclaim, no numbers, and nothing said about Direct/Fully-Associative caches
  needs retracting later.
- **Deferred Internals are declared, never smuggled:** write behaviour,
  coherence, virtual memory, TLB, prefetch, multi-core, and *any* bit layout
  are absent by construction and by gate (12 regex families, plus `bit|byte|hex`
  ban). The address is only ever "information with jobs".
- Chapter 02's Deferred Internal is *opened, not contradicted*: the probe
  protocol ("ask L1 first") remains true; only the interior is new.

## 5 · Protagonist, continuity, and visual traceability

- One Memory Request, always: the golden spark carries the identity card;
  scenes re-frame around it rather than swapping actors (§13). At every seam
  the spark holds the exit anchor (`seamPosition` gate) and the next path
  resumes the same journey.
- Entry fidelity: the ladder metrics are Chapter 02's verbatim; the values ◆ ▲ ■
  are still where the learner left them. The camera *enters* — no cold open.
- Auxiliary requests (mapping streams) render dimmed/decayed, strictly in
  crowd roles (`VISUAL_LANGUAGE §18`); the tally labels them "the four requests"
  so their supporting status stays legible.

## 6 · Minor observations (waivers — none blocking)

1. **The ticker replaces a simultaneous checkpoint chain.** Six simultaneous
   station labels cannot fit the panel span; Act 7 therefore shows one
   masthead label per passed station. Trade: the "whole chain visible at once"
   recap gesture weakens slightly; the narration + b25 question return
   compensate. *Waiver: accepted; revisit if a two-row dock language is
   introduced platform-wide.*
2. **FIFO/LRU evidence is badge-glyph-only** (①②, ●/○) without on-canvas text
   — the narration must carry the badge semantics. Acceptable for a single
   beat-pair; a later chapter on policy depth would need a richer notation.
3. **Numbers stay abstract:** checks, requests, tallies are small integers by
   design; no capacities/latencies are ever quoted. This is spec-directed, but
   some learners may ask "how many lines do real caches have?" — the VI
   glosses carry a hint; a glossary/FAQ page could answer without breaking the
   no-numbers rule (platform-level, out of scope here).

## 7 · Board questions a first-time learner might still ask (anticipated, answered)

- *"Why did the second request beat the counter to 14?"* — answered by design:
  the sweep counts are the evidence the problem exists; the counter's presence
  is exactly the felt-metric PAT §5 requires.
- *"Does the cache throw values away forever?"* — b18/b23: RAM always has the
  original; the cache holds copies (said explicitly, carried over from Ch-02).
- *"Why not always fully associative?"* — b12's fan-out answers visually; the
  closing line says caches settle in the middle without inventing a number.

---

**Board conclusion:** the chapter completes exactly the transformation its
journey definition declares, with mechanism-first pedagogy, gate-enforced
terminology discipline, and a fully-owned self audit. **Recommendation: freeze.**
