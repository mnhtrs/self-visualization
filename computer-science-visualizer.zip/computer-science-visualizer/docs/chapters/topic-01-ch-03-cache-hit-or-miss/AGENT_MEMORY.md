---
chapter_id: "topic-01-computer-architecture--ch-03-cache-hit-or-miss"
guiding_question: "What working memory and execution state was recorded during Topic 01 Chapter 03 production?"
chapter_version: "1.0.0"
status: "FROZEN"
frozen_date: "2026-07-28"
all_phases_completed: true
checkpoint_id: "ch03-freeze-v1.0.0"
gate_coverage: 996
---

# AGENT MEMORY — T01/Ch-03 Cache Hit or Miss

> **⚠ FROZEN — Do not modify this chapter without an explicit owner directive.**
> Reopen only for: factual error, implementation bug, architecture violation, or mandatory platform migration.
> Scope gate enforced by `scripts/scope-gate-topic01-ch03.ts` on every future change.

---

## Phase Completion Record

| Phase | Name | Status |
|---|---|---|
| 1 | Journey Definition | ✅ DONE |
| 2 | Pipeline Design | ✅ DONE |
| 3 | Pipeline Validation | ✅ DONE |
| 4 | Story Architecture | ✅ DONE |
| 5 | Scene Design & Layout Derivation | ✅ DONE |
| 6 | Narration & Voice | ✅ DONE |
| 7 | Self Review & QA Check | ✅ DONE |
| 8 | Audit & Release Freeze | ✅ DONE — 996 checks PASS |
| 9 | Production Closure | ✅ DONE |
| X | Documentation Evolution | ✅ DONE |

---

## Mental Model Transformation

- **Before:** "Cache simply knows whether it holds a value — it answers by magic."
- **After:** "Cache answers by splitting an address — Index picks a Set, Tag identifies the line, Offset picks the word — and when it cannot answer, it makes room by rule."
- **Central Question:** How does a CPU cache determine whether a memory request becomes a Cache Hit or a Cache Miss?

---

## Finalized Decisions (immutable)

- **Protagonist:** ONE Memory Request — carried by the golden spark with an identity card. Never swaps across scenes.
- **Colors:** `cpu: #fb923c`, `cache: #22d3ee`, `ram: #a78bfa`. Auxiliary requests rendered with decayed visual weight.
- **Topic Accent Rule:** Every chapter belonging to Topic 01 MUST use the Topic accent color `#fb923c` in its `meta.ts` (`accent: '#fb923c'`) so that UI card outlines, hover states, and topic tags (`T01`) maintain visual unity across the topic. Chapter-internal visual components (like cache nodes `#22d3ee`) can use distinct colors internally, but card level accent MUST match Topic 01's `#fb923c`.
- **Layout Pattern:** Dock-based pill layout (`dockNorth`, `dockSouth`, `termDock`, `verdictDock`, `mastheadDock`) — standard pattern generalized from this chapter.
- **Story constants:** `QUESTION_WINDOWS`, `COUNTER_EXIT`, `CARD_FOLD` exported and gate-asserted.
- **Act Structure:** 7 acts across 7 scenes: `entry → interior → mapping → lookup → miss → replace → replay`.
- **17 required concepts** taught; **12 forbidden topic families** machine-verified absent.

---

## Scope Boundary (Deferred Internal → declared, never opened)

Not taught, not hinted:
> Physical bit field decomposition of addresses; write-through/write-back; MESI/coherence; virtual memory/TLB; prefetching; branch prediction; multi-core. No bit diagrams, no byte/hex layouts, no address arithmetic, no hardware capacity numbers.

---

## Scene Objectives (frozen reference)

| Scene | Objective |
|---|---|
| `entry` | Recognise Ch-02 ladder; one request reaches the level; ask "how does it know?" |
| `interior` | See Cache Lines; feel that row-by-row search is too expensive |
| `mapping` | See Sets; compare Direct / Set-Associative / Fully-Associative by behaviour first |
| `lookup` | Watch full Cache Lookup: Index→Set→Tag compare→Offset→word home = Hit |
| `miss` | Replay lookup with no match = Miss; watch Cache Line Loading |
| `replace` | Full set problem; compare FIFO vs LRU on same state |
| `replay` | Consolidation — no new concepts; learner narrates chain ahead of ticker |

---

## Artifacts

- [x] `00_JOURNEY_DEFINITION.md` — v1.0.0
- [x] `01_delta.json` — schema-validated
- [x] `02_topology.json` — schema-validated
- [x] `03_trace.json` — schema-validated
- [x] `04_storyboard.json` — 26 beats, bilingual EN+VI, schema-validated
- [x] `05_journey_blueprint.json` — schema-validated
- [x] `06_LAYOUT_PROOF.md` — 428-check layout proof
- [x] `07_QA_AUDIT.md` — 996 checks PASS (smoke 437 + scope 131 + layout 428)
- [x] `08_PHASE_X_REPORT.md` — 5 lessons generalized
- [x] `09_PEDAGOGICAL_AUDIT.md`
- [x] `10_SPEC_DELIVERABLES.md` — 11 deliverables verified
- [x] `11_FREEZE_AUDIT.md` — FREEZE verdict, score 9.0/10

---

## Phase X Lessons Generalized (→ permanent patterns for Ch-04+)

- **L1 — Dock-based pill layout:** Verdict/term/question pills must have derived dock homes (North/South/term/verdict/masthead). Inline arithmetic positioning causes crowding. → Apply from chapter start.
- **L2 — Handoff windows as story constants:** Timing constants (`QUESTION_WINDOWS`, `COUNTER_EXIT`, `CARD_FOLD`) must be exported and gate-asserted. Inline timing literals are unprovable.
- **L3 — Container content derivation:** Every coordinate inside a container must derive from its content metrics, not be set as a metric of its own.
- **L4 — Bbox must include pill-dock growth:** Scene bbox math must account for wrapped pill docks hanging off panels.
- **L5 — Storyboard sync gate:** A gate must compare `storyboard.json` beats exactly (id + EN + VI) against `beats.ts` to catch typographic drift.

---

## Downstream Launchpad (Ch-04 entry state)

The learner exits holding the complete lookup chain: *request → address → index → set → tag compare → hit / miss → load or replace → word returned.* Hit ≈ instant; miss = full RAM round trip. This cost contrast is the assumed entry knowledge for Ch-04 (instruction-level throughput).

Deferred for Ch-04 or beyond: write behaviour, dirty bit, MESI coherence.

---

## Known Risks / Gotchas for Future Chapter Authors

- 11 crowding/collision defects occurred in the first renderer pass — all from inline pill positioning. **Always start with dock-based layout.**
- Storyboard↔code sync must be gated from day one (not retroactively).
- Scene bboxes must be computed after the full dock-wrap geometry is known, not before.
