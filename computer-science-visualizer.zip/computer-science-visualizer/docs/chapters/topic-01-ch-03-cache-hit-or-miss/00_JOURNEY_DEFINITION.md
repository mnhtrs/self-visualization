---
guiding_question: "What single mental-model transformation does Topic 01 Chapter 03 complete, and within what boundaries?"
primary_consumer: "Content Authors, QA Auditors, AI Agents"
depends_on:
  - "docs/pipeline/02_PRODUCTION_LIFECYCLE.md"
  - "docs/curriculum/CURRICULUM_GRAPH.md"
  - "docs/chapters/topic-01-ch-02-cpu-memory-wait/00_JOURNEY_DEFINITION.md"
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# Journey Definition — Topic 01 / Chapter 03

**Chapter ID:** `topic-01-computer-architecture--ch-03-cache-hit-or-miss`
**Slug:** `how-cache-decides-hit-or-miss`
**Status:** Production
**Version:** 1.0.0

---

## 0. Phase-Local Activation Record

* **Governing documents reopened for this phase:**
  `AI_CHARTER.md`, `DOCUMENTATION_EVOLUTION.md`, `PROJECT_STATE.md`,
  `CURRICULUM_GRAPH.md`, `PHILOSOPHY.md`, `VISUAL_LANGUAGE.md`,
  `NARRATIVE_FRAMING.md`, `PEDAGOGICAL_SYSTEM.md`, `01_COGNITIVE_STAGES.md`,
  `02_PRODUCTION_LIFECYCLE.md`, `03_QA_VERIFICATION.md`.
* **Owner directive:** the Official Production Specification for Topic 01
  Chapter 03 ("How does a CPU cache determine whether a memory request becomes
  a Cache Hit or a Cache Miss?"), supplied verbatim by the owner. Its required
  concepts, act structure, protagonist rule and audit list are binding chapter
  requirements and are implemented by this document's successors.
* **Active Constraint List:**
  1. One chapter completes exactly ONE mental-model transformation (`PEDAGOGICAL_SYSTEM` §3).
  2. Terminology may appear only after the phenomenon that motivates it (`NARRATIVE_FRAMING` §13).
  3. Every drawn coordinate must be derived from a named primitive (`VISUAL_LANGUAGE` §2.2).
  4. Distinct logical paths must be drawn as distinct lines (`VISUAL_LANGUAGE` §2.1).
  5. One persistent visual protagonist, continuously traceable (`VISUAL_LANGUAGE` §13).
  6. Deferred Internals must be declared, never explained by false analogy (`PHILOSOPHY` §5.3).
  7. No unlearning: everything taught must stay true in the next chapter (`PHILOSOPHY` §3).
  8. Quantities spoken in narration derive from the same data the renderer draws (`PEDAGOGICAL_SYSTEM` §4.5).
  9. Problem states derive from affirmative predicates (`PEDAGOGICAL_SYSTEM` §4.6).
  10. Container extents derive from their content (`PLATFORM_ENGINE` §2.4); evidence boards draw their empty state from scene entry (§2.5).

---

## 1. Target Mental-Model Transformation

* **Before:** A cache level "just knows" whether it holds a value — it answers
  instantly, apparently by magic. If the learner pictures a mechanism, it is an
  undifferentiated box whose smallness alone explains the answer.
* **After:** A memory request carries an address, and the cache splits that
  address because its parts do different jobs: the **Index** selects one
  **Set**, the **Tag** is compared against the stored tags of that set's
  **Cache Lines** (a match is a Cache Hit, no match is a Cache Miss), and the
  **Word Offset** picks the requested word inside the matching line. On a miss
  the whole line is loaded from RAM; on a miss in a full set a **Replacement**
  policy (FIFO / LRU) chooses which line leaves. How many lines a set holds is
  a trade: Direct Mapping (one) is cheap to check but conflicts, Set
  Associative (a few) is the middle, Fully Associative (all) removes conflicts
  but pays a full comparison every time.
* **Transformation:** *"Cache simply knows"* → *"Cache answers by splitting an
  address — index picks a set, tag identifies the line, offset picks the word —
  and when it cannot answer, it makes room by rule."*

---

## 2. Central Educational Question

**How does a CPU cache determine whether a memory request becomes a Cache Hit or a Cache Miss?**

Every scene, beat and drawn element in this chapter answers that one question.

---

## 3. Narrative Threading & Continuity Contract

* **Upstream Endpoint State (T01/Ch-02 exit):** the learner stands at the end
  of the memory ladder — CPU, then L1, L2, L3, then RAM far away — holding "the
  CPU checks the nearest level first, and a level either has the value or it
  does not." Chapter 02 showed a level *answering* ("got it?" → "yes!"/"nope")
  without ever showing *how*.
* **Contextual Carry-Over:** the ladder itself (axis, rung order, rung sizes,
  colours `cpu #fb923c`, `cache #22d3ee`, `ram #a78bfa`, value glyphs), the
  Cache Hit / Cache Miss verdict vocabulary, and the golden spark protagonist
  visual. The chapter opens on the remembered final state of Chapter 02 and the
  camera *follows one request INTO the nearest level* — the learner enters the
  cache rather than starting a new lesson.
* **Explicitly NOT repeated:** memory latency, the speed gap, why cache exists,
  Cache Hit/Miss as facts, what L1/L2/L3 are. They are used, not re-taught.
* **Downstream Launchpad:** the learner ends holding the complete lookup chain
  (request → address → index → set → tag compare → hit / miss → load or
  replace → word returned). How an address is *physically* decomposed into bit
  fields and how writes behave remain declared Deferred Internals.

---

## 4. Protagonist & Conflict

* **Protagonist:** ONE Memory Request — carried on screen by the golden spark,
  which bears the request's identity card. The learner never leaves it: scenes
  re-frame, the protagonist never swaps. Auxiliary requests (the mapping
  streams) are rendered with decayed visual weight and run strictly in crowd
  roles (`VISUAL_LANGUAGE` §18).
* **Antagonist:** the cost of searching — first as wasted comparisons (Act 1),
  then as slot conflicts (Direct Mapping), then as comparison wiring (Fully
  Associative). Each solution earns the next problem.
* **Conflict:** the cache must answer "have it / have it not" cheaply; the
  chapter is the refinement of that answer.

---

## 5. Strict Scope Boundary

Declared **Deferred Internals** (`PHILOSOPHY` §5.3) — never depicted, never
hinted:

> *How an address is decomposed into physical bit fields; what happens on a
> write request (write-through / write-back); how several caches in several
> cores keep copies consistent (MESI / coherence); virtual memory and the TLB;
> prefetching; branch prediction; multi-core behaviour.*

Also excluded: capacities and latencies as numbers, bit diagrams, and any
address arithmetic. The address is treated as information with jobs, never as a
bit layout. "Eviction" mechanics appear only as behaviour; policy selection is
taught as FIFO vs LRU *outcome*, avoiding implementation detail.

The Chapter-02 Deferred Internal — *how a level determines whether it holds a
value, and what it discards to make room* — is **opened and fully taught here**.

---

## 6. Scenes, Objectives & Act Map (scene-by-scene objectives)

| # | Scene | Act | Objective (what the learner can do after this scene) |
|---|---|---|---|
| 1 | `entry` | 1 | Recognise the Chapter-02 ladder as the same world; watch one Memory Request reach the nearest level; form the question "how does it know?" |
| 2 | `interior` | 1 | See that a cache level is rows of identical **Cache Lines**; watch a line-by-line search cost a comparison per row; feel that asking every row is too expensive. |
| 3 | `mapping` | 2 | See lines grouped into **Sets** and that an address belongs to exactly one set; derive by watching that **Direct** (1 line) conflicts, **Set Associative** (2 lines) coexists, **Fully Associative** (all lines) removes conflict but compares everywhere — naming each only after its behaviour. |
| 4 | `lookup` | 3–4 | See the **Memory Address** unpacked into **Index / Tag / Word Offset** by purpose; replay one full **Cache Lookup**: index selects the set, tag compares, the match opens its line, the offset picks the word, the word goes home — and understand *why* that is a Cache Hit. |
| 5 | `miss` | 5 | Replay a lookup where no tag matches; understand *why* it is a Cache Miss; watch **Cache Line Loading** bring the whole line (tag + words) from RAM into a free slot before the lookup completes. |
| 6 | `replace` | 6 | Meet the full-set problem; see the **Replacement** need; compare **FIFO** (earliest arrival leaves) and **LRU** (least recently used leaves) on the same state; watch the lookup complete afterwards. |
| 7 | `replay` | 7 | Replay the entire lookup continuously with zero new concepts; consolidate the mental model; answer the chapter's opening question. |

---

## 7. Success Criterion

A complete beginner can, after ONE viewing, mentally replay:

> request → address → index selects one set → that set exposes its lines →
> incoming tag compares against stored tags → match = Hit / no match = Miss →
> load the line from RAM (replacing a full set's victim by rule) → offset picks
> the word → data returns

…in their own words, and can say why *some* mapping middle ground exists.

---

## 8. Learning Checkpoints

Interactive State-Predictive Verification is platform-wide deferred debt
(`PROJECT_STATE` §2); checkpoints therefore take the chapter's canonical
non-interactive form — created-question pauses and consolidation replays:

1. **CP1 (end `interior`):** "must every row be asked?" — problem pill; the
   learner predicts a cheaper organization before sets appear.
2. **CP2 (`mapping`, after Direct):** the stream's misses force the question
   "what if the set had a second slot?" — the 2-line replay answers it
   immediately after the question forms.
3. **CP3 (`lookup` beat `the-tag`):** the tag visits stored tags; the beat
   holds each comparison long enough to be predicted before resolving.
4. **CP4 (`replace` beat `set-full`):** "which line should leave?" is posed and
   left open for a beat before any policy demonstrates an answer.
5. **CP5 (`replay`):** the silent full pass — the learner narrates the chain
   internally before the recap line confirms it.
