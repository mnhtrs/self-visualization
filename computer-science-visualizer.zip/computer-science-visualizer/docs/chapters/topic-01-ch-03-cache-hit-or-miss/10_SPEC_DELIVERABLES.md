---
guiding_question: "Does Topic 01 Chapter 03 deliver every artifact demanded by the owner's Official Production Specification?"
primary_consumer: "Owner, QA Auditors, Maintainers"
depends_on:
  - "docs/chapters/topic-01-ch-03-cache-hit-or-miss/00_JOURNEY_DEFINITION.md"
  - "docs/chapters/topic-01-ch-03-cache-hit-or-miss/04_storyboard.json"
referenced_by:
  - "docs/chapters/topic-01-ch-03-cache-hit-or-miss/09_PEDAGOGICAL_AUDIT.md"
  - "docs/chapters/topic-01-ch-03-cache-hit-or-miss/11_FREEZE_AUDIT.md"
---

# Official Production Specification — Deliverables

**Chapter:** Topic 01 · Chapter 03
**Question:** *How does a CPU cache determine whether a memory request becomes a Cache Hit or a Cache Miss?*
**Deliverable set:** the 11 artifacts the owner spec binds, each mapped to its
authoritative home. Executive artifacts are inline; machine-checked mirrors
live beside them.

---

## 1 · Chapter Summary

One memory request leaves the CPU and the camera follows it **inside** the
nearest cache level — the exact world Chapter 02 ended on. Inside, the level is
a stack of eight identical compartments (**Cache Lines**). Searching them
line-by-line works but costs one check per line (14 checks for two requests),
so the lines group into **Sets**. Watching request streams decides how many
lines a set should hold: one (**Direct Mapping**) conflicts constantly, two
(**Set Associative Mapping**) lets same-set addresses coexist, all in one set
(**Fully Associative Mapping**) removes conflict but pays a full fan-out
compare every time. A request's **Memory Address** then opens: its **Index**
selects one Set, its **Tag** compares against the set's stored tags (match =
**Cache Hit**), its **Word Offset** picks the word, and the word goes home —
one complete **Cache Lookup**. When no tag matches (**Cache Miss**), **Cache
Line Loading** brings the whole line up from RAM before the lookup finishes.
When the set is full, **Replacement** chooses a victim — **FIFO** (earliest
arrival leaves) then **LRU** (least recently used leaves, on a rewound replay
of the same moment). The chapter closes with one uninterrupted replay of the
whole chain and the answer to the opening question.

**Protagonist:** one Memory Request only (owner rule). **Start state:** Chapter
02's ending — the camera enters the cache already shown (owner rule).
**Forbidden:** write-through/write-back, MESI/coherence, virtual memory, TLB,
branch prediction, prefetching, multi-core behaviour, and any bit-layout
explanation (all machine-checked absent).

---

## 2 · Complete Storyboard

Authoritative artifact: [`04_storyboard.json`](04_storyboard.json) — 26 beats
over 7 scenes, each with `beat_id`, `visual_action`, `narration_en`,
`narration_vi`; mirrored line-for-line by
`src/.../narration/beats.ts` (durations, travel, act metadata) and **enforced in
sync by the smoke gate** (§5 of `scripts/smoke-topic01-ch03.ts`).

| Act | Beats | Scene | Spine |
|---|---|---|---|
| 1 | b0–b5 | `entry` → `interior` | Enter the cache; reveal Cache Lines; naive sweep; the cost problem |
| 2 | b6–b12 | `mapping` | Sets; "how many lines per set?" → Direct / Set Associative / Fully Associative by streams; name each after its behaviour |
| 3 | b13 | `lookup` | The Memory Address is examined — jobs, not bits |
| 4 | b14–b16 | `lookup` | One full Cache Lookup → Cache Hit (Index → Set → Tag → Offset → home) |
| 5 | b17–b19 | `miss` | No tag matches → Cache Miss → Cache Line Loading → serve like a hit |
| 6 | b20–b23 | `replace` | Full set → Replacement → FIFO, then LRU on a rewind → serve |
| 7 | b24–b25 | `replay` | Uninterrupted full pass (zero new concepts) + the answer |

Blueprint mirror: [`05_journey_blueprint.json`](05_journey_blueprint.json).

---

## 3 · Scene-by-scene Objectives

Authoritative table: `00_JOURNEY_DEFINITION.md` §6. Recap: `entry` — form the
question; `interior` — lines exist, asking all is expensive; `mapping` — sets
and the three arrangements discovered, not told; `lookup` — the address's three
jobs and one complete Lookup→Hit; `miss` — Miss defined by no stored tag
matching, then Cache Line Loading; `replace` — a full set needs Replacement;
FIFO vs LRU outcomes; `replay` — consolidation only.

---

## 4 · Animation Description

Process over diagram: nothing merely appears; every fact *travels, compares,
opens, regroups or settles*.

* **Act 1.** The remembered ladder holds (values ◆ ▲ ■ still resident). The
  spark forms at the CPU core and hops to the L1 door; the chapter question
  rises over the level. The interior fades in row-by-row; the sweep scene then
  physically visits tags one at a time — ✕ per row, ✓ + "me!" at the match,
  the matched line *opens* to show its word cells. The compare counter climbs
  1→6→14 and the "where should it look first?" pill takes the north dock as the
  counter bows out.
* **Act 2.** Pair-braces draw themselves around row pairs; two same-stripe
  cards land in the same set twice (behaviour before the word "Set"). The
  braces morph 4×2 → 8×1 → back → 1×8 while **rows never move**. Streams run:
  four misses on one line per set (evictions drift west, unsentimentally), two
  hits on two lines; the tally board (visible empty from scene entry) counts
  requests/hits/misses live. The fully-associative experiment wipes the
  occupancy, loads four anywhere, then fans out 16 beam-compares while the
  counter climbs — the search cost returns as wiring. Names land at the north
  dock only after each behaviour.
* **Act 3–4.** The whole address card appears at the masthead, seams form, and
  its three chips rise out and form up above it. The Index chip rides the
  spark to set 1 (set glows, others dim) and parks west of its brace; the Tag
  chip visits the set's two stored tags (✕ then ✓, "me!", the line opens,
  `Cache Hit` resolves at the verdict dock); the Offset chip drops onto word 2;
  the word flies home along the link to the CPU dock.
* **Act 5.** Same journey for F3: index → set 3, tag fails twice — `Cache
  Miss`. The spark continues out to RAM; the whole line (tag + 4 words, in
  caravan formation) travels home and plugs into set 3's free line. Then the
  lookup completes exactly like a hit.
* **Act 6.** G2's set is full; `Cache Miss`; the "no free line — which one
  should leave?" question takes the north dock once the card folds. Arrival
  badges ①② appear on the two tags; the earliest arrival drifts west and G2
  settles (`FIFO` named). A rewind wash replays the moment; use-stamps (filled
  vs hollow) appear; this time the *other* line leaves (`LRU` named). The
  lookup completes.
* **Act 7.** One continuous pass for C1 with a single checkpoint ticker at the
  masthead naming each known station as it passes. The final checkpoint bows
  out; the opening question returns — answered — and the chapter loops at rest.

## 5 · Narration

Full bilingual script (verbatim with the storyboard / beats source of truth):

| # | Beat | Narration (EN) | Narration (VI) |
|---|---|---|---|
|  | **entry** — Act 1 — the level that simply answers (continuity from Chapter 02) | | |
| 0 | `the-level-answers` | Pick up right where the last chapter left off: the CPU asks the nearest cache level first, and the level answers at once. Yes — or no. | Ta tiếp tục ngay từ chỗ chapter trước dừng lại: CPU hỏi tầng cache gần nhất trước, và tầng đó trả lời ngay lập tức. Có — hoặc không. |
| 1 | `inside` | This time we follow the memory request right to the level's door. It answered… but HOW does it know whether the value is inside? Let's go in after it. | Lần này ta đi theo memory request tới tận cửa của tầng cache. Nó vẫn trả lời ngay… nhưng bằng cách nào nó BIẾT dữ liệu có ở trong hay không? Chui vào theo nó nào. |
|  | **interior** — Act 1 — inside the cache: lines, and the cost of asking every line | | |
| 2 | `rows-of-compartments` | So this is what one cache level looks like inside: a stack of identical compartments. Each one keeps a copy fetched from RAM — a chunk of memory that always travels together. Each of these compartments is called a Cache Line. | Đây là bên trong một tầng cache trông như nào: một dãy ngăn giống hệt nhau. Mỗi ngăn giữ một bản sao được lấy từ RAM — một khối dữ liệu luôn đi cùng nhau. Mỗi ngăn này gọi là một Cache Line. |
| 3 | `find-a` | A request arrives. Is the value it needs in one of these lines? The honest way to find out: check every line, one by one. Count the checks — one, two… six. Found it, in the sixth line. | Một request tới. Dữ liệu nó cần có ở đây không? Cách thật thà nhất để biết: kiểm tra từng line một. Đếm số lần kiểm nào: một, hai… sáu. Tìm thấy rồi, ở line thứ sáu. |
| 4 | `find-b` | Another request. Same drill: line by line… all eight lines this time. Found in the very last one. Every check takes work — and we just did fourteen of them for two requests. | Thêm một request nữa. Lại lần lượt từng line… tám line luôn. May mà thấy ở line cuối cùng. Mỗi lần kiểm đều tốn công — mà vừa rồi là mười bốn lần kiểm chỉ cho hai request. |
| 5 | `too-expensive` | If every request has to ask every line, answering will stay slow — far slower than this small fast store is supposed to be. There has to be a better place to START looking. Where should the cache look first? | Nếu mỗi request đều phải hỏi tất cả các line, việc trả lời lúc nào cũng chậm — chậm hơn hẳn cái kho nhỏ mà nhanh này đáng lẽ phải thế. Phải có cách chọn sẵn chỗ để BẮT ĐẦU tìm. Cache nên nhìn vào đâu trước? |
|  | **mapping** — Act 2 — sets, and how many lines a set should hold | | |
| 6 | `into-groups` | Try this: split the lines into small groups. Watch the two request cards with the same marking — both land in the same group, always. From now on a request only ever asks its own group. A group of lines like this is called a Set. | Thử thế này: chia các line thành từng nhóm nhỏ. Nhìn hai thẻ request có cùng một dấu hiệu này — cả hai đều đi tới cùng một nhóm, lúc nào cũng vậy. Từ giờ một request chỉ hỏi đúng nhóm của NÓ thôi. Một nhóm line như vậy gọi là một Set. |
| 7 | `how-many-per-set` | Now a design question: how many lines should one Set hold? Start with the simplest choice there is — exactly one line in every set. | Giờ tới một câu hỏi thiết kế: một Set nên chứa bao nhiêu line? Bắt đầu từ lựa chọn đơn giản nhất có thể — mỗi set đúng một line. |
| 8 | `one-line-stream` | Four requests come in. Watch the set they both land in: one request settles into its single line… then the other same-marked one arrives, needs THE SAME single slot, and the first has to give it up. Then it happens all over again. Four requests, four misses — not one second visit is ever served. | Bốn request lần lượt tới. Nhìn set mà cả hai cùng đi tới này: một request vào nằm ở line duy nhất… rồi request kia có CÙNG dấu hiệu tới, cũng cần ĐÚNG chỗ duy nhất đó, nên request trước đành nhường. Rồi y chang một lần nữa. Bốn request, bốn lần miss — chẳng ai quay lại lần hai mà được phục vụ cả. |
| 9 | `name-direct` | An arrangement with exactly one line per set is called Direct Mapping: every address has exactly one possible home. Simple — but two addresses that share a home can never live there at the same time. | Cách sắp xếp mà mỗi set có đúng một line gọi là Direct Mapping: mỗi địa chỉ có đúng một chỗ nó được phép ở. Đơn giản thật — nhưng hai địa chỉ chung một chỗ thì không bao giờ ở lại cùng nhau được. |
| 10 | `two-line-stream` | Give every set a second line, and run the exact same four requests again. The second one arrives at the same set… and simply takes the line next to the first. They both stay! Same requests — two hits this time. (Meanwhile a few quieter requests fill the other sets for later.) | Cho mỗi set thêm một line nữa, rồi chạy lại đúng bốn request ban nãy. Request thứ hai tới cùng một set… và cứ thế nằm vào line trống kế bên. Cả hai cùng ở lại! Vẫn các request đó mà lần này có tới hai hit. (Trong lúc đó vài request lặng lẽ hơn lấp các set khác, để lát nữa dùng.) |
| 11 | `name-set-assoc` | A set that holds several lines can keep several same-set addresses at once — this is Set Associative Mapping. Two lines per set, like here, is called a 2-way set associative cache. | Một set chứa được nhiều line thì giữ được nhiều địa chỉ cùng set một lúc — đây là Set Associative Mapping. Hai line một set như thế này gọi là cache 2-way set associative. |
| 12 | `one-giant-set` | Now push it all the way: ONE set holding all eight lines. Any request may land anywhere — no two addresses can ever fight. But watch what answering costs: every request must compare against EVERY line at once. The old search is back — moved into the machinery. All lines in a single set: Fully Associative Mapping. Real caches settle in the middle. | Giờ đẩy tới tận cùng: MỘT set chứa cả tám line. Request nào cũng muốn ở đâu thì ở — chẳng hai địa chỉ nào tranh nhau bao giờ. Nhưng nhìn cái giá của việc trả lời này: mỗi request phải so với TẤT CẢ các line cùng một lúc. Kiểu tìm kiếm ban nãy quay lại rồi — chỉ là chuyển vào trong phần cứng. Tất cả line chung một set: Fully Associative Mapping. Cache thật thì nằm ở khoảng giữa. |
|  | **lookup** — Acts 3–4 — the address opens, and one full lookup runs | | |
| 13 | `the-address` | Back to one single request. It has been carrying something the whole time: its Memory Address — the identity of the value the CPU wants. Look closely: an address is not one thing. It is several pieces of information packed together, because each piece has a different job. | Giờ quay lại với một request duy nhất. Nãy giờ nó luôn mang theo một thứ: Memory Address — chính là địa chỉ của dữ liệu CPU đang cần. Nhìn kỹ nhé: địa chỉ không phải chỉ một thứ — nó là vài mảnh thông tin gói lại với nhau, vì mỗi mảnh làm một việc khác nhau. |
| 14 | `the-index` | The first piece breaks off and flies to one particular set. That set alone opens its lines; the others take no part. You have watched this piece work ever since the lines grouped — it is what routes a request. Its name is the Index. | Mảnh thứ nhất tách ra và bay tới đúng một set. Chỉ set đó mở các line của nó ra; mấy set còn lại không liên quan. Mảnh này từ hồi chia nhóm đã hoạt động ngay trước mắt bạn rồi — nó là thứ dẫn đường cho request. Tên của nó là Index. |
| 15 | `the-tag` | The next piece visits the stored names inside that set: the first line answers not me — the second answers me. The piece being compared is the Tag — the name each line answers to. A matching tag IS a Cache Hit: that is what hit has always meant. | Mảnh tiếp theo đi so với các cái tên đang cất trong set: line đầu trả lời không phải tôi — line thứ hai trả lời chính tôi. Mảnh được đem đi so sánh gọi là Tag — cái tên mà mỗi line nhận lấy. Tag trùng khớp — đó CHÍNH LÀ Cache Hit. Hoá ra suốt nãy giờ hit nghĩa là vậy. |
| 16 | `the-offset` | The last piece drops onto one word inside the open line — the Word Offset: which of the line’s words the CPU actually asked for. Off that word goes, home to the CPU. This whole question and answer, address to word, is a Cache Lookup. | Mảnh cuối cùng đậu xuống đúng một từ bên trong line đang mở — Word Offset: chính xác là từ nào trong line mà CPU cần. Từ đó lập tức bay về CPU. Toàn bộ quá trình hỏi-đáp này, từ địa chỉ tới từ dữ liệu, gọi là một lần Cache Lookup. |
|  | **miss** — Act 5 — no tag matches: the miss and the line that comes home | | |
| 17 | `no-match` | Another request, another lookup. The index picks its set… the tag knocks on its lines: one is free, and the occupied one answers not me. No stored tag matches. That is what a Cache Miss is: the right set was asked, and nothing inside carried that name. | Một request khác, một lần lookup khác. Index chọn set của nó… tag đi gõ cửa từng line: một line còn trống, còn line có chủ trả lời không phải tôi. Không tag nào khớp cả. Đó là bản chất của Cache Miss: đã hỏi đúng set rồi, nhưng bên trong không ai mang cái tên ấy. |
| 18 | `fill-from-ram` | A miss never ends the story — the request rolls on to RAM, which always has the value. And watch what travels back: not just one word — the WHOLE line, tag and all its words together, settling into the set’s free line. This trip is called Cache Line Loading. | Miss không có nghĩa là hết — request đi tiếp ra RAM, chỗ nào dữ liệu cũng có sẵn. Và nhìn xem thứ gì quay về này: không chỉ mỗi từ cần dùng — mà NGUYÊN cache line, tag và cả bốn từ cùng nhau, đậu vào line còn trống của set. Chuyến đi này gọi là Cache Line Loading. |
| 19 | `serve-miss` | Now the line lives in the cache, and the lookup finishes like any hit: offset picks the word, the word goes home. A miss costs one RAM round trip — after that, requests for this line become hits. | Giờ line đã nằm trong cache, lookup kết thúc y hệt một hit: offset chọn từ, từ bay về. Miss tốn đúng một chuyến đi-về RAM — sau đó, mọi request tới line này đều trở thành hit. |
|  | **replace** — Act 6 — the full set: which line must leave? | | |
| 20 | `set-full` | One more request — and its set is FULL: both lines are occupied, no tag matches. The new line has to come in… but there is nowhere to put it. One of the two must leave. Choosing the one that leaves is called Replacement. But which one should it be? | Thêm một request nữa — mà set của nó ĐẦY rồi: cả hai line đều có chủ, không tag nào khớp. Line mới bắt buộc phải vào… nhưng còn chỗ nào đâu mà đặt? Một trong hai line kia phải rời đi. Việc chọn line nào rời đi gọi là Replacement. Nhưng nên chọn ai? |
| 21 | `fifo` | One simple answer: look at when each line arrived. The one that has been there LONGEST gives up its slot — the earliest arrival drifts away, and the new line settles in. First in, first out. That rule has a name: FIFO. | Một câu trả lời đơn giản: nhìn xem mỗi line đến lúc nào. Line nào ở đó LÂU NHẤT thì nhường chỗ — line tới sớm nhất rời đi, line mới vào thay. Vào trước, ra trước. Quy tắc này tên là FIFO. |
| 22 | `lru` | Rewind the same moment — and answer differently: look at when each line was last USED. The one untouched for the longest time leaves instead — notice it is the OTHER one. Least recently used out. That rule is LRU. Same full set, different rule, different victim. | Tua lại đúng khoảnh khắc đó — và trả lời bằng cách khác: nhìn xem mỗi line được DÙNG gần nhất lúc nào. Line lâu nhất không ai đụng tới sẽ rời đi — kỳ này là line CÒN LẠI đấy. Ít được dùng gần đây nhất thì out. Quy tắc này là LRU. Cùng một set đầy, khác luật chơi, khác người phải đi. |
| 23 | `serve-replaced` | With a slot free, the new line moves in and the lookup finishes: offset, word, home. Replacement only ever happens on a miss in a full set — a hit never disturbs anyone. | Vừa có chỗ trống xong, line mới vào ở ngay và lookup kết thúc: offset, từ, về nhà. Replacement chỉ xảy ra khi miss trong một set đã đầy — còn hit thì chẳng làm phiền ai cả. |
|  | **replay** — Act 7 — the whole lookup, replayed without interruption | | |
| 24 | `full-pass` | Watch it once, all the way through, no interruptions: a request arrives… its index chooses a set… its tag compares… a match opens the line… the offset picks the word… and the word goes home. Every piece of this trip, you have already seen. | Nhìn lại trọn vẹn một lần, không ngắt quãng: request tới… index chọn set… tag đi so… khớp thì line mở ra… offset chọn từ… và từ bay về nhà. Từng mảnh của chuyến đi này, bạn đều đã thấy rồi. |
| 25 | `the-answer` | So how does a cache know? It never guesses. The address splits: the index finds the one set that might hold the value, the tag asks whether it is really there, and the offset carries the right word home. When no tag answers, the line comes up from RAM — and a full set gives one line up, by rule. That is everything behind every hit and every miss you will ever see. | Vậy cache biết bằng cách nào? Nó không bao giờ đoán. Địa chỉ tách ra: index tìm đúng một set có thể chứa dữ liệu, tag hỏi xem nó có thật sự ở đó không, còn offset mang đúng từ cần dùng về. Nếu không tag nào trả lời, cả line được kéo lên từ RAM — và một set đầy sẽ nhường một line, theo luật chọn sẵn. Đó là tất cả những gì đứng sau mỗi hit và mỗi miss bạn sẽ gặp. |

*Beat durations (`narration/beats.ts`): act totals 38.0s · 52.6s · 27.0s · 20.4s · 28.2s · 18.6s — **chapter total 184.8s**.*

## 6 · Camera Plan

The camera never pans inside a scene during a beat; it re-fits per scene and
crossfades (450 ms) at seams while the protagonist holds its exit anchor. All
rects are derived (see `06_LAYOUT_PROOF.md` §5–§8):

| Scene | Bbox (world units, derived) | Pad | Why |
|---|---|---|---|
| `entry` | x 106…1890 · y 225…538 | 0.95 | Chapter-02 ladder + question pill — the memory the learner re-enters; the zoom begins at L1's door |
| `interior` | x 118…1422 · y 44…940 | 0.94 | Panel + CPU dock + counter + east "Cache Line" term dock |
| `mapping` | x 118…1326 · y 44…940 | 0.94 | Panel + tally board (RAM deliberately absent) |
| `lookup` | x 118…1014 · y −48…940 | 0.94 | Panel + address stage + rising chips (masthead air) |
| `miss` / `replace` | x 118…1562 · y −48…940 | 0.94 | The journey now reaches RAM — both always in frame (the trip IS the miss's cost) |
| `replay` | x 118…1014 · y −48…940 | 0.94 | Same frame as lookup: the learner recognises the arena |

Continuity rule (owner spec "camera should naturally zoom into the cache
already shown previously"): the entry scene re-uses Chapter 02's axis, rung
sizes, gaps and colours verbatim; the interior scene's L1 door dock sits one
spark-radius west of the panel exactly as the entry's L1 door sits one
spark-radius west of the L1 rung.

## 7 · Visual Layout

* **The level as a magnified panel** (`PANEL`, content-derived 570×684): header
  band with the level's name and the "inside L1 Cache" orientation chip; 8
  countable rows (56 high), each = tag chip (108×40) + 4 word cells (82×40) at
  fixed pads. Empty tag slots show as dashed structure, never fake content.
* **Sets as braces** (stroke-only, set-coloured `#818cf8 #34d399 #fb7185 #fbbf24`),
  wrapping rows with `SET_PAD`; rows never move when braces regroup.
* **The protagonist** (golden spark) carries a mini request card (identity
  letter, body colour per request); stored tags keep the card's colour as their
  tint, so "the same request lives here" reads by colour.
* **Request identity by stripe:** an address's set-membership is drawn as the
  card's stripe (set colour), foreshadowing the Index *as behaviour* before it
  is named.
* **Instruments:** compare counter (north-east), tally board (east, mapping
  only), RAM panel (east, miss/replace only) — Visual Economy: each exists only
  in the scene that uses it.
* **Pill docks:** north (questions, mapping terms, b25 question), south-centre
  (lookup terms), south-east (`Cache Line Loading`, `Replacement`, `FIFO`,
  `LRU`), south-west (verdicts), east-row (`Cache Line`), masthead (checkpoint
  ticker + returning question). Term pills wrap their sub to ≤2 lines clamped
  to `TERM.maxW`.
* **Type/colour:** Quicksand (UI) + JetBrains Mono (request letters); CPU
  `#fb923c`, cache `#22d3ee`, RAM `#a78bfa`, hit green `#4ade80`, miss/wait
  `#fb7185`, question gold `#facc15`, terms `#7dd3fc`.

## 8 · Transition Design

* **Scene seams:** the spark holds at each scene's path-end anchor during the
  450 ms crossfade (`runtime.seamPosition` = path end, gate-verified); the next
  scene's path resumes the same journey (CPU dock ↔ L1 door ↔ RAM block ↔
  home) — the protagonist never teleports inside a shot.
* **entry → interior:** the door anchor shifts from the ladder's L1 dock to the
  panel's west dock — same role, same rule (one spark-radius clear of the
  level's west face); the crossfade covers the re-anchoring while the camera
  *enters* the level.
* **Arrangement changes (mapping):** brace morphs inside the beat with exported
  windows (`FRAME_STATE`, `GIANT_RETURN`); rows and occupancy animate
  explicitly (fade-out/in at 0.06/0.92–0.95) so nothing pops.
* **The address split:** card → seams → chips rise out (`SPLIT_TRAVEL`), each
  named on landing; the card folds away by `CARD_FOLD` before anything else
  needs the north band.
* **The LRU rewind:** a labelled "same moment, replayed" wash and an occupancy
  restore event (0.12) — the *mechanics stay honest* (G2 disappears as A2/B2
  return), never a magic state swap.
* **Endings:** b25 rests with `effect: 'loop'` — the chapter idles at home, not
  on a black end-card.

## 9 · Learning Checkpoints

Interactive prediction is platform-deferred (see `00_JOURNEY_DEFINITION.md` §8);
the chapter ships its checkpoints as created-question pauses:

1. **CP1** (b5, end `interior`): counter finishes its climb to 14 and the "where should it look first?" pill takes the dock — predict before sets appear.
2. **CP2** (b8→b9, `mapping`): four misses force "what if the set had a second slot?" — answered by the immediate 2-way replay.
3. **CP3** (b15, `lookup`): each tag comparison is held ≈2.3s before resolving — the learner predicts the verdict before it lands.
4. **CP4** (b20, `replace`): "which one should leave?" is posed and left open (0.6→0.98) before FIFO demonstrates an answer.
5. **CP5** (b24, `replay`): the silent full pass — narrate internally, then the ticker confirms each station by name.

## 10 · Final Replay

Act 7 (b24–b25) replays the lookup **uninterrupted, zero new concepts** (gate-enforced: every required term in Act 7 must already exist earlier):

`C1 request` → masthead ticker: *"Memory Address splits"* (0.12) → *"Index selects one Set"* (0.30) → *"Tag compares"* (0.50) → match at row 2 → *"the matching Cache Line opens"* (0.58) → *"Word Offset picks the word"* (0.66) → word home → *"the word goes home"* (0.85). b25: ticker bows out; the opening question *"How does it KNOW?"* returns to the masthead [0.4–0.85] over the resting request — the answer is the journey itself. `VERDICTS[fullPass]` stamps one final `Cache Hit` at the verdict dock (0.78).

## 11 · Self Educational Audit

The spec's rejection criteria, answered against the shipped artifacts and the
executable gates (verdict citations: `06_LAYOUT_PROOF.md`, `07_QA_AUDIT.md` §G4):

| Spec audit criterion | Verdict | Evidence |
|---|---|---|
| Crowding / overlapping on-canvas items | **PASS** — 11 crowding defects found in review and removed; docks + disjointness now gate-proven | 06 §6–§8; defect list 06 §9 |
| Textbook-style mapping diagram (terms before behaviour) | **PASS** — every term first *spoken* exactly at its reveal beat after the behaviour; enforced | scope gate §3 (16 terms incl. exact beat indices) |
| Narrator-driven animation ("telling instead of showing") | **PASS** — streams/tally/braces/caravan/beams carry every claim; the narration only ever counts what the renderer counts (§4.5 gate: 14 checks, 4/0/4, 4/2/2, 8/4/4 tallies derived from the same tables) | smoke §2 |
| Missing required concepts | **PASS** — all 17 present | scope gate §2 |
| Forbidden topics | **PASS** — 12 topic families machine-checked absent (incl. any bit/byte/hex mention) | scope gate §1 |
| Protagonist rule (one Memory Request) | **PASS** — one `active` actor per beat; aux requests decayed, crowd-role only; no stray protagonist nouns | journey §4; scope gate §3.5 |
| Starts from Chapter 02's ending / camera enters cache | **PASS** — entry scene metrics = Ch-02 ladder mirror; L1 door dock = panel west dock rule | layout proof §8; beats b0–b1 |
| Order problem → need → animation → understanding → terminology | **PASS** — questions precede solutions (QUESTION windows precede term beats: b5q→b6t, b7q→b9t, b20q→b21t; counter hands the dock to its question) | layout proof §4.2–4.3, §6.6 |
| One new concept per beat | **PASS** — every beat mutates exactly one story dimension; term reveals are the only beats that add vocabulary, one per beat (`term2` = `Cache Lookup` summarises, adds no behaviour) | beats; smoke §2 term table |
| No new concepts in the final replay | **PASS** — gate-enforced | scope gate §3.4 |
| Bit layouts | **PASS** — purpose-only jobs; "bit(s)/byte(s)" absent by regex | scope gate §1 |
| Bilingual, spoken register | **PASS** — 26/26 beats EN+VI, differing, length-ratio bounded; locked terms stay English inside VI lines (§15) | scope gate §4 |
| 11 deliverables produced | **PASS** — this document | §1–§11 here |

**Verdict:** the chapter satisfies the owner spec's audit criteria; non-spec
pedagogy findings are tracked in `09_PEDAGOGICAL_AUDIT.md`.
