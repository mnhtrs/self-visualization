---
guiding_question: "Can a learner extract any of the 12 targeted misconceptions from Topic 02 Chapter 01's geometry, animation, or narration?"
primary_consumer: "QA Auditors, Curriculum Guardian, AI Agents"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/curriculum/CURRICULUM_GUARDIAN_T02_DRAFT.md"
referenced_by: []
---

# Adversarial Pedagogical Audit — Topic 02 / Chapter 01

**Date:** 2026-08-14 · **Method:** frame-by-frame inspection of the real Viewer
(headless Chromium, 1400×850 and 1140×660), EN + VI, against the 12 target
misconceptions. Verdict per item: the on-screen evidence that BLOCKS it.

| # | Misconception | Blocking evidence (observed on canvas) | Verdict |
|---|---|---|---|
| 1 | "The Program turns into the Process." | The Program card is painted at its shelf position in every frame of all 14 beats (b01 and b13 pixels identical modulo ambient stars); the Process cell is born 540+ world px away by a creation pulse + boundary draw-in; different shape (breathing cell vs. document with folded corner) and different colour family (green vs. cyan). B05 shows both simultaneously while narration only asks. | BLOCKED |
| 2 | "The OS is the Process." | The OS band and the Process cell coexist in every post-birth frame; the OS visibly *emits* the creation signal (charge → east-port emission) and remains in place while Processes die; term pill "Process" resolves onto the cell, never the band. | BLOCKED |
| 3 | "PID is the Program's ID." | The PID chip flies OS→cell and docks inside a cell; the layout gate proves `chip S_i ∩ Program = ∅` for all spots; the Program card never carries any chip; narration: "the identity of one Process, and no other." | BLOCKED |
| 4 | "PID is the Process itself." | The chip is a small tag docked inside an already-living, already-observed cell (cells lived for 3 beats before any chip existed); the pill sub reads "the number that is this Process's identity." | BLOCKED |
| 5 | "A Process is just another name for Program." | The rupture beat (b05) holds both objects on screen with sequential pulses and a still pause; b10 shows a Process dying while the Program persists — an object and its name cannot survive the other's death if they were identical. | BLOCKED |
| 6 | "One Program can have only one Process." | b07–b08: two, then three cells born from the same card via the same OS route, coexisting; narration counts them from the PROCS table. | BLOCKED |
| 7 | "When a Process dies, the Program dies." | b10 termination: dissolve is local to cell A; the Program painter takes zero input from Process state (immutability by construction); narration states the contrast after it is visible. | BLOCKED |
| 8 | "The second Process is the first Process restarted." | b11: the relaunch is born at a DIFFERENT spot with a DIFFERENT PID (4402 ≠ 4312, both drawn from the same story table the narration reads); the smoke gate asserts spot ≠ and pid ≠. | BLOCKED |
| 9 | "Processes form a queue." | Layout gate proves: no 3 spot centres within 12° of collinear; nearest-neighbour spacing spread > 30; both axes used. Births fill scattered spots in non-monotonic x-order (S0→S1→S2→S3→S4→S0→S2). | BLOCKED |
| 10 | "Processes are taking turns." | All alive cells' activity bars animate simultaneously and continuously (phases offset by spot, never gated on each other); no cell ever pauses because another is born; climax deaths are C→E→B→D — anti-FIFO, no rotation pattern. | BLOCKED |
| 11 | "The chapter is teaching process states." | No state names anywhere (scope gate: ready/waiting/blocked/terminated absent EN+VI); a cell is only ever visually alive-or-absent; termination is a single dissolve, not a labelled transition. The bridge deliberately OPENS the execution question without answering it. | BLOCKED |
| 12 | "The chapter is teaching scheduling." | No queue geometry, no counters, no CPU-allocation animation; the machine emblem stays quiet and untouched by cells; scope gate bans scheduler/queue/time-slice/preempt EN+VI. | BLOCKED |

**Fixes applied during this audit (implementation changed, not documented-around):**
1. b00/waiting narration originally said the machine "has nothing to do / is idle" —
   contradicted canon C-09 (work enters continuously). Rewritten to re-affirm the running
   machine and re-open C-10 verbatim.
2. b10 narration originally said "ready to be launched again" — "ready" is CH03-owned
   vocabulary; scope gate caught it; rephrased to "untouched, and it can be launched again."
3. Spot S3/S4 coordinates adjusted after the anti-queue proof found one near-collinear
   triple and an over-uniform nearest-neighbour spread.

---

## Final Pedagogical Refinement (2026-08-14, pre-freeze review round)

A deep pedagogical review of the passing implementation found three release-blocking
issues. All three were fixed IN THE IMPLEMENTATION and locked with new gate checks.

### Mandatory Fix #1 — "alive = executing" visual ambiguity (highest priority)
- **Problem:** the Process cell's interior "activity bars" swept their widths with `s.t`
  while a cell was alive. Muted-narration test FAILED: a learner watching a long-lived cell
  could reasonably conclude "the CPU is executing this Process right now" purely from the
  motion — contradicting the bridge question ("does an existing Process execute every
  moment it is alive?") that CH03 owns.
- **Fix (visual model, not narration):** `renderers/world.ts` — the interior marks are now
  STATIC content marks with constant widths from the new named metric
  `CELL_BAR_FRACS` (metrics.ts); the interior fill no longer oscillates. Lifetime presence
  is kept by a RESTRAINED boundary-only shimmer (frequency halved to 0.0016, amplitude cut
  to 0.08 stroke / 0.03 glow) plus the unchanged creation/termination animations — the
  entity persists without implying CPU work. Also renamed/reframed: narration no longer
  calls a Process "a running instance" or "living thing" (b05, b06, b07, b11, Process pill
  sub → "an execution instance the OS created").
- **Misconception prevented:** #5 "Process = currently executing code",
  #15 "Processes execute simultaneously because all animate".
- **Evidence:** critical test re-run — same cell (S1) screenshotted ~1.4 s apart while
  alive (`review/shots-t02c01/alive-t1.png` / `alive-t2.png`): interior byte-stable, only
  the faint boundary glow differs (782 px above 8% fuzz in a 15 750 px crop, all located on
  the boundary ring; interior marks identical). The Process reads as the SAME persistent
  entity, not as a busy machine. Gate: smoke now asserts `CELL_BAR_FRACS` exists, is
  per-bar, constant, and that the bridge keeps the open question (5 new checks); scope gate
  bans "running instance / thực thể đang chạy" in learner text.
- **Bridge strengthened:** with a still interior, b13's question ("is it actually executing
  every moment it is alive?") now points at something the visuals genuinely left open.

### Mandatory Fix #2 — "A program does not [have a lifetime]" falsehood
- **Problem:** b10 ended "A Process has a lifetime. A program does not." — teaches the
  false proposition that programs cannot have lifetimes (files do). Violates No Unlearning.
- **Fix:** b10 EN/VI rewritten to the intended distinction: "The Process's execution
  lifetime has ended… The program remains as the stored artifact… The lifetime that ended
  belonged to the Process, not to the program." Verified by repo-wide search: no remaining
  "program does not / no lifetime / chương trình thì không / không có vòng đời" phrasing.
- **Misconception prevented:** "programs are eternal objects with no lifecycle" (a new
  falsehood the earlier wording would have installed).
- **Gate:** scope gate now fails on any recurrence of the falsehood, EN+VI.

### Mandatory Fix #3 — recipe/cooking analogy removed
- **Problem:** b06 explained "The program is the recipe… The Process is the cooking" —
  frames a Process as an *activity* rather than an OS-managed execution instance
  (misconception #6), and "cooking" has no identity/lifetime/manageability semantics.
- **Fix:** b06 EN/VI replaced with direct ontology, leaning on the already-sufficient
  visual model: "The program stays what it always was — a stored list of instructions. The
  Process is an execution instance the OS created from that program: a separate entity
  that the OS manages, with an existence of its own." No replacement analogy introduced.
- **Gate:** scope gate bans recipe/cooking/công thức/nấu in learner-visible text.

### Additional issues found in the secondary precision audit (all fixed)
| Issue | Location | Fix |
|---|---|---|
| "The OS never had this problem" — anthropomorphic; also implied the identity problem was fake | b09 | Rewritten to the conceptual relation: several instances → OS needs to distinguish them → each Process has an identifier, associated at creation ("gave it a number" → "associated a number with that Process"). Scope-gated. |
| PID pill sub "the number that IS this Process's identity" — chip-is-the-Process drift | story.ts PID_TERM | → "the identifier of exactly one Process" (EN), "định danh của đúng một Process" (VI) |
| "this new living thing" / "what is running?" at the rupture — pre-names the entity as *running* before any execution semantics exist | b05 | → "the new entity… existing on its own. …then what did the OS create?" (also re-aims the question at the chapter's actual central question) |
| "Two running instances" / "The first one keeps living" | b07 | → "One stored program. Two independent Processes." / "still there, untouched" |
| "a new life … the two still living" — biological framing over execution framing | b11 | → "a new, separate Process with its own identity and its own lifetime — and the two existing Processes were never disturbed" |

### 20-item accidental-implication sweep (post-fix)
Items 1–4, 6–14, 16–20: unchanged blocking evidence from the original audit table (visual
model untouched except the interior stillness). Item 5 (Process = executing code) and
item 15 (all animate ⇒ all execute simultaneously): now blocked by the static interior —
no cell ever displays motion that could be read as CPU work; only creation and termination
animate, and both are lifecycle events, not execution. Verdict: no unresolved implication.

### Muted-narration test (mandatory, PROCESS ALIVE)
Frame `alive-t1.png` (cell alive for ~6 s): learner sees a stable bounded green cell with
fixed content marks and a "Process" caption. Reasonable inference: "this exists and
persists." Nothing moves that could mean "the CPU is on it right now." Frame `alive-t2.png`
1.4 s later: same cell, same identity, same contents, lifetime continuing. PASS.

---

## Deep Refinement Round 2 (2026-08-14, owner-directed, pre-freeze)

### Changes and the misconceptions they close

| Change | Misconception prevented (round-2 list #) |
|---|---|
| New `why-the-os` beat: shared machine → artifact can't manage it → system software → OS | #4 "OS is just a visual gate", #6 "OS is an arbitrary magical creator", #5 "OS is the CPU" (the CPU is now visibly one of the resources the OS manages, plus the separate east emblem) |
| OS internal structure: intake port → management core (3 function rows) → creation port → resource strip | #4, #6; also makes "OS creates AND manages" visually grounded (#21) |
| OS internal causal sequence (intake lights → core wakes → create row works → east port emits → birth) with per-stage story windows | "Program passed through a gate and transformed" (#2, #3) — the request enters a port; nothing crosses the OS body |
| Launch narration: "the program itself stays on its shelf — what travels is only the launch request" | #3 "Program travels through OS" |
| Birth narration: "It was not hiding inside the program file… The OS created it" | #14 "multiple Processes are copies of the Program artifact"; "Program contains the Processes" |
| Second-launch narration: "Launching one stored program twice caused the OS to create two independent Processes" | #13, and blocks the forbidden "the Program creates Processes" agency inversion |
| PID redesigned as ASSOCIATION: focus ring → dashed logical link → chip resolves in place → link releases; identify-row pulses | #22 "PID is physically transmitted like a data packet", #11 "PID is Process" |
| "Process" pill moved to the concept band above the whole field; per-cell captions carry the class name | #24-type error: pill naming ONE instance instead of the class |
| Deterministic variation of birth-window spans (gate-asserted distinct) | conveyor-belt reading of repeated creation (#15/#16 adjacent) |
| VI gloss discipline: Process (tiến trình), PID — mã định danh tiến trình, OS — hệ điều hành at first introduction only; "progress" banned | terminology drift (round-2 §0) |

### Round-2 adversarial audit (22 items)
Items 1–3, 7–20 carry the evidence already recorded above (unchanged mechanisms).
New/strengthened verdicts:
- #4/#6 (OS gate/magic): BLOCKED — the OS now shows WHY it exists (resource strip:
  the shared machine) and WHAT it does (three observed functions, labelled only after
  observation).
- #5 (OS = CPU): BLOCKED — the CPU appears twice as NOT-the-OS: as a resource slot
  inside the strip the OS manages, and as the quiet east emblem the Processes face.
- #21 (Process exists independently of OS management): BLOCKED — every lifecycle event
  visibly involves an OS row (create/identify/manage); the manage row acknowledges the
  termination.
- #22 (PID = physical packet): BLOCKED — nothing travels; a logical dashed link draws and
  releases while the chip resolves in place inside its owner.
No unresolved major misconception.

### Muted-narration re-test of the new OS sequence
Frames C (intro), D (request mid-flight), E (intake), F (core wakes / emit), G (birth):
with narration muted the geometry alone reads "the document stayed; a signal went into
the pink system's port; the system worked inside; something new appeared from its far
side." The Program card is pixel-stable throughout. PASS.

**Final quality bar:** with narration muted, the frame sequence alone reads:
program stays → OS acts → new entity appears → both visible → more entities → identical →
numbers disclosed one-per-entity → one entity ends, program remains → relaunch = new number →
interleaved births/deaths at scale → two survivors + still program. This reconstructs
PROGRAM → OS INTERVENTION → NEW PROCESS → PROGRAM ≠ PROCESS → MULTIPLE → IDENTITY → PID →
LIFETIME → INDEPENDENT INSTANCES. **PASS.**
