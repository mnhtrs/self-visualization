---
guiding_question: "How is Topic 02 Chapter 01 (Process — From Program to Managed Execution) produced so that the learner discovers Program ≠ Process, PID, lifetime and independent instances purely from observation?"
primary_consumer: "Implementation Engineers, QA Auditors, AI Agents"
depends_on:
  - "docs/curriculum/CURRICULUM_GUARDIAN_T02_DRAFT.md"
  - "docs/curriculum/CURRICULUM_GRAPH.md"
  - "docs/curriculum/CURRICULUM_CONSTITUTION.md"
  - "docs/pedagogy/PEDAGOGICAL_SYSTEM.md"
  - "docs/constitution/PHILOSOPHY.md"
  - "docs/constitution/NARRATIVE_FRAMING.md"
  - "docs/constitution/VISUAL_LANGUAGE.md"
  - "docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md"
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# Chapter Production Blueprint — Topic 02 / Chapter 01
## "Process — From Program to Managed Execution"

**Chapter ID:** `topic-02-operating-systems--ch-01-process-from-program-to-execution`
**Slug:** `process-from-program-to-execution` · **Topic slug:** `operating-systems` · **Accent:** `#f472b6`
**Status:** Blueprint (locked) → Implementation

---

## 0. PHASE 0 — Constraint Map (source-of-truth reconstruction)

### 0.1 Authority resolution
`PROJECT_STATE` → charter/governance → constitution (PHILOSOPHY / VISUAL_LANGUAGE /
NARRATIVE_FRAMING) → CURRICULUM_CONSTITUTION → CURRICULUM_GUARDIAN_T02_DRAFT →
PEDAGOGICAL_SYSTEM → CHAPTER_PRODUCTION_STANDARD → pipeline docs → code as evidence.
No conflicts were found that require adjudication; the T02 Guardian §5 (CH01 canonical
boundary) explicitly supersedes the stale pre-existing CH01 story idea (which previewed
states/scheduling — a documented boundary violation to be avoided, not reproduced).

### 0.2 Pedagogical constraints (binding)
- P1 One chapter = ONE mental-model transformation (PEDAGOGICAL_SYSTEM §3; Constitution Art. VI).
- P2 One beat = one causal state mutation (§4.3; PHILOSOPHY §5.1).
- P3 Observation before explanation; animation T0 → observation T1 → narration T2 (VL §19; CPS §5.1).
- P4 Mental model before terminology (§4.1; NF §13 Knowledge Reveal Law).
- P5 Exactly ONE experiential climax, silent, visual, at scale (§4.7; NF §17).
- P6 Cognitive replay: opening must reactivate the T01 exit model (§4.8; Guardian T02 §4).
- P7 Single source for quantities (§4.5): every spoken/drawn number derives from story data.
- P8 Affirmative state derivation (§4.6): no state as negation of another.
- P9 Curiosity bottleneck genesis (NF §16): every scene/section born from the previous question.
- P10 No unlearning (PHILOSOPHY §3): late PID *reveal* must be narrated as *disclosure*
  ("each got its number the moment it was created"), never as late assignment.

### 0.3 Curriculum / boundary constraints
- C1 Central question (Guardian T02 CH01): *What does the OS actually create when you launch a program?*
- C2 Mental model: *A Program is not a Process. A Process is a managed execution instance created and maintained by the OS.*
- C3 Scope: Program ≠ Process; OS as creator/manager; identity; PID; lifetime; multiple independent instances. NOTHING ELSE.
- C4 Explicit non-goals (leak = defect): Ready/Running/Waiting/Terminated state machine (CH03),
  context switching (CH03), scheduling/scheduler/Ready Queue/time slice/preemption (CH04),
  address space / memory layout internals (CH02), threads (CH05), race/concurrency (CH06/T06),
  exit codes, zombie, program-loading re-teach (Guardian T01 §5 binding condition 2).
- C5 Debt facet: resolves exactly **F1 — ownership of the system** (Axis I of D0). Extends C-09/C-10.
- C6 Entry state: T01 complete — machine executes continuously; C-10 (who decides what enters) is
  the open debt. Do NOT re-teach loading/instruction cycle/cache/pipeline.
- C7 Terminology ownership: `Process` (owned here), `PID` (owned here). `Program`, `CPU`, `OS`,
  `storage` are already-known T01 vocabulary. "running" only as ordinary language.
- C8 Permitted open loop at end: *a Process has identity and lifetime — but does it actually
  execute continuously the whole time it exists?* (bridge to CH02/CH03).

### 0.4 Terminology reveal rules (locked)
| Term | Reveal beat | Precondition observed |
| :-- | :-- | :-- |
| (unnamed "new entity") | B04 | OS action produced a new bounded thing in execution space |
| **Process** | B06 | Program visibly unchanged while new entity lives (rupture, B05) |
| **PID** | B09 | ≥3 identical Processes + identity search failed to tell them apart (B08) |

The strings "Process" / "PID" must not occur in any learner-visible text before their reveal
beats (machine-checked by the scope gate).

### 0.5 Causal-order rules (locked; Phase 1 sequence)
Program exists → launch initiated → OS intervenes → NEW entity appears → Program ≠ entity →
name: Process → multiple instances → identity ambiguity → PID reveal → lifetime/termination
(Program survives) → relaunch = new independent Process (new PID; old ones untouched) →
silent climax → open question. This order may not be changed for implementation convenience.

### 0.6 Visual-language rules
- V1 Structural isomorphism (§2): Program never morphs/moves/disappears; Process is created,
  not transformed, not teleported.
- V2 Derivable geometry (§2.2): every coordinate = named metric or function of a container rect.
- V3 Separation of structure and state (§4): regions/shelf/band = structure; cells/chips = state.
- V4 Spatial stability (§6): one world scene; nothing relocates.
- V5 Protagonist continuity (§13): the golden spark (T01 identity) is the single protagonist —
  it is the *launch/attention signal*: Program → OS → birth point; traceable at every second.
- V6 Attentional economy (§7)/§16: one moving focus per beat.
- V7 Determinism (§15): all state = pure function of (beatIndex, beatElapsed) (+ s.t for
  ambient breathing and the loop hook, per the T01/Ch-04 precedent).
- V8 Cross-domain consistency (§10): colors — CPU `#fb923c`, storage/Program `#22d3ee`,
  RAM-family not used, OS = topic accent `#f472b6`, Process life `#4ade80`, chip text `#e2e8f0`;
  spark/glow/pill/label primitives reused from the shared rendering layer.
- V9 Transition causality (§14): single scene → no scene seams to justify.

### 0.7 Animation rules
- A1 Every load-bearing animation declares FROM → CAUSE → EVENT → EFFECT → FINAL (contracts in §6).
- A2 No fire-and-forget timers; beat-driven windows only.
- A3 Reuse easing (`easeInOutCubic`), spark, glow, pulse, pill conventions from T01.
- A4 Births communicate creation (pulse + boundary draw-in), never teleport/morph.

### 0.8 Geometry rules
- G1 Semantic regions west→east (matches T01 causality axis and C-10 "gate" imagery):
  STORAGE (Program shelf) → OS band (the gate) → EXECUTION FIELD (open space + the T01 machine
  emblem at its east edge).
- G2 Program spatially persistent for 100% of the timeline.
- G3 Process spots: scattered, non-collinear, non-grid, pairwise non-overlapping — **no queue,
  row, pipeline or ordered arrangement** (checked by layout proof: no 3 spot centers within
  18° of collinear, uneven nearest-neighbour spacing).
- G4 PID chip docks strictly inside its owning cell; Program never carries a chip.
- G5 Legibility at the real Viewer canvas (~stage = viewport minus 300 px panel minus controls;
  audit at 1100×700 and 836×570), not only 1600×900.

### 0.9 Implementation architecture rules
- I1 Directory `src/content/topics/02-operating-systems/01-process-from-program-to-execution/`
  with the Ch-02/03/04 pattern: `meta.ts` / `index.ts` / `assemble.ts` (meta-free) /
  `types.ts` / `narration/{beats,labels}.ts` / `scenes/{metrics,layout,story,01-world}.ts` /
  `renderers.ts` + `renderers/world.ts` / `assets/thumbnail.jpg`.
- I2 Zero platform changes; chapter auto-discovered by the meta glob.
- I3 Declarative story data (`scenes/story.ts`) is the single truth for lifecycle, PIDs,
  climax schedule; renderers read it, never re-derive pedagogy in draw conditions.
- I4 Gates: `scripts/smoke-topic02-ch01.ts`, `scripts/scope-gate-topic02-ch01.ts`,
  `scripts/layout-proof-topic02-ch01.ts` (vite-node), wired into `npm run smoke`
  (the T01/Ch-04 gate scripts are absent from the tree — recorded debt, PROJECT_STATE §2.5).

### 0.10 Verification requirements
Build + tsc; deterministic double-render byte-equality; beat/terminology ordering checks;
program-immutability paint check; PID→cell association geometry check; scope gate (forbidden
CH02–CH06/T06 concepts EN+VI); layout containment/disjoint/anti-queue proof; real-browser
playthrough with screenshots at every beat at real Viewer geometry; adversarial misconception
audit (12 items, §12 below).

---

## 1. PHASE 1 — Locked pedagogical model

- **Central question:** What does the OS actually create when you launch a program?
- **Initial false model:** "The program is the thing that runs." (Misconception inventory #1,
  Guardian T02 §4.)
- **Target model:** Program = static artifact on storage. The OS creates a **Process** — the
  managed executing entity — with its own identity (**PID**) and its own lifetime. One Program
  → many independent Process instances.
- **Transformation (exactly one):** "the program runs" → "the OS creates a managed running
  instance of the program — and the program itself never changes."
- **Discovery sequence:** locked as §0.5. No reordering.

---

## 2. PHASE 2 — Locked beat table (14 beats, one scene `world`)

Legend: MM = mental model; ¬R = must NOT be revealed yet. All beats scene `world`.

| # | Beat ID | Purpose / Discovery | Learner sees (T0→T1) | Tension → Question | MM change | Causal link from prev | ¬R yet | Visual state | Animation event | Geometry req | Narration role | Term status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| B00 | `the-question` | Cognitive replay of T01 exit; pose the debt | Whole world: Program on shelf (W), dim OS band (mid), empty execution field with quiet CPU emblem (E); spark emerges at Program | Machine executes whatever enters — but nothing is running; where does work come from? | reactivates C-09/C-10 | — (entry state) | Process, PID, OS action | all idle | spark emerge; machine idle pulse | 3 regions visible in one frame | orient + replay + question | none |
| B01 | `the-program` | Program = static artifact | Program card glows; instruction rows visible (C-01 anchor); it does not move | "You launch it — what actually happens?" | program is a *file*, inert | question needs an object: the program | everything | Program salient | soft glow only (no motion) | Program W, static | names known things only | none |
| B02 | `launch` | Launch goes to the OS first, not into the machine | Click ripple on Program; spark travels Program → OS; Program stays put | It didn't go to the machine — why here? | launch = a request handed to a manager | B01's "launch it" | what OS will do | spark in transit | ripple + spark travel (ease) | path crosses OS band | guide the eye; no conclusion | none |
| B03 | `os-receives` | The OS acts (visible cause) | OS band brightens, absorbs spark, charge shimmer builds | The OS is *doing something* — what? | OS is an actor, not a pipe | spark arrived at OS | the effect | OS working | absorb + charge pulse | OS distinct band | minimal: "it took over" | none |
| B04 | `birth` | A NEW entity appears in execution space | OS emits signal → spark flies to empty spot S0 → creation pulse → boundary draws itself → breathing cell | Something new exists that wasn't there | the OS *created* something | OS finished its work | its name; its relation to Program | cell A birthing | signal travel + pulse + ring draw-in | birth in FIELD, far from Program | near-silent; point, don't name | entity unnamed |
| B05 | `not-the-program` | RUPTURE: Program ≠ new entity | Program (W) pulses once, unchanged; cell A (E) pulses once; both simultaneously in frame; pause | If the program is still there… what is this? | the running thing is NOT the program | cell exists; look back west | the name | both salient in turn | two restrained pulses + hold | max spatial separation W↔E | organize what was seen; ask, don't answer | entity unnamed |
| B06 | `the-name` | Name the phenomenon: **Process** | Term pill "Process" resolves above cell A; cell gains its small "Process" caption | — (release of B05 tension) | "managed running instance" gets its name | rupture observed → term earned | PID, internals, states | A named | pill fade/settle (T01 pill convention) | pill clear of other spots | one naming sentence | **Process revealed** |
| B07 | `second-launch` | One Program → multiple Processes | Spark: A → Program (ripple) → OS → new spot S1; second birth; A untouched; Program untouched | Two of them — from one file? | instances multiply; artifact doesn't | "what if you launch it again?" | identity, PID | A alive, B birthing | full launch cycle replay | S1 scattered (no row with S0) | name the count; note A unchanged | Process only |
| B08 | `identity-problem` | Identity ambiguity becomes a felt problem | Third launch → cell C at S2; then a selector ring hops A→B→C→A — cells look identical | Three alike. Which is which? How does the OS tell? | manager needs identity; looks fail | more instances → ambiguity | PID (until next beat) | 3 unnamed-identical cells | launch replay + hesitating selector | S0/S1/S2 non-collinear scatter | voice the learner's confusion | Process only |
| B09 | `pid` | Identity reveal: **PID** | Chip flies OS→A docks inside A: "PID 4312"; then OS→B "4318"; OS→C "4331"; term pill "PID" | — (release) | each Process has its own OS-given number | the question B08 established | states, scheduling | chips docked, owned | chip flight + settle ×3, then pill | chip strictly inside its cell | disclosure: "it numbered them at creation" | **PID revealed** |
| B10 | `lifetime` | A Process ends; the Program does not | Cell A: bright completion shimmer → boundary dissolves outward → chip fades → empty space; B, C keep breathing; Program unchanged on shelf | It's gone — but the program isn't. | Process has a lifetime; artifact persists | identity established → watch one live/finish | restart semantics | A dying → gone | slow-down + dissolve (no explosion) | A's spot returns to negative space | name lifetime; point west once | Process, PID |
| B11 | `independent` | Relaunch = NEW Process, new PID; not a restart | Spark: S2 → Program → OS → S3; cell D born **with** chip "PID 4402" (≠4312); B, C unaffected | Different number — so not "A again"? | instances are independent lives | A ended → launch again | — | B, C alive; D birthing | launch cycle + immediate chip | S3 fresh spot; scatter kept | say the number difference; nothing else | Process, PID |
| B12 | `climax` (SILENT) | Compress the whole model at scale | Deterministic pattern: launches (spark Program→OS→spot, birth+chip) and endings interleave OUT of creation order; ≤4 alive; Program lit and still the whole time | — | model self-confirms | the system simply keeps living | scheduling, queues, states, turns | many independent lives | scripted schedule (story data) | scattered spots; anti-FIFO death order | **none (silent)** | no new terms |
| B13 | `bridge` | Quiet integration + permitted open loop | World settles: 2 Processes breathing, Program on shelf, OS quiet; spark drifts at OS | Does a Process actually run the whole time it exists? | opens CH02/CH03 door | climax observed | any CH02+ content | steady state | ambient only | — | ONE short question line | closed |

Beat count justification: 14 = every discovery in §0.5 gets exactly one beat; the third launch in
B08 repeats B07's already-made discovery (allowed reinforcement, not a merged discovery).

Durations (ms): 6500, 6500, 5500, 5000, 7000, 7000, 6000, 7000, 8000, 9000, 8000, 8000, 16000, 10000 ≈ 110 s.

---

## 3. PHASE 3 — The Process/PID visual argument

- **A. Program:** cyan card on a shelf, instruction rows inside (C-01 echo). Never moves, never
  morphs, never dims out, never receives a chip, never "breathes" (only static glow when salient).
  Painted identically in B01 and B13 (paint-log checked).
- **B. OS intervention:** vertical pink band between storage and execution — literally the *gate*
  of C-10. CAUSE = spark (launch request) enters; visible action = absorb + charge shimmer;
  EFFECT = creation signal leaves its east face.
- **C. Process birth:** OS signal → arrives at an EMPTY spot → local creation pulse → boundary
  ring draws in (~arc sweep) → interior life shimmer → persistent breathing cell. Never appears
  at/near the Program; never inherits the Program's shape or color (green vs cyan).
- **D. Rupture (B05):** both objects simultaneously visible at maximal separation; sequential
  restrained pulses; temporal pause; narration only asks.
- **E. Multiple processes:** 5 scattered spots (S0–S4), uneven spacing, non-collinear —
  provably not a queue/row/pipeline (layout proof asserts it).
- **F. Identity problem:** cells carry NO visible identity until B09; selector ring hops and
  hesitates — ambiguity is *shown*, then the need is voiced.
- **G. PID reveal:** chip animates OS → cell, docks INSIDE the cell header, one per cell, never
  floating, never on the Program; pill "PID" only after chips observed. PIDs (single source,
  story.ts): 4312, 4318, 4331, 4402, 4417, 4459, 4473.
- **H. Lifetime:** completion shimmer → dissolve → empty space; Program and other cells
  visibly untouched. No state names, no exit codes.
- **I. Independence:** B10 (A dies, B/C live) + B11 (relaunch ⇒ new PID at a new spot while
  B/C untouched) together prove independent lifetimes visually.

---

## 4. PHASE 4 — Silent climax design (B12)

16 s, narration = NBSP. Entering alive: B(4318,S1), C(4331,S2), D(4402,S3).
Schedule (fractions of the beat; single source `CLIMAX_EVENTS` in story.ts):

| frac | event | proof carried |
|---|---|---|
| 0.06→0.16 | launch → E 4417 @ S4 | Program stays; OS creates; new identity |
| 0.30 | C ends | middle-aged dies first → **not a queue, not FIFO, not turns** |
| 0.40→0.50 | launch → F 4459 @ S0 | freed space is just space; new PID (≠ A's) |
| 0.58 | E ends | young dies before old B → anti-ordering again |
| 0.70 | B ends | the oldest ends last of the three |
| 0.78→0.88 | launch → G 4473 @ S2 | pattern is endless |
| 0.92 | D ends | exits into B13 with F & G alive |

Max 4 concurrent (readability). Every birth is preceded by the visible cause (spark
Program→OS→spot via the deterministic `loopPosition` hook — T01/Ch-04 horizon precedent).
Nothing overlaps; no queue geometry; no state badges; no counters.

---

## 5. PHASE 5 — Geometry specification (all named metrics; world units)

| Region | Rect / anchor | Purpose | Allowed entities | Forbidden readings |
|---|---|---|---|---|
| STORAGE shelf | card 170×200 @ (240, 380) | artifact home; permanence | Program card only | program "goes somewhere" |
| OS band | 170×420 @ (555, 380) | the gate; causal actor | OS band, charge fx, term pill anchor south | OS = the process; OS = pipe |
| EXECUTION field | x 780..1580, y 150..610; inner spot area x 810..1540, y 190..580 | where running work lives | cells, chips, selector, pulses, orient chip, CPU emblem (east edge, 80×80 @ (1530, 380)) | queue/pipeline; cells touching CPU |

Spots (cell 190×120; centers): S0 (912,284) · S1 (1233,252) · S2 (1073,424) · S3 (1379,405) ·
S4 (854,518). Pairwise gap ≥ 20 world px on the separating axis; no 3 centers collinear;
nearest-neighbour distances uneven (anti-queue). Protagonist path anchors:
`[P, OS, S0, P, OS, S1, P, OS, S2, P, OS, S3]` (P = Program center) — each launch traverses
Program → OS → spot, so travel slices stay contiguous.

Ten geometry requirements of the directive: (1) Program static ✓ (single scene, fixed rect);
(2) OS positioned between cause and effect ✓; (3) Process geometry ≠ Program geometry
(rounded breathing cell vs. document card, different color family) ✓; (4) births only inside the
field ✓; (5) chip inside owning cell ✓; (6) anti-queue proof ✓; (7) termination local to a cell
✓; (8) 4-max coexistence, disjoint spots ✓; (9) legible at real canvas (~1100×700 ⇒ fit zoom
≈ 0.7; smallest persistent text 13 world px ≈ 9 px screen, chip text 15 ≈ 11 px — matches
T01/Ch-04 scale) ✓; (10) empty field before B04 and after deaths = deliberate negative space ✓.

## 6. PHASE 6 — Animation contracts (FROM → CAUSE → EVENT → EFFECT → FINAL)

1. **Launch:** Program static → ripple (click/relaunch) → spark travels P→OS (easeInOutCubic,
   engine travel) → OS absorbs → Program still static.
2. **Creation:** OS charged → signal (spark) leaves east face → arrives empty spot → pulse ring
   expands + boundary arc draws in (~0.35 of the beat window) → persistent breathing cell.
   Travel beats use `holdAt` on the destination anchor so arrival happens mid-beat and the birth
   is watched, not clipped at the seam.
3. **PID:** ≥3 identical cells → selector fails (B08) → chip springs from OS → flies (ease) →
   docks inside cell header → stays forever associated (drawn from cell rect each frame).
4. **Termination:** alive cell → work completes (bright shimmer, breathing stops) → boundary
   dissolves outward + chip fades → empty space → Program & neighbours unchanged.
5. **Second launch:** identical to contract 1+2 with new spot + new PID; prior cells' draw state
   provably unmodified (pure functions of story data).
6. **Climax:** contracts 1/2/4 replayed from `CLIMAX_EVENTS`; spark driven by deterministic
   `runtime.loopPosition(t)` (beat-start offset computed from beat durations, Ch-04 pattern).

All windows are functions of `(beatIndex, beatFrac)`; ambient breathing uses `s.t` exactly as
T01/Ch-04's ambience does. No timers, no random.

## 7. PHASE 7 — Topic 01 architecture extraction (what is reused)

| Convention | Source | Reuse here |
|---|---|---|
| meta/index/assemble split (meta-free assembly) | Ch-02/03/04 | identical |
| metrics → layout → story purity chain | Ch-04 `scenes/*` | identical |
| beats as declarative `BeatDescription[]`, silent NBSP beats | Ch-04 `narration/beats.ts` | identical |
| beat-driven pure renderers keyed by `kind` | Ch-04 `renderers/*` | identical |
| engine travel/rest/holdAt/emerge/effect:'loop' | engine/update.ts | identical |
| `runtime.loopPosition` for scripted loop protagonist | Ch-04 horizon | climax/bridge |
| golden spark protagonist + trail | shared spark.ts | identical |
| term pill after observation | Ch-03/04 pills | Process (B06), PID (B09) |
| orientation chip plain-language | Ch-04 "inside the CPU" | "execution space" chip |
| hit-zone click-to-start on the story's own object | Ch-04 CPU box | the Program card |
| bilingual EN/VI narration register | all | identical |

**Not copied:** ladder/stations/counters/instruction cards — T01 subject-specific semantics.

## 8. New primitive justification

| New painter | Why existing ones don't suffice |
|---|---|
| `program-card` | artifact-with-instruction-rows glyph; must NEVER animate position (unlike T01 panels that scroll) |
| `os-gate` | a causal actor band with absorb/charge/emit states — no T01 part has this role |
| `exec-field` | draws dynamic Process cells/chips/selector/pulses from story data; the chapter's entire state lives here |
| `machine-dock` | miniature quiet CPU emblem (continuity anchor), one glyph |

All four are composed exclusively of shared primitives (rrPath, glow, hexA, drawName, pills).

## 9. Boundary / leak audit plan

Scope gate scans ALL learner-visible strings (beats, labels, glosses, captions, pills) EN+VI for:
ready, waiting, terminated/terminate-as-state-name, blocked, scheduler/scheduling, queue,
time slice, quantum, preempt, context switch, dispatch, thread, address space, heap, stack,
page, virtual memory, exit code, zombie, fork, parent/child, core, parallel, concurren-,
race, lock, mutex + VI: hàng đợi, lập lịch, định thời, luồng, tiểu trình, không gian địa chỉ,
chuyển ngữ cảnh, song song, đồng thời. Required-present: Process (first at B06), PID (first at
B09), OS, Program. "run/chạy" allowed as ordinary language only.

## 10. Responsive geometry strategy

Single world bbox derived from content (min ≈ (95,110), max ≈ (1625,690)); `cameraPad 0.92`;
BoundedCameraController fits any stage size. Legibility audited at 1100×700 and 836×570
(real Viewer stage sizes documented in the shell history), not just 1600×900.

## 11. Deterministic rendering strategy

- Everything drawn = f(beatIndex, beatElapsed) via story tables; ambience = f(s.t).
- `loopPosition(t)` uses beat-duration prefix sums (exactly `durationBefore`, kept consistent by
  the orchestrator's jumpTo).
- Verification: full grid render (14 beats × 5 fracs × 2 langs) twice → byte-identical logs.

## 12. Verification strategy (Phases 10–12)

1. `tsc` + `vite build`.
2. Smoke: playthrough integrity, terminology ordering, story invariants (birth/death windows,
   ≤4 alive, chip-visibility rules, anti-FIFO climax order), determinism double-render,
   program-immutability paint subset equality (B01@0.5 vs B13@0.5).
3. Scope gate (§9).
4. Layout proof: containment, pairwise disjointness, chip-inside-cell, anti-queue
   (non-collinearity + uneven spacing), bbox coverage.
5. Real browser (headless Chromium): full playthrough, screenshot every beat at real Viewer
   geometry, EN + VI spot-checks; agent visually inspects every load-bearing frame
   (B01, launch, birth, rupture, multiplicity, identity problem, PID, lifetime, second launch,
   independence, climax, bridge).
6. Adversarial misconception audit — all 12 items of the directive, each answered with the
   on-screen evidence that blocks it; any failure ⇒ fix implementation.

**STOP — end of blueprint. Implementation begins only after this file.**

---

## Amendment A1 — Deep Refinement Round 2 (2026-08-14, pre-freeze)

Owner-directed second refinement. The 14-beat spine is preserved; the changes below
supersede the corresponding original sections. History above is unmodified.

### A1.1 Refined OS causal model (supersedes parts of §0.5/§2)
The OS is now INTRODUCED before it acts. New beat `why-the-os` (index 2) establishes,
concisely: the machine (CPU/RAM/devices) is shared → a stored file cannot manage a whole
machine → one piece of system software has that job → the OS (hệ điều hành) stands between
programs and the machine. This resolves sub-question "what role does the OS play?" BEFORE
the launch, so the creation has an understandable actor. It remains subordinate to the one
central question (it is framed as "so when you launch it, what happens?" preparation) and
teaches no kernel/system-call/scheduler internals. Beat count: 15.

### A1.2 Refined OS visual architecture (supersedes the "band" of §3-B)
The OS is a management layer with derived internal structure (all metrics named):
- **intake port** (west boundary, on the causal axis) — where launch requests arrive;
- **management core** — three function rows; rows highlight ONLY during their causal
  action (create row during creation; identify row during each PID association; manage row
  during lifetime events). Their micro-labels (create/identify/manage · tạo/định danh/quản
  lý) are revealed per the Knowledge Reveal Law only AFTER each function was observed
  (windows `OS_ROW_LABEL_AT`: after the Process naming, after the PID disclosure, after
  the independence proof);
- **creation port** (east boundary) — emits an expanding arc when a Process is created;
- **resource-context strip** ("the machine": CPU · RAM · I/O slots in T01 colours) —
  context only, internals never explained.
Structure resolves visually during `why-the-os` (strip first, then core) and persists.

### A1.3 Launch-request invariant (reinforces §3-A)
The Program NEVER travels. The moving golden signal is narrated and gated as "the launch
request"; it enters the OS through the intake port. New OS internal causal sequence per
launch: request arrives at intake → intake lights → core wakes row-by-row → create row
works → east port emits → birth pulse at the destination spot. Each stage has its own
(beat, frac) window in story.ts (`OS_RECEIVE`, `OS_CREATE`).

### A1.4 One Program → many Processes, stated causally (supersedes §2 B07 wording)
Narration now uses the launch-mediated form: "Launching one stored program twice caused
the OS to create two independent Processes" — never "the Program creates Processes".
Birth also narrated as "not hiding inside the program file" (B05).

### A1.5 PID as identity ASSOCIATION (supersedes §3-G chip flight)
The chip no longer flies as a packet. Association sequence per instance: identity focus
ring closes onto the owning cell → dashed association line draws OS→cell (logical link)
→ the PID chip RESOLVES IN PLACE at its dock (fade + settle) → line releases, chip stays.
The OS identify-row pulses during each association. Narration: "each Process has an
identifier, associated with it at creation."

### A1.6 Process pill names the class (supersedes §2 B06 visual state)
The "Process" term pill now sits in the concept band above the whole execution field (not
above one instance); the per-cell caption carries the class name onto instances; the PID
chip carries instance identity.

### A1.7 Motion/geometry invariant (codifies refinement §14–15)
MOTION = transition/change (birth, association, termination, requests). STABLE GEOMETRY =
persistent state (Program, OS structure, living cells with static content marks and
restrained boundary breathing). Deterministic launch variation: the four launch/birth
windows have distinct spans (gate-asserted) so repeated creation never reads as a conveyor.

### A1.8 Terminology rule (refinement §0)
Locked English terms with first-introduction VI glosses: "Process (tiến trình)" at the
naming beat; "PID — mã định danh tiến trình" at the identity beat; "OS — hệ điều hành" at
the OS introduction. Elsewhere the English terms are used; "tiến trình" outside the gloss
positions and the word "progress" anywhere are scope-gate failures.
