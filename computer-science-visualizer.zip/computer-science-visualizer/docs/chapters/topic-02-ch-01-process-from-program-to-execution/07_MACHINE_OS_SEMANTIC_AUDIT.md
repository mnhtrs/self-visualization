---
guiding_question: "Does Topic 02 Chapter 01 currently duplicate the machine representation (a CPU·RAM·I/O strip inside the OS AND a standalone external CPU), and what is the smallest coherent fix that yields one low-salience machine context distinct from the OS?"
primary_consumer: "Implementation Engineers, QA Auditors, Curriculum Guardian, AI Agents"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/05_SEMANTIC_VISUAL_REFINEMENT.md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/06_CONCEPTUAL_READABILITY_AUDIT.md"
referenced_by: []
---

# Round 8 — Machine / OS Semantic Cleanup Audit — Topic 02 / Chapter 01

**Date:** 2026-08-14 · **Method:** source inspection. Every finding is grounded in the
current implementation (line references from `world.ts`, `metrics.ts`, `layout.ts`,
`story.ts`, `01-world.ts`).

---

## 1 · The confirmed problem

Two machine representations coexist, with ambiguous ontology:

**A. Resource strip INSIDE the OS.** `drawOsGate` draws a "the machine" strip
(`CAP.osResTitle`) containing CPU / RAM / I/O slots at the base of the OS band
(`L.osResRect`, `L.osResSlot`, `M.OS_RES`). Visually this says: **the OS contains the
machine**.

**B. Standalone CPU emblem OUTSIDE the OS.** A `machine-dock` entity at the far east
(`M.MACHINE_C = (1530, 380)`, 80×80, `name: 'CPU'`), drawn as an orange "CPU" box with a
breathing core and an external "CPU" label. Visually this says: **there is a separate,
unexplained CPU** — distinct from the RAM and I/O that live inside the OS strip.

Together these imply a false ontology: "the OS contains the machine" + "the CPU is a
separate thing from RAM/I/O" + "the far-east CPU is an unexplained decorative object."

## 2 · Why this is a real (not invented) problem

- **Duplication** (§4 of the directive): CPU appears in two places (inside the OS strip
  and as the far-east emblem), with different visual treatment.
- **"OS ⊇ machine"** (§3): the strip renders the physical machine *inside* the system
  software, contradicting the target ontology "OS = system software that manages the
  machine" and the narration's own words ("the OS stands between programs and the
  machine").
- **Unexplained standalone** (§6): the far-east "CPU" is a single hardware part with no
  stated relationship to anything.

## 3 · Narration is already correct — no change needed

B00 ("the machine on the far side is still at work") and B02 ("It stands between programs
and the machine: the OS") already frame the machine as a *separate* physical context and
the OS as the *mediator*. There is no narration implying "the OS contains the machine."
**The defect is purely visual**, so the fix is purely visual.

## 4 · Chosen fix (directive §6 option A)

1. **Remove the resource strip from the OS.** The OS becomes pure system software: title
   ("OS / Operating System") → intake port → management core (create / identify / manage)
   → creation port. Nothing physical lives inside it anymore.
2. **Replace the far-east CPU emblem with a coherent "THE MACHINE" context region** —
   a low-salience container labelled "the machine" holding three lightweight slots
   CPU / RAM / I/O. This keeps the "machine on the far side" narration true, removes the
   unexplained standalone CPU, and puts CPU·RAM·I/O in exactly ONE place.
3. **Make the machine region static** (no breathing core) — per §9, the machine must not
   pulse continuously (that would imply CPU activity and contradict ALIVE ≠ EXECUTING).
4. **Fill the OS band's freed space** by expanding the management core (132 → 168 px) so
   the OS does not read as an empty shell.

## 5 · Spatial decision — why far-east, not "above"

The directive's §8/§15 sketches show MACHINE *above* the OS as an ideal. §15 explicitly
allows adapting "to CESVI's existing visual language," which is a locked west→east
causality axis (Program → OS → execution). Keeping the machine at the far east is the
minimal, narration-compatible choice: B00's "machine on the far side" and B02's "OS
stands between programs and the machine" both remain literally true (Program west → OS
middle → machine far east). Moving the machine north of the OS would break the "far side"
wording and is a larger re-layout than the inconsistency warrants.

Rejected alternatives:
- **Remove the external CPU and keep only the strip** (option B): keeps "OS ⊇ machine",
  the worse misconception.
- **Machine band north of the OS**: breaks the west→east axis and "far side" narration;
  larger change.
- **Machine frame wrapping the field**: already rejected in Rounds 3/6 (physical-container
  reading; OS becomes protagonist).

## 6 · What must NOT regress

15-beat spine; Process/PID discovery; Program identity; second-launch proof; lifetime
proof; silent climax; scope boundaries; anti-queue geometry; deterministic
`(beatIndex, beatFrac)` rendering; static Process interiors.

---

## 7 · Implementation plan (after this audit)

- `metrics.ts`: remove `OS_RES`; replace `MACHINE { w:80, h:80, r:12, core:26 }` with a
  region shape + slot shape; expand `OS_CORE.h` 132 → 168.
- `layout.ts`: remove `osResRect`/`osResSlot`; update `machineRect`; add `machineSlotRect`.
- `story.ts`: remove `CAP.osResTitle`/`CAP.osRes`; add `CAP.machineTitle` +
  `CAP.machineRes`; repurpose `OS_INTRO.resStrip` → `OS_INTRO.machine` (the far-east
  machine region's slots light in turn during `why-the-os`).
- `world.ts`: delete the strip block from `drawOsGate`; rewrite `drawMachineDock` →
  static machine region (container + "the machine" title + CPU/RAM/I/O slots with the
  intro stagger); drop its `drawName` and breathing core.
- `01-world.ts`: machine entity `name` 'CPU' → 'Machine'; gloss updated to "the physical
  machine (CPU, RAM, I/O)".
- Gates: layout proof — machine region within field/bbox, slots inside region, cells clear;
  smoke — drop `osResRect` reference, assert no duplicate machine labels (CPU/RAM/I/O
  appear only via the machine region, never inside the OS), OS ≠ machine, machine static.
- Verify: tsc, build, smoke, scope, layout, deterministic double-render, EN+VI browser
  playthroughs at 1400×850 and 1140×660.

*Implementation follows this audit.*
