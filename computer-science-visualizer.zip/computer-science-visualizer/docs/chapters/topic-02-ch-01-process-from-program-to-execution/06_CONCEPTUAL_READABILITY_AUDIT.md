---
guiding_question: "Does the visual system of Topic 02 Chapter 01 communicate the ontology of Program / OS / Process / PID without relying on terminology or narration, and is any object still mistakable for another?"
primary_consumer: "Implementation Engineers, QA Auditors, Curriculum Guardian, AI Agents"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/05_SEMANTIC_VISUAL_REFINEMENT.md"
referenced_by: []
---

# Round 6 — Conceptual Readability Audit — Topic 02 / Chapter 01

**Date:** 2026-08-14 · **Method:** source inspection + deterministic render geometry.
This is a *conceptual* audit, not a polish audit. Colors/fonts/radii are only touched if a
concrete misconception requires it.

---

## 1 · The four-object test

| Object | What it LOOKS like it is (muted) | Geometry-implied relationship | Verdict |
|---|---|---|---|
| **A. Program** | A concrete app: rounded cyan tile, "Photos" icon (sun+mountain) + "Photos" name, on a storage shelf labelled "storage", with the "Program" part-name below. | A stored application artifact on storage. | ✓ unambiguous |
| **B. OS** | A squared pink band (r=6) with "OS / Operating System" title, an intake socket (west), a management core, a creation socket (east), and a dim resource strip ("the machine": CPU·RAM·I/O) at its base. | System software mediating between storage (west) and execution (east), managing the machine. | ✓ unambiguous (see §3) |
| **C. Process** | A rounded green cell (r=16) with a small "Photos" marker, a "Process" caption, static content marks, and (from B09) a "PID n" chip. | An execution entity created in the field, distinct from the Program. | ✓ (one residual issue — §5) |
| **D. PID** | A "PID n" chip docked inside a cell. | An identifier attached to exactly one Process. | ✓ unambiguous |

## 2 · OS is not a factory — audit

The concern: does the OS reduce to "Program → [factory] → Process"?

Evidence it does **not**:
1. **Resource strip.** The OS visibly has "the machine" (CPU·RAM·I/O) at its base — it is
   *managing* something broader than creating Processes.
2. **Three roles, one emphasized.** The core has create/identify/manage rows; only
   *create* is the subject of the central question ("what does the OS create when you
   launch a program?"). The other two rows light and get labelled later (identify at the
   PID beat, manage at the lifetime beats) — so the OS is shown to do more than create.
3. **Title.** "OS / Operating System" (not "Process Maker").
4. **`why-the-os` beat.** Narration establishes: shared machine → a stored file cannot
   manage a machine → system software exists for that job → the OS. Its visual state
   (resource strip resolves first, then the core) supports this.

Residual risk: during the birth beat the *dominant* animation is creation (intake → core
wake → create row → east port → birth pulse), which emphasizes "create". This is
**correct emphasis, not a misconception** — the chapter's central question is creation.
The "management layer" reading is anchored by items 1–4 and does not require the OS to
stop emphasizing creation.

**Verdict: no change.** The OS already communicates "management layer", not "factory only".

## 3 · OS visual grammar — alternatives evaluated (§5)

| Alternative | Semantic reading | Risk | Verdict |
|---|---|---|---|
| A. central system layer | OS as a mid-axis layer | same as current | — |
| B. management band | OS as a band | same as current (already a band) | — |
| C. system surface | OS as a surface | over-abstract | reject |
| D. system frame (wraps the field) | OS encloses Processes | reads as physical container; OS becomes protagonist | reject (Round 3 already rejected) |
| **E. current squared panel** | system layer between storage and execution | minimal | **keep** |

The current squared band (r=6, on the west→east causal axis, with intake west / creation
east) already *is* a "management band". No redesign is warranted — the directive's own
rule ("do not redesign merely for aesthetics") applies.

## 4 · Program → OS → Process causality (§6)

Verified correct by construction: the protagonist path is `Program → OS → spot` (anchors
0→1→2); the launch request travels into the OS intake port, the core wakes, the creation
port emits, and the birth pulse fires at the destination spot. There is no frame with a
direct Program→Process path. Program geometry is stable. **No change.**

## 5 · Program identity vs Process identity — THE ONE FINDING

The directive §7 requires:

```
PROCESS      (entity)
  ↓
PID          (instance)
  ↓
SOURCE       (program)
```

and explicitly forbids:

```
Photos
  ↓
Process
```

**Current state violates this.** Measured from source: the Process header is

```
line 1 (y=14):  [icon] Photos   ← source marker, on TOP
line 2 (y=32):  Process          ← class caption, BELOW
```

"Photos" is a proper noun on the top line of a card — in card convention the top line is
the *name/title*. Round 5 subordinated the marker by size/weight/alpha (10px, 600, dim),
but its **position still reads as the entity's title**. A muted-narration learner can
still read the cell as "a thing named Photos", collapsing the Program/Process distinction.

The required hierarchy is "Process is the name; Photos is the source." The smallest
correction is to **swap the two lines** so the class name is the title and the source
marker is a subordinate subtitle:

```
line 1 (y=14):  Process          ← entity name (title)
line 2 (y=32):  [icon] Photos    ← source (subtitle)
```

This keeps every other property (same marker, same gating at B06+, same icon, PID chip
unchanged, identical trio during B08) and directly implements §7. No new text, no new
term, no "from Photos" wording.

Rejected alternatives: (a) adding "from Photos" text — the directive discourages more
text; (b) making the marker a corner badge — larger change, no added semantic value.

## 6 · Multiple-process proof (§8)

With the swap, two cells read as "Process (from Photos)" + distinct PID each — the four
facts (shared source, independent entity, distinct PID, independent lifetime) are all
visible. The shared "Photos" subtitle + distinct "PID n" chips carry source-identity vs
instance-identity. **No further change.**

## 7 · Second launch (§9)

Verified correct: A is alive/stable (pure function of its own lifecycle window) while B
births at a new spot with a new PID. Regression gate added in Round 5 asserts A's state
and pid/spot distinctness. **No change.**

## 8 · Termination (§10)

Verified correct: dissolve is local to one cell; Program pixel-immutable (Round-5 gate);
siblings unaffected. **No change.**

## 9 · Muted-narration checklist (§11)

| Frame | "If text disappeared, what would I think this is?" | Verdict |
|---|---|---|
| B01 program | a stored app ("Photos" tile + icon + shelf) | ✓ |
| OS-intro | system software with a machine-resource strip | ✓ |
| launch | request travelling to the OS | ✓ |
| birth | something new created far from the Program | ✓ |
| rupture | two different things (west tile vs east cell) | ✓ |
| multiple | several "Photos"-sourced Process cells | ✓ (after §5 fix) |
| PID reveal | each cell gets its own number | ✓ |
| second launch | a new instance with a new number | ✓ |
| termination | one cell ends; others + tile remain | ✓ |
| climax | the system keeps creating/ending instances | ✓ |

The only failing frame before the §5 fix was "multiple" (the "Photos"-on-top title
ambiguity). After the fix it passes.

## 10 · Animation semantics (§12)

Every animation has a cause → transition → effect: Program→OS = launch request;
OS→spot = creation; focus-ring→dashed-link→resolve = identity association;
dissolve = lifetime end. No motion exists without meaning. **No change.**

## 11 · Over-animation check (§13)

Static interiors, restrained breathing, deterministic birth, PID association, dissolve —
all preserved. No spinning/queues/scheduler/constant-OS animation introduced. **No change.**

## 12 · Pedagogical boundary check (§14)

No visual implies Program=Process, OS=application, OS=factory-only, PID=Program-ID,
PID=Process, Process=window/queue/CPU-task, second-launch=restart, or death=deletion.
The single residual ambiguity is §5 (marker position), which is fixed below.

## 13 · Verdict

**One real semantic problem** (the §5 marker-position violation of §7), **one minimal fix**
(swap the two header lines). Everything else is correct and left unchanged.

*Implementation follows.*
