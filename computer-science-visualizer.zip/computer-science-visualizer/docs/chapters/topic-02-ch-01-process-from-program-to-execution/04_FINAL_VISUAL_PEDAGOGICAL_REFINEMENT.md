---
guiding_question: "How is Topic 02 Chapter 01 raised from 'technically and pedagogically correct' to 'exceptionally clear, visually intuitive, semantically precise and polished' (9.6–9.8/10) without rebuilding architecture or expanding scope?"
primary_consumer: "Implementation Engineers, QA Auditors, AI Agents, Curriculum Guardian"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/02_PEDAGOGICAL_AUDIT.md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/03_QA_AUDIT.md"
referenced_by: []
---

# Final Visual + Pedagogical Refinement — Topic 02 / Chapter 01
## "Process — From Program to Managed Execution"

**Date:** 2026-08-14 · **Round:** 3 (FINAL visual/pedagogical) · **Prior status:** FROZEN (technical)

This document records the final refinement round. It is written **before** any code
change (per the refinement directive §31) and is the contract the implementation below
must satisfy.

---

## 1 · Current weaknesses (audit of the real rendered chapter)

Measured from the actual rendered world (deterministic screenshot harness, 1400×850 /
1140×660 / 1100×700 / 836×570 fit zooms; source read line-by-line).

1. **The Program is a generic abstract rectangle.** It is a cyan "document" card with a
   folded corner, six instruction stripes and the caption "the program". Nothing makes it
   read as *a concrete stored application*. §3 of the directive calls this out explicitly:
   "This is NOT sufficient for the target quality bar." The Program has **no stable visual
   identity** that the eye can re-recognise when it must stay "the same program" across
   launches — weakening the ONE-PROGRAM → MANY-PROCESSES argument (directive §5).

2. **The OS reads as a thin vertical capsule.** `OS_BAND = 170 × 420` (aspect **0.40**).
   A 0.40-aspect rounded rect reads as "a tall machine / control panel", not as *system
   software / a management layer* (directive §6). It is the tallest object in the world
   while being the *secondary* actor — it risks dominating the hierarchy (directive §8).

3. **"OS" is drawn twice.** The giant 42 px name-plate (`S.CAP.osLetters`) inside the band
   *and* `drawName(…"OS"…)` below the band. Redundant label = wasted attention and visual
   noise (directive §20).

4. **Resource-context strip is over-detailed and near-illegible.** Three labelled slots
   (CPU/RAM/I/O) at hardcoded 10 px text inside a 54 px strip, plus a hardcoded 11 px
   "the machine" title. At 1140×660 these render at **≈7–9 px** — cluttered yet unreadable,
   and higher-contrast than a tertiary "context" element should be (directive §9, §20).
   Font sizes 10/11/24 are hardcoded literals, violating the "one named size per role"
   rule (metrics.ts docstring + VISUAL_LANGUAGE §2.2).

5. **Type-scale inconsistency.** `M.F` defines a role per size, yet the OS micro-labels,
   resource slots and selector "?" use raw literals (10, 11, 24). This is a latent
   maintenance/consistency defect (§20, §27).

6. **Program name placement reads ambiguously.** "storage" (small, at y≈508) sits *above*
   "Program" (part name, at y≈526) under the shelf — the location label outranks the entity
   label spatially, and the entity name floats 46 px from the card.

7. **Interior "content marks" of a Process cell are three identical horizontal bars**, which
   at a glance can read as a generic UI card/window rather than "managed execution entity"
   (§14). (They are already static — Fix #1 held — so this is a *semantic reading* issue,
   not an animation issue.)

These seven are the *visual/polish* gaps. The technical gates (tsc, build, deterministic
double-render, EN/VI, scope, layout, anti-queue, immutability) all already pass and are
**not** re-litigated here except as regression guards.

---

## 2 · Program redesign rationale (directive §3–5)

**Decision:** replace the generic document card with a **concrete app tile**: a rounded
app **icon** (cyan, a simple "photo" glyph — sun over mountains) + a **program name**
("Photos"), resting on the storage shelf. The shelf line and the "storage" label stay; the
"Program" part name stays as the entity label.

**Why a photo viewer and not a browser:** a browser is a complexity trap (multi-process
architecture — renderer/browser/GPU processes — is exactly what CH01 must NOT teach,
directive §4). A single simple app with a recognizable icon gives the cleanest
"one stored program → many launch instances" mental model.

**Identity contract (directive §5):** the icon + name are the *Program identity* and are
pixel-stable for 100% of the timeline. Processes carry **no icon, no program name** — they
are a different shape (rounded breathing cell), a different colour family (green), and get
their identity only from the **PID chip**. The same icon + name therefore stay identical
while two/three/four distinct Processes each resolve a distinct PID. This is the visual
proof of ONE PROGRAM → MULTIPLE INDEPENDENT PROCESS INSTANCES.

**What is NOT implied:** the icon is not a Process; no PID ever attaches to the icon; the
icon never travels, morphs, or dims; the Program never becomes a Process.

---

## 3 · OS redesign rationale (directive §6–8)

**Decision:** re-proportion the OS from a 170×420 capsule into a **moderately wide system
panel** (target aspect ≈ 0.72–0.8) with a clear **title header** ("OS" + subtitle
"Operating System / hệ điều hành"), keeping the exact causal anatomy that already works:
intake port (west) → management core (create/identify/manage rows) → creation port (east)
→ resource-context strip (base). West→east flow is preserved (blueprint G1; the directive's
§7 A/B sketches show a top→bottom layer, but G1 and §27 require staying CESVI-consistent,
and CESVI's Topic-01 causality axis is west→east).

**Why this reads as "system software" rather than "appliance":**
- a **wider-than-tall panel with a proper title** reads as *software*, not hardware;
- the title "OS — Operating System" states its nature explicitly instead of a lone 42 px
  letter;
- the redundant second "OS" label is removed (one name, one place);
- the three function rows remain **event-anchored** (they light only during their causal
  action; labels appear only after observation — Knowledge Reveal Law preserved, §10).

**Hierarchy check (§8):** the panel is made *shorter* (300 vs 420) so the OS no longer
dominates vertically; Program/Process/PID remain the primary actors.

---

## 4 · Program identity vs Process identity (directive §5)

Enforced by construction (and now by a new gate check):
- `programRect()` derives the icon/name; the Program painter takes **no input** from any
  Process state (already true; kept).
- The PID chip is drawn **from its owning cell's rect** (already true; kept) — it can
  never attach to the icon.
- A new smoke assertion: the Program's painted pixels are byte-identical between the
  pre-launch beat (b01) and the final frame (b13/b14) — the *same program identity* is
  visually proven stable.

---

## 5 · OS geometry alternatives considered (directive §7)

| Candidate | Sketch | Verdict |
|---|---|---|
| **A. Wide horizontal "system layer"** (Program above, Process field below) | top→bottom flow | **Rejected.** Inverts the locked west→east causality axis (G1) and Topic-01's orientation; would read as a *new* layout language, not an evolution (§27). |
| **B. Full-width "system environment" wrap** (OS encloses the Process field) | OS as a container around everything | **Rejected.** Makes the OS read as a *physical container* (§7: "OS does not look like a physical container") and inevitably becomes the protagonist (§8). |
| **C. Wider system panel on the west→east axis** (keeps intake→core→emit) | Program → [ OS ] → field | **Chosen.** Keeps causal flow, G1, spatial stability (§6), and reads as system software. |

---

## 6 · CPU / RAM / I/O context decision (directive §9)

**Keep, but de-emphasise:** the resource strip remains as the *context* that the OS manages,
but (a) slots become lower-contrast (dimmed fill/stroke), (b) labels move to the shared
type scale at the smallest *named* role (`F.micro`), (c) the strip is visually grouped as
one quiet unit. No resource-management mechanics are added; internals stay untaught.

---

## 7 · Animation audit (directive §23)

Played the full beat timeline continuously (engine-driven, narration muted). Findings and
fixes:

| Beat / transition | Issue found | Fix |
|---|---|---|
| B02→B03 (launch) | Program ripple + spark travel correct; **no change** | — |
| B04→B05 (birth) | creation pulse → boundary draw-in correct; **no change** | — |
| B08 (identity selector) | ring hop correct; **no change** | — |
| B09 (PID) | association (focus ring → dashed link → resolve-in-place → release) correct; **no change** | — |
| B10 (lifetime) | completion shimmer → dissolve outward correct; **no change** | — |
| B11 (second launch) | new spot + new PID correct; **no change** | — |
| B12 (climax) | interleaved births/deaths anti-FIFO correct; **no change** | — |
| — | The cell interior content marks were already made **static** (Fix #1); no "alive = executing" motion | kept |

**Conclusion:** no timing defects were found that imply queue/CPU/morphing. The animation
contracts (blueprint §6) already satisfy the directive's timing questions. The only changes
are the static visual redesigns in §2–§3.

---

## 8 · UI audit (directive §20)

Fixes applied: remove the duplicate "OS" label; move all font sizes onto the named scale;
dim the resource strip; re-anchor the Program's "storage" label *below* the entity name;
ensure the app icon + name are legible at the fit zooms. Decoration is not added anywhere.

---

## 9 · Silent-narration audit (directive §24)

The geometry already reconstructs the causal chain with narration muted (per
`02_PEDAGOGICAL_AUDIT.md`). The redesign strengthens this further: a *concrete* icon
(stable) + a *clearly named* system panel + scattered cells with PID chips make
"same program → OS → many instances, each with its own number" inferable from geometry
alone.

---

## 10 · Adversarial misconception audit (directive §25) — 24 items

1. Program = Process — **BLOCKED** (distinct shapes/colours/locations; B05 rupture).
2. Program transforms into Process — **BLOCKED** (pixel-stable program; birth far away).
3. Program creates Process — **BLOCKED** (launch request → OS → OS creates; narration §A1.4).
4. OS is the Process — **BLOCKED** (OS emits creation; coexists with cells).
5. OS is a physical machine component — **BLOCKED / strengthened** (title "OS — Operating
   System", software-panel form, resource strip shows the *actual* machine as separate).
6. OS is just a UI/control panel — **BLOCKED** (causal intake→create→emit anatomy).
7. OS is only CPU management — **BLOCKED** (strip shows CPU + RAM + I/O).
8. PID is the Process — **BLOCKED** (chip docks inside an already-living cell).
9. PID belongs to the Program — **BLOCKED** (chip never touches the icon; gate asserts).
10. PID is a transmitted object — **BLOCKED** (association, not flight).
11. Process = currently executing CPU work — **BLOCKED** (static interior; Fix #1).
12. Process = application window — **BLOCKED / strengthened** (cell ≠ app icon/window; icon
    stays on the Program).
13. Processes form a queue — **BLOCKED** (scatter, anti-queue proof).
14. Processes execute one after another — **BLOCKED** (no ordering animation).
15. One Program → only one Process — **BLOCKED** (2 then 3 cells from one icon).
16. Process termination destroys Program — **BLOCKED** (program immutability).
17. Second launch restarts the same Process — **BLOCKED** (new spot, new PID).
18. All Processes share identity — **BLOCKED** (distinct PIDs).
19. CPU is where a Process lives — **BLOCKED** (cells in the field; CPU emblem separate).
20. CPU/RAM/I/O are the subject — **BLOCKED / strengthened** (dimmed to tertiary).
21. OS has exactly three modules — **BLOCKED** (labels appear only after observation).
22. One launch = exactly one Process — **BLOCKED** (same launch route, new instance each time).
23. Every Process must visibly be working — **BLOCKED** (static content marks).
24. OS "thinks/wants" — **BLOCKED** (causal wording only; §19).

---

## 11 · Scope audit (directive §26)

No scheduler / states / context switch / threads / PCB / address space / syscalls /
fork / tree / IPC / browser multi-process introduced. Chapter still ends at
Program → OS → Process → PID → lifetime → independent instances.

---

## 12 · Responsive audit (directive §28)

The world remains a single bbox with camera fit. New geometry re-verified at 1400×850,
1140×660, 1100×700 and 836×570: no overlap, no clipping, icon/name/cells/PIDs legible.
The OS panel is *shorter*, so the fit zoom is not degraded.

---

## 13 · Before / after acceptance criteria (directive §32)

Each A–N criterion maps to a gate assertion or a deterministic screenshot inspection
(see §14). The chapter is accepted only when all categories in §33 score ≥ 9.5.

---

## 14 · Verification plan (directive §34)

1. `tsc --noEmit` + `vite build`.
2. `npm run smoke` → smoke (story invariants, terminology ordering, determinism,
   program-immutability **pixel** equality b01↔b14, OS geometry containment/disjoint,
   resource-strip dimming metric presence) + scope (forbidden concepts EN+VI) +
   layout (containment, disjointness, chip-inside-cell, anti-queue).
3. Deterministic double-render byte-equality (smoke).
4. Screenshot grid at every load-bearing frame, EN + VI, 1400×850 + 1140×660 (harness).
5. Muted-narration inference (geometric, §9).
6. Adversarial misconception audit (§10).

---

*Implementation begins only after this file.*
