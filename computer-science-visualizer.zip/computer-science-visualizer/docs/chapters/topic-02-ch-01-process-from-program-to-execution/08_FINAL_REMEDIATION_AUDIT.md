---
guiding_question: "Which of Issues A–O still constitute real P1/P2 weaknesses in the current chapter, and which have already been proven correct by prior rounds — so that this round makes only justified changes?"
primary_consumer: "Implementation Engineers, Curriculum Guardian, QA Auditors, AI Agents, Owner"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/10_FINAL_HUMAN_ACCEPTANCE_REVIEW.md"
referenced_by: []
---

# Round 13 — Final Remediation Audit — Topic 02 / Chapter 01

**Date:** 2026-08-14 · **Method:** re-read of the current implementation (source + rendered
geometry), then an explicit A–O disposition. This round makes **only** the changes its own
audit justifies; it does not re-litigate issues already proven correct.

---

## Issue-by-issue disposition (A–O)

| # | Issue | Disposition | Evidence / rationale |
|---|---|---|---|
| A | Program too abstract / app identity | **KEEP — proven correct** | Concrete "Photos" app: icon (sun+mountain) + name on a shelf labelled "storage", gloss "a stored application … doing nothing on its own", no window chrome, no running-state. Compared against Calculator/Text-Editor/Terminal/Browser/Music/File-Explorer in Round 11; Photos has the lowest execution+window connotation while remaining naturally multi-instance. |
| B | One program → many Processes visually stronger | **KEEP** | Process cell is titled **"Process"** (class = title), "Photos" is a dim 10px *provenance subtitle*, PID chip carries instance identity. Hierarchy Process > PID > source is exact. No ownership arrow; OS remains the mediator (launch path `Program → OS → spot`). |
| C | OS system-software ontology | **KEEP** | Squared band (r=6) distinct from rounded tile/cell; "OS / Operating System" title; intake→create/identify/manage→creation; idle rows are borderless tracks (action slats, not three modules). |
| **D** | Why does the OS exist? | **FIX (P2)** | The narration carries the reason ("machine is shared → a stored file can't manage it → system software stands between"), but the *visual* only shows "machine slots light → OS core resolves". The stored Program plays **no part** in the beat, so muted the "between programs and the machine" mediation is not visible. Fix below. |
| E | Machine ≠ OS | **KEEP** | One coherent far-east machine region (CPU·RAM·I/O), separate from the OS, static (Round 8). |
| F | CPU ≠ Process | **KEEP** | Static machine, static Process interiors (existence ≠ execution). |
| G | Process ≠ window | **KEEP** | No chrome; scope gate forbids window/title-bar/desktop terms EN+VI. |
| H | OS mediation causally obvious | **KEEP** | Launch path `Program → OS → spot`; intake lights → core wakes → creation port emits → birth pulse. |
| I | PID from identity problem | **KEEP** | Selector ring fails on identical cells → chips dock one-per-cell. |
| J | Process lifetime | **KEEP** | Local dissolve; Program pixel-immutable; siblings remain. |
| K | Second launch / independence | **KEEP** | New spot + new PID; A gate-asserted unchanged. |
| L | Animation teaches | **KEEP** | Every motion has a cause→effect proposition. |
| M | Geometry expresses relationships | **KEEP** | West→east causal axis; anti-queue scatter. |
| N | Silent climax | **KEEP** | Anti-FIFO deaths (C→E→B→D), no queue/scheduler reading. |
| O | Responsive readability | **DEFER (P3)** | Primary info legible at 1400×850 / 1140×660; only tertiary labels shrink at legacy 836×570. Inherent, not a misconception. |

**Net: one justified fix (Issue D); 13 issues proven correct; 1 deferred P3.**

---

## Issue D — exact fix

**Problem:** during the `why-the-os` beat (B02) the stored Program is visually absent from
the story — a muted learner sees "machine lights up → OS appears" but not *why* the OS is
needed (a stored artifact cannot manage the shared machine by itself).

**Fix (minimal, in-scope):** give the beat a three-part *spatial* sequence that mirrors the
narration and makes the OS's mediating position visible:

1. machine region slots light in turn (existing, 0.22–0.42) — "the machine is shared";
2. **NEW** the Program emits a single restrained salience pulse (0.36–0.50) — "a stored
   file, inert, by itself";
3. OS core resolves in the middle (existing, 0.5–0.7) — "system software stands between
   programs and the machine".

The Program is west, the OS middle, the machine east — the three-part highlight makes
"programs … OS … machine" a visible left→right mediation, not a narrated claim. The pulse
reuses the existing `pulseK`/`glow` primitives and is visually distinct from the B05 rupture
ring (a soft glow, not an expanding ring) so the two beats cannot be confused.

**Regression risk:** none to the mental model (adds salience only, no new causality, no new
path, no new term). Bounded to the `why-the-os` beat window.

*Implementation follows this audit.*
