---
guiding_question: "Is the chapter ready for FINAL HUMAN ACCEPTANCE — would a beginner reconstruct Program → OS → Process → PID → lifetime from the actual rendered frames, with narration optional?"
primary_consumer: "Owner (human reviewer), Curriculum Guardian"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/09_FINAL_ADVERSARIAL_REVIEW.md"
referenced_by: []
---

# Round 12 — Final Human Acceptance Review — Topic 02 / Chapter 01

**Date:** 2026-08-14 · **Mode:** review only — **no code modified**. Rendered the real
chapter (16 A–P frames, EN + VI, at 1400×850; 1140×660 verified in prior rounds) via the
actual composer + chapter renderers + camera fit. Frames: `review/contact/{en,vi}/`,
contact sheets `_contact.png`.

**Honesty note (per the review's own rule):** this environment cannot literally *see*
bitmaps. Findings are therefore marked **PIXEL** (measured from the actual rendered
framebuffer) vs **GEOMETRY/SOURCE** (inferred from the deterministic renderer + metrics).
The contact sheets are presented for the human to do the literal eye pass.

---

## 1 · Human-review contact sheet (16 frames, EN + VI rendered)

| Frame | Beat | Should infer | Possible wrong inference | Blocked by (PIXEL/GEOMETRY) | Narration needed? | Confidence |
|---|---|---|---|---|---|---|
| A. Program | B01 | a stored "Photos" app on storage | "it's running / it's a window" | shelf + "storage" label + icon tile (no chrome) | no | STRONG |
| B. Why the OS | B02 | a system layer + a quiet machine context | "the OS is the machine" | squared band ≠ far-east machine region | no | STRONG |
| C. Launch begins | B03 | a request leaves; the app stays | "the app itself went" | Program pixel-static; spark travels | no | STRONG |
| D. OS receives | B04 | the OS takes over | "the OS is passive" | intake lights → core wakes | no | STRONG |
| E. OS creates | B05 | the OS creates a NEW entity | "the program became it" | creation pulse + boundary draw-in, 500px away | no | STRONG |
| F. Coexist | B06 | two different things (tile + cell) | "same thing" | rupture: both at max separation, sequential pulses | no | STRONG |
| G. "Process" | B07 | the new entity is named "Process" | "it's the app" | cell titled "Process", "Photos" is a dim subtitle | no | STRONG |
| H. Multiple | B08 | one program → a second entity | "only one instance" | second cell, same route, first untouched | no | STRONG |
| I. Identity problem | B09 | three identical entities, can't tell apart | "they're obviously different" | identical cells + failing selector ring | no | STRONG |
| J. PID | B10 | each got its own number | "PID = the program's number" | chip per cell, 3 distinct PIDs, 1 Program | no | STRONG |
| K. Lifetime | B11 | one Process's time is ending | "the program is ending" | shimmer local to one cell | no | STRONG |
| L. Termination | B11 late | Process gone; program + sibling remain | "killing it kills the app" | Program pixel-immutable; B still breathing | no | STRONG |
| M. Second launch | B12 | a NEW Process with a NEW PID | "old Process restarted" | new spot + new PID; A's state gate-asserted unchanged | no | STRONG |
| N. Independent | B12 late | instances are independent lives | "they're linked" | scattered cells, distinct PIDs, one dies while others live | no | STRONG |
| O. Climax | B13 | births/deaths interleave independently | "queue / turns / one at a time" | anti-FIFO deaths (C→E→B→D), scatter | no (silent) | STRONG |
| P. Bridge | B14 | one program, many independent instances | "window = Process" | no window anywhere; 2 cells + tile | no | STRONG |

**Narration required: NO on all 16.** Every load-bearing inference is carried by geometry +
animation.

---

## 2 · Five human-level tests

**TEST 1 — Program.** "What exactly is the Program?" → a stored application/artifact.
A cyan icon tile on a shelf labelled "storage", gloss "a stored application … doing nothing
on its own". Not a window (no chrome), not running (static), not a Process/CPU/OS. **PASS
(STRONG).**

**TEST 2 — Process birth.** At E (B05, frac 0.45): the spark left the Program two beats
earlier and is *inside the OS*; the OS creation port emits; a pulse + arc draw-in forms a
green cell in the field. Spatial origin = OS east port, not the Program. The Program is
pixel-static. Learner reads "the OS created a new entity", not "the program started
running". **PASS (STRONG).**

**TEST 3 — OS.** "What is this OS object?" → system software mediating between programs and
the machine. Squared band (r=6) distinct from the rounded tile (r=18) and cell (r=16);
title "OS / Operating System"; intake→create/identify/manage→creation; machine is a
*separate* far-east region. Tested against: factory (blocked — resource context + three
roles), CPU/machine (blocked — separate machine region), application (blocked — squared
system grammar + title), magic box (blocked — visible causal ports), scheduler (blocked —
no queue/order), Process itself (blocked — coexists with cells). **PASS (STRONG).**

**TEST 4 — Multiple Processes.** Muted: one Program → first → second → third Process. Reads
"repeated launches of the same stored Program made the OS create separate instances": the
same "Photos" provenance subtitle ties them to one Program; distinct PIDs + scattered
independent cells separate them. Not "one per window" (no windows), "duplicated itself"
(Process ≠ copy of the tile), "one Process contains all" (separate cells), "queue" (scatter),
"green boxes are copies" (green entity vs cyan file). **PASS (STRONG).**

**TEST 5 — Lifetime.** Muted: Process A dissolves; Program + Process B remain. Reads "the
Process instance ended", not "the Program ended". Local dissolve; Program pixel-immutable
across the termination beat (gate-asserted). **PASS (STRONG).**

---

## 3 · Geometry as semantic evidence

- **Program**: shelf + "storage" label → storage ✓; icon + name → identity ✓; pixel-static
  100% of timeline ✓.
- **OS**: squared shape → "system layer" (vs rounded entities) ✓; distinct from Program
  (cyan tile) and Process (green cell) ✓; west→east intake→core→creation ✓; reads as a
  mediator, not a decorative card ✓.
- **Process**: green rounded cell, "Process" title dominant over dim "Photos" subtitle ✓;
  PID chip = identifier inside the entity, not the entity ✓.
- **Machine**: CPU/RAM/I/O in one far-east region, *outside* the OS ✓ (Round 8); reads as
  physical context, static ✓; CPU no longer duplicated/unexplained ✓.
- **Multiple**: scatter + uneven spacing + anti-FIFO = independence ✓; no queue/scheduler ✓.

---

## 4 · Animation semantic audit

| Motion | Causal statement | Correct? |
|---|---|---|
| Program → OS | "a launch request travels; the Program stays" | ✓ (not "transforms into") |
| OS intake → core → creation port | "the OS processes and creates" | ✓ |
| birth pulse + draw-in | "a new entity is created" | ✓ (not "opens"/"activates") |
| selector fails → chips dock | "identity needed → each gets a PID" | ✓ (not "PID = Process") |
| dissolve | "the Process's lifetime ended" | ✓ (not "CPU stopped"/"window closed") |
| second launch | "same Program → new Process" | ✓ (not "old restarted") |

---

## 5 · P0/P1/P2/P3 findings

**P0 (fundamental misconception): NONE.**
**P1 (major causal/mental-model weakness): NONE.**
**P2 (meaningful beginner confusion): NONE.**
**P3 (visual polish only):** the two already-documented items — (a) tertiary labels
(source cue, machine resources) are smallest at the legacy 836×570 size; (b) the OS
"manage" role is the least-animated of its three roles. Both are polish, do not touch any
distinction, and are intentionally **not** escalated (per the rule against promoting P3 →
P2).

**NONE — no actionable issue.**

---

## 6 · Final decision

## FREEZE

All conditions hold:
- central mental model is self-evident (STRONG on all 16 frames);
- causal chain (Program → OS → Process) is visually recoverable;
- muted narration passes (all six core claims are visual, not narration-only);
- Program ≠ Process is unmistakable;
- OS mediation is understandable;
- one Program → many Processes is understandable;
- PID meaning is clear; lifetime distinction is clear;
- no P0/P1/P2 issue exists.

The chapter is ready for the owner's literal human visual pass over the contact sheets
(`review/contact/{en,vi}/_contact.png`) — the single remaining verification step, which is
a human eyeball, not a code change.

*No code was modified during this review.*
