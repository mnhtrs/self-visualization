---
guiding_question: "Which remaining visual relationships in Topic 02 Chapter 01 are still semantically ambiguous, and which minimal changes make the Program → OS → Process model self-evident without expanding scope?"
primary_consumer: "Implementation Engineers, QA Auditors, Curriculum Guardian, AI Agents"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/04_FINAL_VISUAL_PEDAGOGICAL_REFINEMENT.md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/05_ROUND4_VISUAL_SEMANTIC_AUDIT.md"
referenced_by: []
---

# Round 5 — Semantic Visual Refinement — Topic 02 / Chapter 01

**Date:** 2026-08-14 · **Method:** source inspection + deterministic render geometry. Every finding
below is grounded in the current implementation, not invented.

---

## Phase 0 — Audit answers (A–G)

### A. Does the "Photos" marker communicate provenance or identity?

**Finding: it is currently ambiguous, leaning toward identity.**

Measured from source: the source marker renders "Photos" at `F.cellId = 12 px`, weight 700,
cyan, alpha 0.85 — while the class caption renders "Process" at `F.cellCaption = 13 px`,
weight 800, white. The two lines are **within 1 px and one weight step of each other**.
Because "Photos" is a proper noun and sits on the top line of the cell, a learner can
reasonably read it as *the Process's name* ("this thing is called Photos"), collapsing the
Program/Process distinction the chapter exists to teach.

The marker's *purpose* (provenance) is correct; its *hierarchy* is wrong. This is the
concrete, real problem for Round 5.

### B. Does the OS read as system software or as a larger app card?

**Finding: it reads as a larger app card.**

The OS is a rounded rectangle (`OS_BAND.r = 22`) with a title inside its top ("OS" +
"Operating System") — the **identical grammar** as the Program card (rounded rect,
`r = 18`, name inside) and the Process cell (rounded rect, `r = 16`). All three object
types are the same shape family, differentiated only by colour and text. A learner can
read the OS as "another application, bigger, named OS" — the misconception the directive
flags ("OS = another application card").

### C. Does the launch animation establish Program → OS → Process?

**Finding: yes — verified correct by construction.**

The protagonist path is `Program → OS → S0` (anchors 0→1→2); the launch request travels
into the OS intake port, the OS core wakes, the creation port emits, and the birth pulse
fires at the destination spot. There is **no** Program→Process direct path in `PATH_WORLD`
or any renderer. No change required.

### D. Does the second launch preserve Process A while creating Process B?

**Finding: yes — correct by construction, but not yet explicitly asserted.**

Every instance's lifecycle is a pure function of `(beat, frac)` from `PROCS`; creating B
cannot touch A's state. However the smoke gate only asserts `relaunch.spot != first.spot`
and `relaunch.pid != first.pid` — it does **not** assert A's *lifetime/identity* invariance.
This is a missing regression gate, not a missing behavior.

### E. Does Process termination leave the Program visually untouched?

**Finding: yes — correct by construction, but under-asserted.**

The Program painter takes zero input from Process state (immutability by construction); the
termination dissolve is local to the cell. The existing pixel check compares B01 vs B14;
there is no assertion that the Program is pixel-identical *within the lifetime beat* across
the termination event. Missing regression gate.

### F. Can the chapter be understood muted?

**Finding: after Round 4, mostly — two residual ambiguities.**

The provenance marker (A) and the OS card grammar (B) are the two remaining obstacles. The
causal sequence, PID discovery, lifetime, and independence are already geometry-recoverable.

### G. Which frames are semantically ambiguous?

1. **Every post-naming frame (B07 → B14):** "Photos" ≈ "Process" in weight → ambiguous
   whether the Process's name is "Photos" or "Process" (finding A).
2. **OS-intro + steady-state frames (B02 → B14):** the OS reads as a big rounded card
   (finding B).
3. **OS core frames:** three permanently-stroked rows read as three labeled *modules*
   (`create / identify / manage`), inviting "the OS consists of exactly three parts"
   (§7). The labels are correctly event-anchored, but the permanent row borders
   communicate "three products" rather than "three actions this chapter uses."

---

## Design decisions

### 1 · Source marker → subordinated provenance cue (finding A)

Evaluate the three alternatives from §4:

| Option | Verdict |
|---|---|
| **A. restrained source marker** (icon + name, small) | chosen — but must be *smaller + dimmer* than today |
| **B. hierarchy** (small/dim "Photos", strong "Process", prominent PID) | **chosen as the target** — the current code *intends* B but doesn't achieve it (12 vs 13 px) |
| **C. permanent Program→Process lineage line** | **rejected** — implies the Program directly creates the Process, violating "OS remains the causal mediator" |

**Decision:** strengthen B. Reduce the marker name from 12 px → **10 px** (`F.sourceCue`),
weight 700 → 600, alpha 0.85 → 0.55, and shrink the mini icon 16 → 13 px. The result is an
unambiguous hierarchy: **Process (13 px, white, 800) > PID chip > Photos (10 px, dim cyan)**.
The marker reads as "this Process came from Photos", not "this Process is Photos". No new
term ("provenance") is introduced to the learner.

### 2 · OS → square system frame (finding B)

**Decision:** change `OS_BAND.r` from 22 → **6**. This is the smallest grammar change that
separates the three object types:

- **Program** — rounded app tile (r=18): *artifact/object*
- **OS** — squared system band (r=6): *system layer/framework*
- **Process** — rounded cell (r=16): *managed entity instance*

Squared corners are a long-standing "system/structure" cue (vs. rounded = "object/app"),
require no new drawing code, no new labels, and are legible at every canvas size. The OS
is already a vertical band on the west→east causal axis (intake west, creation east), so it
already *is* a "system layer" geometrically; only its corner grammar was card-like.

Rejected alternatives (documented, not chosen): widening the OS into a taller "band" or
wrapping it around the field (system frame surrounding everything) — both would make the
OS the dominant visual object (§8 of the Round-3 directive: OS must stay secondary), and
the latter reads as a physical container.

### 3 · OS rows → action states, not three modules (finding G3)

**Decision:** remove the permanent stroke on idle rows. Idle rows render as a faint fill
*track* only (no border); the border + fill appear only while the row is active (its causal
action). This keeps the "structure resolves during the intro" property (A1.2) while making
the *action* the salient thing — the rows read as "the OS doing work", not "three modules".
Labels remain revealed strictly post-observation (Knowledge Reveal Law).

### 4 · New regression gates (findings D, E, §23)

Add spec-derived assertions:
- **Second launch independence:** at `B.secondLaunch`, Process A is `alive`, its PID/spot
  equal its declared values (unchanged while B births), and A.pid ≠ B.pid.
- **Termination immutability:** Program pixels byte-identical at `(lifetime, 0.25)` vs
  `(lifetime, 0.95)` (the termination event occurs between them).
- **Provenance subordination (spec-derived):** `F.sourceCue < F.cellCaption` and
  `F.sourceCue < F.chipText` — the marker must be smaller than both the class name and the
  PID.
- **OS grammar:** `OS_BAND.r < CELL.r` (squared system frame vs rounded entity).

---

## Findings intentionally left unchanged

- **Launch causality** (C): already correct; re-verified.
- **PID discovery** (§14): already correct (no PID before B09; selector fails first).
- **Alive ≠ CPU** (§15): already correct (static interiors).
- **Anti-queue scatter** (§13): spots are balanced (two upper, three lower, both axes used,
  no row) — semantically meaningful, not merely non-collinear.
- **Silent climax** (§16): already correct (anti-FIFO deaths C→E→B→D, comets as decayed
  auxiliary launches).
- **`why-the-os` beat** (§6): the OS's conceptual origin (shared machine → stored file can't
  manage it → system software → OS) is already in narration; its visual state (resource
  strip resolving first, then the core) supports it. Preserved.

---

## Scope discipline

No new concepts, no new terms, no beat changes, no engine/platform change, no Topic-01
change. Deterministic `(beatIndex, beatFrac)` rendering preserved; renderers remain pure.

*Implementation follows.*
