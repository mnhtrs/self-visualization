---
guiding_question: "Has Topic 02 Chapter 01 reached a genuinely high pedagogical and visual standard such that a beginner can reconstruct Program → OS → Process → PID → lifetime without OS knowledge, and are there any remaining STRONG/ADEQUATE/AMBIGUOUS/FAIL criteria?"
primary_consumer: "Curriculum Guardian, QA Auditors, AI Agents, Owner"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/07_FINAL_MENTAL_MODEL_AUDIT.md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/07_MACHINE_OS_SEMANTIC_AUDIT.md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/07_WINDOW_PROCESS_PEDAGOGICAL_AUDIT.md"
referenced_by: []
---

# Round 10 — Final Holistic Acceptance Audit — Topic 02 / Chapter 01

**Date:** 2026-08-14 · **Method:** full source reconstruction + deterministic render
geometry + text scan + real-browser playthroughs. This is an acceptance audit: its job is
to *verify*, not to find work to do.

---

## Phase 1 — Beginner reconstruction

**With narration OFF, the visual sequence alone reconstructs:**

- A cyan app tile ("Photos" icon + name) rests on a shelf labelled **storage** — a stored
  artifact, not a running thing.
- A squared pink band ("OS / Operating System") sits between the tile and an open field,
  with "the machine" (CPU·RAM·I/O) as a quiet region at the far east.
- A spark leaves the tile toward the OS; the tile does not move; the OS intake lights, its
  core wakes, its creation port emits; a **green cell** draws itself in the field.
- The cell is titled **"Process"**, with "Photos" as a dim subtitle and (later) a **"PID n"**
  chip. A second launch births another cell with a new PID. One cell later dissolves while
  the tile and its sibling remain.

**BEGINNER MODEL == TARGET MODEL.** No gap requires narration to bridge. The six
load-bearing distinctions are all carried by geometry + animation (Phase 15: none are
"narration only").

---

## Phase 2 — Six load-bearing distinctions

| # | Distinction | Evidence | Verdict |
|---|---|---|---|
| 1 | PROGRAM ≠ PROCESS | different shape (tile vs cell), colour (cyan vs green), location (shelf vs field); rupture beat shows both at maximal separation | **STRONG** |
| 2 | Program does not BECOME Process | Program pixel-stable 100% of the timeline; birth is a creation pulse + boundary draw-in 500+ px away, never a morph | **STRONG** |
| 3 | OS creates Process | launch path `Program → OS → spot`; OS intake → core → creation port → birth pulse; no Program→Process path exists | **STRONG** |
| 4 | PROCESS ≠ PID | PID is a small chip docked inside a living cell; cells exist 3 beats before any chip; selector fails first | **STRONG** |
| 5 | Process has own lifetime | termination dissolve is local; Program pixel-immutable; siblings unaffected (gate-asserted) | **STRONG** |
| 6 | ONE PROGRAM → MULTIPLE PROCESSES | same "Photos" provenance subtitle + distinct PID chips on scattered cells; second launch = new spot + new PID, A unchanged | **STRONG** |

---

## Phase 3 & 20 — Program representation + exemplar decision

The Program is an app **tile** (icon + name) on a **"storage" shelf**, gloss "a stored
application … doing nothing on its own", with **no window chrome** (no title bar, no
close/minimize/maximize, no content area). It reads as a stored artifact, not an open app
or a GUI window.

**Exemplar comparison (conceptual):**

| Exemplar | Concreteness | Multi-instance naturalness | Window/Process confusion risk | Execution connotation |
|---|---|---|---|---|
| **Photos** | high (sun+mountain glyph) | high (image viewers are commonly opened twice) | low (icon on shelf, not window) | low |
| Terminal | high | very high | low | **high** (implies "where commands run") |
| Browser | high | high | medium | **high** (real multi-process arch = complexity trap, already banned) |
| Text editor | high | high | medium (document ≈ file confusion) | low–medium |
| Calculator | medium | **low** (single-instance feel) | low | medium |

**Decision: A. KEEP "Photos".** It is the strongest concrete exemplar: recognizable,
simple to draw, naturally multi-instance, and the *lowest* execution/GUI connotation. No
change is justified.

---

## Phase 4 — Process representation

Green rounded cell, titled **"Process"** (class name is the title), **"Photos"** as a dim
10px cyan *provenance subtitle*, **PID chip** as instance identity, two **static** content
marks. Hierarchy is **Process → Photos (provenance) → PID** — exactly the required order.
No window chrome, no Task-Manager-row affordances, no "busy" interior. Reads as an
OS-managed execution entity. **STRONG.**

---

## Phase 5–7 — OS + Machine ontology

OS = squared system band (r=6, distinct from the rounded Program tile r=18 and Process
cell r=16) with title "OS / Operating System", intake (west) → core (create/identify/manage
action slats, labelled only after observation) → creation port (east). It reads as system
software, not a machine/app/factory/dashboard.

Machine = **one** coherent low-salience region at the far east ("the machine": CPU·RAM·I/O),
static, distinct from the OS (Round 8 removed the former CPU·RAM·I/O strip from *inside*
the OS and the duplicate standalone CPU emblem). **Exactly one** machine representation.
**STRONG.**

---

## Phase 8–13 — animation, multiple process, PID, lifetime, alive≠executing, anti-queue

- **Launch:** Program stable → request → OS intake → create → birth. **No morph, no
  Program→Process, no window.** STRONG.
- **Birth:** creation pulse + boundary arc draw-in + interior condense — **creation**, not
  "opening"/"transformation"/"activation". STRONG.
- **Multiple:** same Program + separate OS-mediated launches → distinct spots + PIDs +
  lifetimes; A gate-asserted unchanged while B births. STRONG.
- **PID:** selector fails on identical cells → chips dock one-per-cell. STRONG.
- **Lifetime:** local dissolve; Program + siblings untouched. STRONG.
- **Alive ≠ executing:** static interior bars; only restrained boundary breathing; birth/
  association/dissolve are the only motions. STRONG.
- **Anti-queue:** scattered non-collinear spots, uneven spacing, anti-FIFO climax deaths
  (C→E→B→D). STRONG.

---

## Phase 14 — Window misconception

Absent by construction: zero "window" language (Round 9 scope-gate guards `window`/`title
bar`/`desktop` EN, `cửa sổ`/`thanh tiêu đề`/`màn hình nền` VI), no window chrome, no
window→Process causal path. The real acceptance criterion (visual semantics) is met:
nothing looks like a window. **STRONG.**

---

## Phase 15–19 — narration vs visual, climax, hierarchy, animation quality, UI

- None of the six core claims is narration-only; all are geometry-recoverable.
- Silent climax reconstructs "same Program → OS → multiple Processes → distinct PIDs →
  independent lifetimes", anti-FIFO, no queue/thread/window reading.
- Hierarchy: Program > OS causal action > Process > PID > machine context > labels.
- Every motion encodes a proposition (intake pulse = received; create-row = creation work;
  birth pulse = new entity; association = identity; dissolve = lifetime end).
- UI is clean, restrained, coherent with Topic 01; no decorative additions.

---

## Phase 21 — Acceptance matrix

| Criterion | Evidence | Risk | Verdict |
|---|---|---|---|
| Program ontology | stored-app tile on storage shelf | low | STRONG |
| Process ontology | green "Process" entity, provenance subtitle | low | STRONG |
| OS ontology | squared system band, software roles | low | STRONG |
| Machine ontology | one low-salience CPU·RAM·I/O region, static | low | STRONG |
| Program → OS causality | launch path + intake | low | STRONG |
| OS → Process causality | core → creation port → birth pulse | low | STRONG |
| PID meaning | chip inside owning cell, discovered post-selector | low | STRONG |
| Process lifetime | local dissolve, Program immutable | low | STRONG |
| Multiple instances | same provenance + distinct PID + scatter | low | STRONG |
| Independence | A unchanged while B births; anti-FIFO deaths | low | STRONG |
| alive ≠ executing | static interiors, no CPU/activity motion | low | STRONG |
| anti-queue | scatter proof + anti-FIFO climax | low | STRONG |
| Window misconception | absent by construction + scope guards | low | STRONG |
| Muted comprehension | full model reconstructable without narration | low | STRONG |
| Animation semantics | every motion has a proposition | low | STRONG |
| UI hierarchy | Program > OS > Process > PID > machine | low | STRONG |
| Responsive readability | ≥7px primary text at 1140×660/1400×850; tertiary labels smaller only at legacy 836×570 | low | ADEQUATE |
| Scope discipline | no scheduler/queue/thread/window/kernel terms EN+VI | low | STRONG |

---

## Phase 22 — Change decision

**FINAL ACCEPTANCE AUDIT — NO CHANGES REQUIRED.**

Every load-bearing criterion is STRONG; the single ADEQUATE item (responsive readability of
*tertiary* labels at the legacy 836×570 size) is inherent to the type scale, affects only
deliberately-subordinate context labels (source cue, machine resources), and does not touch
any of the six distinctions. Per the final rule — "Do not invent problems merely to justify
another code change" — no code is modified.

---

## Phase 23–24 — Documentation + verification (no code changed)

Verification re-run to confirm the accepted state is green:
- `tsc --noEmit` — PASS
- `vite build` — PASS
- `npm run smoke` (smoke + scope + layout) — PASS
- Deterministic double-render — byte-identical
- EN + VI browser playthroughs @ 1400×850 and 1140×660 — 0 page errors

**Freeze recommendation:** all six load-bearing distinctions STRONG, causal sequence
verified, muted narration passes, browser rendering passes, EN/VI equivalent, no major
misconception, no window/factory/queue reading. The chapter is **ready to freeze pending the
owner's literal human visual pass** over `review/shots-t02c01/{en,vi}` — the one item this
environment cannot perform itself.
