# Agent Memory — Topic 02 / Chapter 01 (process-from-program-to-execution)

**Last checkpoint:** FINAL ACCEPTANCE — FROZEN (2026-08-14)

> ⚠️ **NON-NEGOTIABLE STATUS:** Chapter 01 is **FROZEN**.
> DO NOT modify CH01 source code, renderer, story, animation, or geometry.
> All CH01 lessons have been extracted into the authoritative Topic 02 inheritance baseline:
> - [`00_TOPIC_02_PRODUCTION_BASELINE.md`](../../topics/topic-02/00_TOPIC_02_PRODUCTION_BASELINE.md)
> - [`01_INHERITED_AND_LOCKED_DECISIONS.md`](../../topics/topic-02/01_INHERITED_AND_LOCKED_DECISIONS.md)
> - [`02_CHAPTER_DELTA_AUDIT_TEMPLATE.md`](../../topics/topic-02/02_CHAPTER_DELTA_AUDIT_TEMPLATE.md)
> - [`03_TOPIC_02_FAST_PRODUCTION_WORKFLOW.md`](../../topics/topic-02/03_TOPIC_02_FAST_PRODUCTION_WORKFLOW.md)
> - [`04_TOPIC_02_CHAPTER_CONTRACT.md`](../../topics/topic-02/04_TOPIC_02_CHAPTER_CONTRACT.md)
>
> **Future Topic 02 Chapters (CH02–CH05):** Inherit all locked decisions and visual/animation contracts. Execute via `INHERIT → DEFINE → DELTA AUDIT → STORY → IMPLEMENT → RENDER → MATERIALITY CHECK → VERIFY → FREEZE`. Do NOT re-audit CH01 ground truth.

## Freeze
One comprehensive audit found no remaining P0/P1/P2 issues. The prior choreography pass
(rupture simultaneity + look-back, second-launch independence ack, lifetime survivor ack)
closed the last material gaps. All six central proofs are visual; all major false models
blocked; scope clean; runtime/build green. P3 items (cosmetic) intentionally left per the
materiality rule. **Chapter FROZEN.**

## Choreography pass — coexistence + independence proofs (2026-08-14)

## Choreography pass (material, visible at normal speed)
Strengthened the chapter's two central *proofs* so they are demonstrated by motion, not
just labelled:

1. **Rupture = true simultaneity (Program ≠ Process).** The Program pulse and the Process
   pulse now OVERLAP (windows 0.10–0.42 vs 0.30–0.68) — both salient at once, which is the
   actual point ("two things coexist"). A new "look-back" pulse (0.62–0.88) re-glows the
   Program afterward: "still here, unchanged". (Previously they were sequential — which
   wrongly separated them in time.)
2. **Second-launch independence (B08).** While Process B is born, Process A emits one
   restrained "still here, untouched" pulse (`INDEP_A_ACK`, 0.62–0.92) — the second launch
   visibly does not disturb the first instance.
3. **Lifetime independence (B10).** After Process A is gone, the surviving Processes
   (B, C — computed via `cellStateAt`, not hardcoded) emit one restrained "still alive"
   pulse (`SURVIVOR_ACK`, 0.84–0.97) — only A ended.

No new concepts, no spine change, deterministic beat/frac preserved. Gates: tsc/build/
smoke/scope/layout PASS; deterministic byte-equal double-render; EN+VI browser playthroughs
0 page errors. Contact sheets regenerated.

## Final pass (skeptical visual review)

## Final pass (skeptical visual review)
Removed the directional chevrons I had added to the OS intake/creation ports: static
east-pointing arrows read as a **network/data-flow pipeline or hardware socket** — a false
model. Causality is (and was) carried by the animated launch request + creation pulse, not
a drawn glyph. The ports are now plain causal entry/exit points. No other false-reading
element remained (Process has no header divider / progress tracks; OS has no nested panel;
Program sits in a storage platform; machine is one separate region).

Gates: tsc/build/smoke/scope/layout PASS; deterministic byte-equal double-render; EN+VI
browser playthroughs 0 page errors. Contact sheets regenerated.

## Final remediation (OS system-layer grammar + causal flow)

## Final remediation (OS system-layer grammar + causal flow)
1. **OS band tightened** 300→232 tall (was a tall hollow box reading as an empty card;
   now a tight *band* of system software, aspect ≈1.0). Core re-fit (top 84→70, h 168→112);
   the PID term pill no longer floats far below the band (moved up ~60px).
2. **Port directional chevrons** — the intake (west) and creation (east) ports now each
   carry a small east-pointing chevron: causal flow runs west→east (requests in, creation
   out), so the ports read as *flow*, not hardware sockets.
3. **Borderless core tint** — a soft fill (no border) behind the three action tracks
   unifies them as ONE system area (functions of one OS), not three modules and not a card.

Gates: tsc/build/smoke/scope/layout PASS; deterministic byte-equal double-render; EN+VI
browser playthroughs 0 page errors. Contact sheets regenerated.

## Deep refinement — de-windowing / de-card / materialization (2026-08-14)

## Deep refinement (senior visual-design pass)
Focused on removing "generic UI card / dashboard / window" readings and making the
conceptual visualization read as such:

1. **Process cell: removed the horizontal header divider** (a "title-bar" affordance that
   read as an application window). Grouping is now carried by spacing + weight alone.
2. **Process content marks: removed the "track" outline** (a progress-bar / task-bar cue
   that implied activity); now short filled segments that read as "contents".
3. **OS: removed the nested core sub-panel border** (a "panel inside a panel" = dashboard
   card); the three action tracks now float directly in the band — one software layer.
4. **Process birth: added a center bloom** — the entity now materializes from a point
   (radial fill expanding with the boundary) instead of "a rectangle being drawn", so
   birth reads as "came into existence". Pixel-verified smooth 0→4446 lit ramp.
5. **Program: added a recessed storage platform** behind the tile — the artifact visibly
   SITS IN storage, grounding "stored artifact" without a label.

Gates: tsc/build/smoke/scope/layout PASS; deterministic byte-equal double-render; EN+VI
browser playthroughs 0 page errors. Contact sheets + montage regenerated.

## Final quality improvement pass (4 targeted changes)

## Final quality improvement pass (4 targeted changes)
1. **Process title hierarchy fixed** — the PID chip text (15px) was visually louder than
   the "Process" title (13px), inverting the required hierarchy. Now: `cellCaption` 13→15,
   `chipText` 15→14, `sourceCue` 10→11 → **Process (15) > PID (14) > Photos (11)**. New gate
   asserts `cellCaption > chipText`.
2. **Launch-request departure ripple (B03)** — a small expanding cyan ring fades out as the
   request leaves the Program, so "something departed from here" is a distinct event and the
   tile reads as stationary. Pixel-verified (peaks ~9925 px at B03 frac 0.2 vs ~8500 baseline).
3. **OS ports more legible** — `OS_PORT` 10×38 → 12×44 (entry/exit sockets of the mediation).
4. Provenance "Photos" slightly more readable (10→11px) while staying subordinate.

Gates: tsc/build/smoke/scope/layout PASS; deterministic byte-equal double-render; EN+VI
browser playthroughs 0 page errors. Screenshots + contact sheets regenerated.

## Final quality polish (4 targeted visual improvements)

## Final quality polish (4 targeted visual improvements)
1. **Process birth boundary** now sweeps in as the cell's own rounded-rect outline
   (dash-offset along the real path) instead of a circular arc that didn't match the cell
   shape — the entity forms continuously as itself.
2. **OS idle core rows** given a faint visible track (fill 0.04→0.07, still borderless) so
   the three action tracks read as structure, not an empty panel (kept subordinate; not
   "three modules").
3. **OS "Operating System" subtitle** contrast up (unlit alpha 0.4→0.52).
4. **Machine region corner radius 14→8** — a squarer "physical bay" grammar, distinct from
   the rounded Program/Process "objects".

Gates: tsc/build/smoke/scope/layout PASS; deterministic byte-equal double-render; EN+VI
browser playthroughs 0 page errors. Screenshots + contact sheets regenerated.

## Round 14 — Final Holistic Remediation (no code change)

## Round 14 — Final Holistic Remediation (no code change)
See `08_FINAL_HOLISTIC_REMEDIATION.md`. Full A–AD adversarial matrix (31 items): 30 SOLVED,
1 OK (why-OS reason = narration-carried premise). **Zero material P0/P1/P2 issues found.**

- **Pixel-verified the two highest-priority concerns:** (1) "OS already exists before
  launch" — the OS band + "OS" title render from beat 0 (53,126 lit px at B00 and B01,
  before any launch), so "Program → OS appears" is structurally impossible; (2) "why the OS
  exists" — already handled by Round 13's three-part sequence (machine → inert-Program
  pulse → OS core resolves) + the OS's mediating position on the axis.
- OS shape re-evaluated vs 3 alternatives → current squared band IS the "mediation layer";
  no change. Program exemplar re-scored → Photos still best; no change.
- Per the FINAL RULE (do not manufacture problems), no code was changed. Gates re-run:
  tsc/build/smoke/scope/layout PASS.

## Round 13 — Final Remediation (one P2 fix)

## Round 13 — Final Remediation (one P2 fix)
See `08_FINAL_REMEDIATION_AUDIT.md`. Explicit A–O disposition: 13 issues KEEP (proven
correct across prior rounds), 1 DEFER (P3 responsive of tertiary labels), **1 FIX (Issue D,
why-the-OS)**.

- **Issue D fix:** the `why-the-os` beat now has a three-part *spatial* sequence that makes
  the OS's mediating position visible: (1) machine slots light (0.22–0.42, existing) →
  (2) the Program emits a single restrained glow pulse (0.36–0.5, NEW, "a stored artifact,
  inert, by itself") → (3) OS core resolves in the middle (0.5–0.7, existing). The Program
  (west) → OS (middle) → machine (east) left-to-right mediation is now *seen*, not just
  narrated. New story window `OS_INTRO.programPulse`; soft glow (distinct from the B05
  rupture RING) in `drawProgramCard`. Pixel-verified: pulse peaks at B02 frac 0.43
  (~10113 lit px) vs baseline ~8300 elsewhere.
- No other code changed (Issues A–C, E–N proven correct; O deferred).

Gates: tsc/build/smoke/scope/layout PASS; deterministic byte-equal double-render; EN+VI
browser playthroughs 0 page errors.

## Machine glyph polish (owner request, 2026-08-14)

## Machine resource glyphs (owner small request)
Upgraded the three resource markers inside "the machine" region from flat labelled slots
to **mini hardware glyphs echoing Topic-01 CH01**: CPU = chip with pins + glowing core
(drawCpuGlyph); RAM = rounded stick with memory segments (drawRamGlyph); I/O = trapezoid
port with contact pins (drawIoGlyph), designed to match the other two. Metrics: `MACHINE`
84→96 wide; `MACHINE_SLOT` 60×20→76×22 (to fit icon + label). Static (no new animation);
low-salience fills/strokes preserved. Gates re-passed (machine region inside field, slots
inside region, cells clear); tsc/build/smoke/scope/layout green; EN+VI browser 0 errors.
Screenshots + contact sheets regenerated.

## Round 12 — Final Human Acceptance Review (review only, no code change)

## Round 12 — Final Human Acceptance Review (review only, no code change)
See `10_FINAL_HUMAN_ACCEPTANCE_REVIEW.md`. Rendered the real chapter at 16 A–P frames
(EN+VI @ 1400×850) into a human-review contact sheet (`review/contact/{en,vi}/_contact.png`),
ran the five human-level tests, geometry + animation semantic audits, and a P0–P3
classification. Result: **FREEZE** — no P0/P1/P2 issue; all 16 frames STRONG; the six core
claims are visual (not narration-only). The only remaining step is the owner's literal human
visual pass over the contact sheet.

## Round 11 — Final Adversarial Review (acceptance, no code change)
See `09_FINAL_ADVERSARIAL_REVIEW.md`. Independent Level-4 (beginner-resistance) test:
26-misconception attack (A–Z), 7-exemplar re-litigation, honest 16-dimension scoring.
Result: **ACCEPTED — zero code changes.**

- All 26 misconceptions BLOCKED (none survive muted narration); the core one ("launching
  = the program itself runs") is the most aggressively blocked (frozen Program + new
  OS-created entity).
- "Photos" confirmed as the best exemplar (recognizable + multi-instance + lowest
  execution/window connotation vs Calculator/Text Editor/Terminal/Browser/Music/File
  Explorer).
- All six core claims are VISUAL (not narration-only). Honest scores: core pedagogy
  dimensions 9.5; weakest = responsive readability 8.5 (legacy 836×570 tertiary labels),
  a P3 not fixed per the directive.
- No P0/P1/P2 issues. Final verification (no code changed): tsc/build/smoke/scope/layout
  PASS.

**Freeze recommendation: ready to freeze pending owner's literal human visual pass**
over `review/shots-t02c01/{en,vi}`.

## Round 10 — Final Holistic Acceptance Audit (acceptance, no code change)
See `08_FINAL_HOLISTIC_ACCEPTANCE_AUDIT.md`. Full-spec acceptance audit (18-criterion
matrix). Result: **FINAL ACCEPTANCE — NO CHANGES REQUIRED.**

- All six load-bearing distinctions STRONG (Program≠Process; no morph; OS creates; PID≠
  Process; own lifetime; one→many instances).
- Beginner reconstruction (muted) == target model; no narration-only claims.
- Exemplar decision: **KEEP "Photos"** — strongest of {Photos, Terminal, Browser, Text
  editor, Calculator} (recognizable, naturally multi-instance, lowest execution/GUI
  connotation).
- One ADEQUATE (not STRONG) criterion: tertiary-label size at the legacy 836×570 size —
  inherent, affects only subordinate context labels, no fix justified.
- Verification re-run (no code changed): tsc/build/smoke/scope/layout PASS; deterministic
  byte-equal double-render; EN+VI browser playthroughs 0 page errors.

**Freeze recommendation: ready to freeze pending the owner's literal human visual pass**
over `review/shots-t02c01/{en,vi}`.

## Round 9 — Window ↔ Process Pedagogical Audit (owner-directed)
See `07_WINDOW_PROCESS_PEDAGOGICAL_AUDIT.md`. Adversarial test of one beginner
misconception: "a window opens ⇒ a Process is created / one window = one Process."

**Classification: A. NO REAL RISK** — the design already prevents it by construction:
zero "window" language in learner-visible text; no window chrome on any object; Program is
explicitly a *stored* artifact ("storage" shelf + gloss "a stored application"); Process is
titled "Process" (not "Photos"), with "Photos" as a dim subordinate provenance subtitle;
birth = creation pulse + boundary draw-in (not "opening"); launch always OS-mediated
(Program → OS → spot).

**One justified change (verification only, no chapter code):** added Window-term regression
guards to the scope gate — `window` / `title bar` / `desktop` (EN) and `cửa sổ` /
`thanh tiêu đề` / `màn hình nền` (VI) are now forbidden in learner-visible text, so the
misconception can never be introduced by a future narration edit. Derived from the
pedagogical spec (Phase 15 items 10–11), not from current geometry.

All green: tsc, `vite build`, smoke/scope/layout, EN+VI browser playthroughs (0 page errors).

**Status: NOT frozen** — final owner sign-off + human visual pass still required.

## Round 8 — Machine / OS Semantic Cleanup (owner-directed)
See `07_MACHINE_OS_SEMANTIC_AUDIT.md`. Fixed the duplicate/ambiguous machine
representation. No spine / concept / scope / engine change.

- **Problem:** "the machine" was drawn as a CPU·RAM·I/O strip INSIDE the OS panel, while a
  separate standalone "CPU" emblem sat at the far east — implying "OS contains the machine"
  + "the CPU is separate from RAM/I/O" + "unexplained CPU".
- **Fix (directive option A):** (1) removed the resource strip from the OS (OS is now pure
  system software: title + intake → create/identify/manage core → creation port; core
  expanded 132→168 to fill); (2) replaced the far-east "CPU" emblem with a coherent
  low-salience **"the machine" region** holding CPU · RAM · I/O slots (machine in exactly
  ONE place); (3) made the machine region **static** (no breathing core — no CPU-activity
  implication). Metrics: removed `OS_RES`, added `MACHINE {84×116}` + `MACHINE_SLOT`;
  `OS_CORE.h` 132→168. Captions: `CAP.machineTitle`/`machineRes` replace
  `CAP.osResTitle`/`osRes`. `OS_INTRO.resStrip` → `OS_INTRO.machine`. Machine entity name
  'CPU'→'Machine', gloss rewritten.
- Narration was already correct ("OS stands between programs and the machine") — no change.
- New smoke gates: no duplicate machine representation (machine region separate from OS,
  slots inside region, cells clear of machine region).

All green: tsc, `vite build`, smoke/scope/layout, deterministic byte-equal double-render,
EN+VI browser playthroughs @ 1400×850 + 1140×660 (0 page errors).

**Status: NOT frozen** — final owner sign-off + human visual pass still required.

## Round 7 — Final Mental Model Audit (acceptance, no code change)
See `07_FINAL_MENTAL_MODEL_AUDIT.md`. This was an acceptance audit, not a redesign.
Result: **ACCEPTED (option A)** — no major mental-model weakness; no code changed.

- Five-minute learner simulation: all 14 beats produce the correct interpretation from
  geometry alone.
- Six critical distinctions all STRONG (Program/Process, OS/Program, Process/PID,
  program-identity/process-identity, lifetimes, new-vs-restarted).
- OS ontology sufficient (resource strip + three roles + "Operating System" title + manage
  row pulse = "management layer", not "factory").
- Muted-narration table: 9/9 PASS. Animation/geometry/UI-hierarchy/scope tests all PASS.
- Two honest minor observations (not misconceptions, no fix): the OS "manages" role is its
  least-animated role; resource-strip labels are smallest at ≤1140×660.

Freeze recommendation: **freeze pending owner's human visual pass** — automated/geometric/
pixel/browser evidence all green; the literal human visual review is the one item I cannot
perform myself.

## Round 6 — Conceptual Readability Review (owner-directed)

## Round 6 — Conceptual Readability Review (owner-directed)
See `06_CONCEPTUAL_READABILITY_AUDIT.md`. This was a *conceptual* (not polish) round:
the four-object test (Program/OS/Process/PID) was audited with narration muted.

**One real semantic problem found, one minimal fix.**
- The Process header still placed "Photos" on the TOP line and "Process" below — the
  "Photos ↓ Process" arrangement the directive §7 forbids. A proper noun on a card's top
  line reads as the entity's *title*, so a muted learner could still read the cell as "a
  thing named Photos". Fix: swapped the two lines — the class name "Process" is now the
  title (top), the source marker "Photos" is a subordinate subtitle (below). Metrics:
  `CELL_CAPTION_Y` 32→14, `CELL_ID.y` 14→32. Pixel-verified (white "Process" centroid row
  13 vs cyan "Photos" row 27).
- New spec-derived gate: `CELL_CAPTION_Y < CELL_ID.y` (class name above source marker).

**Audited and intentionally left unchanged** (no real misconception): OS-is-not-a-factory
(resource strip + three roles + title + `why-the-os` already anchor "management layer");
OS grammar (squared band on the west→east causal axis already IS a management band);
launch causality; multiple-process proof; second-launch independence; termination
immutability; PID discovery; alive≠CPU; anti-queue scatter; animation semantics
(every motion has cause→transition→effect).

All green: tsc, `vite build`, smoke/scope/layout, deterministic byte-equal double-render,
EN+VI grids @ 1400×850 + 1140×660, real-browser playthrough (0 page errors).

**Status: NOT frozen** — final owner sign-off + human visual pass still required.

## Round 5 — Semantic Visual Refinement (owner-directed)
See `05_SEMANTIC_VISUAL_REFINEMENT.md`. Two real semantic ambiguities closed, plus
missing regression gates. No spine / concept / scope / engine change.

- **Provenance marker subordinated (critical).** The Process cell's "Photos" marker was
  nearly the same weight as the class caption (12px vs 13px) — it could read as the
  Process's *name* ("this thing IS Photos"). Now: `F.sourceCue = 10px`, weight 600, alpha
  0.55, icon 16→13px — an unambiguous hierarchy **Process (13px) > PID (15px) >
  Photos (10px)**. The marker is a provenance cue, not an identity.
- **OS → squared system frame.** `OS_BAND.r` 22 → 6. Three grammars now distinguish the
  object types: Program = rounded app tile (r18) · OS = squared system layer (r6) ·
  Process = rounded entity (r16). The OS no longer reads as "a bigger app card".
- **OS rows → action states.** Idle rows render as borderless tracks; the border+fill
  appear only while a row acts (create/identify/manage). Rows read as the OS *doing work*,
  not "three modules".
- **New regression gates (Round 5):** second-launch independence (A alive/unchanged while
  B births, distinct pid/spot); termination immutability (Program pixels identical across
  the lifetime beat, ambient clock held constant); provenance subordination
  (`sourceCue < cellCaption < …`); OS grammar (`OS_BAND.r < CELL.r && < PROGRAM_CARD.r`).

All green: tsc, `vite build`, smoke/scope/layout, deterministic byte-equal double-render,
EN+VI grids, real-browser playthrough (0 page errors).

**Status: NOT frozen** — final owner sign-off + human visual pass still required.

## Round 4 — Visual Semantic Audit (owner-directed)
See `05_ROUND4_VISUAL_SEMANTIC_AUDIT.md`. One critical gap closed, plus restrained
semantic softening. No spine / concept / scope / engine change.

- **Program identity now propagates (critical).** Process cells carry a restrained
  Program-identity marker: a small copy of the SAME app icon + "Photos" name (cyan),
  above the "Process" class caption, with the PID chip as instance identity. A
  three-layer identity stack: program → class → instance. Gated by `nameKnown` (B06+),
  so birth (B04) and rupture (B05) still show an *unnamed* entity; the identity-problem
  trio stays identical (same marker, no PID). Draws via shared `drawAppGlyph` (same icon
  as the Program card). Metrics: `CELL_ID`, `CELL_CAPTION_Y`, `F.cellId`; `CELL_HEAD_H`
  30→42; `CELL_BARS` 3→2; `CHIP.dyFromCellTop` 78→76.
- **OS reads less like a dashboard.** Function rows slimmed/dimmed (action slats, not
  three "modules"), "OS" monogram 26→22 px, row labels → `F.micro`. Resource strip dimmed
  a further notch. Addresses "the OS consists of exactly three modules" risk.
- No change to the causal animation contracts (birth pulse + boundary draw-in; PID
  association; OS-mediated second launch) — re-audited, correct.

Gates (spec-derived additions: `CELL_BAR_FRACS.length === CELL_BARS.count`, header
identity-marker/caption fit above divider, bars/chip no-collision). All green: tsc,
`vite build`, smoke / scope / layout, deterministic byte-equal double-render, EN+VI
screenshot grids, real-browser playthrough (0 page errors).

**Status: NOT frozen** — visual self-evidence is now implemented but final owner
sign-off (and a human visual pass over the screenshots) is still required.

## Final Visual + Pedagogical Refinement (Round 3, owner-directed)
See `04_FINAL_VISUAL_PEDAGOGICAL_REFINEMENT.md`. The 15-beat spine, causal model,
mental model, PID-association, static cell interiors, and all locked rules are
UNCHANGED. Round 3 raised visual/polish quality only:

- **Program → concrete app.** The generic document card is now a concrete app
  tile: a "Photos" icon (sun+mountain glyph) + name on the storage shelf. The
  icon/name are the Program's stable visual identity; no PID ever attaches to it
  (proves ONE PROGRAM → MANY PROCESS INSTANCES). Narration b01 anchors "Photos"
  once. (metrics `APP_ICON`, `APP_NAME`; `CAP.appName`; `appIconRect`/`appNamePos`.)
- **OS → system panel.** Re-proportioned 170×420 (0.40 capsule) → 230×300 (0.77
  panel) with a title header ("OS" + "Operating System / Hệ điều hành" subtitle,
  revealed from the intro). Removed the duplicate giant "OS" + external drawName.
  Same causal anatomy: intake port → core (create/identify/manage) → creation port.
- **Resource strip de-emphasised** (CPU/RAM/I/O now dimmer; `F.micro` added).
- **Type scale:** all font sizes moved onto `F` (added `osTitle`, `appName`,
  `micro`, `mark`); removed hardcoded 10/11/24/42 literals.
- Glosses/narration lightly updated for the concrete app.

Gates re-established (were absent from the tree — recorded debt): `scripts/` now
holds smoke/scope/layout gates + deterministic screenshot harness. All green:
tsc, `vite build`, smoke (15-beat order, terminology ordering, lifecycle,
anti-FIFO climax, determinism byte-equal, program pixel-immutability), scope
(forbidden concepts EN+VI), layout (containment/disjoint/anti-queue/legibility).

**Status: NOT re-frozen — final owner sign-off pending (per Round-3 directive §35,
"FROZEN" only when all categories ≥ 9.5 AND no unresolved issue).**

## Deep Refinement Round 2 (owner-directed)
15 beats now (new `why-the-os` at index 2 — OS conceptual origin before it acts). OS
redesigned: intake port → management core (create/identify/manage rows, labels revealed
post-observation via OS_ROW_LABEL_AT) → creation port → resource strip (CPU·RAM·I/O).
PID re-visualized as identity ASSOCIATION (focus ring + dashed logical link + chip
resolves in place — no packet flight). Process pill names the class (concept band above
the field). Launch narration separates request from Program. VI glosses locked:
Process (tiến trình) / PID — mã định danh tiến trình / OS — hệ điều hành. Gates 367
(smoke 209 · scope 53 · layout 105). EN+VI playthroughs (34 A–U stops) + 1140×660: clean.

## Refinement round (post-production, pre-freeze)
Three mandatory fixes applied in-implementation (see 02_PEDAGOGICAL_AUDIT.md §Final
Pedagogical Refinement): (1) static cell interiors — existence ≠ execution, new metric
`CELL_BAR_FRACS`, restrained boundary breathing; (2) Program-lifetime falsehood removed
from b10; (3) recipe/cooking analogy replaced with direct ontology in b06. Plus 5
secondary precision fixes (b05/b07/b09/b11 wording, both term-pill subs). Gates grew
314 → 323 (locks against regressions). EN+VI browser playthroughs re-verified, 0 errors.

## Completed phases
- Phase 0: source-of-truth reconstruction + constraint map (blueprint §0)
- Phase 1–7: pedagogical model locked, beat table locked, visual argument, silent climax,
  geometry, animation contracts, T01 architecture extraction — all in
  `01_CHAPTER_PRODUCTION_[BLUEPRINT].md`
- Phase 8: blueprint frozen before any code
- Phase 9: implementation at `src/content/topics/02-operating-systems/01-process-from-program-to-execution/`
  (metrics → layout → story → beats → renderers → assemble; declarative story data; single
  stable `world` scene; deterministic beat-driven painters)
- Phase 10: real-browser playthrough EN+VI at 1400×850 + 1140×660, 31 deterministic stops,
  0 page errors — screenshots in `review/shots-t02c01/`
- Phase 11: adversarial audit — 12/12 misconceptions blocked (`02_PEDAGOGICAL_AUDIT.md`);
  3 implementation fixes applied
- Phase 12: gates — smoke 191 · scope 33 · layout 90 (314 total, `npm run smoke`), build PASS

## Key facts
- Terms owned: Process (revealed b06), PID (revealed b09, disclosure-at-creation framing)
- Debt facet: F1 (ownership); canons extended: C-09, C-10
- PIDs single-sourced in `scenes/story.ts` PROCS: 4312/4318/4331/4402/4417/4459/4473
- Climax death order C→E→B→D (anti-FIFO by design, gate-asserted)
- Program painter takes no Process-state input (immutability by construction)

## Next task
Owner review → freeze ceremony; then CH02 (`process-execution` — Process Execution: Pause, Switch, Resume) production may begin from
the b13 open loop ("does a Process actually execute every moment it is alive?").
