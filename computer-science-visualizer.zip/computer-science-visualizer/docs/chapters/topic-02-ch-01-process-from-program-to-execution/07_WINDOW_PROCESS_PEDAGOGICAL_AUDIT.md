---
guiding_question: "Does Topic 02 Chapter 01 inadvertently teach that 'a window opens ⇒ a Process is created' or 'one window = one Process', and if not, which assertions lock that misconception out permanently?"
primary_consumer: "Curriculum Guardian, QA Auditors, AI Agents, Owner"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/07_FINAL_MENTAL_MODEL_AUDIT.md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/07_MACHINE_OS_SEMANTIC_AUDIT.md"
referenced_by: []
---

# Round 9 — Window ↔ Process Pedagogical Audit — Topic 02 / Chapter 01

**Date:** 2026-08-14 · **Method:** source inspection + deterministic render geometry +
text scan. This audit tests one specific beginner misconception: **"a Process is created
when a window opens / one window = one Process."**

---

## 1 · Locked distinction (Phase 1)

Program = stored artifact · Process = OS-created execution instance · Window = GUI
presentation surface. The chapter's causal chain is **Program → launch request → OS →
Process → PID + lifetime** — no window anywhere in it.

## 2 · Phase 2 — adversarial beginner test (evidence from source)

| # | Question | Answer | Evidence |
|---|---|---|---|
| 1 | What object did the learner launch? | The stored "Photos" app (a tile on a "storage" shelf) | `drawProgramCard`: icon + name on `shelfLine`, "storage" label, "Program" part-name |
| 2 | What does the OS create? | A green "Process" cell | `drawCell`: green cell, class caption "Process" |
| 3 | What event signals creation? | Creation pulse + boundary draw-in | birthing phase: `pulseK` + arc sweep |
| 4 | What precedes birth? | OS creation port emits | `OS_CREATE.emit` → east port arc → birth pulse at the spot |
| 5 | Does a window appear before birth? | **No window exists anywhere** | zero "window" in learner-visible text; no window chrome drawn |
| 6 | Does a window transform into Process? | No window to transform | — |
| 7 | Does Process transform into a window? | No | — |
| 8/9 | Does opening a window create (another) Process? | No window opens | — |
| 10 | Does the Program read as a GUI window? | **No** — it is an app *tile* (icon + name) on a shelf labelled "storage", gloss "a stored application" | no title bar, no close/minimize/maximize buttons, no content area |
| 11 | Does the Process cell look like an app window? | **No** — titled "Process" (not "Photos"), green entity, PID chip | class caption is the title; "Photos" is a dim subordinate subtitle |
| 12 | Does the Process header/icon read as "the Photos window"? | **No** | header order is Process (title) → Photos (subtitle); no window chrome |
| 13 | Can Process be understood without windows? | **Yes** — introduced purely as "a new entity the OS created in execution space" | B04/B05 show an unnamed entity; "Process" named at B06 |
| 14 | Muted: could a beginner infer "one window = one Process"? | **No** — there is no window to map to a Process | — |
| 15 | Muted: could a beginner infer "opening another window creates another Process"? | **No** — second launch is the same Program → OS → new cell route | `PATH_WORLD`: every launch is `P_PROGRAM → P_OS → spot` |

## 3 · Phase 3 — the "Photos" example audit

The Program representation is **A (a stored application/program artifact)**, not **B (an
application window)**:
- It sits on a shelf explicitly labelled **"storage"**.
- Its gloss is **"A stored application… an ordered list of instructions, written once,
  doing nothing on its own."**
- It has **no window chrome** (no title bar, no close/minimize/maximize buttons, no
  content area) — it is an *app icon tile* (glyph + name below), the universal
  "application" glyph, not a window.
- The chapter title/subtitle reinforce the model: "…the OS actually creates … a Process —
  a managed instance", explicitly *not* "the program running".

No redesign is warranted. The concrete "Photos" identity is retained; it does not read as
a window.

## 4 · Phase 4 — Process visual audit

The Process cell reads as an **OS-managed execution entity**, not a window and not a
Task-Manager row: it is a rounded green cell, titled **"Process"** (the class name is the
title), with "Photos" as a **dim subordinate provenance subtitle** and a **PID chip** as
instance identity, plus two **static** content marks (existence ≠ execution). It has no
window chrome, no per-row "task" affordances, no close affordances.

## 5 · Phase 6 — launch causality

`PATH_WORLD` and the travel beats route **every** launch as `Program → OS → spot`; the OS
intake port receives, the core wakes, the creation port emits, then the birth pulse fires
at the destination. There is no Program→Process path and no window in the chain. The
Program never moves.

## 6 · Phase 7 — multiple processes

Second launch = same Program → OS → a **new** spot + **new** PID; Process A's state is
gate-asserted unchanged. The "Photos" marker is a provenance cue (subtitle), not the
Process's name; hierarchy is **Process (title) → Photos (subtitle) → PID (chip)** — the
exact order Phase 7 requires. No "one window becomes two Processes" reading is possible
(there is no window).

## 7 · Phase 11 / 12 — animation & lifetime

Birth = creation pulse + boundary draw-in + interior condense — **creation**, not "a window
opening / a panel expanding". Termination = local dissolve of the cell, never a "window
close" (no window exists); the Program is pixel-immutable across termination (gate-asserted).

## 8 · Phase 13 — classification

**A. NO REAL RISK.** The design already prevents the Window ↔ Process misconception by
construction:
1. zero "window" language in learner-visible text (only internal code comments / the
   `ProcWindow` time-window type);
2. no window chrome on any object;
3. Program explicitly stored ("storage" shelf + gloss);
4. Process explicitly titled "Process" with "Photos" subordinate;
5. birth is creation, not "opening";
6. launch is always OS-mediated.

No visual/story/narration change is justified.

## 9 · The one justified change — a permanent regression guard (Phase 15 items 10–11)

Although no misconception exists *today*, nothing currently prevents a future narration
edit from introducing "window" language. Per Phase 15, add a scope-gate assertion that the
Window terms are **absent** from learner-visible text: `window` (EN) and `cửa sổ` (VI).
This is derived from the pedagogical spec ("the chapter must not teach windowing"), not
from current geometry — it locks the misconception out, and costs nothing if already true.

This is verification tooling only; no chapter code changes.

*No chapter modification beyond the scope-gate assertion.*
