---
guiding_question: "After re-evaluating the whole chapter as a beginner-facing mental-model visualization, which of items A–AD still constitute material P0/P1/P2 weaknesses, and what coherent change (if any) closes them?"
primary_consumer: "Implementation Engineers, Curriculum Guardian, QA Auditors, AI Agents, Owner"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/08_FINAL_REMEDIATION_AUDIT.md"
referenced_by: []
---

# Round 14 — Final Holistic Remediation — Topic 02 / Chapter 01

**Date:** 2026-08-14 · **Method:** independent reconstruction (not trusting prior
conclusions), an A–AD adversarial matrix, and pixel verification of the two highest-priority
concerns (OS ontology / why-OS). No code was modified to produce this document.

---

## 1 · Current mental model (reconstructed)

Program = a concrete "Photos" app (icon + name) on a "storage" shelf · OS = a squared pink
band ("OS / Operating System") already present between the shelf and the field · Machine = a
far-east "the machine" region (CPU·RAM·I/O) · Process = a green cell titled "Process" with
"Photos" as a dim provenance subtitle and a "PID n" chip · launch = a spark Program→OS→spot,
the OS intake→core→creation-port→birth pulse · lifetime = local dissolve · second launch =
new spot + new PID.

## 2 · Target mental model

Identical to the reconstruction — with the explicit additions this round tested: the OS is
**already present before launch**; a Program is a stored artifact that cannot manage the
machine by itself; the OS is the system software that mediates.

## 3 · A–AD adversarial matrix

Legend: SOLVED (visual+animation establish it, narration optional) · OK (established with
narration support, no false reading) · FIX (material weakness).

| Item | What learner should infer | Verdict | Evidence |
|---|---|---|---|
| A Program = stored artifact | shelf + "storage" label + icon tile, no chrome | SOLVED | drawProgramCard |
| B Program ≠ Process | distinct shape/colour/location; rupture beat | SOLVED | B05 |
| C Program doesn't transform | pixel-stable Program; birth far away | SOLVED | immutability gate |
| D Program doesn't create Process | no Program→Process path; OS mediates | SOLVED | PATH_WORLD |
| E OS already exists before launch | **OS band + "OS" title visible from B00** | SOLVED | pixel: 53k lit px @ B00/B01 |
| F Why OS exists | machine shared → file inert → OS mediates | OK | B02 (Round 13 three-part sequence) |
| G OS = system software | squared band + "Operating System" title | SOLVED | grammar vs rounded tile/cell |
| H OS ≠ Machine | separate regions | SOLVED | Round 8 |
| I OS ≠ CPU | CPU is inside machine region, not OS | SOLVED | Round 8 |
| J OS doesn't contain CPU/RAM/I/O | removed in Round 8 | SOLVED | — |
| K OS mediates Program ↔ Machine | OS sits between them on the axis | SOLVED | west→east layout |
| L launch request ≠ Program artifact | spark travels; Program stays | SOLVED | B03 |
| M OS creates Process | intake→core→creation→birth | SOLVED | B04/B05 |
| N Process is a new entity | birth pulse + draw-in | SOLVED | B05 |
| O Process ≠ PID | chip inside living cell, 3 beats later | SOLVED | B09/B10 |
| P PID identifies one instance | one chip per cell, distinct PIDs | SOLVED | B10 |
| Q one Program → many Processes | same provenance subtitle + distinct PIDs | SOLVED | B08+ |
| R multiple Processes independent | scattered, A unchanged while B births | SOLVED | gate |
| S Process lifetime | birth → existence → termination | SOLVED | B05→B11 |
| T Program lifetime ≠ Process lifetime | Program pixel-immutable across termination | SOLVED | gate |
| U termination doesn't destroy Program | local dissolve | SOLVED | B11 |
| V Window ≠ Process | no chrome; scope forbids window terms | SOLVED | Round 9 |
| W opening a window ≠ Process creation | no window anywhere | SOLVED | — |
| X multiple windows ≠ multiple Processes | n/a (no windows) | SOLVED | — |
| Y Process ≠ CPU | CPU in machine region; Process = green cell | SOLVED | — |
| Z Process ≠ "the app file" | Process = green entity, not the cyan file | SOLVED | — |
| AA Process ≠ scheduler | no scheduler terms/queue geometry | SOLVED | scope |
| AB Process ≠ queue | anti-queue scatter | SOLVED | layout gate |
| AC Process ≠ thread | no thread terms | SOLVED | scope |
| AD alive ≠ CPU executing | static interior; no CPU/machine animation | SOLVED | Fix #1 |

**Result: 30 items SOLVED, 1 item OK (F — why-OS, established with narration support).**
Zero FIX.

## 4 · OS ontology audit (Phases 2–4)

The two highest-priority concerns are **already satisfied**:

1. **"OS already exists before launch"** (Phase 2's core worry): the OS band and its "OS"
   title are drawn from beat 0. Pixel check: **53,126 lit px at B00 and B01** (pre-launch),
   unchanged at B02. The OS never "appears" in response to the Program; only its *internal
   structure* (core rows) is revealed during the why-OS beat. So the "Program exists → OS
   appears" false reading is structurally impossible.
2. **"Why the OS exists"** (Phase 2/5): the Round-13 three-part sequence (machine slots
   light → Program's "inert artifact" pulse → OS core resolves) plus the spatial position
   (Program west, OS middle, machine east) makes the mediation visible. The one-sentence
   *reason* ("a stored file cannot manage a shared machine") is carried by narration, which
   is legitimate: it is a conceptual explanation, not a hidden causal fact — the causal
   facts (OS mediates, OS creates) are visual.

OS shape re-evaluated against 3 alternatives (system layer / mediation interface /
management infrastructure): the current squared band on the west→east axis **is** the
"mediation layer" alternative — a system boundary between program and machine with
intake→core→creation ports. No redesign is warranted; the alternatives are the same thing
drawn differently, with no beginner-comprehension gain.

"OS manages the machine" (Phase 4): expressed geometrically — the OS sits *between* the
Program and the Machine, which is the mediation relationship, without adding an animated
"management arrow" that would risk implying scheduling/CPU-control. Correct as-is.

## 5 · Program exemplar audit (Phase 6)

Re-scored (recognizability, stored-artifact clarity, multi-instance, execution connotation,
window connotation, misconception risk, simplicity, familiarity, one→many, CESVI
compatibility):

| Exemplar | Verdict |
|---|---|
| **Photos** | **KEEP** — highest combined score; lowest execution+window connotation while multi-instance and recognizable |
| Calculator | weaker multi-instance |
| Text Editor | window/file connotation |
| Terminal | execution connotation |
| Browser | complexity trap (banned) |
| Music Player | weaker |
| File Explorer | worst window connotation |

No change.

## 6 · Process identity audit (Phase 7)

Hierarchy Process (title) > "Photos" (dim provenance subtitle) > PID (chip) — correct.
No window chrome, no close/minimize/maximize. No change.

## 7 · Multiple-process / lifetime audit (Phases 8–9)

One stable Program, scattered independent cells with distinct PIDs; termination local;
second launch = new spot + new PID; A gate-asserted unchanged. No change.

## 8 · Animation semantic audit (Phase 10)

Every load-bearing animation has FROM→CAUSE→EFFECT→FINAL→inference (documented in prior
rounds): OS intro = reveal; launch = request; mediation = intake/core/creation; birth =
creation pulse + draw-in; naming = pill; identity problem = failing selector; PID =
association; termination = dissolve; second launch = re-run of the route; climax = interleaved
births/deaths. No decorative motion; no CPU activity; no queue trajectories. No change.

## 9 · Geometry audit (Phase 11)

STORAGE (west) → OS (middle) → EXECUTION (east) → MACHINE (far-east context). Semantic,
not merely non-overlapping. No false relationship implied. No change.

## 10 · Muted-narration + beginner test (Phases 12–13)

The 15-question beginner test (what is Program/OS/why-OS/…, did Photos transform, is a
Process a window/CPU/file, is PID the Process, why multiple, what ends, does the Program
end, what stays constant) — all answerable from geometry + animation, with the single
exception of the *stated reason* for the OS ("a file can't manage a machine"), which is
narration-carried by design (a conceptual premise, not a hidden causal fact).

## 11 · P0/P1/P2/P3 classification

- **P0/P1/P2: NONE.** All 30 items SOLVED, 1 OK.
- **P3 (polish, deferred):** responsive size of tertiary labels at legacy 836×570; machine
  region now large (owner-requested) sits as context. Neither touches a distinction.

## 12 · Proposed coherent redesign

**None.** The chapter is complete. The one material issue this prompt emphasizes (OS
pre-existence + why-OS) is already satisfied: the OS is pixel-visible from B00, and the
why-OS beat shows the mediation.

## 13 · Things intentionally NOT changed

Program exemplar (Photos proven best); OS squared-band grammar; machine region (enlarged
per owner request, kept); Process cell; PID association; anti-queue geometry; all animation
contracts; the 15-beat spine; all scope boundaries.

## 14 · Acceptance criteria

Met: Program = stored artifact · OS = system software already present · Machine = CPU+RAM+
I/O context · Program ≠ Process · OS mediates creation · Process = execution instance ·
PID = identifier · lifetime · one Program → many Processes · Process ≠ Window/CPU/Program ·
OS ≠ Machine.

---

## Final decision

**NO CODE CHANGE REQUIRED.** This round found zero material weaknesses. The highest-priority
concern (OS pre-existence / why-OS) is already resolved and pixel-verified. Per the FINAL
RULE ("do not manufacture problems; leave a category alone if it needs no change"), no code
is modified. Verification state (from the current tree) remains: tsc ✓, build ✓,
smoke/scope/layout ✓, deterministic byte-equal double-render ✓, EN+VI browser playthroughs
0 page errors ✓.

The chapter remains ready for the owner's literal human visual pass.
