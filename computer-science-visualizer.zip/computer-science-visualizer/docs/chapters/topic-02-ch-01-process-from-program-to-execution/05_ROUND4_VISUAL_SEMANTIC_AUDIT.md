---
guiding_question: "What is the remaining gap between 'technically correct and polished' and 'visually self-evident CESVI pedagogy' in Topic 02 Chapter 01, and which concrete changes close it without expanding scope?"
primary_consumer: "Implementation Engineers, QA Auditors, Curriculum Guardian, AI Agents"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/04_FINAL_VISUAL_PEDAGOGICAL_REFINEMENT.md"
referenced_by: []
---

# Round 4 — Visual Semantic Audit — Topic 02 / Chapter 01

**Date:** 2026-08-14 · **Method:** source inspection + deterministic render (pixel/geometry) +
the Round-4 interpretation checklist. This round targets *visual self-evidence*, not
technical correctness (already green).

---

## 1 · CRITICAL FINDING — Program identity does not propagate (FIXED)

The Program was made concrete ("Photos" + icon) in Round 3, but the **Process cell still
carries no Program identity**. A Process reads as a generic green box:

```
      Process
      ▓▓▓▓▓▓▓▓
      PID 4459
```

A muted-narration learner cannot answer *"what is the relationship between Photos and these
two Processes?"* — the link exists only in narration. This is the single largest remaining
gap: the visual proof of **SAME PROGRAM → MULTIPLE PROCESS INSTANCES** is incomplete.

**Fix:** introduce a **restrained Program-identity marker** into the Process cell — a small
copy of the same app icon + the app name ("Photos"), drawn in the Program's cyan, above the
class caption. The cell then reads as a three-layer identity stack:

```
   [icon] Photos      ← program identity (cyan, small — an attribute, not the name)
   Process            ← class (the entity's name)
   ▓▓▓▓▓▓
   PID 4459           ← instance identity (chip)
```

**Design guards (directive §1):**
- The marker is **small and cyan**, clearly subordinate to "Process" (class) and "PID"
  (instance) — it does NOT read as the entity's own name.
- It does **not** make the cell a window: there is no title bar / chrome; the class caption
  + PID chip dominate.
- It does **not** imply "icon = Process": the icon is an *attribute label* of which program
  this Process is an execution instance of.
- **No Program→Process ownership lines** are added: the OS remains the causal mediator
  (the spark path Program→OS→spot already carries the causal route).
- The marker appears **only once the entity is named** (`nameKnown`, B06+), together with the
  class caption — so the birth (B04) and rupture (B05) still show an *unnamed* new entity,
  preserving the "what did the OS create?" question. The three identity-problem cells stay
  identical (all "Photos" + "Process", no PID), so B08's selector still fails.

---

## 2 · Program → Process relationship test (muted)

With the fix, the muted-narration read becomes:

- shelf: cyan **Photos** app tile (unchanged forever);
- field: two green cells, each carrying a small **Photos** icon + "Process" + its own PID.

A first-time learner can now infer "the same Photos program produced these two distinct
Processes, each with its own number" **from geometry alone**. Before the fix this depended
entirely on narration.

---

## 3 · OS semantic form — reads as an app-like panel (softened)

Round 3's 230×300 panel is better than the capsule, but its interior still reads like a
**dashboard**: a title header ("OS / Operating System") + a boxed core containing **three
equal rounded rows** that resemble three clickable modules, + a resource strip.

**Fix (restrained):**
- Reduce the three rows' visual weight (thinner strokes, dimmer fills, smaller radius,
  slimmer height) so they read as *action slats*, not a fixed taxonomy of three buttons.
- Shrink the "OS" monogram 26→22 px (still identifiable, less "app title bar").
- Keep the labels event-anchored (already correct: they appear only after observation).

This directly serves directive §4: the learner observes *the OS performing* create →
identify → manage, and does not leave believing "the OS consists of exactly three modules".

---

## 4 · Resource context (kept tertiary, slightly reduced)

CPU / RAM / I/O slots already de-emphasised in Round 3. A further small reduction of slot
stroke/label alpha ensures they never compete with Program / OS / Process / PID. Not removed.

---

## 5 · Process visual semantics

With the marker, the cell reads as "a Photos Process #4459 with contents" — a managed
execution entity, not a window / file / queue item / task. Interior stays static (no "busy"
animation); birth/termination animation unchanged (creation pulse + boundary draw-in;
dissolve outward).

---

## 6 · Causal animation audit (re-verified, no change needed)

- Launch: Program stationary → request travels → OS receives → OS acts → birth. **No morph.**
- PID: identity need (selector fails) → association (focus ring → dashed link → resolve in
  place) → PID. **No packet flight.**
- Second launch: same Program → OS-mediated creation → new spot → new PID. **No restart.**

---

## 7 · Final frame

After the fix, the bridge frame shows: Photos program on shelf + OS panel + two living cells
each with "Photos" + "Process" + distinct PID. The whole argument is visible in one
environment (not a flowchart).

---

## 8 · Interpretation checklist (muted, first-time learner)

| # | Question | Recoverable without narration? |
|---|---|---|
| 1 | What is the Program? | YES — cyan "Photos" app tile + icon on storage shelf |
| 2 | What is the OS? | YES — "OS / Operating System" panel between program and field |
| 3 | What caused the Process to appear? | YES — spark Program→OS→spot, then creation pulse |
| 4 | Did the Program become the Process? | YES — program stays on shelf; green cell appears far away, different shape/colour |
| 5 | Why multiple Processes? | YES — same "Photos" marker on two scattered cells |
| 6 | What distinguishes A from B? | PARTIAL → resolved by PID disclosure (B09) — correct, identity comes from PID |
| 7 | What is PID? | YES — chip "PID n" docked inside each cell after the failed selector |
| 8 | Which entity has the lifetime? | YES — one cell dissolves; program + siblings remain |
| 9 | What happens when one terminates? | YES — local dissolve; neighbours breathe on |
| 10 | Does the Program remain? | YES — pixel-stable tile |
| 11 | Why can another Process appear later? | YES — relaunch spark + new cell + new PID |

Items 1–5, 7–11 are geometry-recoverable; item 6 is intentionally deferred to the PID beat.
After the §1 fix, item 5 becomes fully visual (it was the weak one).

---

## 9 · Test-design discipline (directive §10)

Gate additions are derived from the **pedagogical specification**, not from the current
geometry: (a) `CELL_BAR_FRACS.length === CELL_BARS.count` (content-mark consistency),
(b) the cell identity marker fits above the divider and below it the bars/chip do not
collide (containment). No test merely re-encodes today's pixels as "correct".

---

## 10 · Implementation scope

Targeted edits only, in `metrics.ts` / `layout.ts` / `renderers/world.ts` (+ gate
assertions). No new concepts, no spine change, no engine/platform change, no other chapter
touched.

*Implementation follows this audit.*
