---
guiding_question: "Does the final visual + narrative system of Topic 02 Chapter 01 produce the intended mental model — Program ≠ Process, OS as system software, PID as instance identity, independent lifetimes — without narration rescuing weak visuals?"
primary_consumer: "Curriculum Guardian, QA Auditors, AI Agents, Owner"
depends_on:
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/05_SEMANTIC_VISUAL_REFINEMENT.md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/06_CONCEPTUAL_READABILITY_AUDIT.md"
referenced_by: []
---

# Round 7 — Final Mental Model Audit — Topic 02 / Chapter 01

**Date:** 2026-08-14 · **Method:** source inspection + deterministic render geometry +
pixel checks + real-browser verification. This is an **acceptance audit**, not a redesign
round. No code was modified to produce this document.

---

## 1 · Target mental model

Program = stored application artifact. OS = system software that manages the machine and
mediates execution. Launch → OS creates a Process (separate execution entity) → each has
its own PID → each has its own lifetime → one Program → many independent Processes.

The one transformation: **"the program runs" → "the OS creates a managed instance, and the
program never changes."**

---

## 2 · Five-minute learner simulation (what the visuals SHOW, not what narration says)

| Beat | What the learner sees | Likely interpretation |
|---|---|---|
| B00 question | Photos app tile on a shelf ("storage"); dim squared band ("OS"); empty field; quiet CPU emblem | "An app sits stored. Something else decides what runs." |
| B01 program | Photos tile glows; it does not move | "This is the program — just a stored thing." |
| B02 why-the-os | The squared band shows "the machine" (CPU/RAM/I/O) at its base, then three rows inside | "This system thing sits between the app and the machine." |
| B03 launch | A spark leaves Photos, travels toward the band; Photos stays put | "A request goes to the system — the app itself didn't move." |
| B04 receives | The band's intake lights; its core wakes row by row | "The system is doing work." |
| B05 birth | A green cell draws itself in the field, far from Photos | "Something NEW appeared — not the app." |
| B06 rupture | Photos (west) + green cell (east) shown together, both pulsing | "These are two different things." |
| B07 name | "Process" pill; cell titled "Process" with small "Photos" subtitle | "The new thing is called a Process; it came from Photos." |
| B08 second launch | A second green cell appears; first untouched | "One app, two things now." |
| B09 identity | Three identical cells; a selector ring hops and finds nothing | "They look the same — how to tell them apart?" |
| B10 PID | Each cell resolves a "PID n" chip | "Each one got its own number." |
| B11 lifetime | One cell dissolves; Photos + the others stay | "That one ended; the app didn't." |
| B12 independent | A new cell with a NEW number; others untouched | "Launch again = a new one, not the old one coming back." |
| B13 climax (silent) | Cells appear and vanish out of order | "Entities keep being created and ending, independently." |
| B14 bridge | Two cells + Photos + quiet OS | "One program, many independent instances." |

---

## 3 · Critical distinctions — STRONG vs WEAK

| Distinction | Strength | Evidence |
|---|---|---|
| Program vs Process | **STRONG** | Different shape (tile vs cell), colour (cyan vs green), location (shelf vs field), and the rupture beat shows both at maximal separation |
| OS vs Program | **STRONG** | Squared band (r=6) vs rounded tile (r=18); title "Operating System"; resource strip; ports |
| Process vs PID | **STRONG** | PID is a small chip docked INSIDE a living cell; cells exist 3 beats before any chip |
| Program identity vs Process identity | **STRONG** | "Photos" is a dim cyan subtitle (10px) under the "Process" title (13px); PID chip carries instance identity |
| Process lifetime vs Program lifetime | **STRONG** | Termination dissolve is local; Program is pixel-immutable (gate-asserted) |
| new Process vs restarted Process | **STRONG** | Second launch: new spot + new PID; A's lifecycle is a pure function of its own window (gate-asserted A unchanged) |

No distinction depends on terminology alone.

---

## 4 · The OS test (most important)

Muted, at OS-intro: a squared pink band, titled "OS / Operating System", with "the machine"
(CPU·RAM·I/O) at its base, three rows inside, an intake socket (west) and a creation socket
(east), standing **between** the stored app (west) and the execution field (east).

Inference: "system software that relates to the machine and stands between the app and
where things run." Evidence against "factory only": (1) the resource strip says "the
machine" — the OS is *managing* resources, not only creating Processes; (2) three roles
(create/identify/manage), each revealed only after being observed; (3) the "manage" row
visibly pulses during termination; (4) the title is "Operating System", not "Process
Maker".

**Verdict: OS ontology is SUFFICIENT.** It reads as a system layer, not a creation
machine. It does not (and must not) teach kernel/scheduler/syscalls.

---

## 5 · Program test

Muted, program-only state: a rounded cyan app tile with a "Photos" icon (sun+mountain) and
"Photos" name, resting on a shelf labelled "storage", with "Program" beneath. Reads as "a
stored application," NOT "a running Process" or "a Process waiting to run." Artifact
grammar (rounded tile + shelf + storage label) is intact. **PASS.**

---

## 6 · Process test

Muted, single Process after birth: a green cell, titled "Process", with a small dim
"Photos" subtitle and (later) a "PID n" chip. "Is this the Photos program?" → **No** (it is
green, titled Process, located in the execution field, not the shelf). "Why does it say
Photos?" → "it was created from Photos" (the subtitle is a subordinate provenance cue, not
the name). **PASS** — this was the Round 6 fix, and it holds.

---

## 7 · Multiple Process test

Photos + OS + two cells (each "Process / Photos / PID n"). "How many programs?" → 1.
"How many Processes?" → 2. "Why?" → same app launched twice; the OS created two instances.
The shared "Photos" subtitle (source) + distinct PID chips (instance) carry this
geometrically. **PASS.**

---

## 8 · PID test

Before PID: three identical cells; the selector fails — ambiguity is *shown*. After PID:
each cell owns a "PID n" chip. "What does PID belong to?" → that Process instance (chip is
drawn from the owning cell's rect; it never touches the Program). **PASS.**

---

## 9 · Lifetime test

Terminate A: local dissolve; Photos (pixel-identical) and B remain. **PASS.**

---

## 10 · Second launch test

"Is this Process A restarted?" → No: new spot, new PID, A's state proven unchanged by gate.
**PASS.**

---

## 11 · Muted-narration table

| Beat | Sees | Likely interpretation | Correct? | Risk | Verdict |
|---|---|---|---|---|---|
| why-the-os | system band + machine strip | "system manages machine" | yes | low | PASS |
| launch | request travels to OS | "launch goes to OS" | yes | low | PASS |
| birth | new green cell, OS port emits | "OS created something new" | yes | low | PASS |
| rupture | tile + cell together | "two different things" | yes | low | PASS |
| multiple | two cells, same subtitle | "one program, two instances" | yes | low | PASS |
| PID reveal | selector fails → chips dock | "each got a number" | yes | low | PASS |
| second launch | new cell + new number | "new instance" | yes | low | PASS |
| termination | one cell ends, others stay | "independent lifetime" | yes | low | PASS |
| silent climax | interleaved births/deaths | "independent lives" | yes | low | PASS |

---

## 12 · Animation semantic test

Every motion has cause → transition → effect: Program→OS = launch request; OS core wake =
management action; OS→spot = creation; focus-ring→dashed-link→resolve = identity
association; dissolve = lifetime end. **No motion without meaning.**

---

## 13 · Geometry semantic test

- Program ↔ OS (west→east, intake socket on axis): application → system relationship.
- OS ↔ Process (creation port → field): management/creation relationship.
- Process ↔ PID (chip inside cell): identity relationship.
- Process ↔ Process (scattered, uneven, anti-queue): independence.
- Program ↔ multiple Processes (one tile, several cells with the same subtitle): one source
  → many instances.

These are *semantic* positions, not merely non-overlapping. **PASS.**

---

## 14 · UI hierarchy test

Program concrete; OS system-level + structurally distinct; Process the primary entity
(green, titled); PID an instance chip; source marker a secondary cue. No decorative
dominance. **PASS.**

---

## 15 · Scope test

Scope gate passes: no scheduler / queue / thread / context switch / state machine /
concurrency / kernel internals / virtual memory / system calls in learner-visible text
(EN+VI). The chapter stops at Program → OS → Process → PID → lifetime → independent
instances. **PASS.**

---

## 16 · Final decision

**ACCEPTED (option A).** The central transformation is produced by geometry + animation,
not rescued by narration. All six critical distinctions are STRONG; the OS ontology,
Program/Process distinction, multiple-process proof, PID meaning, and lifetime proof are
all sufficient; the muted-narration table has no failures.

Two **honest minor observations** (documented, NOT misconceptions, NOT warranting a code
change): (1) the OS's "manages" role is the least *animated* of its three roles — "create"
carries the central question (correct emphasis), and "manages" is evidenced by the resource
strip, the manage-row pulse during termination, and the title rather than by a dedicated
animation; (2) the resource-strip labels (CPU/RAM/I/O) are deliberately small/dim and read
best at ≥1140×660. Neither threatens the transformation.

---

## 17 · Freeze recommendation

Per the directive, FROZEN requires verified mental model + causal sequence + muted
narration + browser rendering + EN/VI equivalence + no major misconception. Of these, the
**automated, geometric, pixel, and real-browser evidence all pass** (see §16 of the QA
audit and the gates). The one item I cannot perform myself is the **literal human visual
pass** over the rendered frames. Recommendation: **freeze pending the owner's visual
confirmation** — not "FROZEN" unilaterally, since that requires actual human visual review.
