---
guiding_question: "Has Topic 02 Chapter 01 satisfied the mandatory quality gates, and how was it verified in a real browser?"
primary_consumer: "QA Auditors, Maintainers"
depends_on:
  - "docs/pipeline/03_QA_VERIFICATION.md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/01_CHAPTER_PRODUCTION_[BLUEPRINT].md"
  - "docs/chapters/topic-02-ch-01-process-from-program-to-execution/02_PEDAGOGICAL_AUDIT.md"
---

# QA Audit — Topic 02 / Chapter 01 · "Process: From Program to Managed Execution"

**Date:** 2026-08-14 (refinement round same day) · **Status:** **FROZEN** (technical + pedagogical acceptance)

## 1 · Gate Results (executable, post-refinement)

| Gate | Script | Checks | Result |
| :--- | :--- | :--- | :--- |
| TypeScript + Build | `npm run build` | — | PASS (0 errors / 0 warnings) |
| Smoke | `scripts/smoke-topic02-ch01.ts` | 196 | PASS |
| Scope | `scripts/scope-gate-topic02-ch01.ts` | 37 | PASS |
| Layout proof | `scripts/layout-proof-topic02-ch01.ts` | 90 | PASS |
| **Total** | `npm run smoke` | **323** | **PASS** |

Pre-refinement baseline was 314 checks; the refinement ADDED 9 checks (5 smoke:
static-content-marks metric + open-bridge assertions; 4 scope: recipe/cooking ban,
program-lifetime-falsehood ban, "running instance" ban, OS-anthropomorphism ban).

## 2 · Smoke coverage (191 checks)
- Playthrough integrity: 14 beats × bilingual lines, single `world` scene, travel/rest
  bounds within the 14-anchor path, durations derived from `DURATIONS` (§4.5).
- Locked causal order: the 14 beat ids asserted in the blueprint's exact sequence.
- Terminology ordering (Knowledge Reveal §13): "Process" absent from beats 0–5, first at
  beat 6; "PID" absent from beats 0–8, first at beat 9; climax fully silent EN+VI; PID
  narrated as disclosure-at-creation (no unlearning).
- Quantity single-source: every 4-digit number spoken in narration exists in `PROCS`.
- Lifecycle invariants: birth<alive<chip<die<gone per instance; unique PIDs; no spot
  double-occupancy on a 14×11 grid scan; ≤4 concurrent instances; field empty before the
  birth beat; exactly 1 at the rupture; 3 at the identity problem; A gone / B,C alive after
  the lifetime beat; relaunch PID ≠ first PID and spot ≠ first spot; trio chips hidden
  through the identity problem; late instances numbered at birth.
- Climax contract: death order C→E→B→D (anti-FIFO), comet arrival = birth start per event,
  ≥2 survivors into the bridge, loop-effect protagonist.
- Determinism (§15): full story grid double-rendered — byte-identical.

## 3 · Scope coverage (33 checks)
Forbidden absent from ALL learner-visible text, EN+VI: Ready/Waiting/Blocked/Terminated,
state machine, scheduler/scheduling (lập lịch/định thời/điều độ), queue (hàng đợi), time
slice/quantum, preemption, context switch (chuyển ngữ cảnh), dispatch, thread (luồng/tiểu
trình), address space (không gian địa chỉ), heap/stack, virtual memory/pages, exit code,
zombie/orphan, fork/parent-child, PCB, concurrency/parallel (song song/đồng thời),
race/lock/mutex, multi-core, program-loading re-teach, "tiến trình" (VI translation of the
locked term). Required present: Process (first at b06), PID (first at b09), OS, Program.

## 4 · Layout proof (90 checks)
Region separation with causal negative space (≥40); every cell inside the field and clear
of the machine emblem; cells pairwise disjoint (≥20); PID chip strictly inside its owning
cell, never overlapping any other cell and never touching the Program; anti-queue proof
(no near-collinear triple <12°, nearest-neighbour spread >30, both axes used); term pills
clear of all cells; bbox containment for all parts, pills and path anchors; text legibility
at 1100×700 and 836×570 fit zooms.

## 5 · Browser verification (headless Chromium)
Two full playthroughs (EN + VI) at 1400×850 with **zero page errors**, pausing at 31 exact
deterministic (beat, frac) stops (drift-checked) and screenshotting each: B01, launch,
OS-receives, birth signal/pulse/done, rupture (both pulses + hold), Process pill, second
launch, three-identical + selector, all three chip flights, PID pill, completion shimmer,
dissolve, gone-program-remains, relaunch, new-PID, six climax events, bridge. A separate
run at 1140×660 (small real Viewer geometry) confirmed chip/caption legibility. Screenshots
in `review/shots-t02c01/{en,vi}`.

## 6 · Adversarial audit
All 12 target misconceptions blocked by on-screen evidence — see
`02_PEDAGOGICAL_AUDIT.md`, including the three implementation fixes it forced
(C-09-safe opening narration, "ready" vocabulary removal, anti-queue spot re-scatter).

## 6b · Final Pedagogical Refinement round (pre-freeze)

Scope of change (minimal, local — no architecture/renderer rewrite, no engine change,
no other chapter touched):
- `renderers/world.ts`: cell interior content marks made STATIC (Fix #1); boundary
  breathing restrained (0.0016 freq, reduced amplitude); interior fill de-animated.
- `scenes/metrics.ts`: new named metric `CELL_BAR_FRACS` (constant mark widths).
- `scenes/story.ts`: Process pill sub → "an execution instance the OS created"; PID pill
  sub → "the identifier of exactly one Process".
- `narration/beats.ts`: b05, b06 (analogy removed), b07, b09 (anthropomorphism removed),
  b10 (lifetime falsehood removed), b11 — EN and VI kept conceptually identical.
- `scripts/smoke-topic02-ch01.ts` (+5), `scripts/scope-gate-topic02-ch01.ts` (+4 locks).

Re-verification after the refinement:
- **TypeScript / build:** PASS (tsc clean, vite build clean).
- **Automated gates:** 323/323 green (`npm run smoke`).
- **Deterministic rendering:** story-grid double-render byte-identical (smoke).
- **Browser runtime:** EN full playthrough (31 stops, drift-checked) — 0 page errors;
  VI full playthrough — 0 page errors.
- **Small canvas (1140×660):** PID beat legible; chips, captions, pills readable.
- **Load-bearing frames re-inspected:** A–P checklist (initial Program, launch, OS
  intervention, unnamed birth, coexistence rupture, Process reveal, multiple Processes,
  identity ambiguity, PID reveal, lifetime, termination-with-Program-remaining, relaunch,
  different PID, independence, silent climax, bridge) — all consistent with the refined
  narration; climax remains trackable (each dying cell keeps its PID chip visible through
  the dissolve; ≤4 concurrent cells).
- **Existence ≠ execution proof:** two screenshots of the same living cell 1.4 s apart —
  interior pixel-stable; only the restrained boundary glow varies
  (`review/shots-t02c01/alive-t1.png` / `alive-t2.png`).

Final acceptance checklist (24 items of the refinement directive): all checked. In
particular: Process existence is no longer visually equivalent to CPU execution; no
Program-lifetime falsehood remains; no recipe/cooking analogy remains; geometry still
anti-queue; silent climax unchanged in length and pedagogy; EN/VI conceptually identical.

**FINAL STATUS: FROZEN.**

## 6c · Deep Refinement Round 2 (owner-directed, same day)

Scope: OS conceptual origin + visual redesign, launch-request separation, PID-as-
association, class-vs-instance labelling, deterministic launch variation, VI gloss
discipline. Architecture unchanged (story → beats → lifecycle data → pure renderers;
deterministic beatIndex/beatFrac). No engine/platform change; no other chapter touched.

| Gate | Checks | Result |
| :--- | :--- | :--- |
| TypeScript + `npm run build` | — | PASS |
| Smoke | 209 | PASS |
| Scope | 53 | PASS |
| Layout | 105 | PASS |
| **Total (`npm run smoke`)** | **367** | **PASS** |

New executable coverage: 15-beat locked order with `why-the-os` before the first launch;
OS row micro-labels revealed only after their functions observed; distinct birth-window
spans (deterministic variation); OS core/strip/rows/slots/ports containment + disjointness
proofs; ports centred on the causal axis; VI gloss discipline (tiến trình only at
introduction glosses; hệ điều hành at the OS intro; "progress" banned everywhere).

Browser verification: EN + VI full playthroughs at 1400×850, 34 deterministic stops
covering the A–U load-bearing list, drift-checked — **0 page errors** each. Small canvas
1140×660: OS-intro and PID frames legible (rows, slots, chips, glosses readable).
Deterministic story-grid double-render remains byte-identical. All A–U frames visually
inspected; muted-narration re-test of the new OS causal sequence passes (see
`02_PEDAGOGICAL_AUDIT.md` round-2 section).

**FINAL STATUS after Round 2: FROZEN** (technical + pedagogical acceptance; all 34
acceptance criteria of the round-2 directive checked).

## 6d · Final Visual + Pedagogical Refinement (Round 3, owner-directed)

Scope: visual/polish only — the mental model, 15-beat spine, causal model and all
locked rules are unchanged. See `04_FINAL_VISUAL_PEDAGOGICAL_REFINEMENT.md`.

| Gate | Result |
| :--- | :--- |
| TypeScript + `npm run build` | PASS |
| Smoke (15-beat order, terminology ordering, lifecycle, anti-FIFO climax, determinism byte-equal, program pixel-immutability) | PASS |
| Scope (forbidden CH02–CH06/T06 concepts EN+VI; gloss discipline) | PASS |
| Layout (containment, disjointness, chip-inside-cell, anti-queue, legibility at 1140×660+) | PASS |
| Deterministic screenshot grid EN+VI @ 1400×850 + 1140×660 | PASS (byte-identical double-render) |

Changes: Program → concrete "Photos" app (icon + name, pixel-stable identity);
OS re-proportioned 170×420 → 230×300 system panel with title header + subtitle;
duplicate "OS" label removed; resource strip de-emphasised; all font sizes moved
onto the named type scale. No engine/platform change; no other chapter touched.

**Status: pending final owner sign-off** (per Round-3 directive §35, "FROZEN" is
withheld until all quality categories are confirmed ≥ 9.5).

## 6e · Round 4 — Visual Semantic Audit (owner-directed)

See `05_ROUND4_VISUAL_SEMANTIC_AUDIT.md`. One critical gap closed, no scope/spine change.

| Gate | Result |
| :--- | :--- |
| TypeScript + `npm run build` | PASS |
| Smoke (+3 spec-derived: content-mark count, header identity fit, bars/chip no-collision) | PASS |
| Scope (unchanged) | PASS |
| Layout (unchanged) | PASS |
| Deterministic EN+VI grids @ 1400×850 + 1140×660 | PASS (byte-identical double-render) |
| Real-browser playthrough | PASS (0 page errors) |
| Pixel check: identity marker gated to B06+ | PASS (0 cyan px @ b05 unnamed → 207 px @ b07 named) |

Changes: Process cells now carry a restrained Program-identity marker (small copy of the
same app icon + "Photos" name, cyan) above the class caption — a program→class→instance
identity stack; OS function rows slimmed/dimmed so they read as action slats, not a
three-module taxonomy; "OS" monogram 26→22 px; resource strip dimmed a further notch.

**Status: NOT frozen** — visual self-evidence implemented; human visual pass + owner
sign-off still required.

## 6f · Round 5 — Semantic Visual Refinement (owner-directed)

See `05_SEMANTIC_VISUAL_REFINEMENT.md`. Two semantic ambiguities closed; no scope/spine
change.

| Gate | Result |
| :--- | :--- |
| TypeScript + `npm run build` | PASS |
| Smoke (+4: second-launch independence, termination immutability, provenance subordination, OS grammar) | PASS |
| Scope / Layout (unchanged) | PASS |
| Deterministic EN+VI grids @ 1400×850 + 1140×660 | PASS (byte-identical double-render) |
| Real-browser playthrough | PASS (0 page errors) |

Changes: (1) Process provenance marker subordinated — "Photos" 12→10px, weight 700→600,
alpha 0.85→0.55, icon 16→13px, so hierarchy is Process > PID > Photos (marker can no
longer read as the Process's name). (2) OS corner radius 22→6 — a squared system frame
grammar distinct from the rounded Program tile and Process cell (OS no longer reads as
"another app card"). (3) OS idle rows de-boxed — border appears only during a row's causal
action (action states, not three modules). All causal animation contracts re-audited,
unchanged.

**Status: NOT frozen** — human visual pass + owner sign-off still required.

## 6g · Round 6 — Conceptual Readability Review (owner-directed)

See `06_CONCEPTUAL_READABILITY_AUDIT.md`. A conceptual (not polish) round: the
four-object test (Program/OS/Process/PID) under muted narration.

| Gate | Result |
| :--- | :--- |
| TypeScript + `npm run build` | PASS |
| Smoke (+1: class name above source marker) | PASS |
| Scope / Layout (unchanged) | PASS |
| Deterministic EN+VI grids @ 1400×850 + 1140×660 | PASS (byte-identical double-render) |
| Real-browser playthrough | PASS (0 page errors) |
| Pixel check: header ordering | PASS ("Process" centroid row 13, "Photos" row 27) |

Change: the Process header's two lines were swapped — "Process" (class name) is now the
title line; the "Photos" source marker is a subordinate subtitle below it. This closes the
directive §7 violation ("Photos ↓ Process") where a proper noun on the top line could read
as the entity's name. Everything else (OS as management layer, launch causality,
multiple-process proof, second-launch independence, termination immutability, PID
discovery, alive≠CPU, anti-queue geometry, animation semantics) was audited and left
unchanged — no real misconception was found there.

**Status: NOT frozen** — human visual pass + owner sign-off still required.

## 6h · Round 7 — Final Mental Model Audit (acceptance)

See `07_FINAL_MENTAL_MODEL_AUDIT.md`. Acceptance audit, **no code changed**.

**Decision: ACCEPTED.** The central transformation (Program ≠ Process; OS creates and
manages; PID = instance identity; independent lifetimes) is produced by geometry +
animation, not narration. All six critical distinctions STRONG; muted-narration table
9/9 PASS; OS ontology sufficient; scope gate clean.

Two minor observations documented (not misconceptions, no fix): OS "manages" role is its
least-animated role; resource-strip labels smallest at ≤1140×660.

Freeze recommendation: freeze pending the owner's literal human visual pass over
`review/shots-t02c01/{en,vi}` (the one item I cannot perform myself).

## 6i · Round 8 — Machine / OS Semantic Cleanup (owner-directed)

See `07_MACHINE_OS_SEMANTIC_AUDIT.md`. Fixed the duplicate machine representation.

| Gate | Result |
| :--- | :--- |
| TypeScript + `npm run build` | PASS |
| Smoke (+no-duplicate-machine-representation checks) | PASS |
| Scope / Layout | PASS |
| Deterministic EN+VI grids @ 1400×850 + 1140×660 | PASS (byte-identical double-render) |
| Real-browser EN + VI playthroughs | PASS (0 page errors) |

Change: removed the CPU·RAM·I/O resource strip from inside the OS (the OS is now pure
system software — title + intake → create/identify/manage core → creation port), and
replaced the far-east standalone "CPU" emblem with a coherent low-salience **"the machine"
region** (CPU · RAM · I/O) that is now the machine's only representation. The machine region
is static (no breathing core) to avoid implying CPU activity. Narration was already correct
and unchanged.

**Status: NOT frozen** — human visual pass + owner sign-off still required.

## 6j · Round 9 — Window ↔ Process Pedagogical Audit (owner-directed)

See `07_WINDOW_PROCESS_PEDAGOGICAL_AUDIT.md`. Adversarial test of the "one window = one
Process" misconception.

**Classification: A. NO REAL RISK.** The design already prevents it: no "window" language,
no window chrome, Program stored-artifact grammar, Process titled "Process" (not "Photos"),
creation (not "opening") birth animation, OS-mediated launch.

| Gate | Result |
| :--- | :--- |
| TypeScript + `npm run build` | PASS |
| Scope (+Window-term guards: window/title bar/desktop EN; cửa sổ/thanh tiêu đề/màn hình nền VI) | PASS |
| Smoke / Layout | PASS |
| Real-browser EN + VI playthroughs | PASS (0 page errors) |

Change: verification-only — added Window-term regression guards to the scope gate (no
chapter code changed), so the misconception can never be introduced by future narration
edits.

**Status: NOT frozen** — human visual pass + owner sign-off still required.

## 6k · Round 10 — Final Holistic Acceptance Audit (acceptance, no code change)

See `08_FINAL_HOLISTIC_ACCEPTANCE_AUDIT.md`. 18-criterion acceptance matrix.

**Decision: FINAL ACCEPTANCE — NO CHANGES REQUIRED.** All six load-bearing distinctions
STRONG; beginner muted reconstruction == target model; "Photos" exemplar KEPT (strongest of
five candidates); one ADEQUATE criterion (tertiary label size at legacy 836×570) — inherent,
no fix. Verification re-run: tsc/build/smoke/scope/layout PASS; deterministic byte-equal
double-render; EN+VI browser playthroughs 0 page errors.

**Freeze recommendation: ready to freeze pending owner's literal human visual pass.**

## 6l · Round 11 — Final Adversarial Review (acceptance, no code change)

See `09_FINAL_ADVERSARIAL_REVIEW.md`. Independent Level-4 test: 26-misconception attack
(A–Z all BLOCKED), 7-exemplar re-litigation ("Photos" confirmed), 16-dimension honest
scoring (core pedagogy 9.5, weakest responsive-readability 8.5 = P3, not fixed).

**Decision: ACCEPTED — zero code changes.** No P0/P1/P2 issue found; the chapter satisfies
the final acceptance sentence. Verification re-run (no code changed): tsc/build/smoke/
scope/layout PASS; deterministic double-render byte-identical; EN+VI browser playthroughs
0 page errors.

**Freeze recommendation: ready to freeze pending owner's literal human visual pass.**

## 6m · Round 13 — Final Remediation (one P2 fix)

See `08_FINAL_REMEDIATION_AUDIT.md`. Explicit A–O disposition: 13 KEEP, 1 DEFER (P3), 1 FIX.

| Gate | Result |
| :--- | :--- |
| TypeScript + `npm run build` | PASS |
| Smoke / Scope / Layout | PASS |
| Deterministic EN+VI double-render | PASS (byte-identical) |
| Real-browser EN + VI playthroughs | PASS (0 page errors) |
| Pixel check: why-the-os program pulse gated to B02 | PASS |

Change: the `why-the-os` beat now visually shows the OS's mediating position — machine
slots light → Program emits a restrained glow pulse ("a stored artifact, by itself") → OS
core resolves between them. No other code changed; Issues A–C/E–N were re-verified correct.

**Status: NOT frozen** — human visual pass + owner sign-off still required.

## 7 · Residual notes
- `npm run smoke` now points at the T02/CH01 gate set; the T01/Ch-04 gate scripts referenced
  by the previous configuration are absent from the tree (pre-existing repository debt,
  PROJECT_STATE §2.5) — no T01 gate was removed by this chapter.
- `vite.config.ts` gained `server: { host: true, allowedHosts: true }` for sandboxed
  preview verification; production build behaviour is unchanged.
- Curriculum compliance header: canons touched C-09, C-10 (extended, never replaced);
  extension classification: extends; debt facet resolved: **F1 — ownership of the system**;
  owned terms introduced: `Process`, `PID`.
