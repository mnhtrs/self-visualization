# Chapter Production Blueprint — Topic 02 / Chapter 02 (Increment 1)
## "Inside a Process: Memory, Resources & Execution Context"

**Chapter ID:** `topic-02-operating-systems--ch-02-process-execution`
**Slug:** `process-execution` · **Topic slug:** `operating-systems` · **Accent:** `#f472b6`
**Status:** Blueprint (locked) → Implementation
**Authority chain:** Guardian T02 v0.4.0 §5 (CH02) → Topic 02 Baseline (`docs/topics/topic-02/00`–`04`) → this increment contract (`00_CHAPTER_CONTRACT.md`) → this blueprint.

> **Increment rule:** the canonical CH02 arc continues with States → Context
> Switch → Resume in a later increment. This blueprint implements only the
> *Inside a Process* increment and its Execution-Context bridge. Nothing here
> may enact the later story.

---

## 1. Locked pedagogical model

- **Central question:** What actually makes a Process a managed execution instance?
- **Initial model:** "A Process is a bounded entity with a PID and a lifetime — 'managed' is a word."
- **Target model:** "A Process is managed because the OS grants and tracks everything it is:
  its private Address Space (code/data/heap/stack), its Resources (handles), and its
  Execution Context (the exact point its execution stands: position, registers, stack top).
  Every Process, from any program, has this anatomy."
- **Transformation (exactly one):** *label* → *anatomy*: "managed instance" stops being a
  name and becomes the concrete set of things the OS holds for the Process.
- **Discovery order (locked):** empty shell at creation → private space granted → code
  copied in (Program unchanged) → execution runs, values kept (data) → mid-run room granted
  (heap) → sub-task and return (stack) → the four are ONE granted space → **Address Space**
  → outside things via OS, handles dock (file, display) → **Resources** → the gold point —
  the execution IS somewhere exact → its companions (registers, stack top) → **Execution
  Context** → a different program shows the same anatomy (generality) → one machine, one
  advancing point; the second point is HELD → silent climax → bridge (can a held point stop
  and continue?).

### Black Box declarations (PHILOSOPHY §5.3)
- *How the private space maps onto physical RAM* (pages, virtual memory) — **Deferred
  Internal**, Topic 05 Memory Systems.
- *How the OS enforces the boundary* (protection, kernel mode) — **Deferred Internal**,
  Topic 11 / later.
- *Whether/why an alive Process is not always advancing* — **Deferred Internal**, THIS
  chapter's next increment (States/Switch/Resume). This increment only shows the phenomenon.

### Terminology reveal (locked; machine-checked by the scope gate)
| Term | Reveal beat | Precondition observed |
| :-- | :-- | :-- |
| `code` / `data` / `heap` / `stack` (band names) | B04 / B05 / B06 / B07 | each band's behaviour watched first |
| **Address Space** | B08 | four bands ringed as one granted space |
| **Resources** | B10 | two handles docked; targets never moved |
| **Execution Context** (+ Program Counter, Stack Pointer) | B13 | gold point + registers + stack top ringed as one snapshot |

"Registers" is Topic-01 vocabulary (already owned) and may appear from B05.
No state names, no "context switch", no "pause/resume" as mechanism terms anywhere.

---

## 2. Beat table (18 beats, one scene `world`)

| # | Beat ID | Discovery / purpose | Learner sees (T0→T1) | One causal mutation |
|---|---|---|---|---|
| B00 | `the-question` | Cognitive replay of CH01 exit; pose the central question | CH01 world: Photos on its shelf, OS band (rows already labeled — earned in CH01), empty execution field, quiet machine bay | reactivates CH01 model |
| B01 | `relaunch` | Watch a known operation once more — this time to look inside | Launch request → OS → birth bloom → large cell; PID 4488 resolves (familiar, chunked per §5.2) | a new Process exists |
| B02 | `empty-shell` | The tension: a named, bounded — empty — instance | Interior visibly empty; instructions live far west in the file; the machine executes instructions — this can execute nothing yet | interior = unknown → visibly empty |
| B03 | `the-space` | First grant: somewhere of its own | Request → OS manage row → grant arc → an empty private column materializes inside the cell | the Process HAS its own granted space |
| B04 | `code-arrives` | Instructions become reachable | Copy stream Program → OS → top band fills with instruction rows; Program pulses unchanged (coexistence) | code copied IN; label `code` |
| B05 | `first-run` | Execution runs; what it computes must be kept | Gold row-point starts stepping the code rows (T01 grammar); produced values (◆ ▲ ■ ●) settle into a second band | running produces kept values; label `data` |
| B06 | `heap` | Mid-run, unpredictable room | The photo is opened — request comet → OS → grant arc → a third region grows | memory can GROW by grant; label `heap` |
| B07 | `stack` | Sub-task and return | Marker steps into a sub-task; a slat pushes in; on return it pops; the top tick follows | the Process remembers where to return; label `stack` |
| B08 | `address-space` | The four are ONE granted space | A ring closes around all four bands; term pill **Address Space** | 4 behaviours → 1 concept |
| B09 | `the-file` | Outside things don't come in | The photo file glyph on storage; request through OS; the FILE stays; a handle chip docks inside the Process | access granted ≠ object moved |
| B10 | `outside-things` | The pattern of granted access | Second need (the display) → second handle docks; term pill **Resources** | handles = recorded grants |
| B11 | `the-exact-point` | The deepest observation | Everything quiets; the gold point alone is salient: at this instant, execution IS at exactly one place | attention → the position itself |
| B12 | `the-snapshot` | The point's companions | Position row + register values + stack-top tick ringed together as one live snapshot | position+registers+stack top = one state |
| B13 | `execution-context` | Name it | Term pill **Execution Context**; the position is the Program Counter; the stack top is the Stack Pointer | the snapshot has a name; the OS holds it |
| B14 | `another-program` | Generality — not a Photos thing | A DIFFERENT program (Notes) is launched; a second Process forms with the same anatomy (fast, chunked): space, code, handle, own gold point, PID 4517 | anatomy generalizes to every Process |
| B15 | `one-machine` | The honest constraint (bridge fuel) | Both alive; A's point advances; B's point stands HELD (soft glint, never advancing); the machine is one | alive ≠ advancing (phenomenon only) |
| B16 | `climax` | SILENT — the model at scale | A runs (marker, data, a heap grant, handle blink, stack breathing); B holds, complete and still; OS rows glint on grants; both Programs unchanged | — (observation only) |
| B17 | `bridge` | Quiet integration + open loop | "The OS holds everything each Process is — even its exact point. B's point is held, not lost. If the exact point can be held… can execution stop, and later continue from exactly there?" | permitted open loop → next increment |

**Beat durations (ms):** 7000, 8000, 7000, 7000, 8000, 8000, 8000, 8000, 7000, 7500, 7500, 7000, 7500, 7500, 9000, 8000, 16000, 10000 (~149 s).

---

## 3. Geometry (all metrics named; derivable geometry §2.2)

Semantic axis preserved (DEF-01): STORAGE (west) → OS (middle) → EXECUTION FIELD (east,
machine bay far-east). CH01 pixel values are NOT inherited (CH01-specific); this chapter's
framing is closer because its subject is the interior.

- **Storage bay (west):** TWO program tiles (Photos y≈290, Notes y≈505; tile 144×150) on one
  recessed bay. Notes is present from B00 (a second stored program is normal), inert until B14.
- **OS band (middle):** CH01 grammar — 220×232 @ (520, 400); intake/creation ports; three
  function rows WITH their labels from B00 (earned in CH01 — no unlearning).
- **Process A (focus cell):** 430×470 @ center (955, 405). Interior derived from the cell rect:
  - header: caption "Process" (15px) top-center, provenance "Photos" (11px) under it, PID chip top-right inside;
  - memory column (left): x+22, y+78, 196 wide, 356 tall; four bands top-down code(150)/data(56)/heap(40→72, grows)/stack(64); hairline dividers, band labels revealed per-band on the right edge;
  - resource dock (right-upper): two handle chips;
  - register strip (right-lower): 3 slots with T01 value glyphs; gold stack-top tick on the stack band.
- **Process B (Notes cell):** 300×300 @ center (1360, 530) — same anatomy, compact scale; NOT
  axis-aligned with A (anti-queue).
- **Machine bay (far east, top):** 140×180 @ (1495, 230) — CPU·RAM·I/O glyphs, quiet; its CPU
  slot carries a very soft glint while an execution point is advancing (truthful ambient), and
  is never highlighted by memory grants (blocks "column = RAM").
- **Term pills:** concept band above the field (Address Space, Resources) and below cell A
  (Execution Context) — all clear of every entity (layout-proof asserted).
- **Protagonist path:** `[Photos, OS, A, Notes, OS, B]` (anchors 0–5). B01 travel 0→2 (holdFrom
  .5); B14 travel 2→5 (holdFrom .55); rests: B00@0, B02–B13@2, B15@5, B16/B17@4 (the OS — the
  holder of it all), both `effect:'loop'`.

## 4. Animation contracts (FROM → CAUSE → EVENT → EFFECT → FINAL)

1. **GRANT (space B03, heap B06, handles B09/B10, climax aux):** need cue at the cell →
   request comet cell→OS intake → manage row lights → grant arc creation-port→cell →
   structure materializes/grows → persistent. All windows are named (beat, frac) spans in
   story.ts.
2. **COPY STREAM (B04):** three staggered comets Program→OS→code band; Program pulse
   overlaps arrivals (coexistence, CH01 grammar); rows condense as comets land.
3. **EXECUTION POINT (B05→):** gold row highlight steps rows deterministically from the
   chapter clock (pure f(beat, frac) via duration prefix sums); registers update with the
   step; NEVER more than one advancing point chapter-wide (smoke-gate invariant).
4. **STACK (B07, climax):** slat eases in (push) with the marker entering the sub-rows; pops
   with the return; top tick tracks depth.
5. **HELD POINT (B14→):** B's gold point resolves at its first row and holds; a slow
   low-amplitude glint says "held", it never advances, never transfers.
6. **SILENT CLIMAX (B16):** all of the above replayed from a declarative `CLIMAX` schedule;
   no narration, no text.

Determinism: every drawn state is a pure function of (beatIndex, beatElapsed) via story
tables; ambience uses `s.t` exactly as CH01 does (LOK-08).

## 5. Scope gate plan

Forbidden in ALL learner-visible strings (EN+VI): ready, waiting, blocked, terminated (as
state), scheduler, scheduling, queue, time slice, quantum, preempt, dispatch, context
switch, pause, resume, suspend, thread, page, page table, TLB, virtual memory, physical
address, mutex, lock, race, parallel, concurren-, PCB, process control block + VI: hàng
đợi, lập lịch, định thời, luồng, tiểu trình, chuyển ngữ cảnh, tạm dừng, phân trang, bộ nhớ
ảo, song song, đồng thời. Required with exact first-reveal beats: Address Space (B08),
Resources (B10), Execution Context (B13), Program Counter (B13+), Stack Pointer (B13+),
code (B04) / data (B05) / heap (B06) / stack (B07).

## 6. Verification plan

1. `tsc` + `vite build`.
2. Smoke: playthrough integrity; terminology ordering; story invariants (heap monotone in
   grant, ≤1 advancing point at every sampled (beat, frac), B's point held from dock on,
   handle docks after requests); deterministic double-render byte-equality (18 beats × 5
   fracs × 2 langs); Program tiles paint-stable.
3. Scope gate (§5).
4. Layout proof: bands ⊂ column ⊂ cell A; dock/registers/chip ⊂ cell A; B anatomy ⊂ cell B;
   A/B/OS/machine/tiles pairwise disjoint; pills clear of entities; anti-alignment A↔B; bbox
   coverage.
5. Browser playthrough at real Viewer geometry with screenshots at every load-bearing beat
   (if the environment provides a browser; otherwise report the limitation honestly).
6. Adversarial misconception pass over §5 of the Delta Audit.

**STOP — end of blueprint. Implementation follows.**
