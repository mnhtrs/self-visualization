# Chapter Pre-Implementation Contract: Inside a Process — Memory, Resources & Execution Context

**Chapter ID:** `topic-02-ch-02-process-execution`
**Order:** 2
**Author / Agent:** AI Agent (Topic 02 Fast Production Workflow, Phase 2 — DEFINE)
**Date:** 2026-08-15

> **Increment note (binding):** The canonical CH02 (`process-execution`,
> Guardian T02 v0.4.0 §5) owns the full arc *environment + context → states →
> context switch → resume*. This contract locks **Increment 1** of that
> chapter: *Inside a Process — Memory, Resources & Execution Context*
> (owner directive, 2026-08-15). The later execution story (States, Context
> Switch, Resume) is **explicitly out of scope for this increment** and will
> extend this same chapter in a later increment. Execution Context is the
> deliberate bridge toward that story; the bridge may only ASK the question,
> never answer it.

---

### 1. Chapter Identity & Slug
* **Slug:** `process-execution` (canonical CH02 slug — the increment ships under the canonical chapter identity)
* **Title (EN, this increment):** Inside a Process: Memory, Resources & Execution Context
* **Title (VI, this increment):** Bên trong một Process: Bộ nhớ, Tài nguyên & Ngữ cảnh thực thi

### 2. Central Question
> **What actually makes a Process a managed execution instance?**
> *(VI: Điều gì thực sự khiến một Process là một thực thể thực thi được quản lý?)*

CH01 named the Process "a managed execution instance" and proved identity +
lifetime. But on screen the Process was a bounded cell with a PID and
anonymous content marks. If that were all, the OS would have nothing to
manage. This chapter looks inside.

### 3. Previous Mental Model (Upstream Exit State)
From CH01 (FROZEN) the learner holds:
* Program ≠ Process (LOK-01); the Program never changes when launched (LOK-02).
* The OS creates, identifies, and manages Processes (LOK-03); every instance
  has a PID assigned at creation (LOK-04); one Program → many independent
  Processes (LOK-05).
* Open question left by CH01's bridge: *"a Process that exists… is it
  actually executing every moment it is alive?"*
* From Topic 01: the machine executes instructions one at a time; instructions
  and values live in memory; registers hold working values; the value glyphs
  ◆ ▲ ■ ● denote data values.

### 4. Target Mental Model (Downstream Exit State)
> A Process is not just a name and a number. It is a managed execution
> instance because the OS grants and tracks everything the Process is:
> **its own private Address Space** (code, data, heap, stack) holding
> everything it remembers; **its Resources** — handles to outside things
> (files, devices) granted through the OS; and **its Execution Context** —
> the exact point its execution stands at this instant (position/PC, register
> values, stack top). Every Process, from any program, has this same anatomy.

The model is GENERAL: proven on two Processes born from two different
programs, not tied to the CH01 "Photos" exemplar.

### 5. False Model Blocked
1. *"A Process is just the program 'running' — a label on the program."*
   Blocked: the interior is built up in front of the learner, piece by piece,
   each granted by the OS, none of it present in the stored Program.
2. *"The Process's memory IS the machine's RAM stick."* Blocked: the space is
   drawn INSIDE the Process (private, per-Process), the machine's RAM stays a
   separate quiet context; how the private space maps onto physical memory is
   a declared Deferred Internal (Topic 05).
3. *"Files/devices move into the Process when used."* Blocked: the file stays
   on storage; only a handle (access token) docks inside the Process.
4. *"Everything alive is executing right now."* Blocked (observationally
   only): the second Process's execution point is HELD, not advancing, while
   the first advances — one CPU, one advancing point (T01 canon C-05
   preserved). No state names, no reasons — that is the next increment.

### 6. Central Discovery
The learner watches the interior of one already-known Process become
progressively real *because of what the Process does*: instructions must be
reachable (→ its own code in its own granted space), it keeps working values
(→ data), it needs unpredictable extra room mid-run (→ heap grows on an OS
grant), it steps into sub-tasks and returns (→ stack), it needs outside
things (→ handles through the OS), and — the deepest one — at any instant its
execution IS somewhere exact (→ the golden position marker + registers +
stack top = Execution Context). Then a second Process from a *different*
program shows the same anatomy: it is the shape of every Process.

### 7. Prerequisite Assumptions
- [x] Program ≠ Process; Program persists unchanged (CH01, LOK-01/02).
- [x] OS creates/identifies/manages Processes; PID at creation (LOK-03/04).
- [x] Launch grammar: request → OS intake → creation port → birth bloom (CH01).
- [x] T01: instructions execute one at a time; registers hold working values;
      ◆ ▲ ■ ● are data values; the machine (CPU·RAM·I/O) is a separate
      physical context (LOK-07).

### 8. Inherited Concepts & Visual Grammar
- [x] Visual grammar: de-windowed Process cell (DEF-04), borderless OS band
      with three function rows create/identify/manage (row labels already
      earned in CH01), recessed storage bay (west), machine bay with
      CPU/RAM/I-O glyphs (east), West→Storage / Middle→OS / East→Execution
      axis (DEF-01).
- [x] Animation semantics: causality via motion (DEF-05), materialization
      bloom for births (CH01 contract 2), identity resolve-in-place for PID
      chips, restrained acknowledgment pulses, golden spark as the single
      protagonist (attention/launch signal), deterministic (beat, frac)
      engine (LOK-08).
- [x] Entity hierarchy: Process (15) > PID (14) > provenance (11) — DEF-02.

### 9. New Concepts Introduced
1. **Address Space** — the Process's own private memory space, granted and
   tracked by the OS; observed as code / data / heap / stack before naming.
2. **Resources (handles)** — access to outside things (file, display) granted
   through the OS and recorded as handles docked in the Process.
3. **Execution Context** — the exact point of execution: position (PC),
   register values, stack pointer — held by the OS for the Process.

### 10. Forbidden Concepts & Scope Boundaries
- [ ] Process States (Ready/Running/Waiting/Blocked/Terminated as terms) — later increment.
- [ ] Context Switch / context preservation-and-restore choreography — later increment.
- [ ] Pause/Resume as named mechanism — later increment (bridge may only ask "can it stop and continue?").
- [ ] Scheduler, Ready Queue, time slice, preemption, policies — CH03.
- [ ] Threads — CH04/05.
- [ ] Virtual memory implementation (pages, page tables, TLB, physical mapping) — Topic 05 (Deferred Internal).
- [ ] Memory protection mechanics, kernel/user space — Topic 11 / later.
- [ ] PCB / "process control block" as a term — later increment at the earliest.

### 11. New Visual Grammar Requirements
* **Intra-entity structural regions:** the Process cell gains internal
  semantic regions (memory column with four bands; resource dock; context
  markers). These are STRUCTURE inside one entity, drawn borderless-soft
  (tint + hairline), never as nested dashboard cards. Justified: the chapter's
  entire subject is the interior anatomy of the Process.
* **Handle chip:** a small docked token (icon + name) recording granted
  access; the target (file/device) never moves.
* **Golden position marker:** a gold row-highlight on the code band — the T01
  golden-instruction continuity glyph for "the exact point of execution".

### 12. New Animation Grammar Requirements
* **Grant sequence:** request (small comet, Process → OS intake) → manage row
  lights → grant (arc/comet, OS creation port → Process) → the granted
  structure grows/materializes. Used for: space grant, heap growth, file
  handle, display handle.
* **Copy stream:** staggered comets Program → OS → code band; the Program
  pulses unchanged (CH01 coexistence grammar reused).
* **Stack breathing:** frame slats push in / pop out (call → return).
* **Held marker:** the second Process's marker appears and stays still with a
  soft held-glint — motion only where execution advances (§20 truthfulness:
  only ONE marker ever advances — one CPU).

### 13. Terminology Reveal Plan
* **B02–B03:** Phenomenon — OS grants a private space; instructions copied in (Program unchanged).
* **B04–B06:** Phenomena — data values; heap grows on request; stack pushes/pops. Band names `code`/`data`/`heap`/`stack` land AFTER each observation, per band.
* **B07:** Term unlocked: **`Address Space`** (không gian địa chỉ).
* **B08:** Phenomenon — file request through OS; handle docks; file stays on storage.
* **B09:** Second handle (display) → Term unlocked: **`Resources`** (tài nguyên).
* **B10:** Phenomenon — the golden marker: WHERE the execution is, moving line by line.
* **B11:** Phenomenon — the marker's companions: register values + stack top (the exact snapshot).
* **B12:** Term unlocked: **`Execution Context`** (ngữ cảnh thực thi) — PC, Registers, SP named.
* **B13:** Generalization — second program (Notes) → second Process, same anatomy, own everything.

### 14. Silent Climax & Bridge to Next Chapter
* **Silent Climax (B14, no narration):** the complete general model operating
  at once — Process A's golden marker running through its code, a heap grant
  arriving, the file handle blinking in use, the stack breathing; Process B
  alive beside it with its own anatomy and a HELD execution point; the OS rows
  glinting on each grant; both Programs unchanged on the shelf.
* **Open Bridge Question (B15):** *"The OS holds everything each Process is —
  even its exact point of execution. The second Process's point is held, not
  lost. If the exact position can be held… can execution stop, and later
  continue?"* → motivates the States / Switch / Resume increment.

---

## Sign-off & Approval
* **Status:** APPROVED FOR IMPLEMENTATION (increment 1 of canonical CH02)
* **Approver:** Owner directive (task specification, 2026-08-15)
* **Date:** 2026-08-15
