# Agent Memory — Topic 02 / Chapter 02 (process-execution, increment 1: Inside a Process)

**Last checkpoint:** IMPLEMENTATION COMPLETE — gates green, visual pass done (2026-08-15)
**Status:** Production candidate — awaiting owner review (NOT frozen)

> **Increment rule (binding):** this release ships **increment 1** of the canonical
> CH02 (`process-execution`, Guardian T02 v0.4.0 §5): *Inside a Process — Memory,
> Resources & Execution Context*. The later execution story (States, Context
> Switch, Resume) extends this SAME chapter in a later increment. Its only trace
> here is the bridge question ("if the exact point can be held… can execution stop
> and later continue?") and the observed-but-unnamed HELD point of Process B.
> **Do not implement the later story without an owner directive.**

## What exists

- **Chapter implementation:** `src/content/topics/02-operating-systems/02-process-execution/`
  - `meta.ts` / `index.ts` / `assemble.ts` (meta-free) / `types.ts`
  - `narration/{beats,labels}.ts` — 18 beats, EN+VI, silent NBSP climax (b16)
  - `scenes/{metrics,layout,story,01-world}.ts` — metrics → layout → story purity chain
  - `renderers.ts` + `renderers/world.ts` — painters: `storage-bay`, `os-band`,
    `machine-bay`, `process-field`
  - `assets/thumbnail.jpg`
- **Docs:** `docs/chapters/topic-02-ch-02-process-execution/`
  `00_CHAPTER_CONTRACT.md` (Phase 2) · `01_DELTA_AUDIT.md` (Phase 3) ·
  `02_CHAPTER_PRODUCTION_[BLUEPRINT].md` (Phase 4) · this memory.
- **Gates:** `scripts/{smoke,scope-gate,layout-proof}-topic02-ch02.ts`, wired into
  `npm run smoke`. (The CH01 gate scripts referenced there before are ABSENT from
  the tree — same class of debt as PROJECT_STATE §2.5; CH01 remains frozen and
  untouched.)
- **Evidence frames:** `review/shots-t02c02/{en,vi,small}/` — full EN playthrough
  (28 frames), VI spot-checks, 1100×700 legibility set. 0 page errors in all runs.

## Gate status (last run)

- `npm run build` — PASS (tsc + vite, zero errors)
- Smoke — **438 checks** (structure, story invariants, deterministic byte-equal
  double-render 18 beats × 5 fracs × 2 langs, storage-painter immutability)
- Scope gate — **3783 checks** (forbidden EN+VI strings incl. states/switch/
  pause/resume/scheduling/threads/VM; exact reveal beats: Address Space@B08,
  Resources@B10, Execution Context@B13; PIDs derived from story)
- Layout proof — **146 checks** (bands ⊂ column ⊂ cell; docks/registers/chips
  contained; regions pairwise disjoint; column far from machine bay; anti-queue
  A↔B; pills clear; bbox coverage; path anchors)

## Load-bearing design decisions

1. **The interior is the chapter.** One stable world (CH01 axis preserved);
   Process A is a large focus cell whose interior (memory column with
   code/data/heap/stack, resource dock, register strip, gold execution point)
   materializes piece by piece — each piece caused by something the Process DOES,
   each granted through the OS (grant grammar: need cue → request comet → manage
   row → grant arc → structure grows).
2. **Grant grammar is the one new causal animation.** Space (b03), heap (b06),
   file handle (b09), display handle (b10), climax aux — all use the same
   watched route, so "the OS grants and tracks" is enacted five times, never told.
3. **Anti-"column = RAM".** The private space lives strictly INSIDE the cell
   (green family), the machine bay (with its violet RAM glyph) is far east and
   never lights during memory grants; mapping to physical RAM is a declared
   Deferred Internal (Topic 05).
4. **Address-space shape is real:** code/data top-down, stack bottom-anchored,
   heap grows DOWNWARD toward the stack (gap between them asserted by the gate).
5. **Gold point discipline (T01 continuity, canon C-05):** at most ONE advancing
   execution point chapter-wide (smoke-asserted). Process B's point resolves once
   and stands HELD with a slow glint — the phenomenon that fuels the bridge; no
   state names, no switching. The machine's CPU slot glints only while a point is
   advancing.
6. **Protagonist ≠ marker:** the golden spark (attention/launch signal) parks at
   a derived WATCH-POINT beside cell A during interior beats (path anchor 3) so
   the gold execution marker is the only gold point inside the cell. Continuous
   travels, no teleports.
7. **Generality before climax:** a second, visibly different program (Notes)
   forms Process B with the same anatomy at compact scale — "this is what a
   Process IS", not a Photos feature. Anti-queue offsets are gate-proven.
8. **Terminology order (scope-gate locked):** band names after each band's
   behaviour (code b04 / data b05 / heap b06 / stack b07) → Address Space b08 →
   handle b09 → Resources b10 → Execution Context b13 (with Program Counter /
   Stack Pointer micro-labels + leader lines). "Registers" is inherited T01 vocab.

## Iteration log (single materiality pass, per the STOP rule)

- P1 fixes after first full render: (a) EC micro-labels moved from beside the
  marker (collided with registers) to the free lower-right area with gold leader
  lines; (b) band labels offset +24px to clear the Address-Space ring; (c) dock
  chips moved below the code-band label line; (d) protagonist rest moved off the
  cell interior to the watch-point (two gold points read as two executions);
  (e) machine bay height 180→196 (slot containment); (f) "one thread of thought"
  wording in the bridge (scope-gate catch) → "one question".
- P3 (documented, NOT fixed per the materiality rule): the CESVI watermark
  passes behind cell A (background cosmetic); B's held-glint period vs A's
  breathing period are close (cosmetic).

## Environment / verification notes

- Headless Chromium (playwright-core + apt libs) works in this sandbox after
  `apt-get install libnss3 …`; capture script: `scripts/shots-topic02-ch02.mjs`
  (drives the real Viewer at 1400×850 via the beat dots — direct beat navigation
  is therefore exercised on every capture run).
- `node_modules` is not persisted (PROJECT_STATE debt #3) — rerun `npm install`.

## Next actions

1. Owner review (Phase 9 human pass) → freeze per Phase 10 if accepted.
2. Later increment (owner-directed): States / Context Switch / Resume — extends
   this chapter; its entry state is this increment's bridge (the HELD point).
