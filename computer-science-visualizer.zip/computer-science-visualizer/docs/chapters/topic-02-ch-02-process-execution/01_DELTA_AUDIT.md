# Chapter 02 — Delta Audit: Inside a Process — Memory, Resources & Execution Context

**Chapter ID:** `topic-02-ch-02-process-execution` (increment 1 of canonical CH02)
**Author / Agent:** AI Agent
**Date:** 2026-08-15
**Template:** `docs/topics/topic-02/02_CHAPTER_DELTA_AUDIT_TEMPLATE.md` — NEW material only.

---

## 1. Inherited Baseline
- [x] Mental model: Program ≠ Process; PID ownership; OS mediation; one Program → many Processes (LOK-01…05).
- [x] Visual grammar: de-windowed Process cell; squared borderless OS band with create/identify/manage rows (labels already earned in CH01); recessed storage bay (west); machine bay CPU·RAM·I/O (east, LOK-07); West→OS→East semantic axis (DEF-01); entity hierarchy Process > PID > provenance (DEF-02).
- [x] Animation patterns: causality via motion (DEF-05); materialization bloom; identity resolve-in-place; restrained acknowledgment pulses; golden spark protagonist; deterministic (beat, frac) engine (LOK-08).

## 2. New Mental-Model Transformation
* **Current Learner Model:** "A Process is a managed instance — a bounded entity with a PID and a lifetime." (Interior unknown; 'managed' is a name, not a mechanism.)
* **Target Learner Model:** "A Process is a managed instance because the OS grants and tracks everything it is: a private Address Space (code/data/heap/stack), Resources held as handles, and an Execution Context — the exact point its execution stands. Every Process, from any program, has this anatomy."
* **Central Question Answered:** What actually makes a Process a managed execution instance?

## 3. New Entities Introduced
- **Address-space column** (memory bands: code/data/heap/stack)
  - Visual: a soft column INSIDE the Process cell with four hairline bands; heap visibly grows on grant; stack slats push/pop.
  - Parent / Container: the Process cell (strictly inside; derived from the cell rect).
- **Handle chip** (resource token)
  - Visual: small docked chip (mini glyph + name) in a resource dock inside the Process cell; pink (OS-granted) border.
  - Parent / Container: the Process cell's resource dock.
- **Execution-point markers**
  - Visual: gold row marker on the code band (T01 golden-instruction continuity), register slots with T01 value glyphs (◆ ▲ ■ ●), gold stack-top tick.
  - Parent / Container: the Process cell (all derived from cell rect).
- **Second Program tile ("Notes")**
  - Visual: same storage-tile grammar as Photos, second position on the shelf.
  - Parent / Container: storage bay (west).

## 4. New Causal Relationships Introduced
- Trigger: Process must execute instructions that live in a file far away ⟶ Action: OS grants a private space + copies code in ⟶ Effect: instructions are reachable inside the Process; Program unchanged.
- Trigger: mid-run need for unpredictable extra room ⟶ Action: request to OS, manage row lights, grant returns ⟶ Effect: heap band grows (memory is granted/tracked, not ambient).
- Trigger: sub-task entered/finished ⟶ Action: stack slat pushed/popped ⟶ Effect: the Process remembers where to come back to.
- Trigger: Process needs an outside thing (file, display) ⟶ Action: request through OS ⟶ Effect: handle docks inside the Process; the thing itself never moves.
- Trigger: "where exactly does this execution stand?" ⟶ Action: gold marker + register values + stack top ringed as one snapshot ⟶ Effect: the exact point of execution is a real, held thing (Execution Context).

## 5. New Misconception Inventory
1. **"The Process's memory IS the machine's RAM stick."**
   * Protection: the space is drawn strictly INSIDE the Process; the machine bay (with its RAM glyph) stays a separate quiet east region and never lights during grants; narration says "its own private space, granted by the OS"; physical mapping declared Deferred Internal (Topic 05). Layout gate asserts the column is inside the cell and disjoint from the machine bay.
2. **"Code moves out of the Program into the Process" (Program consumed).**
   * Protection: CH01 coexistence grammar reused — copy comets travel while the Program pulses unchanged; narration states "a copy"; the Program tile persists 100% of the timeline (paint-equality check inherited from CH01's program-immutability idea).
3. **"Files/devices enter the Process when used."**
   * Protection: the file glyph stays on the storage shelf; only the handle chip docks; a thin dashed use-link (logical, not a pipe) blinks during use.
4. **"Heap/stack are separate memories the machine provides."**
   * Protection: bands are regions of ONE granted column (single container, hairline dividers), named only after each behaviour is observed.
5. **"Both Processes execute simultaneously" (would contradict T01 canon C-05, one instruction at a time).**
   * Protection: only ONE gold marker ever advances; Process B's marker is visibly HELD (soft held-glint, no advance). No state terms, no switching choreography — held-ness is shown as phenomenon only (the bridge).
6. **"Execution Context is a checkpoint file" (forbidden analogy, Guardian §10).**
   * Protection: the context is ringed as live markers inside the Process, never as a document/file glyph.

## 6. New Visual Grammar Required
- [x] Intra-entity structural regions (memory column, resource dock, register slots) drawn as borderless-soft structure inside ONE entity — justified because the interior anatomy IS the chapter's subject. No nested dashboard cards (inherits De-Carding rule: tint + hairline only).
- [x] Handle chip; gold execution-point marker; held-glint for a non-advancing marker.

## 7. New Animation Semantics Required
- [x] GRANT: need arises (cell-local cue) → request comet Process→OS intake → manage row lights → grant arc OS→Process → structure grows/materializes.
- [x] COPY STREAM: staggered comets Program→OS→code band; Program pulse (unchanged) overlaps arrival (coexistence).
- [x] STACK BREATHING: slat pushes in (call), pops out (return); stack-top tick follows.
- [x] HELD MARKER: appears with B's anatomy, then holds still with a low-frequency glint; never advances.

## 8. Scope & Leakage Risks
- [x] Risk: Process States terms (Ready/Waiting/Blocked/Terminated) — Guard: scope gate forbids the strings (EN+VI) in all learner-visible text.
- [x] Risk: Context Switch / preserve-restore choreography — Guard: no marker ever transfers between Processes; scope gate forbids "context switch", "pause", "resume", "chuyển ngữ cảnh", "tạm dừng", "tiếp tục thực thi" as mechanism terms; bridge uses ordinary "stop / continue" phrasing as a question only.
- [x] Risk: Scheduling (queue, scheduler, time slice) — Guard: scope gate; only two Processes, no ordering structure.
- [x] Risk: Virtual-memory internals (pages, mapping, addresses as numbers) — Guard: no numeric addresses anywhere; bands carry behaviour labels only; Deferred Internal declared in blueprint §5.
- [x] Risk: Threads — Guard: scope gate; exactly one execution point per Process.

## 9. Geometry & Spatial Risks
- [x] Spatial Risk: the big focus Process reads as a "dashboard window". Correction: keep CH01 cell grammar (rounded rect, no header divider, no close affordance, borderless inner tints), caption hierarchy unchanged.
- [x] Spatial Risk: memory column adjacency to the machine bay implies "column = RAM". Correction: column strictly inside the cell, machine bay far east, never highlighted during memory events.
- [x] Spatial Risk: two Processes side by side read as a queue/pipeline. Correction: B sits offset lower-right of A, different size; anti-alignment asserted in the layout proof.

## 10. Verification Additions
- [x] New Scope Gate Rules: forbidden state/switch/scheduling/thread/VM strings (EN+VI); required terms with exact first-reveal beats (`Address Space`@B07, `Resources`@B09, `Execution Context`@B12, `PC`/`Program Counter`/`Stack Pointer`@B12 only).
- [x] New Layout Proof Assertions: bands ⊂ column ⊂ cell; handles ⊂ dock ⊂ cell; registers ⊂ cell; A, B, machine, OS, storage pairwise disjoint; pills inside bbox; B not axis-aligned with A (anti-queue).
- [x] Smoke additions: single-advancing-marker invariant (at every sampled (beat,frac), at most one marker advancing); heap monotone growth within its grant; deterministic double-render byte-equality.

## 11. Decision & Materiality Verdict

### Materiality Classification (pre-implementation)
- **P0:** 0 — **P1:** 0 — **P2:** 0 — **P3:** 0 (audit of design; verified again after render in Phase 7)

### Verdict
* **[x] GO:** Proceed to STORY (blueprint) and implementation.
