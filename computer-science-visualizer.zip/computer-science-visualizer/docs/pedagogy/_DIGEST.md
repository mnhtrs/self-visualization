---
type: "digest"
guiding_question: "What are the essential pedagogical rules extracted from PEDAGOGICAL_SYSTEM for chapter production?"
sources: ["PEDAGOGICAL_SYSTEM.md 1.3.0"]
authority: "Compression layer only. Source document wins on any conflict."
---

# Pedagogy Digest — Operational Rules for Chapter Production

---

## Conflict Resolution Hierarchy (§2.1)

When two design choices conflict, higher items strictly override lower items:

1. Technical truth and no unlearning — never teach a false mechanism.
2. Visible causality — every state change must have an observable cause.
3. Continuity of protagonist, scene, and curriculum.
4. Cognitive load control — one beat, one new idea.
5. Observation before terminology — names follow experienced behaviour.
6. Visual economy — remove or delay anything not needed now.
7. Narration naturalness and brevity — narration guides, never carries the mechanism.
8. Aesthetic polish — valid only after all above are satisfied.

---

## Pedagogical Unit Hierarchy (§3)

| Unit | Must do | Must NOT do |
|---|---|---|
| **Chapter** | Complete exactly one mental-model transformation | Survey multiple mechanisms |
| **Scene** | Resolve one required sub-question | Introduce mechanisms because they are interesting |
| **Beat** | Make one causal state change observable | Carry multiple independent new ideas |
| **Animation** | Show where protagonist/data/state goes and why | Depend on narration to supply causality |
| **Narration** | Guide attention; name terms after experience | Teach the mechanism instead of the animation |

---

## Operational Principles (§4) — with Review Checks

**4.1 Mental Model Before Terminology:** Introduce terms only after the learner has observed the motivating phenomenon. *Check: Can the learner describe the behaviour before hearing the term?*

**4.2 Observation Before Explanation:** Visual state change occurs before or with narration. *Check: Does animation precede or accompany the narration line?*

**4.3 One Beat, One Causal Mutation:** Each beat mutates exactly one independent concept. *Check: Does the beat force tracking of multiple simultaneous changes? If yes, split it.*

**4.4 Protagonist Traceability:** One persistent visual protagonist per chapter; its position is answerable at every second. *Check: Can you answer "where is the focus?" at every moment?*

**4.5 Single Source for Quantities:** Every quantity spoken in narration must derive from the same data the renderer draws. *Check: For every spoken number, name the constant or array the renderer reads.*

**4.6 Affirmative State Derivation:** Problem-state badges must derive from an affirmative predicate, never from logical negation (`!working`). *Check: Does every badge trace to a named predicate listing the beats where the problem genuinely occurs?*

**4.7 Experiential Climax Requirement:** Culminate in exactly ONE climax observed visually at scale without narration commentary. *Check: Does the climax allow watching the system run without text commentary?*

**4.8 Longitudinal Cognitive Replay & Model Reactivation:** Opening scene must reactivate and test previous mental models as cognitive tools or points of friction. *Check: Does scene entry explicitly test the upstream prerequisite exit state?*
