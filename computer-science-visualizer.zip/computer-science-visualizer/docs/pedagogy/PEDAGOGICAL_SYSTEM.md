---
guiding_question: "How do authors resolve pedagogical conflicts, structure mental-model transformations, and maintain cross-chapter consistency?"
primary_consumer: "Content Authors, QA Auditors, AI Agents"
depends_on:
  - "docs/constitution/PHILOSOPHY.md"
  - "docs/constitution/VISUAL_LANGUAGE.md"
  - "docs/constitution/NARRATIVE_FRAMING.md"
referenced_by:
  - "docs/README_FOR_AI.md"
  - "docs/pipeline/01_COGNITIVE_STAGES.md"
  - "docs/pipeline/03_QA_VERIFICATION.md"
---

# Cesvi Operational Pedagogy System

**Status:** Frozen — operational pedagogy baseline  
**Version:** 1.3.0  
**Authority:** Single authoritative source for operational lesson design, conflict resolution, and cross-chapter consistency.

---

## 1. Core Thesis & The Golden Spark

Cesvi is a visible world where learners observe computational systems operating. The learner should not feel, *"I memorized a definition."* The learner should feel, *"I watched the system work, and now I can explain it."*

All principles serve one central goal:

> **Build durable mental models through observed causality.**

### Non-Goals
Cesvi does **not** optimize for:
- Teaching the maximum number of facts per chapter.
- Documentation completeness or terminology coverage for its own sake.
- Decorative animation or stylistic novelty.
- Isolated lessons that do not continue the curriculum.
- Clever metaphors that learners must remember.
- Implementation convenience over mental-model correctness.

---

## 2. Decision Frameworks & Conflict Hierarchy

### 2.1 Conflict Resolution Hierarchy
When two design choices conflict, apply this hierarchy. Higher items strictly override lower items:

1. **Technical truth and no unlearning** — Never teach a false mechanism.
2. **Visible causality** — Every state change must have an observable cause.
3. **Continuity of protagonist, scene, and curriculum** — The learner must not lose where they are.
4. **Cognitive load control** — One beat, one new idea; one moving focus.
5. **Observation before terminology** — Names follow experienced behavior.
6. **Visual economy** — Remove or delay anything not needed now.
7. **Narration naturalness and brevity** — Narration guides, never carries the mechanism.
8. **Aesthetic polish** — Beauty is valid only after the above are satisfied.

### 2.2 Selecting Between Valid Implementations
When multiple implementations are technically correct, choose using these operational criteria:

| Design Choice | Prefer the option that... |
|---|---|
| Two animations both show the mechanism | Uses fewer simultaneous moving objects and clearer causality |
| Two labels are both accurate | Appears later, after observation, and requires less reading |
| Two layouts both fit | Preserves prior spatial language and structural truth |
| Two narration lines both work | Is shorter and leaves more time to watch |
| Two scene structures both answer the question | Keeps the protagonist more continuously traceable |
| A future object can be visible or hidden | Hides or dims it unless it supports current orientation |
| Two visual styles are both attractive | Matches existing Cesvi visual language |
| Completeness conflicts with clarity | Includes only what is necessary for the central question |
| A metaphor and direct runtime language both work | Uses direct runtime language unless the metaphor is essential |

---

## 3. Pedagogical Unit Hierarchy

The governing unit of a Cesvi chapter is **one mental-model transformation**, not merely a topic and not merely a question.

| Layer | Primary Responsibility | Must Not Do |
|---|---|---|
| **Course** | Sequence mental-model transformations so each chapter's exit state becomes usable prior knowledge. | Become a list of topics without cumulative state. |
| **Chapter** | Complete exactly one target mental-model transformation (from a specific misconception to an accurate model). | Become a survey of related mechanisms. |
| **Scene** | Resolve one necessary sub-question or bottleneck required by the chapter's target mental model. | Introduce a mechanism because it is interesting rather than needed. |
| **Beat** | Make one causal state change or idea mutation observable. | Carry multiple independent new ideas at once. |
| **Animation** | Show the mechanism: where the protagonist, data, value, or state goes and why. | Depend on narration to supply missing causality. |
| **Narration** | Guide attention, create or close curiosity, summarize what was just observed, and name terms after experience. | Teach the mechanism instead of the animation. |

---

## 4. Operational Principles

### 4.1 Mental Model Before Terminology
- **Rule:** A technical term or concept may be introduced only after the learner has observed the phenomenon that makes that term necessary.
- **Review Check:** Can the learner describe the behavior before hearing the term? Does the term appear only after the visual referent exists?

### 4.2 Observation Before Explanation
- **Rule:** Every explanation organizes something already seen rather than replacing observation.
- **Review Check:** Does the visual state change occur before or simultaneously with the narration line explaining it?

### 4.3 One Beat, One Causal Mutation
- **Rule:** Each timeline beat introduces or mutates exactly one independent concept or state variable.
- **Review Check:** Does a single beat force the learner to track multiple moving elements in different places? If so, split into sequential beats.

### 4.4 Protagonist Traceability
- **Rule:** Every chapter maintains one persistent visual protagonist (e.g. packet, instruction, execution spark) that guides the learner's attention through every scene.
- **Review Check:** Can the learner answer *"Where is the focus right now?"* at every second of the timeline?

### 4.5 Single Source for Quantities
- **Rule:** If narration states a quantity that a renderer also draws (counts, totals, ratios, step numbers), both must read the same declared data structure. A quantity shall never be typed independently in prose and in code.
- **Rationale:** A learner who counts along with the visual is doing exactly what Cesvi asks of them. If the narration disagrees with the board, the chapter teaches that the visuals cannot be trusted — the opposite of *"watch the system work."*
- **Review Check:** For every number spoken in narration, can you name the array or constant the renderer derives it from?
- **Provenance:** Generalized from `docs/chapters/topic-01-ch-02-cpu-memory-wait/08_PHASE_X_REPORT.md` (L1, defect D1).

### 4.6 Affirmative State Derivation
- **Rule:** A visual state that makes an accusation about the system (stalled, idle, failed, congested, dropped, corrupted) must be derived from an affirmative predicate in the chapter's story data — never as the logical negation of another state.
- **Rationale:** `!working` is not the same claim as `stalled`. Beats that merely explain, recap or reveal are "not working" without anything being wrong, and a badge left on screen during them asserts a falsehood.
- **Review Check:** Does every problem-state badge trace to a predicate that names the beats where the problem genuinely occurs?
- **Provenance:** Generalized from `docs/chapters/topic-01-ch-02-cpu-memory-wait/08_PHASE_X_REPORT.md` (L2, defect D2).

### 4.7 Experiential Climax Requirement
- **Rule:** Every chapter must culminate in exactly ONE climax where the target mental model is observed operating visually at scale without narration commentary.
- **Rationale:** Learning is locked when the learner discovers the truth through unassisted visual observation. Text summaries, static diagrams, or voiceover recaps do not constitute a climax.
- **Review Check:** Does the climax allow the learner to watch the system run without text commentary?

### 4.8 Longitudinal Cognitive Replay & Model Reactivation
- **Rule:** Every new chapter must actively reactivate and test previous mental models as cognitive tools or friction points in scene entry.
- **Rationale:** Knowledge decays if treated as isolated topics. Later chapters must enrich prior discoveries, allowing previous models to be replayed with deeper systemic understanding.
- **Review Check:** Does the opening scene explicitly test or reactivate the exit state of upstream prerequisite chapters?

---

## 5. Cross-Chapter Consistency & Review Gates

Every new or revised chapter must pass these consistency checks before approval:
1. **Target Mental Model Gate:** Is the target mental-model transformation explicitly declared alongside the central question?
2. **Derivable Layout Gate:** Are all visual coordinates derived from named layout primitives rather than hardcoded literals?
3. **Connection Identity Gate:** Are distinct physical/logical paths rendered as visually distinct lines?
4. **Narration Naturalness Gate:** Is narration concise, written in human spoken register, and free from textbook jargon dumps?
5. **Quantity Agreement Gate (§4.5):** Does every quantity spoken in narration derive from the same declared data the renderer draws from?
6. **Affirmative State Gate (§4.6):** Does every problem-state badge derive from an affirmative predicate rather than a negation?
7. **Experiential Climax Gate (§4.7):** Is the single climax reached via unassisted visual observation?
8. **Cognitive Replay Gate (§4.8):** Does scene entry reactivate the upstream prerequisite mental model?
