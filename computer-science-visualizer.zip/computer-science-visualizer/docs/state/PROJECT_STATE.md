---
guiding_question: "What is the CURRENT operational phase, active debt, and next allowed action of the repository?"
primary_consumer: "Maintainers, AI Agents"
depends_on:
  - "docs/protocols/GOVERNANCE_AND_AMENDMENTS.md"
referenced_by:
  - "docs/README_FOR_AI.md"
  - "docs/state/CHANGELOG.md"
---

# Cesvi Current Project State

**Schema Version:** 1.1  
**Project Version:** 0.7.0  
**Current Phase:** Journey Production  
**Repository Status:** Green  
**Constitution Version:** 1.3.0  
**Governance Version:** 1.3.0  
**Architecture Version:** 1.1.0  
**Curriculum Version:** 1.3.0  
**Pedagogy Version:** 1.3.0  

---

## 1. Quick Agent Context

- **Current Phase:** Journey Production (T02/CH02 increment 1 complete — gates green, awaiting owner review; T01/Ch-04 still awaiting owner review for freeze)
- **Next Allowed Action:** Owner review of Topic 02 Chapter 02 increment 1
  (*Inside a Process: Memory, Resources & Execution Context*, production,
  gates green) and of Topic 01 Chapter 04; freeze ceremonies on approval; or
  owner-directed revisions to released chapters.
- **Current Baselines:**
  - **CESVI Curriculum Constitution v1.0.0 (frozen 2026-08-01):** supreme curriculum contract — canonical models C-01…C-10, the single educational debt (D0) with facet ledger, extension doctrine, terminology ownership, boundary rules, canonical regression battery, and the curriculum audit protocol (`docs/curriculum/CURRICULUM_CONSTITUTION.md`). Every future chapter must pass its curriculum gate (between production phases 7 and 8).
  - **Topic 01 Ch-04 (`topic-01-computer-architecture--ch-04-instruction-throughput` v1.0.0, PRODUCTION — pre-freeze):** final chapter of Topic 01 (instruction-level throughput). 3 scenes, 18 beats, one protagonist (the golden instruction); single silent climax; machine-clock story system; gates green — smoke 344 · scope 48 · layout 90 (482 total, `npm run smoke`), build PASS, headless-Chromium playthrough verified.
  - **Topic 01 Ch-03 (`topic-01-computer-architecture--ch-03-cache-hit-or-miss` v1.0.0): Gate-coverage baseline** — 996 executable checks (playthrough + determinism + scope + layout), dock-based pill layout, storyboard↔code sync gate. *2026-07-28: owner-directed Production Fix Pass (R1–R5, surgical-only) completed after a REJECT verdict in the first Production Educational Review; all gates re-green. Same day: owner-directed Post-Review Unclear-Point Verification closed all six review-grip items (two-line miss verdict pills; post-LRU G2 occupancy continuity repaired; gates re-green — 438 + 131 + 432, build PASS; report `review/FIX_VERIFICATION_T01_CH03.md`, details in `docs/state/CHANGELOG.md` §1). Same day: **MODE D Final Production Gate** (adversarial pedagogical stress test) **PASS** (`review/PRODUCTION_GATE_D_T01_CH03.md`) and **MODE E Learner Simulation Gate** (first-time-learner simulation, final freeze authority) **PASS** (`review/LEARNER_SIM_GATE_E_T01_CH03.md`) — both black-box, no code changes, gates unchanged.*
  - **Topic 02 Curriculum Baseline v0.4.0 (2026-08-15):** 5 canonical chapters (`process-from-program-to-execution`, `process-execution`, `cpu-scheduling`, `threads`, `multithreading`). CH01 FROZEN (`topic-02-ch-01-process-from-program-to-execution` v1.0.0). Legacy CH02 (*Inside a Process*) and legacy CH03 (*Running a Process*) merged into new CH02 (*Process Execution: Pause, Switch, Resume*). Baseline: `docs/topics/topic-02/00_TOPIC_02_PRODUCTION_BASELINE.md`.
  - **Topic 02 CH02 — increment 1 (`topic-02-operating-systems--ch-02-process-execution` v0.1.0, PRODUCTION — pre-review, 2026-08-15):** *Inside a Process: Memory, Resources & Execution Context* — the first increment of the canonical CH02. 1 scene, 18 beats, ~149 s; central question *"What actually makes a Process a managed execution instance?"*; establishes Address Space (code/data/heap/stack), Resources (handles), Execution Context (PC/registers/SP); generalizes with a second program (Notes → PID 4517); silent climax; bridge = the HELD execution point (question only — the States/Switch/Resume story is a LATER increment, owner-gated). Gates green: smoke 438 · scope 3783 · layout 146 (`npm run smoke`), build PASS, headless-Chromium playthrough EN+VI+1100×700 with 0 page errors. Docs: `docs/chapters/topic-02-ch-02-process-execution/` (contract, delta audit, blueprint, AGENT_MEMORY).
  - Topic 01 Ch-02 (`topic-01-computer-architecture--ch-02-cpu-memory-wait` v1.0.0): Verification baseline — first chapter shipping executable pedagogy gates (scope boundary + layout proof + headless playthrough).
  - Chapter 03 (`chapter-03-across-the-internet` v1.0.0): Layout architecture & metrics derivation baseline.
  - Chapter 04 (`chapter-04-javascript-runtime` v2.0.0): Runtime storytelling baseline.
  - Viewer Shell v1.1.11: Global Canvas Navigation baseline.

---

## 2. Active Deferred Debt

1. **Chapter 01 Layout:** Un-audited (no metrics/layout proof table) — compliance debt, non-blocking. *Topic 01 Ch-02 now provides a reusable proof-table pattern (`scripts/layout-proof-topic01-ch02.ts`) that this debt can be repaid with.*
2. **State-Predictive Verification Runtime (Constitution §5.4):** Platform-wide deferred architecture debt (unimplemented interactive verification engine). All released chapters remain observational.
3. **Environment:** `node_modules` not persisted across sessions — environmental fact, non-blocking.
4. **Gate generalization (new, non-blocking):** the three gate scripts are currently chapter-scoped. Recommended platform pass: parameterize by chapter id so every chapter inherits them (logged in Topic 01 Ch-02 Phase X report §5).
5. **Missing Ch-02 gate scripts (found during Ch-03 Phase X, non-blocking):** `package.json` historically referenced `scripts/smoke-topic01-ch02.ts`, `scripts/scope-gate-topic01-ch02.ts`, `scripts/layout-proof-topic01-ch02.ts`, but those files are **absent from the tree** — §4's earlier smoke numbers cannot be re-executed as-is. `npm run smoke` now runs the Ch-03 gates; the Ch-02 gate set should be reconstructed from its documented reports (`docs/chapters/topic-01-ch-02-cpu-memory-wait/06`–`08`). Details: `docs/chapters/topic-01-ch-03-cache-hit-or-miss/08_PHASE_X_REPORT.md` §3.

---

## 3. Forbidden Actions

- **Do NOT** redesign Chapter 03 without an explicit new owner directive.
- **Do NOT** redesign Topic 01 Chapter 04 without an explicit new owner directive (production, gates green — freeze review pending).
- **Do NOT** modify frozen artifacts outside the formal Amendment Process (`docs/protocols/GOVERNANCE_AND_AMENDMENTS.md`).
- **Do NOT** reopen Chapter 02 (browser rendering) frozen design (chapter-level corrections only).
- **Do NOT** teach cache internals (tag, index, offset, cache line, mapping, associativity, replacement policy, write-through/back, dirty bit, prefetch) in Topic 01 Ch-02 — they are a declared Deferred Internal reserved for the next chapter, and the boundary is enforced by `scripts/scope-gate-topic01-ch02.ts`. *(That reservation is now fulfilled by Topic 01 Ch-03 — minus write policy, dirty bit and prefetch, which the Ch-03 owner spec bans too.)*
- **Do NOT** reopen Topic 01 Ch-03 (`cache-hit-or-miss`) frozen design without an explicit new owner directive; its boundary is enforced by `scripts/scope-gate-topic01-ch03.ts`.
- **Do NOT** pollute active state with historical commit logs (archive historical notes to `docs/state/CHANGELOG.md`).

---

## 4. Operational Status & Verification

All released chapters are green:
- **Build Status:** PASS (`npm run build`) — zero errors, zero warnings.
- **Smoke Suite:** PASS (`npm run smoke`) — for **Topic 01 Ch-03** (`topic-01-computer-architecture--ch-03-cache-hit-or-miss` v1.0.0):
  - Smoke (playthrough + determinism + integrity): **437 checks** — 26 beats × 7 scenes, bilingual full paint, 2× byte-identical paint logs (~200k calls each), storyboard↔narration sync.
  - Scope gate: **131 checks** — 12 forbidden topics absent (incl. write policy, MESI/coherence, virtual memory, TLB, prefetch, multi-core, any bit layout), 17 required concepts present, exact knowledge-reveal beats.
  - Layout proof: **428 checks** — every rectangle derives from named metrics + container functions; all docks contained and pairwise disjoint.
- *(Ch-02 smoke numbers were recorded here previously; the referenced scripts are absent from the tree — see debt #5.)*

*Historical revision logs and completed release freeze records are archived in [CHANGELOG.md](CHANGELOG.md).*
