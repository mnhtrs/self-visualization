---
guiding_question: "What is the historical record of past releases, pixel revisions, viewer iterations, and completed audits?"
primary_consumer: "Human Contributors, Maintainers"
depends_on: []
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# Cesvi Historical Changelog & Revision Log

This document archives the historical development log, release records, and pixel revision history across Cesvi development cycles. Active project status is maintained in [PROJECT_STATE.md](PROJECT_STATE.md).


---

---

### Topic 02 / Chapter 02 — Increment 1: Inside a Process — Memory, Resources & Execution Context (2026-08-15, owner directive)

- **Scope of the directive:** implement the *Inside a Process* increment of the canonical CH02 (`process-execution`) — Process anatomy (Address Space, Resources, Execution Context) — WITHOUT the later States / Context Switch / Resume story, which remains reserved for a later increment of the same chapter.
- **Implementation:** `src/content/topics/02-operating-systems/02-process-execution/` — 1 stable world scene (CH01 axis preserved: storage → OS → execution field → machine bay), 18 beats, EN+VI, deterministic `(beatIndex, beatFrac)` engine (LOK-08), CH01 visual grammar inherited (de-windowed cells, borderless OS band with earned row labels, grant-by-motion causality).
- **New causal grammar:** the GRANT sequence (need cue → request comet → OS manage row → grant arc → structure grows) — enacted for the private space, the heap growth, and both resource handles; code arrives as a copy stream while the Program pulses unchanged (coexistence, CH01 grammar).
- **Continuity:** same Photos program + PID grammar as CH01; T01 value glyphs (◆ ▲ ■ ●) carry data/registers; the gold execution point is the T01 golden-instruction continuity; canon C-05 protected (at most ONE advancing point chapter-wide, smoke-asserted); Process B (from a different program, Notes) proves the general Process model and leaves a HELD execution point as the bridge.
- **Gates:** `scripts/{smoke,scope-gate,layout-proof}-topic02-ch02.ts` wired into `npm run smoke` — smoke 438 (incl. byte-identical double-render and storage-painter immutability), scope 3783 (forbidden states/switch/pause/resume/scheduling/threads/VM strings EN+VI; exact term-reveal beats), layout 146 (containment/disjointness/anti-queue/bbox). Build PASS. Headless-Chromium playthroughs (EN 28 frames, VI + 1100×700 spot sets) — 0 page errors; evidence `review/shots-t02c02/`.
- **Docs:** `docs/chapters/topic-02-ch-02-process-execution/` — `00_CHAPTER_CONTRACT.md`, `01_DELTA_AUDIT.md`, `02_CHAPTER_PRODUCTION_[BLUEPRINT].md`, `AGENT_MEMORY.md`. `meta.ts` registers the chapter (auto-discovered by the loader glob; the synthetic coming-soon CH02 entry is superseded automatically). CH01 source untouched (FROZEN).
- **Status:** production candidate, gates green — awaiting owner review (Phase 9/10).

### Topic 02 — Curriculum Redesign: Merging Legacy CH02 + CH03 into 5 Canonical Chapters (2026-08-15, owner directive)

- **Trigger:** Topic 02 redesigned from 6 chapters to **5 canonical chapters** (`v0.4.0`) because legacy CH02 (*Inside a Process*) and legacy CH03 (*Running a Process*) form one continuous causal mental model (*Process Execution: Pause, Switch, Resume*).
- **`src/topics/definitions.ts`:** Updated Topic 02 chapter array to 5 canonical chapters:
  1. `process-from-program-to-execution` — Process: From Program to Managed Execution
  2. `process-execution` — Process Execution: Pause, Switch, Resume (merged old CH02 + old CH03)
  3. `cpu-scheduling` — CPU Scheduling: Who Runs Next? (formerly old CH04)
  4. `threads` — Thread: Multiple Paths Inside One Process (formerly old CH05)
  5. `multithreading` — Multithreading: Shared State & Race Conditions (formerly old CH06)
- **Knowledge Conservation:** Merged CH02 (`process-execution`) preserves 100% of legacy CH02 concepts (Address Space, Code/Data/Heap/Stack, Handles, PC/Registers) AND 100% of legacy CH03 concepts (State Machine, Events, Context Preservation, Context Switch, Resume).
- **Scheduling Boundary:** CH02 explicitly defers CPU Scheduling (Scheduler policies, Round Robin, Ready Queue ordering) to CH03 (`cpu-scheduling`).
- **`docs/curriculum/CURRICULUM_GUARDIAN_T02_DRAFT.md`:** Updated to v0.4.0; updated 5-chapter canonical structure, causal flow, boundary tables, terminology ownership, and 5-point test table.
- **`docs/curriculum/CURRICULUM_GRAPH.md`:** Updated §2.2 with 5-chapter sequence, intra-topic chapter table, and transition bridge questions.
- **`docs/topics/topic-02/`:** Updated all multi-chapter production baseline files (`00` to `04`) to reflect the canonical 5-chapter architecture.
- **Scope:** Curriculum metadata + documentation only. Zero chapter renderer code, beats, scenes, animations, or screenshots created or modified. CH01 remains FROZEN.

---

### Topic 02 — Curriculum Architecture Refactor: Processes & Threads (2026-08-13, owner directive)

- **Trigger:** The stale 4-chapter Topic 02 structure and the completely wrong `CURRICULUM_GUARDIAN_T02_DRAFT.md` (which described Browser Rendering, not OS execution) were replaced under explicit owner directive to establish the canonical 6-chapter Processes & Threads architecture before Chapter Production begins.
- **`src/topics/definitions.ts`:** The 4-chapter `topic-02-operating-systems` block (`what-happens-when-you-double-click`, `how-os-switches-processes`, `how-os-decides-which-runs`, `how-processes-talk-safely`) was **replaced** with exactly 6 canonical chapters:
  1. `process-from-program-to-execution` — Process: From Program to Managed Execution
  2. `inside-a-process` — Inside a Process: Memory, Resources & Execution Context
  3. `running-a-process` — Running a Process: State, Events & Context Switching
  4. `cpu-scheduling` — CPU Scheduling: Who Runs Next?
  5. `threads` — Thread: Multiple Paths Inside One Process
  6. `multithreading` — Multithreading: Many Threads, One Shared World
- Topic title updated to *Processes & Threads*; subtitle and centralQuestion updated to match the new identity.
- **`docs/curriculum/CURRICULUM_GUARDIAN_T02_DRAFT.md`:** Completely rewritten (v0.1.0 → v0.2.0). The old document described Browser Rendering (artifact of an earlier numbering system). The new document specifies the Processes & Threads curriculum: topic identity, topic mission, 6-chapter structure (central question, central mental model, scope, non-goals for each), canonical causal flow (Program → Process → Inside a Process → Execution States → CPU Scheduling → Thread → Multithreading → Topic 06), critical CH01/CH03/CH04 boundary table, CH05/CH06 boundary, Topic 06 synchronization handoff boundary, terminology ownership table, prerequisite/follow-up relationships, and the five-point test table.
- **`docs/curriculum/CURRICULUM_GRAPH.md`:** Added §2.2 Topic 02 (Processes & Threads) intra-topic section — 6-chapter sequence, prerequisite table, and causal motivation bridge questions for each chapter transition. Renamed the existing T01 §2.2/§2.3 intra-chapter contracts to §2.1.1/§2.1.2 (correct nesting). Annotated the stale legacy global chapter table as non-authoritative (pre-topic-restructure artifact).
- **Known implementation note recorded:** The pre-existing CH01 source previews Process State and Scheduling. This is a known boundary violation. The implementation is unchanged — it will be refactored during the Chapter Production phase for CH01.
- **Scope:** curriculum metadata + documentation only. No lesson content, narration, storyboard, beats, animation, renderer, or chapter implementation files created or modified. All 6 new chapters produce synthetic `coming-soon` entries via the chapter-loader.
- **Build:** PASS after `definitions.ts` edit (TypeScript types are structural; the new chapter objects satisfy the same `ChapterDef` shape).

### Topic 01 — Owner-directed Explanation Pass (2026-08-01, post-freeze, explanation-only)

- **Trigger:** learner question — the value glyphs (◆ ▲ ■ ●) were never named anywhere in Topic 01, and Ch-04's observation beats did not explain why the instruction kinds repeat.
- **T01/Ch-02 (first appearance of the glyphs):** beat `needs-value` now names ◆ as a value the program needs; beat `the-ladder` now names all four glyphs as data values. Narration-only; no other change to the frozen chapter. Storyboard `04_storyboard.json` re-synced.
- **T01/Ch-04:** beats b1–b4 name LOAD / ADD / STORE / SUB / CMP in one plain sentence each as they execute, and state why the steps repeat (the program is a long list; each repetition is one more row done); beats b8–b12 do the same for the floor scene (row 6 LOAD, machine never waits, first completion, one-in-one-out rhythm, row 19 ADD). The climax (b13) remains the only fully silent beat — the realisation stays the learner's own.
- **Slow-motion & real-speed pass (same day, second round):** learner question — the animation reads as slow while a real CPU is extraordinarily fast, so the speed gap was never named. Now: b5 states that a real program needs billions of steps to draw one screen, that we are watching in slow motion (billions of times slower), and that the real machine finishes ≈ 4 billion instructions/second (~1 billion per blink); b11 re-marks the rhythm as slowed down billions of times; b17 closes with the real-speed figure and the machine never stopping; the horizon counter now carries an on-canvas caption "≈ 4 billion / real second" (EN/VI) beneath the count. All narration-only plus one caption; timeline/ticks/visuals/layout untouched. Storyboard re-synced.
- **Speed-ramp pass (same day, third round):** learner feedback — the chapter *told* about 4 billion/s but never *showed* speed. The horizon epilogue (the endless final beat) now visibly accelerates in three stages: slow-motion pace (tick = 1.6 s, ~6 s), a ramp (tick shortens linearly to 40 ms over 5 s), and max speed (25 ticks/s on screen): the counter spins, the program list scrolls, the fetch trip races, the CPU pulses at tick rate. The counter caption tracks the stage ("slow motion…" → "speeding up…" → "still slowed down — real speed ≈ 4 billion/s", EN/VI), and the narration explains that every tick still completes exactly one instruction — only the tick's length changes. The mechanism is untouched; the canon (one instruction per tick) is preserved; this is a speed *illustration*, not a second climax (the single realization remains b13). Determinstic piecewise functions in story.ts (horizonTickAt / horizonTickLen / horizonStage); no beat-count or timeline changes.
- **Scope:** explanation only — no timeline, no tick windows, no visuals, no layout changed. Storyboard↔narration sync re-verified.
- **Text-overflow fix (same day):** the real-speed caption ("still slowed down — real speed ≈ 4 billion/s") overflowed the counter panel (214 px wide vs ~310 px text) — learner reported text spilling out of the panel. Fixed: the caption is now two short auto-shrinking lines inside the panel ("slow motion / speeding up… / still slow motion" + "real speed ≈ 4 billion/s"), and the Pipeline term-pill sub was shortened so it never needs truncation. Full text sweep of the chapter (entry, floor, pill, horizon frames; canvas edge scan) shows zero clipped/overflowing text.
- **Horizon protagonist fix (same day, fourth round):** learner feedback — the golden spark sat still in the final scene, so the epilogue felt frozen despite the counter/list moving. The engine gained a backward-compatible optional hook (`runtime.loopPosition`); the horizon protagonist now RUNS core → L1 → core, one loop per two ticks, at the chapter's own accelerating tick rate — at speed the spark visibly races with its trail stretching into a light ribbon — and the horizon road now carries three small instruction cards chasing each other (one new card every 2/3 tick), so the machine's rate is felt, not just told. Canon preserved: every tick still completes exactly one instruction; the spark is the flowing work, not a faster instruction (C-05). Not a second climax — the single realization remains b13. Browser-verified: the epilogue now shows motion in both stages (≈4k pixels/400 ms slow, spark visibly moving core↔L1 at speed; previously 0 pixels/400 ms slow).
- **Gates after the pass:** `npm run build` PASS; `npm run smoke` PASS — 348 + 48 + 90 checks.

## 1. Release Freeze Records

### CESVI Curriculum Constitution v1.0.0 (2026-08-01)
- **Status:** FROZEN · **Location:** `docs/curriculum/CURRICULUM_CONSTITUTION.md`
- **Content:** canonical mental model C-01…C-10 (immutable, from T01); curriculum dependency matrix (canon lifecycle + chapter graph, with unallocated planned-growth nodes); the single educational debt D0 with a 15-facet ledger (5 facets unallocated: hazards, branch prediction, superscalar, out-of-order, cache coherence); regression rules + fixed Canonical Regression Battery; extension doctrine (extend/specialize/apply legal, replace forbidden); boundary rules + per-topic tables (incl. TLB ≠ cache, multi-core as C-09 extension, GPU as second-kind system); permanent audit protocol (five proofs, curriculum gate between production phases 7 and 8); final constitution in 10 Articles; living annexes A–C.
- **Scale clause:** scale-invariant — Articles immutable at 40 or 300+ chapters; growth is annex growth.
- **Routing:** linked from `CURRICULUM_GRAPH.md` (supreme law), `README_FOR_AI.md` (chapter-production chain), `docs/README.md`, `PROJECT_STATE.md`.


### Topic 01 / Chapter 04: How does a CPU run billions of instructions per second? (`topic-01-computer-architecture--ch-04-instruction-throughput`)
- **Version:** 1.0.0 (2026-08-01) · **Status:** PRODUCTION — gates green, awaiting owner review before freeze.
- **Scope:** 3 scenes (`entry`, `floor`, `horizon`), 18 beats, ~115 s, one protagonist (the golden instruction — row 6 in the ramp, row 19 in the climax). Final chapter of Topic 01.
- **The chapter completes Topic 01:** one mental-model transformation — *"the CPU runs each instruction faster"* → *"every instruction still takes the same full five-station journey, but the CPU finishes one every tick because it never lets a station sit idle"*. Exactly ONE climax (b13, silent): the watched instruction crosses the floor in five ticks while five instructions complete — its own completion is the fifth pop of the rhythm. No Throughput/Latency text, no on-canvas questions, no concluding narration; the single term (Pipeline) lands in b15 after full observation.
- **Continuity:** opens on the whole assembled Topic-01 world (CPU + ladder + RAM + program + counter), reuses the Chapter-01 cycle (performed, never re-taught), the Chapter-02/03 ladder trips (fast familiar blinks) and the value-glyph language (◆ ▲ ■ ●); leaves the questions for Topics 02+ (scheduling, threads, processes, synchronization, coherence, multi-core) blooming visually, never in text.
- **Platform contribution:** the machine-clock story system (a global tick grid; every floor beat is an exact multiple of TICK so renderer fractions align with the tick rhythm); affirmative fullness predicate; the silent-beat convention (non-breaking space keeps the narration panel height); the horizon single-beat epilogue (avoids the inside-scene tag misfire).
- **Gates at production:** `npm run build` PASS; `npm run smoke` PASS — 482 checks (smoke 344 · scope 48 · layout 90). Headless-Chromium playthrough verified all key moments with zero page errors (report: `docs/chapters/topic-01-ch-04-instruction-throughput/07_QA_AUDIT.md`).
- **Artifacts:** `docs/chapters/topic-01-ch-04-instruction-throughput/` (00 journey definition, 01–05 cognitive artifacts, 06 layout proof, 07 QA audit, AGENT_MEMORY); gates `scripts/{smoke,scope-gate,layout-proof}-topic01-ch04.ts`; `package.json` smoke wired to the Ch-04 gates (the absent Ch-03 gate scripts remain platform debt #4/#5).


### Topic 01 / Chapter 03: How does a CPU cache determine whether a memory request becomes a Cache Hit or a Cache Miss? (`topic-01-computer-architecture--ch-03-cache-hit-or-miss`)
- **Release Version:** 1.0.0 (2026-07-28)
- **Status:** RELEASED (Gate-Coverage Baseline)
- **Scope:** 7 scenes (`entry`, `interior`, `mapping`, `lookup`, `miss`, `replace`, `replay`), 26 beats, ~185 s, one protagonist (a single memory request).
- **Curriculum change:** produced per the owner's Official Production Specification; takes slot 03, opening Chapter 02's declared Deferred Internal; the reserved throughput chapter moves to slot 04 (`CURRICULUM_GRAPH.md` v1.3.0).
- **Platform contribution:** dock-based pill layout (every on-canvas pill anchored to a derived, gate-provable dock); handoff windows as exported story constants; storyboard↔narration sync gate; RAM-block containment derived from its own grid.
- **Gates at freeze:** `npm run build` PASS; `npm run smoke` PASS — 996 checks (smoke 437 · scope 131 · layout 428).
- **Phase X amendments:** none required to constitution/pedagogy documents; one repository hygiene finding recorded (missing Ch-02 gate scripts → PROJECT_STATE debt #5).
- **Immutability Rule:** Reopen ONLY for factual error, implementation bug, architecture violation, or mandatory platform migration.

#### Production Fix Pass (2026-07-28, owner-directed, post-review)

- **Trigger:** the first black-box Production Educational Review for this chapter returned **REJECT** with five educational failures (report: `review/PRODUCTION_REVIEW_T01_CH03.md`). The owner issued the official Production Fix Pass with a surgical-only mandate (preserve chapter length, scene/concept ordering, camera language, visual language, narration style, pacing, production architecture).
- **R1 — Cache Miss now visually demonstrated (b17):** set 3 holds one FREE line (row 6; D3's residency at row 7 is retained from the b12 giant stream — enacted history, not asserted). The incoming Tag hovers between the set's lines and knocks: the free line's dashed slot brightens (nothing to compare — never a ✕ on air), the resident answers. The Index chip docks west of its set (it previously sat labeled inside cache lines — factual defect, R5).
- **R2 — Hit comparison fully legible (b15):** the incoming Tag hovers at scale 0.85 between both stored tags (previously it parked ON them); fail residue lingers so both compared Tags and both answers stay simultaneously visible; `me!`/`not me` are stem-pinned to their own chip (upper row answers above, lower row below) instead of floating near a neighbour.
- **R3 — LRU now matches enacted history (b22):** a use-touch micro-recall re-enacts the stream's own history (A2 touched again), then the last-used stamps (gold vs hollow) appear, the rule flashes the stale line and B2 leaves — previously the asserted marks contradicted the demonstrated stream order.
- **R4 — Set purpose demonstrated by the animation alone (b6):** the two same-marked cards are co-visible in flight, both leave visible ghost tokens standing in the SAME group (set-stripe markings), and the three other groups sink behind a veil — "a request only ever asks its own group" reads without narration.
- **R5 — factual inconsistencies corrected:** b5 counter holds the full fourteen (was an abandoned partial 6) and the counter→question handoff is a relay, not a cross-fade (gate intent preserved, expectation updated in `scripts/layout-proof-topic01-ch03.ts`); singular "1 check so far" grammar; FIFO badges / LRU stamps are bound to their line and depart with it (no inheritance by the incoming line); victim-exit labels follow the UI language; verdict/question timings in b20 follow the probes; tag chip no longer blips out in b19; b17 narrative now only confirms what is visibly enacted (`narration/beats.ts` + `04_storyboard.json` kept in sync by gate).
- **Gates after the pass:** `npm run build` PASS; `npm run smoke` PASS — 996 checks (smoke 437 · scope 131 · layout 428).
- **Self-review evidence:** fresh harness captures `review/shots/X_b*` + composed mute-test sheets `review/shots/Z_*`; report `review/FIX_PASS_T01_CH03.md`.

#### Post-Review Unclear-Point Verification (2026-07-28, owner-directed cross-check)

- **Trigger:** the owner asked for a careful re-check of the fix points the Final Freeze Review gripped on, under the same surgical-only mandate and review semantics (no narration/timing/scene changes; verdict before question; free vs occupied as two lanes; grounded cards; quiet bands).
- **Closed without code change (verified on fresh frames):** grounded cards at their Sets (b15/b20/b22/b23 — no floating residue in the north band, TB artifact confirmed gone everywhere); b20's verdict→question two-step already rendered in order; b17's free-slot pulse carries no ✕; b22's touch-before-answers order; b23's early fold leaves the serve path undisturbed.
- **Small deltas:** (a) verdict pills gained a per-beat second line — `Cache Miss / still has a free line` (b17) and `Cache Miss / every line said not me` (b20), VI in sync; (b) **continuity repair:** post-LRU occupancy now keeps G2 in row 5 through the finale (b23 was serving G2's word from B2's evicted line — same fact-family as the review's F-findings, caught by this pass's frame sweep); (c) gate sync: layout-proof now models the exact per-beat verdict pill rects (+4 checks), smoke +1 continuity assertion.
- **Gates:** `npm run build` PASS; `npm run smoke` PASS — 438 + 131 + 432 checks.
- **Report:** `review/FIX_VERIFICATION_T01_CH03.md` (evidence frames under `review/shots/`).
- **Status:** frozen v1.0.0 — verification closed; follow-up polish ideas recorded as non-blocking notes (serve-comet waypoint; whole-track VI typography audit).

#### MODE D — Final Production Gate (2026-07-28, adversarial pedagogical stress test)

- **Mandate:** black-box learner-experience audit (no code/architecture/documentation discussion); PASS only if all ten freeze conditions hold — one educational question, one protagonist, necessity-driven concepts, no taxonomy-first teaching, no unnecessary scene, mute-replay reconstruction, complete mental model, no cognitive overload spike, no unexplained transition, no memorization-only concept.
- **Verdict: PASS.** All adversarial attacks documented as survived; residual weaknesses recorded as non-blocking notes (fully-associative cost salience; FIFO/LRU hardware-cost asymmetry unshown; b24 hit-side recap boundary; b18/b19 merge debate retained).
- **Report:** `review/PRODUCTION_GATE_D_T01_CH03.md`. No code changes; gates unchanged (438 + 131 + 432, build PASS).

#### MODE E — Learner Simulation Gate (2026-07-28, final freeze authority)

- **Mandate:** faithful simulation of a first-time learner (no outside knowledge; explicit per-beat mental-model / questions / predictions / misconceptions / confidence log across all 26 beats), then the fixed battery: Prediction Test, Concept Acquisition Test (reasoning vs vocabulary, 17 concepts), Misconception Test (15 natural candidates, fate audited), Label Removal Test, Delayed Recall Test (30 min), Transfer Test (unseen request + return request), One-Sentence Test, Illusion of Understanding Test.
- **Verdict: PASS.** Learner builds one coherent model, all 17 concepts acquired via necessity (zero vocabulary-only), no major misconception survives, labels not load-bearing, delayed recall and transfer succeed with hesitations located exactly at declared scope edges. Watch-items recorded: fully-associative cost is told-not-felt; LRU recency-vs-frequency drift risk; LRU motive self-constructed; evicted-line fate unshown (out of scope); EN track simulated (VI typography audit already on the ledger).
- **Report:** `review/LEARNER_SIM_GATE_E_T01_CH03.md`. No code changes; gates unchanged (438 + 131 + 432, build PASS).

#### Owner-directed Residual Fixes (2026-07-29, post-freeze)

- **Trigger:** owner frame review before starting Ch-04 production. Two reported items, both fixed surgically (narration structure, beat order, layout metrics untouched).
- **F1 — caravan formation math (implementation bug, owner's screenshot):** `drawCaravan` anchored the four word cells to the flight `center` while the tag chip was drawn at the row's left-inner slot, so the word group flew one tag-offset (~half row width) east of its chip — two cells visibly hanging outside the L1 panel and never registering with the row's word-cell grid at dock. Fix: anchor every cell to the drawn tag position using the exact `wordC − tagC` row pitch — formation is grid-true at every flight fraction (verified frame-for-frame pre/post on b18, b21, b22: `review/shots/X_b22_pre_car*` vs `X_b22_post_car*`).
- **F2 — VI names for the three mappings (owner terminology directive):** VI narration now carries the translated names next to the locked English terms — Direct Mapping (ánh xạ trực tiếp), Set Associative Mapping (ánh xạ kết hợp theo tập hợp), Fully Associative Mapping (ánh xạ kết hợp toàn phần) — in beats b9/b11/b12, mirrored exactly into `04_storyboard.json` (§5 gate), plus short name-first VI subs on the term pills. All VI strings built programmatically and verified NFC codepoint-exact (U+1EF1 trực, U+1EE3 hợp — no horn-glyph corruption).
- **F3 — b12 morph-back double-card handover (owner-approved fix of the recorded observation):** at the giant experiment's tail (lin 0.92–1.0) the four clears were rendered by the generic eviction path, so the west-drift ghost's 0.14-lin fade overlapped the 0.95 home restore inside the same tag slots — row 5 read as mangled "CB2", row 7 as "DD3", and A2 appeared in two rows at once. Fix (two-file, ghost-grammar only): (a) `paintVictimFlights` now branches the tail clears (`oneGiantSet` events at/after `GIANT_RETURN[0]`) into an in-place dissolve completing at 0.96 — these chips were never rule-victims, so the west-drift flight and "gives up its slot" label no longer apply here (genuine evictions in b20/b21/b22 keep the taught victim grammar unchanged); (b) the home re-seat moved 0.95 → 0.97 in `OCC_EVENTS`, landing exactly as the brace morph settles — fade-out completes strictly before fade-in. Verified frame-for-frame pre/post (`review/shots/X_b12_pre_tail{925,955,97,99}.png` vs `X_b12_post_tail{925,945,965,975,99}.png`); beat-end state equals b13's start state, so the cut is seamless. No narration, storyboard, or layout-metric change.
- **Gates:** `npm run build` PASS; `npm run smoke` PASS — 438 + 131 + 432 checks (re-verified after F1+F2+F3).

### Topic 01 / Chapter 02: How does the CPU avoid waiting for memory? (`topic-01-computer-architecture--ch-02-cpu-memory-wait`)
- **Release Version:** 1.0.0 (2026-07-26)
- **Status:** RELEASED (Verification Baseline)
- **Scope:** 2 scenes (`gap`, `ladder`), 16 beats, ~79.8 s.
- **Curriculum change:** promoted into Topic 01 slot 02 by owner directive; the
  former slot-02 chapter *"How does a CPU execute a single instruction?"* was
  retired as a repeat of Chapter 01's Basic Instruction Cycle
  (`CURRICULUM_GRAPH.md` v1.2.0 §2.1).
- **Platform contribution:** first registration of `npm run smoke`, previously
  `N/A` repo-wide. Adds three reusable gate patterns (headless playthrough +
  scrub determinism, learner-facing scope boundary, layout proof table).
- **Phase X amendments:** `PEDAGOGICAL_SYSTEM.md` → v1.3.0 (§4.5 Single Source
  for Quantities, §4.6 Affirmative State Derivation);
  `PLATFORM_ENGINE.md` → v1.1.0 (§2.4 Derived Container Extent, §2.5 Evidence
  Board Persistence).
- **Immutability Rule:** Reopen ONLY for factual error, implementation bug,
  architecture violation, or mandatory platform migration.

### Chapter 03: How does data travel from Server to Browser? (`chapter-03-across-the-internet`)
- **Release Version:** 1.0.0 (2026-07-23)
- **Status:** FROZEN (Production Baseline)
- **Viewer Version:** 1.1.0 (Global Canvas Navigation compliant)
- **Immutability Rule:** Reopen ONLY for factual error, implementation bug, architecture violation, or mandatory platform migration.

---

## 2. Completed Work Log (Historical Record)

- **Governance Layer v1.1** Frozen
- **PEDAGOGICAL_PRINCIPLES.md v1.2.0** accepted and operationally wired as single authoritative pedagogy baseline.
- **Execution-drift memory hardening applied:** AUTHORING_WORKFLOW requires phase-local governing-doc reloads and Active Constraint Lists.
- **Repository boot architecture upgraded:** README_FOR_AI task-routed authority resolution.
- **Constitution v1.3.0 Frozen** (00–03).
- **Governance layer v1.3.0 Frozen**.
- **Chapter 01 Released** — How Computers Execute Programs.
- **Chapter 02 Frozen & Released** — How Browsers Render Websites (9-phase SOP, audit passed).
- **Chapter 02 Revisions (v1.1.0 to v1.4.4):**
  - v1.1.0: Senior Review Revision (10_REVIEW_REVISION_v1.1.md) — +1 beat (TCP connect), 24 beats, ~74.5s.
  - v1.2.0: Independent Architectural Review (11_ARCHITECTURAL_REVIEW_v1.2.md) — TCP demoted to unnamed foreshadow.
  - v1.3.0 to v1.3.15: Visual Layout & UI Revisions (12_ to 31_) — geometry-only fix packages (F17–F70).
  - v1.4.0 to v1.4.4: Narration & Vietnamese Naturalization (18_, 20_, 22_, 30_, 32_).
- **Viewer Shell Iterations (v1.1.0 to v1.1.11):**
  - v1.1.0 to v1.1.2: Social buttons, responsive controls, FA icon integration, panel head Home.
  - v1.1.3 to v1.1.11: Intro tag motion, green timeline synchronization, fast-forward thaw, inside parity rules.
- **Chapter 03 Redesign & Release:** `chapter-03-across-the-internet` (full 9-phase SOP + audit PASS).
- **Chapter 04 Rebuilt & Frozen:** `chapter-04-javascript-runtime` v2.0.0 (3 scenes / 18 beats).
- **Chapter 03 UI/Layout Revisions:** v1.0.2, v1.0.3, v1.0.4 metrics/layout derivation refactor.
- **Documentation Evolution Protocol Execution:** Layout Derivation Law & Connection Identity generalized into core rules.
- **Global Canvas Navigation Architecture Pass:** `CANVAS_NAVIGATION.md` v1.0.0 normative spec implemented in viewer.
