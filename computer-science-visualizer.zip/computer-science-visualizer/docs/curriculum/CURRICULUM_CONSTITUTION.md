---
guiding_question: "What immutable educational law governs every chapter of the CESVI curriculum — now, and at any future scale (40 or 300+ chapters)?"
primary_consumer: "Curriculum Architects, Chapter Authors, QA Auditors, AI Agents"
depends_on:
  - "docs/curriculum/CURRICULUM_GRAPH.md"
  - "docs/curriculum/CURRICULUM_GUARDIAN_T01_FINAL.md"
  - "docs/constitution/PHILOSOPHY.md"
  - "docs/pedagogy/PEDAGOGICAL_SYSTEM.md"
  - "docs/protocols/GOVERNANCE_AND_AMENDMENTS.md"
referenced_by:
  - "docs/README_FOR_AI.md"
  - "docs/state/PROJECT_STATE.md"
---

# CESVI Curriculum Constitution

**Status:** FROZEN · **Version:** 1.0.0 · **Date:** 2026-08-01
**Authority rank:** apex of the **Curriculum** layer of the CESVI authority
hierarchy (`PHILOSOPHY.md` §8: Constitution → Governance → Architecture →
**Curriculum** → Pipeline → Runtime). It operationalizes, at curriculum
scale: `PHILOSOPHY.md` §3 (No Unlearning), §5.3 (Black Box Rule),
`NARRATIVE_FRAMING.md` §13 (Knowledge Reveal), `PEDAGOGICAL_SYSTEM.md`
§3–4 (unit hierarchy, mental-model-before-terminology), and the Topic 01
Final Validation (`CURRICULUM_GUARDIAN_T01_FINAL.md`). Where any frozen
source above this document conflicts, the higher document wins.

**Validity clause:** this constitution is scale-invariant. Its Articles
(§8) are immutable and hold whether the curriculum has 40 or 300+
chapters. Its Annexes (A–C) are living: they grow by addition, never by
contradiction, and are normative for the current roadmap.

---

## 1 · Canonical Mental Model

The following ten propositions are **curriculum law**. Every learner owns
them permanently after Topic 01. Future topics may only extend, specialize,
or apply them — never replace them. Each canon carries a stable ID
(`C-01` … `C-10`) so every future chapter can declare which canons it
touches, mechanically.

| ID | Canon (law form) | Observable anchor in Topic 01 (keeps the canon alive) |
| :--- | :--- | :--- |
| **C-01** | A program is an ordered stream of instructions. | The program list; exactly one instruction issued per tick. |
| **C-02** | Every instruction follows the identical journey through all stages, in fixed order, taking the same time. | Golden row 6 (enter tick 1 → complete tick 5) and golden row 19 (enter tick 14 → complete tick 18): the same 5-tick journey, measured twice. |
| **C-03** | The journey is a pipeline: at any instant, many different instructions occupy different stages of the one shared pipeline. | Five cards across five stations; zero ticks ever hold two cards in one station. |
| **C-04** | In steady state the pipeline completes exactly one instruction per tick. | The completion counter pops once per tick once the floor is full. |
| **C-05** | The pipeline does not make an individual instruction faster. | Both golden journeys are 5 ticks; nothing in Topic 01 ever shows a shortened journey. |
| **C-06** | The machine's rate is its fullness: idle stages are the only waste. | One card with four empty stations (slow) → full floor (one per tick). |
| **C-07** | The memory hierarchy exists to supply data to the continuous flow; cache is the data supplier of the execution system, not a standalone optimization. | The Memory stage of every instruction; data trips to the nearest cache level every tick. |
| **C-08** | CPU performance is completed work over time — a property of the entire execution system, not of any single instruction or component. | The single completion counter (5 → 6 → 31 → forever). |
| **C-09** | There is exactly one execution system (per core), and work enters it continuously. | One CPU, one core, one program list, one cache ladder; entry never stops (endless loop). |
| **C-10** | Entry into the system is decided by something outside the pipeline. | The issuing mechanism is never examined — the open gate. This canon *is* the official debt (§3). |

Definition of terms: an **execution system** is the pipeline plus its data
supply (cache hierarchy) plus its entry gate, viewed as one causal whole.
A **tick** is the machine's fundamental working interval; all steady-state
claims are tick-claims.

---

## 2 · Curriculum Dependency Matrix

The matrix has two levels: canon lifecycle (2.1) and chapter graph (2.2).
Its purpose is to prevent redundancy (a canon re-taught) and missing
prerequisites (a chapter depending on a canon that has not been
introduced).

### 2.1 Canon lifecycle

| Canon | Introduced | First extended by | Ultimately required by |
| :--- | :--- | :--- | :--- |
| C-01 | T01/Ch-01 (reaffirmed T01/Ch-04) | T07/1 (source → instructions) | Every topic that runs programs |
| C-02 | T01/Ch-01 (completed T01/Ch-04) | T02/2 (switching must preserve the journey) | OS, compilers, performance, embedded |
| C-03 | T01/Ch-04 | Pipeline hazards (fullness breaks); superscalar (wider entry) | T06, modern CPU, performance |
| C-04 | T01/Ch-04 | T07/2 (compiler shapes the flow); T13/2 (deadline rates) | OS scheduling, performance |
| C-05 | T01/Ch-04 | Superscalar / OoO (same journey, different entry) | Performance, compilers |
| C-06 | T01/Ch-04 | Pipeline hazards (why fullness fails); branch prediction (keep the stream full) | Modern CPU, performance |
| C-07 | T01/Ch-02, reinterpreted T01/Ch-04 | Cache coherence (many suppliers); T05/3 (translation — analogous principle, different object: TLB ≠ cache) | Memory systems, multi-core |
| C-08 | T01/Ch-04 | T07/2; T13/2 (feasibility under deadlines) | Performance engineering everywhere |
| C-09 | T01/Ch-04 | T06/1 (many systems); T12/2 (second-kind system: GPU) | Concurrency, distributed |
| C-10 | T01/Ch-04 (as the open question) | T02/1–3; T13/2 (resolution begins) | OS, scheduling, real-time |

### 2.2 Chapter dependency graph (current roadmap, 40 remaining chapters)

```
T01 (canonical base)
 ├─→ T02 OS ──→ T06 Concurrency ──→ T09 Databases
 │                  └──────────────→ T10 Distributed
 ├─→ T05 Memory ──→ T11 Security
 ├─→ T07 Compilers
 ├─→ T03 Networking ──→ T04 Web Browser
 ├─→ T12 Graphics
 ├─→ T13 Embedded ──→ T14 IoT
 └─→ (unallocated planned growth: pipeline hazards · branch prediction ·
      superscalar · out-of-order · cache coherence — see §3, facet status)
T15 AI ← T02, T06, T07, T10 (builds on OS / distributed / performance)
```

**Unallocated planned nodes** (hazards, branch prediction, superscalar,
out-of-order, cache coherence) have no home yet. Each must be allocated —
as a T01 extension or a T06-family chapter — and pass the five-point test
(§5.4) before production. Allocating them is a roadmap task; it does not
touch any frozen chapter.

### 2.3 Matrix rules

- **M-1** A chapter's prerequisites are the closure of its declared entry
  models through this graph. Every entry model must already exist.
- **M-2** No canon may be re-introduced as new knowledge. A chapter may
  *reference* an introduced canon; re-explaining it is redundancy
  (violates `PEDAGOGICAL_SYSTEM` §3: one transformation per chapter).
- **M-3** No canon may remain unextended for more than three topics after
  its introduction without a declared reason in the matrix annex.
- **M-4** Matrix amendments are annex updates (addition-only); they never
  alter the Articles.

---

## 3 · Educational Debt Graph

The curriculum carries exactly **one** educational debt forward from
Topic 01. Every future chapter resolves exactly one facet of it. Unrelated
curiosity is prohibited.

**The debt (D0):**

> *"What determines which work enters this continuously-running execution
> system, and what happens when multiple pieces of work compete for it?"*
> (VI: *"Cái gì quyết định công việc nào đi vào hệ thống thực thi đang
> chạy liên tục này, và điều gì xảy ra khi nhiều công việc tranh giành
> nó?"*)

D0 has two axes; every facet is one leaf of one axis:

```
D0 — entry into, and competition within, the continuously-running execution system
 ├─ AXIS I · ENTRY (what enters next)
 │   ├─ F1  ownership of the system        → T02/1            (allocated)
 │   ├─ F2  ordering of entry              → T02/3, T13/2      (allocated)
 │   └─ F3  changing work without stopping → T02/2            (allocated)
 ├─ AXIS II · COMPETITION (what happens when work competes)
 │   ├─ F4  work multiplies (streams)      → T02 (processes), T06 (threads)   (allocated)
 │   ├─ F5  software data races            → T06/2            (allocated)
 │   ├─ F6  mutual exclusion               → T06/3            (allocated)
 │   ├─ F7  deadlock / starvation          → T06/4, T09/3     (allocated)
 │   ├─ F8  hardware flow breaks           → hazards          (unallocated)
 │   ├─ F9  uncertain future work          → branch prediction (unallocated)
 │   ├─ F10 entry widening                 → superscalar      (unallocated)
 │   ├─ F11 bypassing blocked work         → out-of-order     (unallocated)
 │   └─ F12 memory contention              → T05/3            (allocated)
 └─ AXIS III · SYSTEM MULTIPLICATION (the system itself multiplies)
     ├─ F13 many systems                   → T06/1, T12/2     (allocated)
     ├─ F14 supplier consistency           → cache coherence  (unallocated)
     └─ F15 cross-system competition       → T10              (allocated)
```

**Debt rules**

- **D-1** One facet per chapter. A chapter resolving two facets is a debt
  violation (scope leakage of the question itself).
- **D-2** One chapter per facet. Two chapters resolving the same facet is
  redundancy.
- **D-3** Ancestors first. A facet may be resolved only when its
  prerequisites exist (e.g., F5–F7 require F4; F14 requires F13).
- **D-4** No new debt. A chapter may open new questions only as declared
  Deferred Internals whose resolution facet is already registered in the
  ledger (Annex B) and scheduled to a later chapter.
- **D-5** The ledger is authoritative. Annex B is the single registry of
  facet → chapter; journey definitions must cite their facet.

---

## 4 · Curriculum Regression Rules

Whenever **any** future chapter freezes, the curriculum must prove that
learners can still explain every canonical model correctly. No future
chapter may introduce a misconception requiring unlearning.

- **R-1 Canon integrity (battery).** Every freeze runs the Canonical
  Regression Battery (Annex A): ten questions, one per canon, answered by
  a fresh learner who completed the chapter. All ten must be answerable in
  the learner's own words with the canon intact. A retraction of any canon
  fails the chapter.
- **R-2 Extension declaration.** Every chapter's `01_delta.json` must
  enumerate the canons it touches and classify each as extend / specialize
  / apply (§5). A chapter that cannot classify a canon it touches has
  silently replaced it — reject.
- **R-3 Transfer proof.** Every new mechanism must be exercised against at
  least two unseen scenarios (situations that never appeared in the
  chapter). If the learner reasons with the old model in either scenario,
  the mechanism was not integrated — fix or fail.
- **R-4 Debt ledger audit.** The chapter must resolve exactly its declared
  facet (D-1, D-2) and introduce no unregistered question (D-4).
- **R-5 Terminology ownership.** Every term the chapter introduces must
  belong to it (Annex C). A term introduced before its owning chapter is a
  defect.
- **R-6 Prerequisite chain.** All entry models must exist and be reachable
  through the dependency matrix (M-1). A broken chain fails the chapter.

The battery is a fixed instrument: it does not change between chapters, so
results are comparable across the whole curriculum.

---

## 5 · Curriculum Extension Rules

Four operations are defined on the canonical model. Exactly three are
legal.

| Operation | Definition | Formal test | Example |
| :--- | :--- | :--- | :--- |
| **Extend** | A new mechanism that presupposes a canon and enlarges its domain; the canon remains literally true as a special case. | "The canon is a special case of the new model." | Scheduling (C-10): the gate gets a decision layer; "work enters" remains true. |
| **Specialize** | A new model that constrains a canon to a subset of its domain. | "The new model is the canon plus an added constraint." | Deadlines (T13/2) specialize F2; an embedded machine (T13/1) is C-09 unchanged in a small body. |
| **Apply** | Using a canon as infrastructure in a parallel domain, without deriving a new mechanism from it. | "The canon is used, not modified." | Networking uses "bytes in RAM, processed by the CPU" (C-01/C-02); databases use synchronization (F6) as tooling. |
| **Replace** | Forbidden. A model that requires the learner to retract or qualify any canon. | "To accept the new model, the learner must deny or qualify a canon." | Any chapter that redefines cache (denies C-07), denies the single pipeline (denies C-03), or speeds up individual instructions (denies C-05). |

### 5.4 The five-point test (mandatory, per chapter)

1. Which exact canon(s) does it build upon?
2. Does it extend, specialize, or apply — with the formal test passed?
3. Does the learner need to forget anything from Topic 01? (If yes → fail.)
4. Which single facet of D0 does it resolve? (If none → probably redundant.)
5. Can it stand without re-explaining the instruction cycle, the memory
   hierarchy, cache lookup, or the pipeline? (If not → broken prerequisite
   chain.)

---

## 6 · Curriculum Boundary Rules

### 6.1 General rules

- **B-1 Ownership.** Every term and mechanism has exactly one owning
  chapter (Annex C). Its first appearance is there — never earlier.
- **B-2 Behavior before terminology.** A mechanism's *behavior* may appear
  earlier only as a declared Deferred Internal (`PHILOSOPHY` §5.3) naming
  its opening chapter; its *terminology* appears only at ownership.
- **B-3 Three-column declaration.** Every journey definition must declare:
  **assumed** (models the learner already owns), **may newly appear**
  (owned here), **must never appear yet** (owned elsewhere or unallocated).
- **B-4 Scope leakage.** Any element from a topic more than one position
  ahead in the dependency graph is leakage. Leakage is a defect.
- **B-5 Deferred Internal discipline.** A black box may be opened only by
  its scheduled chapter — never early, never late, never by a bystander.

### 6.2 Topic boundary tables (current roadmap)

| Topic | Must already be assumed (from) | May newly appear | Must never appear yet |
| :--- | :--- | :--- | :--- |
| T02 OS | C-01, C-02, C-06, C-09, C-10 (T01) | process, program-as-work, switching, queues, ownership | threads (T06), scheduler internals beyond T02/3's own scope, virtual memory internals (T05) |
| T03 Networking | C-01/C-02 (bytes processed by CPU), RAM as infrastructure | packets, routing, TCP semantics | any new execution-system model |
| T04 Web Browser | C-01, C-02, C-08; T03 | browser engine, page pipeline | OS scheduling details beyond T02's scope |
| T05 Memory | C-02, C-07; T02 processes | address space, allocation, translation | **TLB must not be called a cache** (C-07 intact — it is a translation lookup); coherence (unallocated) |
| T06 Concurrency | C-03, C-09 (one system), C-10; T02 | threads, races, synchronization, deadlock, **multi-core as an extension of C-09** ("many systems instead of one") | coherence mechanics (unallocated); hazards (unallocated) |
| T07 Compilers | C-01, C-02, C-04, C-05, C-06, C-08 | instruction selection, code generation, optimization as *flow shaping* | superscalar/OoO internals (unallocated) |
| T08 Storage | C-07 (hierarchy principle, parallel domain) | blocks, files, durability | **storage hierarchy must not be presented as redefining cache** (C-07) |
| T09 Databases | T06 synchronization (F6) | transactions, isolation, write conflict | coherence (hardware facet) |
| T10 Distributed | T06 (many systems), T03 | consensus, replication, failure | — |
| T11 Security | T02, T05/3 (protection) | principals, isolation, attestation | — |
| T12 Graphics | C-01, C-02 (CPU math) | raster pipeline; **GPU as a second-kind execution system — an extension of C-09's possibility space, never a denial of C-03** | coherence |
| T13 Embedded | C-09 (one system, small), C-10 | deadlines (specialization of F2) | — |
| T14 IoT | T03, T13 | sensing, actuation, edge | — |
| T15 AI | T02, T06, T07, T10 | scaling, serving, inference systems | — |

---

## 7 · Curriculum Audit Protocol

Every chapter, before freezing, must prove five things. This protocol is
permanent; it applies to all 40 current chapters and any future chapter.

### 7.1 The five proofs

1. **Prerequisite continuity** — every entry model exists and is reachable
   (R-6, M-1). Evidence: dependency-matrix walk in the journey definition.
2. **Mental-model continuity** — the chapter's transformation is an
   extend/specialize/apply of the canons it touches (R-2, §5.4). Evidence:
   delta.json classification + five-point test.
3. **Educational debt continuity** — exactly one registered facet resolved,
   no new debt (R-4, D-1…D-5). Evidence: ledger citation (Annex B).
4. **Transfer ability** — the new mechanism survives ≥2 unseen scenarios
   (R-3). Evidence: transfer-test record in the QA audit.
5. **Future-topic compatibility** — boundary table declared and respected;
   no owned term stolen; no unallocated mechanism opened (B-1…B-5, R-5).
   Evidence: boundary table + term check against Annex C.

### 7.2 Procedure

- The journey definition (`00_JOURNEY_DEFINITION.md`) carries a
  **curriculum compliance header**: canons touched (C-IDs), extension
  classification, facet resolved (F-ID), boundary table, owned terms.
- The chapter's QA gates (existing `03_QA_VERIFICATION.md` set) are
  augmented by: the Canonical Regression Battery (Annex A), the term
  ownership check (Annex C), and the debt ledger check (Annex B) — each
  machine-checkable in the scope-gate script.
- The curriculum gate sits between production Phase 7 (self review) and
  Phase 8 (freeze) of `02_PRODUCTION_LIFECYCLE.md`. A chapter may not
  freeze without a passing curriculum gate.
- **Sign-off.** Freeze requires the curriculum guardian's sign-off
  (the adversarial protocol applied to T01/Ch-04 is the standing
  precedent). Any reviewer may invoke the gate; evidence beats opinion.

---

## 8 · The Curriculum Constitution

> *Educational continuity above everything. Evidence over opinion. One
> story, one debt, one learner.*

**Preamble.** CESVI teaches computation as one continuous causal story.
Topic 01 established the canonical execution model; every later chapter
grows from it. This constitution makes that growth lawful: nothing may
require the learner to unlearn, and every new mechanism must earn its place
by extending what the learner already understands.

- **Article I — The Canon.** The propositions C-01…C-10 (§1) are canonical
  law. They were introduced by Topic 01 and are immutable. No chapter may
  contradict, qualify, or silently bypass a canon.
- **Article II — The Debt.** The curriculum carries exactly one educational
  debt, D0 (§3). Every chapter resolves exactly one registered facet of
  D0. Creating unrelated curiosity, or resolving two facets in one
  chapter, is a violation.
- **Article III — Extension Doctrine.** Extending, specializing, and
  applying the canon are the only legal operations (§5). Replacing a canon
  is forbidden; a chapter that requires any retraction fails.
- **Article IV — Terminology Ownership.** Every term belongs to exactly one
  chapter, where it first appears (§6, Annex C). Behavior may appear
  earlier only as a declared Deferred Internal with a scheduled opener.
- **Article V — No Unlearning.** No chapter may require the learner to
  forget, revise, or distrust anything previously taught. This is
  `PHILOSOPHY.md` §3 operationalized at curriculum scale.
- **Article VI — One Transformation.** Each chapter completes exactly one
  mental-model transformation and resolves exactly one debt facet. A
  chapter that transforms nothing, or transforms two things, is rejected.
- **Article VII — Boundaries.** Every chapter declares what it assumes,
  what it introduces, and what it must not touch (§6). Scope leakage is a
  defect and blocks freeze.
- **Article VIII — Regression.** The Canonical Regression Battery (Annex
  A) is mandatory at every freeze. A chapter that breaks a canon — even
  indirectly — fails and must be revised before release.
- **Article IX — Amendment.** This constitution is amended only through the
  Governance Amendment Process (`GOVERNANCE_AND_AMENDMENTS.md`). Changing
  a canon requires an owner directive and a full regression of every
  released chapter. Annexes may grow by addition under the same process
  with a lighter path: an annex entry that contradicts an Article is void.
- **Article X — Validity and Scale.** This constitution is scale-invariant.
  Its Articles hold at 40 chapters and at 300+. Growth is annex growth:
  new chapters, new facets, new terms, new boundary rows — never new laws
  without amendment. When in doubt, the interpretation that preserves the
  canon wins.

---

## Annex A — Canonical Regression Battery (fixed instrument)

One question per canon. Asked of a fresh learner after any chapter, in
their language, answered in their own words. A canon is intact if the
answer preserves its proposition; a retraction fails the chapter.

| Q | Question (learner-facing) | Canon |
| :--- | :--- | :--- |
| A1 | What is a program, from the machine's point of view? | C-01 |
| A2 | Does every instruction take the same time? What did you see that proves it? | C-02 |
| A3 | Where are several instructions at the same moment? | C-03 |
| A4 | When the machine is full, how many instructions finish per tick? | C-04 |
| A5 | Does the machine make a single instruction faster? | C-05 |
| A6 | What makes the machine fast or slow? | C-06 |
| A7 | Why does the machine need the cache levels? | C-07 |
| A8 | What does the completed-work counter measure? | C-08 |
| A9 | How many execution systems does a CPU have, and does work ever stop entering? | C-09 |
| A10 | Who decides which instruction enters the machine next? | C-10 (the debt) |

## Annex B — Educational Debt Ledger (living)

| Facet | Axis | Resolving chapter(s) | Status |
| :--- | :--- | :--- | :--- |
| F1 ownership | I | T02/1 | allocated |
| F2 ordering | I | T02/3, T13/2 | allocated |
| F3 switching | I | T02/2 | allocated |
| F4 streams | II | T02 (processes), T06 (threads) | allocated |
| F5 races | II | T06/2 | allocated |
| F6 mutual exclusion | II | T06/3 | allocated |
| F7 deadlock/starvation | II | T06/4, T09/3 | allocated |
| F8 hardware flow breaks | II | pipeline hazards | **unallocated** |
| F9 uncertain future work | II | branch prediction | **unallocated** |
| F10 entry widening | II | superscalar | **unallocated** |
| F11 bypassing blocked work | II | out-of-order | **unallocated** |
| F12 memory contention | II | T05/3 | allocated |
| F13 many systems | III | T06/1, T12/2 | allocated |
| F14 supplier consistency | III | cache coherence | **unallocated** |
| F15 cross-system competition | III | T10 | allocated |

## Annex C — Term Ownership Registry (current; living)

| Term | Owning chapter (first appearance) |
| :--- | :--- |
| Fetch / Decode / Execute / Write Back | T01/Ch-01 |
| Cache, L1/L2/L3, Hit, Miss, Cache Line, Set, Index, Tag, Word Offset, Mapping (Direct/Set Associative/Fully Associative), FIFO, LRU, Cache Line Loading, Replacement, Cache Lookup | T01/Ch-02–03 |
| Memory stage, Pipeline | T01/Ch-04 |
| process | T02 |
| scheduler / scheduling | T02/3 |
| context switch | T02/2 |
| thread | T06 |
| parallel / parallelism | T06/1 |
| virtual memory, address space, **TLB (as translation lookup — never "cache")** | T05/3 |
| multi-core | T06/1 |
| GPU pipeline (as second-kind system) | T12/2 |
| hazard / stall / bubble | *unallocated (hazards)* |
| branch prediction | *unallocated* |
| superscalar | *unallocated* |
| out-of-order | *unallocated* |
| cache coherence | *unallocated (F14)* |

Terms marked *unallocated* must not appear in any released chapter until
their owning chapter is produced and this registry is updated.
