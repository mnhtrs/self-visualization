---
guiding_question: "What is the topic-level curriculum contract, chapter boundaries, causal flow, and terminology ownership for Topic 02 — Processes & Threads?"
primary_consumer: "Content Authors, Curriculum Architects, AI Agents"
authority_level: "Draft Specification / Non-Frozen Operational Contract"
depends_on:
  - "docs/curriculum/CURRICULUM_CONSTITUTION.md"
  - "docs/curriculum/CURRICULUM_GRAPH.md"
  - "docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md"
  - "docs/topics/topic-02/00_TOPIC_02_PRODUCTION_BASELINE.md"
referenced_by:
  - "docs/curriculum/CURRICULUM_GRAPH.md"
  - "docs/state/PROJECT_STATE.md"
  - "docs/topics/topic-02/00_TOPIC_02_PRODUCTION_BASELINE.md"
---

# Curriculum Guardian Specification: Topic 02 — Processes & Threads

**Topic ID:** `topic-02-operating-systems`  
**Status:** Draft Specification (Non-Frozen)  
**Version:** 0.4.0  
**Date:** 2026-08-15  
**Authority:** Derived topic-level operational specification extending [`CURRICULUM_CONSTITUTION.md`](CURRICULUM_CONSTITUTION.md) and anchored directly to [`CURRICULUM_GRAPH.md`](CURRICULUM_GRAPH.md). Operationalized by the [`Topic 02 Production Baseline`](../topics/topic-02/00_TOPIC_02_PRODUCTION_BASELINE.md).

> **Amendment record:** v0.4.0 redesigns Topic 02 from 6 chapters to 5 canonical chapters, merging legacy CH02 + CH03 into new CH02 (`process-execution`), and incorporates the Topic 02 Multi-Chapter Production Baseline (`docs/topics/topic-02/`), encoding Chapter 01 frozen lessons into reusable defaults for CH02–CH05.

---

## 1. Governance & Deference Header

* **Supreme Curriculum Law:** [`CURRICULUM_CONSTITUTION.md`](CURRICULUM_CONSTITUTION.md) (Canons C-01…C-10)
* **Macro Curriculum Graph Baseline:** [`CURRICULUM_GRAPH.md`](CURRICULUM_GRAPH.md) §2.2 (Topic 02 intra-topic sequence)
* **Topic Production Baseline & Inheritance Protocol:** [`00_TOPIC_02_PRODUCTION_BASELINE.md`](../topics/topic-02/00_TOPIC_02_PRODUCTION_BASELINE.md) (Authoritative multi-chapter baseline, visual contract, and fast workflow)
* **Deference Rule:** This specification operationalizes Topic 02 boundaries. It cannot override supreme curriculum laws or modify frozen inter-chapter continuity contracts.
* **Pedagogical Law (CESVI):** One Chapter = One Major Concept = One Mental Model Transformation. Chapters are not organized as OS taxonomy; each exists because it transforms one mental model that the previous chapter leaves open.

---

## 2. Topic Identity

* **Topic Title:** Processes & Threads
* **Topic Subtitle (EN):** How the OS creates, runs, and manages execution
* **Topic Subtitle (VI):** OS tạo, chạy và quản lý thực thi như thế nào
* **Central Question:**
  > How does the OS turn programs into managed execution, and how does that execution evolve from processes to threads?
* **Topic Scope:** Topic 02 builds the mental model of the OS execution model — how the OS creates Processes, how those Processes run over time, how the OS allocates CPU time among them, and how Threads enable multiple execution paths inside a single Process. This is NOT a general Operating Systems taxonomy. Memory management internals, I/O subsystems, file systems, and synchronization implementation are out of scope.

---

## 3. Topic Mission & Macro Continuity

* **Topic Mission:** Transform the learner's mental model from *"programs run as a single undivided stream"* to *"the OS creates independent managed execution instances (Processes), each with its own identity and resources, whose execution states change in response to events, whose CPU access is arbitrated by a scheduler, and which can be subdivided into concurrent Threads that share state — introducing new correctness problems."*

* **Upstream Entry Anchor:**
  * **From Topic 01 (Computer Architecture):** The learner holds the canonical T01 execution model: a program is an ordered stream of instructions; the CPU pipeline continuously executes instructions; cache is the data supplier; the entry gate (C-10) is the declared educational debt — *"something outside the pipeline decides which work enters."* Topic 02 is the direct resolution of that debt.
  * **Binding condition (from `CURRICULUM_GUARDIAN_T01_FINAL.md` §5):** T02/CH01 must NOT re-teach program loading. Begin from the T01 exit state: the program is already in RAM, the CPU is already executing it.

* **Downstream Exit Anchor (→ Topic 06):**
  * Topic 02 terminates at the recognition that multiple Threads sharing mutable state create a coordination problem. It must NOT teach the solution — that is Topic 06's territory. See §9 (Topic 06 Boundary).

---

## 4. Step 0 Learner State Baseline

1. **Active Mental Model:** The CPU continuously executes instructions one at a time through the pipeline; the entry gate (C-10) is the open educational debt — something decides which work enters, but it has not been shown yet.
2. **Resident Visual Metaphors:** `CPU.color`: `#fb923c`, `RAM.color`: `#a78bfa` (from Topic 01).
3. **Misconception Inventory:**
   * *"A program and a process are the same thing."*
   * *"The CPU is 100% dedicated to my program while it runs."*
   * *"Multithreading automatically means faster execution."*
4. **Cognitive Replay Trigger (CH01):** Re-enter the T01 exit state — the pipeline that continuously executes instructions — and immediately pose: *"But what is the OS actually managing when you launch a program?"*

---

## 5. Canonical Five-Chapter Structure

Topic 02 has **exactly 5 chapters**. Each chapter is defined by one central question that its central mental model answers.

---

### CH01 — Process: From Program to Managed Execution

| Field | Content |
| :--- | :--- |
| **Slug** | `process-from-program-to-execution` |
| **Order** | 1 |
| **Central Question** | What does the OS actually create when you launch a program? |
| **Central Mental Model** | A Program is not a Process. A Process is a managed execution instance created and maintained by the OS. |

**Scope — the learner discovers:**

```
Program
   ↓ launch
OS
   ↓
Process
   ↓
Identity (PID)
   ↓
Lifetime
   ↓
Multiple Processes
```

Covered concepts: Program ≠ Process distinction; the OS as creator/manager of Processes; Process identity; PID; Process lifetime; one Program spawning multiple independent Process instances.

**Explicit Non-Goals (CH01):**

| Concept | Reserved for |
| :--- | :--- |
| Address Space / Execution Context | CH02 |
| Ready / Running / Waiting state machine | CH02 |
| Context switching | CH02 |
| Scheduling policies & Ready Queue | CH03 |
| Threads | CH04 |

---

### CH02 — Process Execution: Pause, Switch, Resume

| Field | Content |
| :--- | :--- |
| **Slug** | `process-execution` |
| **Order** | 2 |
| **Central Question** | How can the OS manage a Process as it runs, stops, and resumes? / Làm thế nào OS có thể quản lý một Process xuyên suốt quá trình nó chạy, dừng và chạy lại? |
| **Central Mental Model** | A Process is an OS-managed execution instance with an execution environment (Address Space, Resources) and Execution Context (PC, Registers). It does not execute continuously; state changes in response to events (Running, Ready, Waiting, Terminated). When execution stops, the OS preserves its context, switches CPU execution to another Process, and later resumes the Process from its preserved execution state. |

**Scope — the learner discovers:**

```
PROCESS
├── Identity (PID)
├── Address Space (Code, Data, Heap, Stack)
├── Resources (Files, Handles)
└── Execution Context (PC, Registers, Stack Pointer)
        │
        ↓
   execution has state (Running, Ready, Waiting, Terminated)
        │
   events cause state transitions
        │
   execution can be interrupted (stops running without disappearing)
        │
   context preservation (OS saves execution context)
        │
   CPU switches to another Process (Context Switch)
        │
   original Process resumes from preserved context
```

Covered concepts: Address Space (Code, Data, Heap, Stack); Resources and handles; Execution Context (Program Counter, CPU Registers, Stack Pointer); Process Execution States (Running, Ready, Waiting/Blocked, Terminated); State transitions and event triggers; Context preservation; Context Switch; Resuming execution continuity.

**Knowledge Conservation Rule:** CH02 absorbs 100% of legacy CH02 (*Inside a Process*) and legacy CH03 (*Running a Process*). No concepts are deleted.

**Explicit Non-Goals (CH02):**

| Concept | Reserved for |
| :--- | :--- |
| Which policy decides who runs next (Scheduler) | CH03 |
| Ready Queue ordering & scheduling algorithms (FCFS, Round Robin, Time Slice) | CH03 |
| Virtual memory implementation (Page tables, TLB) | Topic 05 (Memory Systems) |
| Thread-specific context & multithreading | CH04 + CH05 |

---

### CH03 — CPU Scheduling: Who Runs Next?

| Field | Content |
| :--- | :--- |
| **Slug** | `cpu-scheduling` |
| **Order** | 3 |
| **Central Question** | How does the OS decide which Process gets the CPU next? |
| **Central Mental Model** | CPU execution time is limited, so the OS must decide how runnable Processes receive execution opportunities according to a scheduling policy. |

**Scope — the learner discovers:**

```
Process A ─┐
Process B ─┼──→ Ready Queue
Process C ─┘
                ↓
            Scheduler
                ↓
        Scheduling Decision
                ↓
               CPU
```

Covered concepts: Ready Queue; Scheduler; scheduling decision; time slice; preemption; FCFS; Round Robin; Priority; responsiveness vs. throughput vs. waiting time trade-offs.

**Algorithms are concrete manifestations of the scheduling problem, not a taxonomy to memorize.** The chapter's goal is to make the learner understand *why* a scheduling policy is necessary, not to enumerate algorithms.

**Explicit Non-Goals (CH03):**

| Concept | Reserved for |
| :--- | :--- |
| Thread scheduling | Topic 06 |
| Multicore scheduling | Topic 06 |
| Real-time scheduling | Topic 13 (Embedded) |
| Kernel scheduler implementation | Deferred internal |
| Advanced scheduling algorithms (CFS, EDF, etc.) | Deferred internal |

---

### CH04 — Thread: Multiple Paths Inside One Process

| Field | Content |
| :--- | :--- |
| **Slug** | `threads` |
| **Order** | 4 |
| **Central Question** | Why does a Process need Threads to do many things at once? |
| **Central Mental Model** | A Process provides the shared execution environment; Threads provide independent execution paths inside that environment. |

**Scope — the learner discovers:**

```
PROCESS
│
├── Thread A (own execution context)
├── Thread B (own execution context)
└── Thread C (own execution context)
    │
    └── (all share: address space, resources)
```

Covered concepts: Process vs Thread; one Process → multiple Threads; shared address space; shared resources; Thread-specific execution context (stack, registers, PC); independent execution paths; why Threads exist as a lighter alternative to spawning multiple Processes.

**Explicit Non-Goals (CH04):**

| Concept | Reserved for |
| :--- | :--- |
| Race conditions | CH05 |
| Mutex, Locks, Semaphores | Topic 06 |
| Atomic operations | Topic 06 |
| Deadlock | Topic 06 |
| Memory ordering | Topic 06 |
| Thread synchronization | Topic 06 |

---

### CH05 — Multithreading: Many Threads, One Shared World

| Field | Content |
| :--- | :--- |
| **Slug** | `multithreading` |
| **Order** | 5 |
| **Central Question** | What happens when many Threads share the same data? |
| **Central Mental Model** | Multiple execution paths sharing mutable state create concurrency problems that do not appear in the same form with a single execution path. |

**Scope — the learner discovers:**

```
Thread A ──┐
           ├── Shared State
Thread B ──┘
      ↓
Interleaving
      ↓
Race Condition
      ↓
"We need coordination."
      ↓
TOPIC 06 — CONCURRENCY & PARALLELISM
```

Covered concepts: concurrency; interleaving; shared state; shared mutable state; race condition; why coordination is needed.

**Explicit Non-Goals (CH05):**

| Concept | Reserved for |
| :--- | :--- |
| Mutex implementation | Topic 06 |
| Lock implementation | Topic 06 |
| Semaphore | Topic 06 |
| Atomic operations / memory ordering | Topic 06 |
| Deadlock analysis | Topic 06 |
| Lock contention / concurrent performance | Topic 06 |

**CH05 is allowed to state the need for synchronization as its concluding mental model.** It must NOT teach the mechanism. The mechanism is Topic 06's discovery journey.

---

## 6. Canonical Causal Flow (Curriculum Backbone)

Topic 02 is one continuous causal chain across 5 chapters:

```
PROGRAM
   │
   │ launch
   ↓
PROCESS                           ← CH01
   │
   ├── Identity (PID)
   ├── Lifetime
   └── Multiple Processes
            │
            │ "How is this Process managed while running, pausing, and resuming?"
            ↓
PROCESS EXECUTION                 ← CH02
   │
   ├── Address Space (Code/Data/Heap/Stack)
   ├── Resources (Files/Handles)
   ├── Execution Context (PC/Registers)
   ├── States (Running/Ready/Waiting/Terminated)
   ├── Context Preservation
   └── Context Switch & Resume
            │
            │ "Multiple Processes are Ready — who gets the CPU next?"
            ↓
CPU SCHEDULING                    ← CH03
   │
   ├── Ready Queue
   ├── Scheduler
   ├── Scheduling Policy
   └── CPU Allocation
            │
            │ "A Process wants to do multiple things at once."
            ↓
THREAD                            ← CH04
   │
   ├── Multiple Execution Paths
   ├── Shared Address Space
   └── Independent Execution Contexts
            │
            │ "Multiple Threads touch the same shared data."
            ↓
MULTITHREADING                    ← CH05
   │
   ├── Interleaving
   ├── Shared Mutable State
   └── Race Condition
            │
            ↓
       "We need coordination."
            │
            ↓
        TOPIC 06 — CONCURRENCY & PARALLELISM
```

---

## 7. Critical Chapter Boundary Table

This table is mandatory. It enforces the critical boundaries in Topic 02.

| Boundary | CH01 owns | CH02 owns | CH03 owns |
| :--- | :--- | :--- | :--- |
| **What is a Process?** | Program → Process → Identity → Lifetime → Multiple Processes | — | — |
| **How does a Process execute over time?** | — | Address Space + Context + Running/Ready/Waiting states + Context Switch & Resume | — |
| **Who gets the CPU next?** | — | — | Ready Queue → Scheduler → Scheduling Policy (FCFS/RR/Time Slice) → CPU |

---

## 8. CH04 / CH05 Boundary

| CH04 boundary | CH05 boundary |
| :--- | :--- |
| Introduces Thread as an execution path inside Process | Introduces the shared-state problem |
| Shows that Threads share an address space | Shows that sharing causes interleaving |
| Shows that Threads have independent execution contexts | Shows that interleaving causes race conditions |
| Ends at: *"Threads are independent execution paths inside one Process"* | Ends at: *"We need a way to coordinate access to shared state"* |
| Does NOT show what breaks | Does NOT show how to fix it |

---

## 9. Topic 06 Boundary (Handoff Contract)

Topic 02 terminates at:

```
Multiple Threads
   ↓
Shared Mutable State
   ↓
Interleaving
   ↓
Race Condition
   ↓
"We need coordination."
```

Topic 06 (Concurrency & Parallelism) owns the full problem and solution space:

```
Concurrency vs Parallelism
        ↓
Shared Memory Problems (deep)
        ↓
Synchronization (Mutex / Lock / Semaphore)
        ↓
Contention / Deadlock
        ↓
Performance
```

**Topic 02 must NOT solve problems that Topic 06 is supposed to discover.**

---

## 10. Terminology Ownership

| Owned Term | Mechanical Meaning | Forbidden Analogy |
| :--- | :--- | :--- |
| `Program` | Static, stored sequence of instructions on disk. | "A running instance." |
| `Process` | Dynamic, OS-managed execution instance of a program. Owns identity, address space, resources, and execution context. | "The same as a program." |
| `PID` | Unique numeric identifier assigned by the OS to each Process at creation. | "A file name." |
| `Address Space` | The private virtual memory region the OS allocates to a Process (Code, Data, Heap, Stack). | "Physical RAM." |
| `Execution Context` | The saved state (registers, PC, stack pointer) that allows the OS to pause and resume a Process. | "A checkpoint file." |
| `Context Switch` | The OS operation of saving one Process's execution context and restoring another's, enabling time-multiplexing on the CPU. | "Rebooting the CPU." |
| `Ready Queue` | The OS data structure holding runnable Processes waiting for CPU time. | "A waiting room where all processes sleep." |
| `Scheduler` | The OS mechanism that applies a scheduling policy to select the next Process from the Ready Queue. | "Random process selection." |
| `Thread` | An independent execution path inside a Process, sharing the Process's address space and resources but maintaining its own execution context. | "A second process." |
| `Race Condition` | A bug that occurs when the outcome of a computation depends on the relative timing of concurrent operations on shared state. | "Just a concurrency bug." |
| `Interleaving` | The non-deterministic ordering of instruction sequences from multiple concurrent threads, as seen from the shared memory. | "Perfect alternation." |

---

## 11. Prerequisite & Follow-Up Relationships

| Relationship | Dependency |
| :--- | :--- |
| **Prerequisite for Topic 02** | Topic 01 — Computer Architecture (canonical execution model C-01…C-10; educational debt C-10 is resolved here) |
| **Topic 02 → Topic 05** | Memory Systems Ch03 (virtual memory / address space) builds on CH02's address space concept |
| **Topic 02 → Topic 06** | Concurrency & Parallelism resolves the synchronization problem introduced by CH05 |
| **Topic 02 → Topic 09** | Databases Ch03 (multi-writer correctness) builds on the thread/shared-state model |
| **Topic 02 → Topic 11** | Security Ch03 (process isolation / protection) builds on CH01/CH02's process identity model |
| **Topic 02 → Topic 13** | Embedded Systems Ch02 (deadline scheduling) extends CH03's scheduling mental model |

---

## 12. Five-Point Test (per `CURRICULUM_GUARDIAN_T01_FINAL.md` §6)

| Chapter | C-01…C-10 basis | Extension type | Debt facet resolved |
| :--- | :--- | :--- | :--- |
| CH01 — Process | C-09 (work enters system), C-10 (entry decided externally) | Extends C-09/C-10: the "work" is now a managed Process | The OS creates the execution unit |
| CH02 — Process Execution | C-02 (instruction journey), C-06 (idle stages are waste) | Extends: unit of work has environment + context; journey pauses/switches/resumes | How OS manages execution lifecycle & context |
| CH03 — CPU Scheduling | C-10 (entry gate) | Resolves C-10 directly: the Scheduler is the gate mechanism | Scheduling policy as the answer to C-10 |
| CH04 — Thread | C-09 (one system, work enters it) | Extends: multiple execution paths inside one Process | Lighter execution unit within a Process |
| CH05 — Multithreading | C-08 (performance = system property) | Extends: shared mutable state breaks correctness of system | Shared state problem; hands off to Topic 06 |

