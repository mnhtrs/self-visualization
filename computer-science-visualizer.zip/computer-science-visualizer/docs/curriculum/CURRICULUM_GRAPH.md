---
guiding_question: "What is the sequence, prerequisite structure, and continuity graph of lessons across the Cesvi curriculum?"
primary_consumer: "Authors, Curriculum Architects, AI Agents"
depends_on:
  - "docs/constitution/PHILOSOPHY.md"
referenced_by:
  - "docs/README_FOR_AI.md"
---

# Macro Curriculum Graph & Inter-Chapter Continuity Specification

**Supreme curriculum law:** [`CURRICULUM_CONSTITUTION.md`](CURRICULUM_CONSTITUTION.md) —
the frozen, scale-invariant contract every chapter must satisfy (canons C-01…C-10,
the single educational debt, extension doctrine, boundary rules, audit protocol).
This graph is its living operational layer.

**Status:** Active  
**Version:** 1.2.0  
**Authority:** Authoritative curriculum sequence, prerequisite dependency tree, and inter-chapter state continuity contracts.

---

## 1. Purpose

This document provides the canonical curriculum graph for the Cesvi ecosystem. It eliminates the need for downstream implementation agents to inspect prior chapter source code to infer state carry-over, entry conditions, or mock assets.

---

## 2. Global Chapter Sequence & Prerequisite Graph

```
[Ch-01: Program Execution] → [Ch-02: Browser Rendering] 
→ [Ch-03: Across the Internet] → [Ch-04: Inside the JavaScript Runtime] 
→ [Ch-05: OS Scheduling]
```

### 2.1 Topic 01 — Computer Architecture (intra-topic sequence)

Topic 01 is authored as its own progression inside the graph above. Its
chapter list is the authoritative one in `src/topics/definitions.ts`:

```
[T01/Ch-01: How does a program actually start running?]
→ [T01/Ch-02: How does the CPU avoid waiting for memory?]
→ [T01/Ch-03: How does a CPU cache determine whether a memory request becomes a Cache Hit or a Cache Miss?]
→ [T01/Ch-04: How does a CPU run billions of instructions per second?]
```

| Chapter | Core Mechanical Truth Taught | Prerequisite | Required Entry Mental Models |
| :--- | :--- | :--- | :--- |
| `T01/Ch-01` | Program loading, SSD → RAM, CPU/GPU overview, Basic Instruction Cycle | None | Basic intuition of input/output |
| `T01/Ch-02` | CPU–RAM speed gap; cache as a fast layer checked before RAM; Cache Hit / Cache Miss; why L1/L2/L3 exist | `T01/Ch-01` | The CPU executes instructions one at a time; RAM holds the program |
| `T01/Ch-03` | How one cache level decides: Cache Line, Set, Index→Set routing, Tag compare, Word Offset, Cache Lookup, Cache Line Loading, Replacement (FIFO, LRU), the three mappings | `T01/Ch-02` | A level answers "yes/no" and a full level displaces something — without ever showing how |
| `T01/Ch-04` | *(reserved)* Instruction-level throughput | `T01/Ch-03` | A hit is one lookup; a miss costs the RAM trip and possibly a replacement |

**Curriculum amendment (v1.2.0, owner directive).** The former `T01/Ch-02`
*"How does a CPU execute a single instruction?"* was **retired**. The Basic
Instruction Cycle is already established inside `T01/Ch-01`, so a dedicated
chapter would have repeated an existing mental model rather than transforming
one (`PEDAGOGICAL_SYSTEM` §3: a chapter completes exactly one transformation).
The memory-latency chapter took slot 02 and the remaining chapters shifted up.

**Curriculum amendment (v1.3.0, owner production specification).** Slot 03
stops being a placeholder: it opens exactly Chapter 02's declared Deferred
Internal ("how a level determines whether it holds a requested value, and what
it discards to make room"). The reserved *Instruction-level throughput* chapter
moves to slot 04 — it now *depends on* Ch-03 (a hit's cost model is assumed
known) instead of standing beside it.

#### 2.1.1 Contract: `T01/Ch-01` → `T01/Ch-02`

- **Upstream Exit State:** The program sits in RAM; the CPU has run it
  instruction by instruction through the Basic Instruction Cycle.
- **Contextual Carry-Over Payload:** `protagonist_entity`: golden execution
  spark; `cpu.color`: `#fb923c`; `ram.color`: `#a78bfa`. Both components are
  re-entered with their Chapter 01 identity intact.
- **Explicitly NOT repeated downstream:** program loading, SSD → RAM transfer,
  CPU overview, GPU overview, the Basic Instruction Cycle. SSD and GPU do not
  appear in `T01/Ch-02` at all.
- **Downstream Launchpad:** the learner holds *"the CPU checks the nearest level
  first, and a level either has the value or it does not."* How a level answers
  that question is a declared **Deferred Internal**, reserved for the chapter on
  cache internals.

#### 2.1.2 Contract: `T01/Ch-02` → `T01/Ch-03`

- **Upstream Exit State:** the memory ladder stands — CPU west, L1/L2/L3 rungs,
  RAM east; L1 answered instantly and displaced on overflow, never showing how.
- **Contextual Carry-Over Payload:** `protagonist_entity`: one memory request
  (golden spark, `cpu.color`: `#fb923c`, `cache.color`: `#22d3ee`,
  `ram.color`: `#a78bfa`); remembered values `◆ ▲ ■` still resident in L1/L2/L3;
  the ladder's axis, rung sizes and gaps re-entered unchanged (the camera simply
  *enters* the nearest level — no new world).
- **Explicitly NOT repeated downstream:** the speed-gap motivation, the two-run
  timing strip, the probe protocol (ask L1 → L2 → L3 → RAM). Ch-03 shows *how a
  level decides*, never re-argues *why levels exist*.
- **Downstream Launchpad:** a cache lookup is `Index → Set → Tag compare →
  (hit) word home | (miss) Cache Line Loading (+ Replacement on a full set)`.
  The cost contrast hit ≈ instant vs miss = RAM round trip is the entry
  assumption for Ch-04 (instruction-level throughput).

> **⚠️ Legacy global chapter table (stale — pre-topic restructure).** The rows below reflect an older single-sequence numbering system (`chapter-01` … `chapter-05`) that predates the topic-based restructure. They are preserved for historical reference only. **Do not use this table as an authoritative chapter list.** The authoritative chapter sequence is in `src/topics/definitions.ts`; the authoritative pedagogical specifications are in the per-topic Guardian documents (`CURRICULUM_GUARDIAN_T0n_*.md`).

| Chapter ID | Chapter Title | Core Mechanical Truth Taught | Prerequisite Chapters | Required Entry Mental Models |
| :--- | :--- | :--- | :--- | :--- |
| `chapter-01` | How Computers Execute Programs | CPU-RAM fetch-decode-execute loop & bus transfer | None | Basic intuition of input/output |
| `chapter-02` | How Browsers Render Websites | HTML/CSS parsing, DOM tree, layout, paint, GPU composite | `chapter-01` | CPU executes code; RAM holds bytes |
| `chapter-03` | How Data Travels Across the Internet | Packets, IP routing, NIC arrival, TCP reassembly | `chapter-01`, `chapter-02` | Browser requests a resource; bytes arrive through NIC/RAM |
| `chapter-04` | Inside the JavaScript Runtime | JavaScript Engine, Call Stack, Browser APIs, queues, Event Loop, rendering opportunity, async/await lifecycle | `chapter-01`, `chapter-02`, `chapter-03` | Complete HTML+JS file is in RAM; Browser is ready to run page script |
| `chapter-05` | How Operating Systems Schedule Tasks | Preemptive context switching, process control blocks, CPU queues | `chapter-01`, `chapter-04` | One JavaScript/runtime story still ultimately shares CPU time with other work |

---

### 2.2 Topic 02 — Processes & Threads (intra-topic sequence)

**Curriculum amendment (v0.4.0, owner directive 2026-08-15):** Topic 02 was redesigned from 6 chapters to the canonical 5-chapter Processes & Threads architecture. Legacy CH02 (*Inside a Process*) and legacy CH03 (*Running a Process*) were merged into new CH02 (*Process Execution: Pause, Switch, Resume*). Each chapter = one mental model transformation. Full specification: [`CURRICULUM_GUARDIAN_T02_DRAFT.md`](CURRICULUM_GUARDIAN_T02_DRAFT.md).

Topic 02 entry condition: the learner holds the canonical T01 execution model (C-01…C-10). In particular, Canon C-10 (*"entry into the system is decided by something outside the pipeline"*) is the official educational debt that Topic 02 resolves.

**Binding condition (from `CURRICULUM_GUARDIAN_T01_FINAL.md` §5):** T02/CH01 must NOT re-teach program loading. Begin from the T01 exit state.

```
[T02/CH01: Process: From Program to Managed Execution]
→ [T02/CH02: Process Execution: Pause, Switch, Resume]
→ [T02/CH03: CPU Scheduling: Who Runs Next?]
→ [T02/CH04: Thread: Multiple Paths Inside One Process]
→ [T02/CH05: Multithreading: Shared State & Race Conditions]
   → (handoff to Topic 06 — Concurrency & Parallelism)
```

| Chapter | Central Mental Model | Prerequisite | Required Entry Mental Model |
| :--- | :--- | :--- | :--- |
| `T02/CH01` | A Program is not a Process. A Process is a managed execution instance. | T01 complete | C-09 (work enters system), C-10 (entry gate — the debt) |
| `T02/CH02` | A Process has an execution environment and execution context; state changes in response to events; execution pauses, switches CPU, and resumes. | `T02/CH01` | The OS creates and identifies Processes |
| `T02/CH03` | CPU time is limited; the OS allocates it via a scheduling policy (resolves C-10 directly). | `T02/CH02` | Multiple Processes can be in the Ready state simultaneously |
| `T02/CH04` | A Process provides the shared environment; Threads provide independent execution paths inside it. | `T02/CH03` | The OS manages CPU access for Processes |
| `T02/CH05` | Multiple execution paths sharing mutable state create concurrency problems. | `T02/CH04` | Threads share an address space; their execution interleaves |

**Causal motivation between chapters:**

| Transition | Open Question that bridges chapters |
| :--- | :--- |
| CH01 → CH02 | A Process has identity and lifetime — but how is it managed as it runs, pauses, and resumes? |
| CH02 → CH03 | Multiple Processes can be Ready at the same time — who gets the CPU next? |
| CH03 → CH04 | Scheduling allocates CPU to Processes — but what if one Process needs to do many things at once? |
| CH04 → CH05 | Multiple Threads share the same address space — what happens when they touch the same data? |
| CH05 → Topic 06 | Race conditions require coordination — how do we safely coordinate access to shared state? |

**Topic 06 Handoff Boundary:**

Topic 02 ends at *"We need coordination."* Topic 06 (Concurrency & Parallelism) owns the full exploration of synchronization mechanisms (Mutex, Lock, Semaphore, Atomic, Deadlock, performance).

---

## 3. The Continuity Contract Protocol

Per `docs/pipeline/02_PRODUCTION_LIFECYCLE.md`, the entry state of Chapter N MUST align seamlessly with the exit state of Chapter N-1.

### Contract 1: `chapter-01` → `chapter-02`
- **Upstream Exit State:** The CPU finishes executing the program loader instruction sequence.
- **Contextual Carry-Over Payload:** `mock_domain`: `example.com`, `protagonist_entity`: Golden spark, `hardware_row`: `[CPU, RAM, GPU]`.

### Contract 2: `chapter-02` → `chapter-03`
- **Upstream Exit State:** The Browser has experienced a response arriving from the Server, but the road between Server and NIC was intentionally deferred as a black box.
- **Contextual Carry-Over Payload:** `mock_url`: `https://best-cats.example`, `mock_domain`: `best-cats.example`, `mock_ip`: `93.184.216.34`, `data_payload`: HTML byte stream.

### Contract 3: `chapter-03` → `chapter-04`
- **Upstream Exit State:** TCP reassembles the complete HTML file and the whole file settles into RAM, ready for the Browser Engine.
- **Contextual Carry-Over Payload:** `data_payload`: complete HTML + JavaScript bytes in RAM, `runtime_row`: `[Browser Runtime, JavaScript Engine, Browser APIs, Event Loop]`.

### Contract 4: `chapter-04` → `chapter-05`
- **Upstream Exit State:** The JavaScript Runtime model is established: one JavaScript engine turn runs at a time, while the Browser and system around it schedule other work.
- **Contextual Carry-Over Payload:** `active_process`: `browser-engine` (PID 4096), `active_runtime`: `JavaScript Runtime`.

---

## 3.1 Learner State Reconstruction & Cognitive Replay Protocol

Every chapter contract MUST specify the exact **Learner State Reconstruction** payload and **Cognitive Replay Trigger** required by `docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md` §2.1 & `PEDAGOGICAL_SYSTEM.md` §4.8:

1. **Active Mental Model:** The exact proposition(s) from upstream exit states that the learner holds as true.
2. **Resident Visual Metaphors:** Colors, component layouts, and protagonist identities that must remain stable.
3. **Misconception Inventory & Un-cleared Debt:** Active misconceptions and unresolved educational debt facets (e.g. Debt D0).
4. **Cognitive Replay Trigger:** The specific prior mechanism tested or weaponized as a cognitive tool in scene entry (e.g. T01/Ch-04 pipeline floor re-entered as the execution engine being scheduled in T02/Ch-02).

---

## 3.4 Curriculum Constitution — the supreme contract

The [CESVI Curriculum Constitution](CURRICULUM_CONSTITUTION.md) (frozen
v1.0.0, 2026-08-01) elevates the Topic 01 canonical model into permanent
curriculum law: ten immutable canons (C-01…C-10), one educational debt
(D0) with a registered facet ledger, the extension doctrine
(extend/specialize/apply — replacement forbidden), terminology ownership,
boundary rules, the mandatory regression battery, and the curriculum audit
protocol. Every future chapter must carry the curriculum compliance header
(canons touched, extension classification, facet resolved, boundary table,
owned terms) and pass the curriculum gate between production phases 7 and 8.

## 3.5 Guardian Record — Topic 01 Canonical Model

Topic 01 is production-frozen and its canonical execution model is validated
by the Curriculum Guardian record
[`CURRICULUM_GUARDIAN_T01_FINAL.md`](CURRICULUM_GUARDIAN_T01_FINAL.md):
one program = a stream of instructions; every instruction takes the same
journey; cache is the data supplier of a continuous execution flow;
performance is a system property; many instructions occupy different stages
of one shared pipeline; there is exactly one execution system; work enters it
continuously; and something must decide which work enters when work competes
— the single official educational debt of Topic 01.

Every future chapter must pass the guardian's five-point test (§6 of the
record) and inherit the six binding conditions (§5), especially: TLB ≠ cache
(T05/3), no program-loading re-teach (T02/1), multi-core = permitted extension
of "one system" (T06/1), GPU = a second-kind system (T12/2), storage hierarchy
≠ cache (T08/3), and cache coherence as a standalone chapter.

## 4. Autonomous Agent Decision Protocol for Chapter Continuity

When initiating Chapter N:
1. Read the prerequisite graph in §2.
2. Retrieve the carry-over payload from the relevant §3 contract.
3. Inject that payload into the Journey Definition and Cognitive Planning artifacts.
