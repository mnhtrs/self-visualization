---
guiding_question: "What is the topic-level curriculum contract, boundary specification, and terminology ownership for Topic 03 — Network & Internet?"
primary_consumer: "Content Authors, Curriculum Architects, AI Agents"
authority_level: "Draft Specification / Non-Frozen Operational Contract"
depends_on:
  - "docs/curriculum/CURRICULUM_CONSTITUTION.md"
  - "docs/curriculum/CURRICULUM_GRAPH.md"
  - "docs/pipeline/CHAPTER_PRODUCTION_STANDARD.md"
referenced_by:
  - "docs/curriculum/CURRICULUM_GRAPH.md"
---

# Curriculum Guardian Specification: Topic 03 — Network & Internet

**Topic ID:** `topic-03-networking`  
**Status:** Draft Specification (Non-Frozen)  
**Version:** 0.1.0  
**Authority:** Derived topic-level operational specification extending [`CURRICULUM_CONSTITUTION.md`](CURRICULUM_CONSTITUTION.md) and anchored directly to [`CURRICULUM_GRAPH.md`](CURRICULUM_GRAPH.md) §2 & §3 (Contracts 2 & 3).

---

## 1. Governance & Deference Header

* **Supreme Curriculum Law:** [`CURRICULUM_CONSTITUTION.md`](CURRICULUM_CONSTITUTION.md) (Canons C-01…C-10)
* **Macro Curriculum Graph Baseline:** [`CURRICULUM_GRAPH.md`](CURRICULUM_GRAPH.md) §2 & §3 (Contracts 2 & 3)
* **Deference Rule:** This specification operationalizes Topic 03 boundaries. It cannot override supreme curriculum laws or modify frozen inter-chapter continuity contracts.

---

## 2. Topic Mission & Macro Continuity

* **Topic Mission:** Transform the learner's mental model from *"data instantly travels through a magic Internet cloud"* to *"data is split into IP packets, routed hop-by-hop across physical routers, received at the Network Interface Card (NIC), and reassembled in sequential TCP order into RAM."*
* **Upstream Entry Anchor (`CURRICULUM_GRAPH.md` Contract 2):**
  * **Upstream Exit:** Browser Engine requests a web resource; the road between Server and NIC is opened (`chapter-02` carry-over payload).
  * **Carry-Over Payload:** `mock_url`: `https://best-cats.example`, `mock_domain`: `best-cats.example`, `mock_ip`: `93.184.216.34`, `data_payload`: HTML byte stream.
* **Downstream Exit Anchor (`CURRICULUM_GRAPH.md` Contract 3):**
  * **Downstream Handoff:** TCP reassembles the complete HTML file and the whole file settles into RAM, ready for the Browser Engine to execute JS / construct DOM.
  * **Carry-Over Payload:** `data_payload`: complete HTML + JS bytes in RAM; `runtime_row`: `[Browser Runtime, JS Engine, Browser APIs, Event Loop]`.

---

## 3. Step 0 Learner State Baseline

1. **Active Mental Model:** The Browser renders HTML/CSS files from RAM (`chapter-02`), but how those bytes got from the remote server into RAM was a black box.
2. **Resident Visual Metaphors:** `Client.color`: `#fb923c`, `NIC.color`: `#38bdf8`, `Server.color`: `#a78bfa`.
3. **Misconception Inventory:** *"The Internet is a single wire connecting my computer directly to website servers."*
4. **Cognitive Replay Trigger:** Re-enter the Browser request state established at the end of `chapter-02`.

---

## 4. Topic Conceptual Boundaries

Anchored to `CURRICULUM_GRAPH.md` §2 table:

* **Owned Concepts (Topic 03 Ownership):**
  * Data payload fragmentation into packets.
  * IP Packet header encapsulation (Source IP, Destination IP, Sequence number).
  * Hop-by-hop router forwarding decisions.
  * Arrival at the physical Network Interface Card (NIC).
  * TCP buffer reassembly (handling out-of-order packets & retransmission).
  * Settling reassembled byte streams into RAM.
* **Assumed Concepts (Upstream Carry-Over):**
  * CPU/RAM execution model (`chapter-01`).
  * Browser Engine resource request state (`chapter-02`).
* **Deferred Concepts (Reserved for Downstream Topics):**
  * Advanced TLS/SSL cryptographic handshakes (*Deferred Internal*).
  * BGP Autonomous System inter-domain routing protocols (*Deferred Internal*).
* **Explicitly Excluded Concepts (Forbidden Overlap):**
  * DOM tree parsing & CSSOM layout derivation (owned by Topic 02 / `chapter-02`).
  * JS Event Loop, Call Stack execution (owned by Topic 04 / `chapter-04`).
  * CPU instruction cache tag/index mapping (owned by Topic 01 / `T01/Ch-03`).
* **Terminal Boundary:** Complete TCP-reassembled byte stream written into Client RAM.

---

## 5. Terminology Ownership

| Owned Term | Mechanical Meaning | Forbidden Analogy |
| :--- | :--- | :--- |
| `IP Packet` | Discrete unit of data formatted with source/destination header and payload. | "A continuous stream of light." |
| `Router Hop` | Forwarding a packet from one network interface to the next based on IP routing table. | "Direct wire connection." |
| `NIC` | Hardware interface receiving physical signals and writing packets to system memory. | "A software folder." |
| `TCP Reassembly` | Reordering arrived out-of-order packets by sequence number into a contiguous byte stream. | "Magically merging files." |

---

## 6. Chapter Breakdown & Allocation

Per `CURRICULUM_GRAPH.md` §2:

* **`chapter-03` (How Data Travels Across the Internet):**
  * **Target Transformation:** From server HTTP response bytes to physical packet routing, NIC arrival, and TCP RAM reassembly.
  * **Core Arc:** HTTP Payload → Packet Encapsulation → Router Hops → NIC Buffer → TCP Reassembly → RAM.
