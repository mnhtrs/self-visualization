---
guiding_question: "Does every future curriculum topic grow from the Topic 01 canonical execution model without requiring learners to unlearn anything?"
primary_consumer: "Curriculum Architects, Chapter Authors, AI Agents"
depends_on:
  - "docs/curriculum/CURRICULUM_GRAPH.md"
  - "docs/chapters/topic-01-ch-04-instruction-throughput/00_JOURNEY_DEFINITION.md"
referenced_by:
  - "docs/state/PROJECT_STATE.md"
---

# Curriculum Guardian Record — Topic 01 Final Validation

**Status:** Active (guardian verdict: PASS)
**Version:** 1.0.0
**Date:** 2026-08-01
**Scope:** Topic 01 (Computer Architecture) is production-frozen. This record verifies that every future chapter in the roadmap (`src/topics/definitions.ts` — 14 topics, 40 remaining chapters) grows from the Topic 01 canonical mental model without requiring unlearning. No visual / narration / implementation criteria are evaluated here — educational continuity only.

---

## 1 · Canonical Mental Model (immutable curriculum canon)

After Topic 01 every learner must permanently understand:

| # | Proposition | Evidence in T01/Ch-04 |
| :--- | :--- | :--- |
| 1 | A program is a stream of instructions. | One program list, 50 rows, issuing exactly one instruction per tick. |
| 2 | Every instruction still follows the same execution journey. | Golden row 6: enters tick 1 → completes tick 5; golden row 19: enters tick 14 → completes tick 18 — the same 5-tick journey, measured twice. |
| 3 | Cache exists because continuous execution requires continuous data supply. | The Memory station is a mandatory stage of every instruction; LOAD/STORE trips run to the L1 dock every tick. |
| 4 | CPU performance is a property of the entire execution system, not of individual instructions. | A single completion counter (5 → 6 → 31 → forever) is the only performance instrument. |
| 5 | Pipelines do NOT make instructions individually faster. | Both golden journeys = 5 ticks. |
| 6 | Pipelines prevent execution resources from sitting idle. | b8: one card, four empty stations → b10: floor full, one completion per tick. |
| 7 | Many different instructions continuously occupy different stages of one shared pipeline. | 0 ticks (of 0–40) ever hold two cards in the same station; one shared Execute station. |
| 8 | There is only one execution system. | One CPU, one core, one program list, one cache ladder. |
| 9 | Work continuously enters that execution system. | The stream head feeds Fetch one instruction per tick, never stopping (horizon loop). |
| 10 | Something must eventually determine which work enters next whenever multiple pieces of work compete. | The issuing mechanism is never examined — this is the designed debt. |

Nothing later may contradict these propositions. Later topics may only **extend** them.

## 2 · The Official Educational Debt (single)

> **"What determines which work enters this continuously-running execution system, and what happens when multiple pieces of work compete for it?"**
> (VI: *"Cái gì quyết định công việc nào đi vào hệ thống thực thi đang chạy liên tục này, và điều gì xảy ra khi nhiều công việc tranh giành nó?"*)

Every future architecture, operating-system, scheduling, concurrency and performance chapter must trace back to exactly one facet of this question. Unrelated debt is forbidden.

## 3 · Roadmap Audit (14 topics / 40 chapters)

| Topic | Relation to the canonical model | Debt facet resolved | Verdict |
| :--- | :--- | :--- | :--- |
| T02 OS (4ch) | #9–10 (work enters; who decides); #6 (machine never stops) | 02-2 context switching · 02-3 scheduling (the classic debt-solver) · 02-4 shared-data contention | PASS (02-1 boundary: start from T01 exit state; do NOT re-teach program loading) |
| T03 Networking (6ch) | Parallel domain — uses T01 events (bytes in RAM, CPU processing) as infrastructure; not a debt-solver (correct per contract) | — | PASS |
| T04 Web Browser (4ch) | Runs *on* the machine = "a program"; the debt reappears as browser + page JS | — | PASS |
| T05 Memory Systems (4ch) | #2 + hierarchy; many programs in one machine (#7/#10) | 05-3 = memory facet of the debt (address-space contention) | PASS (05-3 boundary: TLB ≠ cache — see §5) |
| T06 Concurrency & Parallelism (4ch) | #7 (many instructions in one pipeline), #8 (one system) | 06-2/3/4 = synchronization facet of the debt | PASS (06-1 boundary: multi-core is a permitted extension of #8, never a denial) |
| T07 Compilers (3ch) | #1/#2 (machine runs instructions); #4/#5/#6 (performance = system property) | 07-2 = performance facet | PASS |
| T08 Storage (3ch) | Parallel domain | — | PASS (08-3 boundary: storage hierarchy must not redefine cache) |
| T09 Databases (3ch) | ch3 builds on T06 synchronization (indirect trace to the debt) | — | PASS |
| T10 Distributed (3ch) | Builds on T06 (many systems) + networking | — | PASS |
| T11 Security (3ch) | ch3 builds on T02 + T05/3 protection | — | PASS |
| T12 Graphics (2ch) | ch1: CPU math (canon #1/#2); ch2 GPU: a *different kind* of execution system — must not deny the CPU pipeline | — | PASS (12-2 boundary) |
| T13 Embedded (2ch) | ch1: small machine = exactly one execution system (canon intact); ch2: scheduling facet (deadlines) on T02/3 | 13-2 = deadline scheduling facet | PASS |
| T14 IoT (2ch) | Builds on networking + embedded | — | PASS |
| T15 AI (3ch) | ch3 builds on OS / distributed / performance (indirect) | — | PASS |

**Planned-growth gap (not a Ch-04 defect):** pipeline hazards, branch prediction, superscalar, out-of-order, and cache coherence have no home in the current roadmap. When planned, each must pass the five-point chapter test (§6). Cache coherence must remain a standalone hardware-facet chapter — it must NOT be merged into T06/2 (software races), or the chapter would carry two debts.

## 4 · Hard Rejection Rules — results

| Rule | Result |
| :--- | :--- |
| Reteaches Topic 01 | No chapter violates. Boundaries guarded: T02/1 (no program-loading re-teach), T05/3 (no lookup re-teach), T06/1 (no pipeline re-teach). Ch-04 leaves reusable imagery (the 5-station floor, the counter, the ladder). |
| Replaces the pipeline model | None. All extensions add a second system (GPU, multi-core) or a decision layer (OS, scheduler). |
| Redefines cache | One conditional risk: T05/3 virtual memory. Textbooks call the TLB "a cache of address translations". If T05/3 does this, it violates canon #3 — the TLB is a *translation lookup*, a declared Deferred Internal since T01/Ch-03, not the data-supply cache. Binding condition below. |
| Future terminology before its own topic | Pass. "parallel" is banned from T01 (scope gate); threads/processes/schedulers never appear in T01. |
| More than one educational debt | Pass at design level; each chapter resolves exactly one facet. Only coherence needs a standalone slot (§3). |
| Requires unlearning | None. The strongest reverse test — T06/1 must say "until now there was only ONE system" and then extend — is the growth the contract itself lists ("multi-core → multiple execution systems instead of one"). |
| Cannot explain growth from T01 | No chapter falls into this class. |

## 5 · Binding Conditions for Future Chapters (watch-list)

These conditions are constraints to be inherited into each future chapter's `00_JOURNEY_DEFINITION.md` when it enters production:

1. **T05/3 — TLB ≠ cache.** The TLB must be introduced as an address-translation lookup serving a different purpose; calling it "a cache" (or drawing it as one) is a canon-#3 violation → reject.
2. **T02/1 — no program-loading re-teach.** Begin from the T01 exit state (program already in RAM, CPU already executing it).
3. **T06/1 — multi-core is a permitted extension of canon #8** ("one system" → "many systems"), never a denial of the CPU pipeline.
4. **T12/2 — GPU is a second, different-kind execution system;** it must not replace or contradict the CPU pipeline model.
5. **T08/3 — storage hierarchy ≠ redefinition of cache;** storage is a deeper layer, not the data-supply cache of the execution flow.
6. **Cache coherence — standalone hardware-facet chapter** (multiple systems, each with its own data supplier, kept consistent); must not be merged into T06/2.

## 6 · The Five-Point Test (mandatory for every future chapter)

1. Which exact part of the Topic 01 model does it build upon?
2. Does it extend the existing model, or silently replace it? (Replacement is forbidden.)
3. Does the learner need to forget anything learned in Topic 01? (If yes → fail.)
4. Which single facet of the official educational debt does it resolve? (If none → probably redundant.)
5. Can it be understood without re-explaining instruction cycle, memory hierarchy, cache lookup, or pipeline? (If not → broken prerequisite chain.)

## 7 · Verdict

**PASS — educational continuity confirmed, subject to the six binding conditions of §5.**

- The official debt is one and only one; every execution-family chapter in the current roadmap traces to a concrete facet of it (T02/2–4, T05/3, T06/2–4, T07/2, T13/2 are direct debt-solvers; the rest extend the canon without touching the debt).
- No chapter requires learners to forget anything from Topic 01.
- No chapter in the current roadmap immediately violates the hard rejection rules; the two watch items (TLB in T05/3; coherence without a home) are future-chapter responsibilities, not grounds to reopen Ch-04.
- The planned-growth gap (hazards, branch prediction, superscalar, OoO, coherence) is a roadmap task, not a Ch-04 defect.

**T01/Ch-04 remains frozen.** The Topic 01 canon is a valid foundation for all 40 remaining chapters; continuity enforcement now passes to the §5 conditions, which must be carried into each future chapter's journey definition.
